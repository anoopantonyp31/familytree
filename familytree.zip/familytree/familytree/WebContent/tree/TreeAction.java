package com.dory.tree;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.aboutme.AboutDAO;
import com.dory.aboutme.AboutDAOImpl;
import com.dory.addparents.AddfamilyBean;
import com.dory.contact.ContactsBean;
import com.dory.contact.ContactsDAO;
import com.dory.contact.ContactsDAOImpl;
import com.dory.favourites.FavouritesBean;
import com.dory.favourites.FavouritesDAO;
import com.dory.favourites.FavouritesDAOImpl;
import com.dory.hibernate.HibernateUtil;
import com.dory.login.LoginBean;
import com.dory.login.LoginDAO;
import com.dory.login.LoginDAOImpl;
import com.dory.memberprofile.ProfileBean;
import com.dory.addparents.AddhouseBean;
import com.dory.memberprofile.ProfileDAO;
import com.dory.memberprofile.ProfileDAOImpl;
import com.dory.personal.PersonalBean;
import com.dory.personal.PersonalDAO;
import com.dory.personal.PersonalDAOImpl;
public class TreeAction extends Action {

    

	public ActionForward execute(ActionMapping mapping, ActionForm form,
	    HttpServletRequest request, HttpServletResponse response)
	    throws IOException, ServletException {
	String target = "failure";
	System.out.println("Inside actionnnnnnnnnnnnnnn=====>");
	String add = request.getParameter("addmember");
	String view = request.getParameter("viewmembers");
	String hide = request.getParameter("action");
	String actionsex = request.getParameter("sex");
    //Upesh*******************************************************************
	
	String action = request.getParameter("actionforname");
	
    //Upesh*******************************************************************
	String combo = request.getParameter("combo");
	System.out.println("Value of add=====>" + add);
	System.out.println("Value of view=====>" + view);
	System.out.println("Value of combo=====>" + combo);
	System.out.println("Value of sex=====>" + actionsex);
	Collection members = new ArrayList();
	Collection spouse = new ArrayList();
	Collection siblng = new ArrayList();

	try {
	    if (form != null) {

		Session session = HibernateUtil.getSessionFactory()
			.openSession();
		System.out.println("hoooooooooooooooooooooooooooo=====>");
		HttpSession httpsession = request.getSession();
		TreeForm treeForm = (TreeForm) form;
		TreeDAO treedao = new TreeDAOImpl();

		FamilyBean familyBean = new FamilyBean();
		RelationsBean relationBean = new RelationsBean();
		Relation2Bean relation2Bean = new Relation2Bean();
		RelationdetailBean reldetailBean = new RelationdetailBean();
		AddfamilyBean addfamilyBean= new AddfamilyBean();
		ProfileBean profilebean = new ProfileBean();
		ProfileDAO profileDAO = new ProfileDAOImpl();
		LoginBean loginbean = new LoginBean();
		LoginDAO loginDAO = new LoginDAOImpl();

		int memid = 0;
		int memid1 = 0;
		int head=0;
		int familyid=0;
		
		
		 //Upesh*******************************************************************
		
		
	 		
		
		String famlid1 = (String) httpsession.getAttribute("famid")
		.toString();
	    int famlyid1 = Integer.parseInt(famlid1);

	 	String memberid = (String) httpsession.getAttribute("mid")
		.toString();
    	memid1  = Integer.parseInt(memberid);

    	String fid = request.getParameter("famid");
    	System.out.println("ACSTRING      FIIDIDIDIDIDIDID==========="+fid);
    	int familyid2 = Integer.parseInt(fid);
    	System.out.println("ACINTEGER      FIIDIDIDIDIDIDID==========="+familyid2);
    	
	    if(famlyid1==familyid2)
	    {
	    	familyid = famlyid1;
	        memid = memid1;
		System.out.println("Member id=====>" + memid);
	    	
	    }
	    else
	    {
	    	familyid = familyid2;
	    	head = treedao.findhead(session,familyid);
	    	memid  =head;
	    	
	    	
	    	
	    }

	    
	    
	    if ("familyname".equals(action))
	    {
	    	System.out.println("ACTION FAMILY NAMEMEMEMEMMEMEMEMEMMMMMM"+memid1);
	    	addfamilyBean = treedao.displayfamily1(session,addfamilyBean,memid1);		
	    	
	    	request.setAttribute("familyname", addfamilyBean);
	    	target="familyname";
	    	
	    	
	    }
	    
	    if ("familyadmin".equals(action))
	    {
	    
	    	System.out.println("ACinTEGER      FIIDIDIDIDIDIDID==========="+familyid);
	  
	    	HttpSession session7=request.getSession();
			session7.setAttribute("familyid111",familyid);
			addfamilyBean = treedao.displayfamilynameadmin(session, addfamilyBean, familyid);
	    	
	    	request.setAttribute("familyname", addfamilyBean);
	    	target="familyadmin";
	    	
	    	
	    }
	    
	    
	    //Upesh*******************************************************************

		if ("addchild".equals(add)) {
			
			
			
			 //Upesh*******************************************************************
			
		

			 //Upesh*******************************************************************
			

		    System.out.println("Inside childddddddd name: >>>>>>>>>"
			    + treeForm.getChildname());
		    profilebean.setName(treeForm.getChildname());
		    System.out.println("Inside childddddddd: >>>>>>>>>"
			    + profilebean.getName());
		    
		    profilebean.setBirthorder(treeForm.getBirthorder());
		    System.out.println("Inside childddddddd: >>>>>>>>>"
			    + profilebean.getBirthorder());
		    String sex = treeForm.getSex();
		    profilebean.setSex(sex);
		    System.out.println("Inside childddddddd: >>>>>>>>>"
			    + profilebean.getSex());
		    
		    Date fromdate=new SimpleDateFormat("dd-MM-yyyy").parse(treeForm.getDob());
		    System.out.println("date of birth========"+fromdate);
		    
		    //*************************INSERTION INTO MEMBER PROFILE TABLE******************
		    profilebean.setDob(fromdate);
		    profilebean.setBasefamilyid(familyid);
		    String mother = treedao.getmother(session,treeForm.getMotherid());
		    String father = treedao.getfather(session,memid);
		    profilebean.setFathername(father);
		    profilebean.setMothername(mother);
		    int houseid = treedao.houseid(session, memid);      //TO RETRIEVE HOUSE ID OF THE MEMBER FROM PROFILE TABLE....
		    System.out.println("After retrieval houseid=====>"
				    + houseid);
		    profilebean.setHouseid(houseid);
		    System.out.println("Inside childddddddd: >>>>>basefamilyid>>>>" + profilebean.getBasefamilyid());
		    Serializable id = profileDAO.insert(session, profilebean);
		    int idd = (Integer) id;
		    System.out.println("Member id: >>>>>>>>>" + idd);
		    //******************************************************************************

		    //*************************INSERTION INTO LOGIN TABLE***************************
		    loginbean.setUname(treeForm.getUname());
		    loginbean.setPass(treeForm.getPass());
		    loginbean.setMemberid(idd);
		    loginbean.setUsertype("user");
		    loginbean.setIsactive(1);
		    loginDAO.insert(session, loginbean);

		    //***************************************************************************
		    
		    //*************************INSERTION INTO MEMBER RELATION TABLE*************************
		    profilebean.setMemberid(idd);
		    relationBean.setProfile(profilebean);
		    relationBean.setMotherid(treeForm.getMotherid());
		    relationBean.setFatherid(memid);
		    relationBean.setRelationshipid(0);
		    familyBean = treedao.retrievefamid(session,familyid);             // TO RETRIEVE FAMILYID......
		    relationBean.setFamily(familyBean);
		    treedao.relationinsert(session, relationBean);

		    //***********************************************************************
		    
		    //*************************INSERTION INTO OTHER TABLES*************************
		    AboutBean aboutBean = new AboutBean();
		    AboutDAO aboutDAO = new AboutDAOImpl();
		    aboutBean.setMemberid(idd);
		    aboutBean.setVisibility("0");
		    aboutDAO.insert(session,aboutBean);
		    
		    ContactsBean contactBean = new ContactsBean();
		    ContactsDAO contactDAO = new ContactsDAOImpl();
		    System.out.println("HAHAHAHAHAHAHAHAHAHHAHAAHHAA");
		    profilebean = treedao.profile(session, idd);
		    contactBean.setProfile(profilebean);
		    contactBean.setVisibility("0");
		    contactDAO.insert(session, contactBean);
		    
		    FavouritesBean favourBean = new FavouritesBean();
		    FavouritesDAO favourDAO = new FavouritesDAOImpl();
		    favourBean.setMemberid(idd);
		    favourBean.setVisibility("0");
		    favourDAO.insert(session, favourBean);
		    
		    PersonalBean personBean= new PersonalBean();
		    PersonalDAO personDAO = new PersonalDAOImpl();
		    personBean.setMemberid(idd);
		    personBean.setVisibility("0");
		    personDAO.insert(session, personBean);

		    //***********************************************************************
		    //johnson
		    String r=(String)httpsession.getAttribute("mid").toString();
		       int q=Integer.parseInt(r);
	           System.out.println("rambooo"+q);
	           Collection member = treedao.displaymember(session,loginbean,q);
	           
			    for (Iterator iterator = member.iterator(); iterator.hasNext();) 
		    	  { 
			    	loginbean = (LoginBean) iterator.next();
		    	  }
			    
			    System.out.println("After iterater=====>"+loginbean.getUsertype());
			    String s=loginbean.getUsertype();
			    System.out.println("After iterater=====>"+s);
			    if(s.equals("user"))
			    {
			    	System.out.println("in the loop");
			    	addfamilyBean.setFamilyid(familyid);
			    	 Collection member1 = treedao.displaymember1(session,addfamilyBean,q);		    		    	 
			    	 if(member1.isEmpty())
			    	 {
			    		 System.out.println("in the loop isEmpty");
			    		 request.setAttribute("addchild","addchild");
			 		     request.setAttribute("addparant","addparant");
			 		     request.setAttribute("addpartner","addpartner");
			    	 }
			    	 request.setAttribute("addparant","addparant");
			    }
		    
		    
		    
		    
		    head = treedao.findhead(session,familyid);
			members = treedao.viewmembers(session, familyid,head);
		    System.out.println("After viewmember function=====>"
			    + members.size());
		    request.setAttribute("view", members);
			  //upesh********************************************************************
	           
	           
	           
	           System.out.println("upeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
			Collection admin = treedao.displaymember11(session,addfamilyBean,q);	
			System.out.println("upeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeadmin.size()==============="+admin.size());
			if(admin.size()>0)
			{
			    System.out.println("FAmily id in sideadmin.size() view Meeeeeeeeeeeeeeethodddddddddd=====>" + familyid);
				Collection family = treedao.displayfamily(session,q,familyid);
				System.out.println("upeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeefamily.size()==============="+family.size());
				if(family.size()>0)
				{
					System.out.println("upeeeeeeeeeeeeiiiifffffffffffffffffffffffffefamily.size()==============="+family.size());
					request.setAttribute("family", family);
					
				}
				
			}
			
			
			//upesh********************************************************************
		    
		    if(famlyid1==familyid)
		    {
		    target = "success";
		    }
		    else
		    {
		    	target = "familyadmin";
		    }
	
		    System.out
			    .println("Target after function call insertion in adddddd child relation=====>"
				    + target);
		}
		
		/*......*************************************...................
		 * ..............ADDITION OF PARTNER......................
		 * ..............BY R@VISH@NK@R............................
		 * .......***********************************.................
		 */

		if ("addpartner".equals(add)) {
			System.out.println("	into the ACTIOON FOR INSERTING THE PARTNERRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR=====>");
			

			int spoid = treeForm.getChildid();                 // Spouse id from form......
			int count=0;
			int famid=0;
			int houseid=0;
			
			 //Upesh*******************************************************************
			  int memberid1 = Integer.parseInt(request.getParameter("memberid"));//MEMBER ID OF THE PARTNER
			
			  int house = treeForm.getHousedetails(); 
			  System.out.println("HHHHHHHHOUUUUUUUSSSSSSSSSSEEE========"+house);
			  if(house==1)
			  {
				  houseid = treedao.houseid(session, memid);      //TO RETRIEVE HOUSE ID OF THE MEMBER FROM PROFILE TABLE....
			  }
			  else if(house==2)
			  {
				  AddhouseBean addhouseBean = new AddhouseBean();  
				  addhouseBean.setAddress(treeForm.getAddress());
				  addhouseBean.setCity(treeForm.getCity());
				  addhouseBean.setHousename(treeForm.getHousename());
				  addhouseBean.setStatus(treeForm.getStatus());
				  addhouseBean.setRemark(treeForm.getRemark());
				  Serializable iid=treedao.inserthouse(session,addhouseBean);
		          houseid=(Integer)iid;
				  
			  }
		
			
			
			    //Upesh*******************************************************************
			
			
			// *************************ADDITION INTO FAMILY TABLE***************************
			
		    count=treedao.countwife(session,spoid);
		    if(count>0){
		    	System.out.println("Inside more than one wife>>>>>>>>" + famid);
		    	familyBean = treedao.familyid(session,spoid);
		    	famid = familyBean.getFamilyid();
		    	
		    }
		    else{
		    	//**********************anoop*****************************
		    	System.out.println("from family form name==========="+treeForm.getFamilyname());
		    	System.out.println("from family form number==========="+treeForm.getFamilynumber());
                    familyBean.setFamilyname(treeForm.getFamilyname());
                    familyBean.setFamilyno(treeForm.getFamilynumber());
                  //**********************anoop*****************************
		    		//familyBean.setFamilyname("Gokulam");                 
				    familyBean.setFamilyadmin(spoid);
				    familyBean.setCreatedby(memid);
				    Serializable id1 = treedao.insertfamily(session, familyBean);
				    famid = (Integer) id1;
				    System.out.println("Member id: >>>>>>>>>" + famid);
				  
		    	
		    }
            //****************************************************************************
		    //********************INSERTION INTO MEMBER PROFILE TABLE*****************
		    System.out.println("AINSERT INTO THE MEMBER PROFILE PARTNERRERERERERERER=====>");
		    
            //Retrieval of house id and setting basefamilyid into bean..........
		    
		   
		    System.out.println("After retrieval houseid=====>"
				    + houseid);
		    profilebean.setHouseid(houseid);
		    profilebean.setBasefamilyid(famid);
		    
		    //.....................................................
		    
			System.out.println("Inside partner name: >>>>>>>>>"
			    + treeForm.getPartnername());
		    profilebean.setName(treeForm.getPartnername());
		    System.out.println("Inside partner: >>>>>>>>>"
			    + profilebean.getName());
		    ChecksexBean checksexBean = new ChecksexBean();
		    checksexBean = treedao.checksex(session,checksexBean,memberid1);
		    String sex = checksexBean.getSex();
		    if("f".equals(sex))
		    {
		    	profilebean.setSex("m");
		    	
		    }
		    else
		    {
		    	profilebean.setSex("f");
		    }
		    System.out.println("Inside partner: >>>>>>>>>"
			    + profilebean.getSex());
		    
		    
		    Date fromdate=new SimpleDateFormat("dd-MM-yyyy").parse(treeForm.getDob());
		    System.out.println("date of birth========"+fromdate);
		    profilebean.setDob(fromdate);
		   
		    Serializable id = profileDAO.insert(session, profilebean);
		    int idd = (Integer) id;
		    System.out.println("New partner id: >>>>>>>>>" + idd);
		    
		    System.out.println("AFTERRRRRR    INSERT INTO THE MEMBER PROFILE PARTNERRERERERERERER=====>");
		    //***************************************************************************
		    
		    //*************************ADDITION INTO LOGIN TABLE****************************

		    loginbean.setUname(treeForm.getUname());
		    System.out.println("Inside loginbean uname: >>>>>>>>>"
			    + loginbean.getUname());
		    loginbean.setPass(treeForm.getPass());
		    System.out.println("Inside loginbean password: >>>>>>>>>"
			    + loginbean.getPass());
		    loginbean.setMemberid(idd);
		    loginbean.setUsertype("user");	   
		    loginbean.setIsactive(1);
		    loginDAO.insert(session, loginbean);
		    
		    //****************************************************************************
		   
		    //**************************ADDITION INTO RELATION TABLE***********************
		    System.out.println("beforrrreeeeee    INSERT INTO THE RELATIIIOON PARTNERRERERERERERER=====>");
		    profilebean.setMemberid(idd);
		    relationBean.setProfile(profilebean);
		    relationBean.setMotherid(0);
		    relationBean.setFatherid(0);
		    relationBean.setSpouseid(spoid);
		    relationBean.setFamily(familyBean);
		    relationBean.setRelationshipid(0);
		    treedao.relationinsert(session, relationBean);
		    System.out.println("After relation insertion=====>");
		    System.out.println("AFTERRRRRR    INSERT INTO THE RELATIONNNNNNN PARTNERRERERERERERER=====>");
		    //****************************************************************************
		    //****************************************************************************
		    if(count==0){
		    	
		    	
		    		relation2Bean = treedao.retrievemember(session, idd);      //RETRIEVE FAMILYID OF FAMILY PARTNER
				    relation2Bean.setFamilyid(famid);
				    System.out.println("After retrieveing.......family id: "+relation2Bean.getFamilyid());
				    System.out.println("UPDATION STARTING IN ADD PARTNERRERERERERERERERRERER>>>>>>>>"); 
				    treedao.update(session, relation2Bean);                    // UPDATE FAMILY ID.......
				    System.out.println("UPDATION OVERRRRRRRRRRR IN ADDDDDD PARTNERRRRRRRRRRRRRR>>>>>>>>");    	
		    	
		    
		    }
		  //*************************INSERTION INTO OTHER TABLES*************************
		    AboutBean aboutBean = new AboutBean();
		    AboutDAO aboutDAO = new AboutDAOImpl();
		    aboutBean.setMemberid(idd);
		    aboutBean.setVisibility("0");
		    aboutDAO.insert(session,aboutBean);
		    
		    ContactsBean contactBean = new ContactsBean();
		    ContactsDAO contactDAO = new ContactsDAOImpl();
		    ProfileBean profileBean = treedao.profile(session, idd);
		    contactBean.setProfile(profileBean);
		    contactBean.setVisibility("0");
		    contactDAO.insert(session, contactBean);
		    
		    FavouritesBean favourBean = new FavouritesBean();
		    FavouritesDAO favourDAO = new FavouritesDAOImpl();
		    favourBean.setMemberid(idd);
		    favourBean.setVisibility("0");
		    favourDAO.insert(session, favourBean);
		    
		    PersonalBean personBean= new PersonalBean();
		    PersonalDAO personDAO = new PersonalDAOImpl();
		    personBean.setMemberid(idd);
		    personBean.setVisibility("0");
		    personBean.setMaritalstatus(1);
		    System.out.println("foooooooooooooooooooo"+spoid);
		    PersonalBean person1Bean = treedao.personaldet(session,spoid);
		    System.out.println("PersonalBean====marital status11111111111111111========"+person1Bean.getMaritalstatus());
		    person1Bean.setMaritalstatus(1);
		    personDAO.update(session, person1Bean);      //UPDATION OF THE SPOUSE PERSONAL DET
		    personDAO.insert(session, personBean);       //INSERTION OF THE NEW PARTNER PERSONAL DET

		    //***********************************************************************
		    
		    
		    
		  //johnson
		    String r=(String)httpsession.getAttribute("mid").toString();
		       int q=Integer.parseInt(r);
	           System.out.println("rambooo"+q);
	           Collection member = treedao.displaymember(session,loginbean,q);
	           
			    for (Iterator iterator = member.iterator(); iterator.hasNext();) 
		    	  { 
			    	loginbean = (LoginBean) iterator.next();
		    	  }
			    
			    System.out.println("After iterater=====>"+loginbean.getUsertype());
			    String s=loginbean.getUsertype();
			    System.out.println("After iterater=====>"+s);
			    if(s.equals("user"))
			    {
			    	System.out.println("in the loop");
			    	addfamilyBean.setFamilyid(familyid);
			    	 Collection member1 = treedao.displaymember1(session,addfamilyBean,q);		    		    	 
			    	 if(member1.isEmpty())
			    	 {
			    		 System.out.println("in the loop isEmpty");
			    		 request.setAttribute("addchild","addchild");
			 		     request.setAttribute("addparant","addparant");
			 		     request.setAttribute("addpartner","addpartner");
			    	 }
			    	 request.setAttribute("addparant","addparant");
			    }
		    
		   
		    head = treedao.findhead(session,familyid);
			members = treedao.viewmembers(session, familyid,head);
		    System.out.println("After viewmember function=====>"
			    + members.size());
		    request.setAttribute("view", members);
		    
		  //upesh********************************************************************
	           
	           
	           
	           System.out.println("upeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
			Collection admin = treedao.displaymember11(session,addfamilyBean,q);	
			System.out.println("upeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeadmin.size()==============="+admin.size());
			if(admin.size()>0)
			{
			    System.out.println("FAmily id in sideadmin.size() view Meeeeeeeeeeeeeeethodddddddddd=====>" + familyid);
				Collection family = treedao.displayfamily(session,q,familyid);
				System.out.println("upeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeefamily.size()==============="+family.size());
				if(family.size()>0)
				{
					System.out.println("upeeeeeeeeeeeeiiiifffffffffffffffffffffffffefamily.size()==============="+family.size());
					request.setAttribute("family", family);
					
				}
				
			}
			
			
			//upesh********************************************************************
		    
		    if(famlyid1==familyid)
		    {
		    target = "success";
		    }
		    else
		    {
		    	target = "familyadmin";
		    }
		    System.out
			    .println("Target after addddddd partnerrererrerrer insertion relation=====>"
				    + target);
		}

		if ("view".equals(view)) 
		{
			
	       String r=(String)httpsession.getAttribute("mid").toString();
	       int q=Integer.parseInt(r);
           System.out.println("rambooo"+q);
           
           
			//upesh********************************************************************
           
           
           
           System.out.println("upeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
		Collection admin = treedao.displaymember11(session,addfamilyBean,q);	
		System.out.println("upeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeadmin.size()==============="+admin.size());
		if(admin.size()>0)
		{
		    System.out.println("FAmily id in sideadmin.size() view Meeeeeeeeeeeeeeethodddddddddd=====>" + familyid);
			Collection family = treedao.displayfamily(session,q,familyid);
			System.out.println("upeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeefamily.size()==============="+family.size());
			if(family.size()>0)
			{
				System.out.println("upeeeeeeeeeeeeiiiifffffffffffffffffffffffffefamily.size()==============="+family.size());
				request.setAttribute("family", family);
				
			}
			
		}
		
		
		//upesh********************************************************************
           
           
           
           Collection member = treedao.displaymember(session,loginbean,q);
           
		    for (Iterator iterator = member.iterator(); iterator.hasNext();) 
	    	  { 
		    	loginbean = (LoginBean) iterator.next();
	    	  }
		    
		    System.out.println("After iterater=====>"+loginbean.getUsertype());
		    String s=loginbean.getUsertype();
		    System.out.println("After iterater=====>"+s);
		    if(s.equals("user"))
		    {
		    	System.out.println("in the loop");
		    	addfamilyBean.setFamilyid(familyid);
		    	System.out.println("in the loop fffffffffffffffffffffffffffffffffffffff========"+familyid);
		    	 Collection member1 = treedao.displaymember1(session,addfamilyBean,q);		    		    	 
		    	 if(member1.isEmpty())
		    	 {
		    		 System.out.println("in the loop isEmpty");
		    		 request.setAttribute("addchild","addchild");
		 		     request.setAttribute("addparant","addparant");
		 		     request.setAttribute("addpartner","addpartner");
		    	 }
		    	 request.setAttribute("addparant","addparant");
		    }
		   
		  //johnson end
		    
			head = treedao.findhead(session,familyid);
			members = treedao.viewmembers(session, familyid,head);
		    System.out.println("After viewmember function=====>"
			    + members.size());
		    request.setAttribute("view", members);
		    int val = 1;
		    request.setAttribute("val", val);	
		  //upesh********************************************************************
		    if(famlyid1==familyid)
		    {
		    target = "success";
		    }
		    else
		    {
		    	target="familyadminadd";
		    	
		    }
		    System.out.println("Target after function call in the viewwwwwwwwwwwwwwwwwwwwwwwwww=====>"
			    + target);
		  //upesh********************************************************************
		}

		if ("mother".equals(combo)) {
			//upesh********************************************************************

            	 head = treedao.findhead(session,familyid);
				 System.out.println("Target after function caid=====idiffffffffffffff of mother=====>"+familyid);
				 spouse = treedao.retrievespouse(session, head);
				 System.out.println("After viewmember function=====>"+ spouse.size());

			    request.setAttribute("spouse", spouse);

			    target = "mother";
			 
		
			    System.out.println("Target after function call=====>"
				    + target);
				 /*System.out.println("Target after function caid==nnooooootttttttt===iidelllssssssssseeeeeeee of mother=====>"+famlyid);
				    spouse = treedao.retrieveadminspouse(session,famlyid);
				    System.out.println("After viewmember function=====>"
					    + spouse.size());
				    request.setAttribute("spouse", spouse);
				    target = "mother";
				    System.out.println("Target after function call=====>"
					    + target); 
				 */
				 
			 
			//upesh********************************************************************
		}

		if ("partner".equals(combo)) {
			
			
			//upesh********************************************************************
			
			String famlid = request.getParameter("famid");
			    int famlyid = Integer.parseInt(famlid);
			    
			  
			
			 
		
			 	 
				 System.out.println("IN THE FAMILY ID NNNNNNNNNNOOOOOOOOOOTTTTTTTTEQUAL OF THE SIBLINGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG>");
				 siblng = treedao.retrieveadminsiblings(session,famlyid);
			        System.out.println("After viewmember function=====>"
				    + siblng.size());
			       request.setAttribute("siblng", siblng);

			    	   target="siblng";

			      System.out.println("Target after function call add parnerrrrrrrrrrrrr  	else CONDDDDDDITTTTOONNNNN=====>"
				    + target);
				 
				 
			 
		  //upesh********************************************************************
		}	
		
		
		
		if("hide".equals(hide))
		{
			request.setAttribute("change", "change");
			request.setAttribute("home", "home");
			target="home";
		}

	    }
	} catch (Exception e) {
	    System.out.println("Exception=====>" + e);
	}
	return (mapping.findForward(target));

    }

}