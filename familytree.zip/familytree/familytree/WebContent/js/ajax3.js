function createRequestObject(){

var req;

if(window.XMLHttpRequest){
//For Firefox, Safari, Opera
req = new XMLHttpRequest();
}
else if(window.ActiveXObject){
//For IE 5+
req = new ActiveXObject("Microsoft.XMLHTTP");
}
else{
//Error for an old browser
alert('Your browser is not IE 5 or higher, or Firefox or Safari or Opera');
}

return req;
}

//Make the XMLHttpRequest Object
var http = createRequestObject();
var divv;
function sendRequest(method, url,div){
//alert("cgn");
divv=div;
alert(divv);
if(method == 'get' || method == 'GET'){
http.open(method,url);

	http.onreadystatechange = handleResponse1;

http.send(null);
}
}

function handleResponse1(){
	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
					if(divv=='child'){
						document.getElementById("parents").style.display='none';
						document.getElementById("partner").style.display='none';
						document.getElementById("child").style.display='block';
						document.getElementById(divv).innerHTML = response;
					}
					if(divv=='partner'){
						document.getElementById("parents").style.display='none';
						document.getElementById("child").style.display='none';
						document.getElementById("partner").style.display='block';
						document.getElementById(divv).innerHTML = response;
					}
					if(divv=='parents'){
						alert(3333333);
						document.getElementById(divv).innerHTML = response;
					}	
				}
	}     
}

function handleResponse2(){
	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
						document.getElementById("aaa").innerHTML = response;
				}
	}     
}

function handleResponse3(){
	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
						document.getElementById("j").innerHTML = response;
				}
	}     
}

function handleResponse4(){
	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
						document.getElementById("a").innerHTML = response;
				}
	}     
}

function handleResponse5(){

	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
	alert(111);
						document.getElementById("ph").innerHTML = response;
				}
	}     
}
function handleResponse6(){

	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
						document.getElementById("vu").innerHTML = response;
				}
	}     
}

function handleResponse7(){

	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
						document.getElementById("p").innerHTML = response;
				}
	}     
}

function handleResponse8(){

	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
						document.getElementById("coh").innerHTML = response;
				}
	}     
}

function handleResponse9(){

	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
						document.getElementById("hou").innerHTML = response;
				}
	}     
}

function handleResponse10(){

	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
						document.getElementById("edu").innerHTML = response;
				}
	}     
}

function handleResponse11(){

	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
						document.getElementById("add").innerHTML = response;
				}
	}     
}
function handleResponse12(){

	if(http.readyState == 4 && http.status == 200){
	var response = http.responseText;
	if(response){
						document.getElementById("phf").innerHTML = response;
				}
	}     
}



function foldercreate()
{

var a=document.frm.folname.value;
if(a=="")
{
alert("no items selected");
}
else
{
 document.frm.submit();
}
}
