package com.dory.manageallusers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.searchmember.SearchmemberBean;

public class ManageusersDAOImpl {

	public Collection searchmember(Session session,ManageusersBean manageusersBean,String q) 
	{
			

		Collection memsearch = new ArrayList();
		try {
			List query = session.createQuery("from ManageusersBean ex where ex.membername like'%"+q+"%'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("serching results============ ");	
				manageusersBean = (ManageusersBean) it.next();
				memsearch.add(manageusersBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return memsearch;
	}
	
	
	public Collection searchallmember(Session session,ManageusersBean manageusersBean) 
	{
			

		Collection memsearch1 = new ArrayList();
		try {
			List query = session.createQuery("from ManageusersBean")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("serching results============ ");	
				manageusersBean = (ManageusersBean) it.next();
				memsearch1.add(manageusersBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return memsearch1;
	}
	
	
}
