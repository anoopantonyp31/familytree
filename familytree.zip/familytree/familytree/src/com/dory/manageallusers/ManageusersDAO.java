package com.dory.manageallusers;

public interface ManageusersDAO {

}
