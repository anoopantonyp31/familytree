package com.dory.manageallusers;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.superadminloginedit.SuperadminlogineditBean;
import com.dory.superadminloginedit.SuperadminlogineditDAOImpl;
import com.dory.superadminloginedit.SuperadminlogineditForm;

public class ManageusersAction extends Action {


	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//used to get the action value
					String k = request.getParameter("action");
					
				ManageusersForm manageusersForm = (ManageusersForm) form;
				ManageusersBean manageusersBean = new ManageusersBean();
                HttpSession httpsession = request.getSession();
                Session session = HibernateUtil.getSessionFactory()
				.openSession();
		       System.out.println("session======111111=====>" + session);
				//BeanUtils.copyProperties(aboutBean, aboutForm);
				
				/*aboutBean.setAchivements(aboutForm
						.getAchivements());
				aboutBean.setMyself(aboutForm.getMyself());
				aboutBean.setRemark(aboutForm.getRemark());*/
				System.out.println("inside action ");
				
				
				
				//to get the session from the login action
				//String r=(String)httpsession.getAttribute("mid").toString();
				// int q=Integer.parseInt(r);
	             //System.out.println("rambooo"+q);
	            // aboutBean.setMemberid(q);
	            
				
				ManageusersDAOImpl manageusersDAO = new ManageusersDAOImpl();
				
				//if value of action=insert then enters below statement
				//function to insert the data from aboutme.jsp into about_member tables 
				if ("search".equals(k)) 
				{
					
					String member=manageusersForm.getMembername();
					System.out.println("================inside search============");
						//String data=request.getParameter("data");
					
						Collection serchmem = manageusersDAO.searchmember(session,manageusersBean,member);
						System.out.println("session======222222222222=====>"+ serchmem.size());
						
						if (serchmem.size() > 0) 
						{
							System.out.println("session======333333333=====>"
									+ serchmem.size());
							request.setAttribute("searchmem", serchmem);
							target = "success";
						} 
						
					
						else if (serchmem.size()<= 0) 
						{
							String not="notpresent";
							request.setAttribute("notpresent", not);
							target = "success";
						}
						
				}	
				
				
				else if ("viewall".equals(k)) 
				{
					System.out.println("inside view=====>");

					Collection serchmem1 = manageusersDAO.searchallmember(session,manageusersBean);
					System.out.println("session======222222222222=====>"+ serchmem1.size());
					
					
					{
						System.out.println("session======333333333=====>"
								+ serchmem1.size());
						request.setAttribute("searchmem", serchmem1);
						target = "success";
					} 
								
						
				}
				
				
				else if("redirect".equals(k))
				{
					System.out.println("inside redirect");
					String userid= request.getParameter("userid");
					System.out.println("the value of user is>>>>>>"+userid);
					
					//HttpSession session4=request.getSession();
					//session4.setAttribute("uid2",userid);
				   // String usertype="user";
					//HttpSession session8=request.getSession();
					//session4.setAttribute("utype",usertype);
					// note:--- have to check for the user admin status and all, wrong direction ghange
					target="userhome";
				}
				
				
				
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}
}
