package com.dory.manageallusers;

public class ManageusersBean {


	 private String membername;
	 private String membernumber;
	 private String nickname;
	 private String birthplace;
	 private String fathername;
	 private String mothername;
	 private int memberid;
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getNickname() {
		return nickname;
	}
	public void setBirthplace(String birthplace) {
		this.birthplace = birthplace;
	}
	public String getBirthplace() {
		return birthplace;
	}
	public void setFathername(String fathername) {
		this.fathername = fathername;
	}
	public String getFathername() {
		return fathername;
	}
	public void setMothername(String mothername) {
		this.mothername = mothername;
	}
	public String getMothername() {
		return mothername;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setMembernumber(String membernumber) {
		this.membernumber = membernumber;
	}
	public String getMembernumber() {
		return membernumber;
	}
	
}
