package com.dory.contact;

import org.apache.struts.action.ActionForm;

public class ContactsForm extends ActionForm{

	private String mobileno;
	 private String landlineno;
	 private String emailid;
	 private String remark;
	 private int contactid;
	 
	 private int publicorprivate;
	 private int community;
	 private int groups;
	 private int family;
	 
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setLandlineno(String landlineno) {
		this.landlineno = landlineno;
	}
	public String getLandlineno() {
		return landlineno;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setContactid(int contactid) {
		this.contactid = contactid;
	}
	public int getContactid() {
		return contactid;
	}
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	public void setCommunity(int community) {
		this.community = community;
	}
	public int getCommunity() {
		return community;
	}
	public void setGroups(int groups) {
		this.groups = groups;
	}
	public int getGroups() {
		return groups;
	}
	public void setFamily(int family) {
		this.family = family;
	}
	public int getFamily() {
		return family;
	}
}
