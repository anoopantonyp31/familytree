package com.dory.contact;

import com.dory.memberprofile.ProfileBean;

public class ContactsBean {
	 private String mobileno;
	 private String landlineno;
	 private String emailid;
	 private String remark;
	 private String visibility;
	 private int contactid;
	 private int memberid;
	 
	 private String membername;
	 
	 private ProfileBean profile;
	 
	 public ContactsBean(){
			
		}
		
		public ContactsBean(String name,int mid){
			this.memberid=mid;
			this.membername=name;
		}
		public ContactsBean(String mob,int id,String land,String rem,String email){
			this.mobileno=mob;
			this.landlineno=land;
			this.emailid=email;
			this.remark=rem;
			this.contactid=id;
		}
		
	 
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setLandlineno(String landlineno) {
		this.landlineno = landlineno;
	}
	public String getLandlineno() {
		return landlineno;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setContactid(int contactid) {
		this.contactid = contactid;
	}
	public int getContactid() {
		return contactid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setProfile(ProfileBean profile) {
		this.profile = profile;
	}
	public ProfileBean getProfile() {
		return profile;
	}

	public void setMembername(String membername) {
		this.membername = membername;
	}

	public String getMembername() {
		return membername;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getVisibility() {
		return visibility;
	}

}
