package com.dory.contact;

import org.hibernate.Session;

import com.dory.memberprofile.ProfileBean;

public interface ContactsDAO {

	public boolean insert(Session session, ContactsBean contactsBean);
	public ProfileBean retrieve(Session session,int q);
	public ContactsBean display(Session session,int q);
	public boolean update(Session session, ContactsBean contactsBean);
}
