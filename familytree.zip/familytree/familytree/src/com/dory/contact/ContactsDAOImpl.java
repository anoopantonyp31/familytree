package com.dory.contact;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.dory.memberprofile.ProfileBean;

public class ContactsDAOImpl implements ContactsDAO {
	
	public boolean insert(Session session, ContactsBean contactsBean) {
		session.beginTransaction();
		session.save(contactsBean);
		session.getTransaction().commit();
		return true;

	}
	
	public ProfileBean retrieve(Session session,int q) {
        ProfileBean profileBean = new ProfileBean();
		Collection contactscol = new ArrayList();
		try {
			List query = session.createQuery("from ProfileBean ex where ex.memberid='"+q+"'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				profileBean = (ProfileBean) it.next();
				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return profileBean;
	}
	
	
	public ContactsBean display(Session session,int q) {
        //ProfileBean profileBean = new ProfileBean();
        ContactsBean contactsBean = new ContactsBean();
		Collection contactscol = new ArrayList();
		try {
			/*List query = session.createQuery("select ex from ContactsBean ex " +
					                         "join ex.profile pr " +
					                         "where pr.memberid='"+q+"'").list();
			*/
			Query qu = session.createQuery("select new ContactsBean(ex.mobileno,ex.contactid,ex.landlineno,ex.remark,ex.emailid) from ContactsBean ex " +
                    "join ex.profile pr " +
                    "where pr.memberid='"+q+"'");
			System.out.println("====queryyyy==11111111===> "+qu);
			//List query =qu.list(); 
			//System.out.println("====queryyyy==222222222===> "+query);
			//for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				contactsBean = (ContactsBean) qu.uniqueResult();
				
			
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return contactsBean;
	}

	
	public boolean update(Session session, ContactsBean contactsBean) {
		session.beginTransaction();
		session.update(contactsBean);
		session.getTransaction().commit();
		return true;

	}
	
	

}
