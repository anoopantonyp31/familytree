package com.dory.deletediscussionforum;
import org.apache.struts.action.ActionForm;
public class DeletediscussionforumForm extends ActionForm
{
private int forumid;
private String topic;
private int startby; 
private String posteddate;
private String discreption;
private String name;
private int discussiondet[];
public void setForumid(int forumid) {
	this.forumid = forumid;
}
public int getForumid() {
	return forumid;
}
public void setTopic(String topic) {
	this.topic = topic;
}
public String getTopic() {
	return topic;
}
public void setStartby(int startby) {
	this.startby = startby;
}
public int getStartby() {
	return startby;
}
public void setPosteddate(String posteddate) {
	this.posteddate = posteddate;
}
public String getPosteddate() {
	return posteddate;
}
public void setDiscreption(String discreption) {
	this.discreption = discreption;
}
public String getDiscreption() {
	return discreption;
}
public void setName(String name) {
	this.name = name;
}
public String getName() {
	return name;
}
public void setDiscussiondet(int discussiondet[]) {
	this.discussiondet = discussiondet;
}
public int[] getDiscussiondet() {
	return discussiondet;
}
}
