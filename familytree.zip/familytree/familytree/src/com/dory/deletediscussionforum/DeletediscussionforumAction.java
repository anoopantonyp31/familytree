package com.dory.deletediscussionforum;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.hibernate.Session;

import com.dory.confidential.ConfidentialForm;
import com.dory.confidential.ConfidentialdaoImpl;
import com.dory.confidential.ConfidentialmainBean;
import com.dory.hibernate.HibernateUtil;
public class DeletediscussionforumAction extends DispatchAction
{
	public ActionForward displaydiscussionforum(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException
	{
		//String target = new String("success");
		String target=null;
		try
		{
			
				if (form != null)
				{
					DeletediscussionforumForm deletediscussionforumForm = (DeletediscussionforumForm) form;
					DeletediscussionforumBean deletediscussionforumBean = new DeletediscussionforumBean(); 
				   BeanUtils.copyProperties(deletediscussionforumBean,deletediscussionforumForm);				  
				   Session session =HibernateUtil.getSessionFactory().openSession();
				   System.out.println("session======111111=====>"+session);
				   
				   DeletediscussionforumdaoImpl deletediscussionforumdaoImpl = new DeletediscussionforumdaoImpl();
				   Collection deletediscussion = deletediscussionforumdaoImpl.displayforum(session,deletediscussionforumBean);
				   
				   for(Iterator it=deletediscussion.iterator();it.hasNext();)
				   {
					   deletediscussionforumBean=(DeletediscussionforumBean)it.next();
					   System.out.println("getDiscreption........>>>>>>>>"+deletediscussionforumBean.getDiscreption());
					   System.out.println("getForumid...........>>>>>>>>"+deletediscussionforumBean.getForumid());
					   System.out.println("getPosteddate........>>>>>>>>"+deletediscussionforumBean.getPosteddate());
					   System.out.println("getStartby...........>>>>>>>>"+deletediscussionforumBean.getName());
					   System.out.println("Topic...........>>>>>>>>"+deletediscussionforumBean.getTopic());
				   }
				   request.setAttribute("deletediscussion", deletediscussion);
				   target="discussiondelete";
				}
				   
				
		}
		catch (Exception e)
		{
                 System.out.println("Exception=====>"+e);
                 target="failure";
		}
		
		return (mapping.findForward(target));
		
	}		

	public ActionForward deletediscussionforum(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = new String("success");
		try {
			
			if (form != null) 
			{

				DeletediscussionforumForm deletediscussionforumForm = (DeletediscussionforumForm) form;
				DeletediscussionforumBean deletediscussionforumBean = new DeletediscussionforumBean(); 
				BeanUtils.copyProperties(deletediscussionforumBean,deletediscussionforumForm);
				Session session = HibernateUtil.getSessionFactory().openSession();
				System.out.println("DELETE after session");
				 DeletediscussionforumdaoImpl deletediscussionforumdaoImpl = new DeletediscussionforumdaoImpl();
				int a[]=deletediscussionforumForm.getDiscussiondet();
				System.out.println("a====>"+a);
				for(int i=0;i<a.length;i++)
				{
					System.out.println("IN THE LOOP+++++++++++++++++++");
					deletediscussionforumBean.setForumid(a[i]);	
				    System.out.println("CHECKBOXID======================================================="+a[i]);
				    deletediscussionforumdaoImpl.delete(session,deletediscussionforumBean);
					
				}
				Collection deletediscussion = deletediscussionforumdaoImpl.displayforum(session,deletediscussionforumBean);
				request.setAttribute("deletediscussion", deletediscussion);
				target="discussiondelete";
			      }				


		}

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}

			return (mapping.findForward(target));
			}


}

