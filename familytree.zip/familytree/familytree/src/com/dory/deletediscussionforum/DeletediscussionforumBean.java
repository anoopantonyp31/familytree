package com.dory.deletediscussionforum;

public class DeletediscussionforumBean 
{
	private int forumid;
	private String topic;
	private int startby; 
	private String posteddate;
	private String discreption;
	private String name;
	public void setForumid(int forumid) {
		this.forumid = forumid;
	}
	public int getForumid() {
		return forumid;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getTopic() {
		return topic;
	}
	public void setStartby(int startby) {
		this.startby = startby;
	}
	public int getStartby() {
		return startby;
	}
	public void setPosteddate(String posteddate) {
		this.posteddate = posteddate;
	}
	public String getPosteddate() {
		return posteddate;
	}
	public void setDiscreption(String discreption) {
		this.discreption = discreption;
	}
	public String getDiscreption() {
		return discreption;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
}
