package com.dory.deletediscussionforum;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import com.dory.discussionforum.DiscussionreplyBean;
import com.dory.memberprofile.ProfileBean;
import org.hibernate.Session;
public class DeletediscussionforumdaoImpl 
{
public boolean delete(Session session,DeletediscussionforumBean deletediscussionforumBean)

	{
	DiscussionreplyBean discussionreplyBean= new DiscussionreplyBean();
	List query1 = session.createSQLQuery("select * from discussion_forum_reply ds where forumid="+deletediscussionforumBean.getForumid()+"").addEntity("ds",DiscussionreplyBean.class).list();
	
	for (Iterator it2 = query1.iterator(); it2.hasNext();) 
	{
		discussionreplyBean = (DiscussionreplyBean) it2.next();
		session.beginTransaction(); 
		session.delete(discussionreplyBean);
		session.getTransaction().commit();
	}
	session.beginTransaction();     
	session.delete(deletediscussionforumBean);
	session.getTransaction().commit();
	return true;
	}
	public Collection displayforum(Session session,DeletediscussionforumBean deletediscussionforumBean) 
	
	{
		ProfileBean profileBean= new ProfileBean();
		Collection deletediscussion=new ArrayList();
		try
		{
		List query = session.createSQLQuery("select * from discussion_forum ds ").addEntity("ds",DeletediscussionforumBean.class).list();
		System.out.println("displayclass====query========"+query);		
        for (Iterator it = query.iterator(); it.hasNext();) 
         {
			deletediscussionforumBean = (DeletediscussionforumBean) it.next();
			System.out.println("deletediscussionforumBean.getStartby"+deletediscussionforumBean.getStartby());
			int s=deletediscussionforumBean.getStartby();
			System.out.println("getStartby"+s);
			List query1 = session.createSQLQuery("select * from member_profile  ps where memberid='"+s+"' ").addEntity("ps",ProfileBean.class).list();
			System.out.println("displayclass====query========"+query);		
	        for (Iterator it1 = query1.iterator(); it1.hasNext();) 
	         {
				System.out.println("displayyear====Iterator========");
				profileBean = (ProfileBean) it1.next();
				deletediscussionforumBean.setName(profileBean.getName());
		     }
	        System.out.println("deletediscussionforumBean IMPL"+deletediscussionforumBean.getName());
	        deletediscussion.add(deletediscussionforumBean);
	     }
		}catch(Exception he){
			System.out.println("errorrrrrrrr"+he);
		}
		
		return deletediscussion;
	}
	
	

}