package com.dory.confidential;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
public class ConfidentialdaoImpl 
{
	public boolean insert(Session session,ConfidentialBean confidentialBean)
	{
		session.beginTransaction();     
		session.save(confidentialBean);
		session.getTransaction().commit();
		return true;
		
	}
	public boolean insert2(Session session,ConfidentialmainBean confidentialmainBean)
	{
		session.beginTransaction();     
		session.save(confidentialmainBean);
		session.getTransaction().commit();
		return true;
		
	}
	public boolean update(Session session, ConfidentialBean confidentialBean)
    {
	session.beginTransaction(); 
	session.update(confidentialBean);	
	session.getTransaction().commit();
	return true;
    }
	public boolean update2(Session session, ConfidentialmainBean confidentialmainBean)
    {
	session.beginTransaction(); 
	session.update(confidentialmainBean);	
	session.getTransaction().commit();
	return true;
    }
	public boolean delete(Session session,ConfidentialmainBean confidentialmainBean)
	
	{		
	session.beginTransaction();     
	session.delete(confidentialmainBean);
	session.getTransaction().commit();
	return true;
	}
	
	
	public Collection edit1(Session session, ConfidentialmainBean confidentialmainBean,int d)
	{
		
		
		Collection confidentpermenent=new ArrayList();
		List query = session.createSQLQuery("select * from confidential_datas ds where memberid="+d+"").addEntity("ds",ConfidentialmainBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
        {
			confidentialmainBean = (ConfidentialmainBean) it.next();
			  confidentpermenent.add(confidentialmainBean);
			  System.out.println("Confidentialid"+confidentialmainBean.getConfidentialid());
				System.out.println("Itemvalue"+confidentialmainBean.getItemvalue());
				System.out.println("Itemname"+confidentialmainBean.getItemname());
		}
    
      return confidentpermenent;
	}
	//edit
	public Collection edit(Session session,ConfidentialBean confidentialBean,int d)
	{
		
		
		Collection confident=new ArrayList();
		List query = session.createSQLQuery("select * from confidential_perminant_fields ds where memberid="+d+"").addEntity("ds",ConfidentialBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
        {
    	  confidentialBean = (ConfidentialBean) it.next();  
    	  confident.add(confidentialBean);
		}
      
      return confident;
	}
	

	public Collection editing(Session session, ConfidentialmainBean confidentialmainBean,int b)
	{
		
		
		Collection confidentpermenent=new ArrayList();
		List query = session.createSQLQuery("select * from confidential_datas ds where confidentialid="+b+"").addEntity("ds",ConfidentialmainBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
        {
			confidentialmainBean = (ConfidentialmainBean) it.next();
			  confidentpermenent.add(confidentialmainBean);
			  System.out.println("Confidentialid"+confidentialmainBean.getConfidentialid());
				System.out.println("Itemvalue"+confidentialmainBean.getItemvalue());
				System.out.println("Itemname"+confidentialmainBean.getItemname());
		}
    
      return confidentpermenent;
	}
	
	
}