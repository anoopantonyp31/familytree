package com.dory.confidential;

public class ConfidentialmainBean 
{
	 private String itemname;
	 private String itemvalue;
	 private String remark;
	 private int confidentialid;
	 private int memberid;
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemvalue(String itemvalue) {
		this.itemvalue = itemvalue;
	}
	public String getItemvalue() {
		return itemvalue;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setConfidentialid(int confidentialid) {
		this.confidentialid = confidentialid;
	}
	public int getConfidentialid() {
		return confidentialid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
}
