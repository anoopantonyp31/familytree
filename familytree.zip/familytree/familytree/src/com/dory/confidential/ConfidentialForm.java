package com.dory.confidential;
import org.apache.struts.action.ActionForm;
public class ConfidentialForm extends ActionForm
{
	//confidential  table
	private int confidentialperid;
	private String passportno;
	private String licenceno;
	private String bankaccountno;
	private String votersid;
	private String pancardno;
	private int memberid;
	private int confidentialid;
	//confidential main
	private int confidentdet[];
	public int[] getConfidentdet() {
		return confidentdet;
	}
	public void setConfidentdet(int[] confidentdet) {
		this.confidentdet = confidentdet;
	}
	private String itemname;
	 private String itemvalue;
	 private String remark;
	 
	
	public void setConfidentialperid(int confidentialperid) {
		this.confidentialperid = confidentialperid;
	}
	public int getConfidentialperid() {
		return confidentialperid;
	}
	public void setPassportno(String passportno) {
		this.passportno = passportno;
	}
	public String getPassportno() {
		return passportno;
	}
	public void setLicenceno(String licenceno) {
		this.licenceno = licenceno;
	}
	public String getLicenceno() {
		return licenceno;
	}
	public void setBankaccountno(String bankaccountno) {
		this.bankaccountno = bankaccountno;
	}
	public String getBankaccountno() {
		return bankaccountno;
	}
	public void setVotersid(String votersid) {
		this.votersid = votersid;
	}
	public String getVotersid() {
		return votersid;
	}
	public void setPancardno(String pancardno) {
		this.pancardno = pancardno;
	}
	public String getPancardno() {
		return pancardno;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemvalue(String itemvalue) {
		this.itemvalue = itemvalue;
	}
	public String getItemvalue() {
		return itemvalue;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() 
	{
		return remark;
	}
	public int getConfidentialid() 
	{
		return confidentialid;
	}
	public void setConfidentialid(int confidentialid) {
		this.confidentialid = confidentialid;
	}
	
	
}
