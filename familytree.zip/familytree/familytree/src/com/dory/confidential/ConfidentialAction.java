package com.dory.confidential;
import java.util.Collection;
import java.util.Iterator;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.hibernate.Session;
import com.dory.hibernate.HibernateUtil;
public class ConfidentialAction extends DispatchAction
{
	
	
	public ActionForward insert(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = new String("success");
		try {
			
			if (form != null) 
			{

				ConfidentialForm confidentialForm =(ConfidentialForm)form;
				ConfidentialBean confidentialBean= new ConfidentialBean();
				BeanUtils.copyProperties(confidentialBean,confidentialForm);	
				
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
				HttpSession httpsession = request.getSession();
				String r=(String)httpsession.getAttribute("mid").toString();
				 int d=Integer.parseInt(r);
				 confidentialBean.setMemberid(d);
		        System.out.println("session======111111=====>"+session);
		        
		        ConfidentialdaoImpl confidentialdaoImpl=new ConfidentialdaoImpl();

				{  	
					confidentialdaoImpl.insert(session,confidentialBean);
				}
				}
			target="editing";
}
		

		catch (Exception e) 
		{
			System.out.println("Exception=====>"+e);
		}

		return (mapping.findForward(target));
		}
	//insert2
	public ActionForward insert2(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = new String("success");
		try {
			
			if (form != null) 
			{

				ConfidentialForm confidentialForm =(ConfidentialForm)form;
				ConfidentialmainBean confidentialmainBean= new ConfidentialmainBean();
				BeanUtils.copyProperties(confidentialmainBean,confidentialForm);	
				
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
		        System.out.println("session======111111=====>"+session);
		        
		        ConfidentialdaoImpl confidentialdaoImpl=new ConfidentialdaoImpl();
		        HttpSession httpsession = request.getSession();
				String r=(String)httpsession.getAttribute("mid").toString();
				 int d=Integer.parseInt(r);
				 confidentialmainBean.setMemberid(d);

				{  	
					confidentialdaoImpl.insert2(session,confidentialmainBean);
				}
				target="editing";
				}
}
		

		catch (Exception e) 
		{
			System.out.println("Exception=====>"+e);
		}

		return (mapping.findForward(target));
		}
	
	//edit
	public ActionForward edit(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = new String("success");
		try {
			
			if (form != null) 
			{

				ConfidentialForm confidentialForm =(ConfidentialForm)form;
				ConfidentialBean confidentialBean= new ConfidentialBean();
				ConfidentialmainBean confidentialmainBean= new ConfidentialmainBean();
				
				BeanUtils.copyProperties(confidentialBean,confidentialForm);
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
				 HttpSession httpsession = request.getSession();
					String r=(String)httpsession.getAttribute("mid").toString();
					 int d=Integer.parseInt(r);
		             System.out.println("rambooo"+d);
				System.out.println("update after session");
				ConfidentialdaoImpl confidentialdaoImpl = new ConfidentialdaoImpl();
				
				    Collection confident = confidentialdaoImpl.edit(session,confidentialBean,d);
				    Collection confidentpermenent = confidentialdaoImpl.edit1(session,confidentialmainBean,d);
				    if(confident.isEmpty())
				    {
				    	 request.setAttribute("saveee", "saveee");					    	
				    	 request.setAttribute("newfield", "newfield");	
				    }
				    else 
				    {
					{
						System.out.println("in district.size>0=====>"+confident.size());
						
					    
					    for (Iterator iterator = confident.iterator(); iterator.hasNext();) 
				    	    { 
					    	confidentialBean = (ConfidentialBean) iterator.next();
				    		}
				    	
					    confidentialForm.setBankaccountno(confidentialBean.getBankaccountno());
					    confidentialForm.setConfidentialperid(confidentialBean.getConfidentialperid());
					    confidentialForm.setLicenceno(confidentialBean.getLicenceno());
					    confidentialForm.setPancardno(confidentialBean.getPancardno());
					    confidentialForm.setPassportno(confidentialBean.getPassportno());
					    confidentialForm.setVotersid(confidentialBean.getVotersid());
					    confidentialForm.setMemberid(confidentialBean.getMemberid());
					      }
					    for (Iterator iterator = confidentpermenent.iterator(); iterator.hasNext();) 
		    	          { 
						   confidentialmainBean = (ConfidentialmainBean) iterator.next();						  
		    		      }
					    confidentialForm.setConfidentialid(confidentialmainBean.getConfidentialid());
					    confidentialForm.setMemberid(confidentialmainBean.getMemberid());
					    confidentialForm.setItemname(confidentialmainBean.getItemname());
					    confidentialForm.setItemvalue(confidentialmainBean.getItemvalue());
					    confidentialForm.setRemark(confidentialmainBean.getRemark());
					    request.setAttribute("confidentpermenent", confidentpermenent);
						 request.setAttribute("newfield", "newfield");	
						 request.setAttribute("add", "add");
			             }
						if(confidentpermenent.isEmpty())
						{
							request.setAttribute("deleteb", "deleteb");
							request.setAttribute("editb", "editb");
						}
						   
							     
						   }
			
				           target="updateg";
		                }
		
		
		
		catch (Exception e) 
		{
			System.out.println("Exception=====>"+e);
		}

		return (mapping.findForward(target));
		}
	public ActionForward update(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = new String("success");
		try {
			
			if (form != null) 
			{

				ConfidentialForm confidentialForm =(ConfidentialForm)form;
				ConfidentialBean confidentialBean= new ConfidentialBean();
				//ConfidentialmainBean confidentialmainBean= new ConfidentialmainBean();				
				BeanUtils.copyProperties(confidentialBean,confidentialForm);
				//BeanUtils.copyProperties(confidentialmainBean,confidentialForm);
				ConfidentialdaoImpl confidentialdaoImpl = new ConfidentialdaoImpl();
				Session session = HibernateUtil.getSessionFactory().openSession();
				//from permenent table
				String s=request.getParameter("t");
				int id=Integer.parseInt(s);
				HttpSession httpsession = request.getSession();
				String r=(String)httpsession.getAttribute("mid").toString();
				 int d=Integer.parseInt(r);
				 confidentialBean.setMemberid(d);
				confidentialBean.setConfidentialperid(id);
				confidentialBean.setBankaccountno(confidentialForm.getBankaccountno());
				confidentialBean.setConfidentialperid(confidentialForm.getConfidentialperid());
				confidentialBean.setLicenceno(confidentialForm.getLicenceno());
				confidentialBean.setPancardno(confidentialForm.getPancardno());
				confidentialBean.setPassportno(confidentialForm.getPassportno());
				confidentialBean.setVotersid(confidentialForm.getVotersid());
				confidentialdaoImpl.update(session,confidentialBean);
	            }
			target="aaaaaaaaa";
		}

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}

			return (mapping.findForward(target));
			}
	
	
	public ActionForward edit1(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = new String("success");
		try {
			
			if (form != null) 
			{

				ConfidentialForm confidentialForm =(ConfidentialForm)form;
				ConfidentialmainBean confidentialmainBean= new ConfidentialmainBean();	
				BeanUtils.copyProperties(confidentialmainBean,confidentialForm);
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
				 HttpSession httpsession = request.getSession();
					String r=(String)httpsession.getAttribute("mid").toString();
					 int d=Integer.parseInt(r);
		             System.out.println("rambooo"+d);
				System.out.println("update after session");
				ConfidentialdaoImpl confidentialdaoImpl = new ConfidentialdaoImpl();
				int a[]=confidentialForm.getConfidentdet();
				System.out.println("a====>"+a);
				for(int i=0;i<a.length;i++)
				{
					System.out.println("IN THE LOOP+++++++++++++++++++");
				  
					/* delete district name */	
				    System.out.println("CHECKBOXID======================================================="+a[i]);
				    int b = a[i];
				    System.out.println("CHECKBOXID==============bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"+b);
				    
				    Collection confidentpermenent = confidentialdaoImpl.editing(session,confidentialmainBean,b);
					
					{
						System.out.println("in district.size>0=====>"+confidentpermenent.size());
						
					    
					    for (Iterator iterator = confidentpermenent.iterator(); iterator.hasNext();) 
				    	    { 
					    	confidentialmainBean = (ConfidentialmainBean) iterator.next();
				    		}
				    	
					    confidentialForm.setConfidentialid(confidentialmainBean.getConfidentialid());				   
					    confidentialForm.setItemname(confidentialmainBean.getItemname());
					    confidentialForm.setItemvalue(confidentialmainBean.getItemvalue());	
					    confidentialForm.setMemberid(confidentialmainBean.getMemberid());	
					    confidentialForm.setRemark(confidentialmainBean.getRemark());	
					       }
					 request.setAttribute("edit", "edit");
					 request.setAttribute("new", "new");
					 request.setAttribute("add", "add");
					target="editmain";
					
				}
				}     
			}

				catch (Exception e) 
				{
					System.out.println("Exception=====>"+e);
				}

				return (mapping.findForward(target));
				}
	
	public ActionForward update2(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = new String("success");
		try {
			
			if (form != null) 
			{

				ConfidentialForm confidentialForm =(ConfidentialForm)form;
				ConfidentialmainBean confidentialmainBean= new ConfidentialmainBean();	
				BeanUtils.copyProperties(confidentialmainBean,confidentialForm);
				ConfidentialdaoImpl confidentialdaoImpl = new ConfidentialdaoImpl();
				Session session = HibernateUtil.getSessionFactory().openSession();
				String s=request.getParameter("t");
				int id=Integer.parseInt(s);
				confidentialmainBean.setConfidentialid(id);	
				HttpSession httpsession = request.getSession();
				String r=(String)httpsession.getAttribute("mid").toString();
				 int d=Integer.parseInt(r);
				confidentialmainBean.setMemberid(d);	
				confidentialdaoImpl.update2(session,confidentialmainBean);

	}
			target="editing";
				
		}

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}

			return (mapping.findForward(target));
			}
	
	public ActionForward deleta(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = new String("success");
		try {
			
			if (form != null) 
			{

				ConfidentialForm confidentialForm =(ConfidentialForm)form;
				ConfidentialmainBean confidentialmainBean= new ConfidentialmainBean();
				BeanUtils.copyProperties(confidentialmainBean,confidentialForm);
				Session session = HibernateUtil.getSessionFactory().openSession();
				System.out.println("DELETE after session");
				ConfidentialdaoImpl confidentialdaoImpl = new ConfidentialdaoImpl();	
				int a[]=confidentialForm.getConfidentdet();
				System.out.println("a====>"+a);
				for(int i=0;i<a.length;i++)
				{
					System.out.println("IN THE LOOP+++++++++++++++++++");
					confidentialmainBean.setConfidentialid(a[i]);				
					/* delete district name */	
				    System.out.println("CHECKBOXID======================================================="+a[i]);
				    confidentialdaoImpl.delete(session,confidentialmainBean);
					
				}
				target="editing";
			      }				


		}

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}

			return (mapping.findForward(target));
			}
	public ActionForward adddisplay(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = new String("success");
		try {
			
			if (form != null) 
			{

				ConfidentialForm confidentialForm =(ConfidentialForm)form;
				ConfidentialBean confidentialBean= new ConfidentialBean();
				ConfidentialmainBean confidentialmainBean= new ConfidentialmainBean();				
				BeanUtils.copyProperties(confidentialBean,confidentialForm);
				BeanUtils.copyProperties(confidentialmainBean,confidentialForm);
				ConfidentialdaoImpl confidentialdaoImpl = new ConfidentialdaoImpl();
				Session session = HibernateUtil.getSessionFactory().openSession();				
	            }
			 request.setAttribute("edit", "edit");
			 request.setAttribute("save", "save");
			target="display";
			
		}

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}

			return (mapping.findForward(target));
			}
		
}
	
		