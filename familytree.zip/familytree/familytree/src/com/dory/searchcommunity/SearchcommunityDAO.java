package com.dory.searchcommunity;

public interface SearchcommunityDAO {

}
