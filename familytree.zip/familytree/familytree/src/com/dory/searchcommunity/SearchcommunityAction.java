package com.dory.searchcommunity;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.searchmember.SearchmemberBean;
import com.dory.searchmember.SearchmemberDAOImpl;
import com.dory.searchmember.SearchmemberForm;

public class SearchcommunityAction extends Action {


	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
				System.out.println("inside action form");
					//used to get the action value
					String k = request.getParameter("action");
					
				SearchcommunityForm searchcommunityForm = (SearchcommunityForm) form;
				SearchcommunityBean searchcommunityBean = new SearchcommunityBean();
                HttpSession httpsession = request.getSession();
                Session session = HibernateUtil.getSessionFactory()
				.openSession();
		       System.out.println("session======111111=====>" + session);
				//BeanUtils.copyProperties(aboutBean, aboutForm);
				
				/*aboutBean.setAchivements(aboutForm
						.getAchivements());
				aboutBean.setMyself(aboutForm.getMyself());
				aboutBean.setRemark(aboutForm.getRemark());*/
				
				
				
				
				//to get the session from the login action
				//String r=(String)httpsession.getAttribute("mid").toString();
				 //int q=Integer.parseInt(r);
	             //System.out.println("rambooo"+q);
	             //aboutBean.setMemberid(q);
	            
				
				SearchcommunityDAOImpl searchcommunityDAO = new SearchcommunityDAOImpl();
				
				//if value of action=insert then enters below statement
				//function to insert the data from aboutme.jsp into about_member tables 
				if ("communityearch".equals(k)) 
				{
					//String data=searchcommunityForm.getData();
					System.out.println("================inside search============");
						String data=request.getParameter("data");
						System.out.println("the data value======"+data);
						Collection serchcomun = searchcommunityDAO.searchcommunity(session,searchcommunityBean,data);
						System.out.println("session======222222222222=====>"+ serchcomun.size());
						
						if (serchcomun.size() > 0) 
						{
							System.out.println("session======333333333=====>"
									+ serchcomun.size());
							System.out.println("after search comp-lete");
							request.setAttribute("serchcomun", serchcomun);
							target = "success";
						} 
						
					
						else if (serchcomun.size()<= 0) 
						{
							String not="notpresent";
							request.setAttribute("notpresent", not);
							target = "success";
						}
						
						
						
				}	
				
				
			
				
				
				
				
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}
}
