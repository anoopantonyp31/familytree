package com.dory.searchcommunity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.searchmember.SearchmemberBean;

public class SearchcommunityDAOImpl {

	
	public Collection searchcommunity(Session session,SearchcommunityBean searchcommunityBean,String q) 
	{
			

		Collection memsearch = new ArrayList();
		try {
			List query = session.createQuery("from SearchcommunityBean ex where ex.communityname like'%"+q+"%'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("serching results============ ");	
				searchcommunityBean = (SearchcommunityBean) it.next();
				memsearch.add(searchcommunityBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return memsearch;
	}
}
