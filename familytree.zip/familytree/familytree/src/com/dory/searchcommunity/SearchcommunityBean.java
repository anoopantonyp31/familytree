package com.dory.searchcommunity;

public class SearchcommunityBean {

	private String communityname;
	private int communityid;
	private String data;
	private String aboutthecommunity;
	private String category;
	public void setCommunityname(String communityname) {
		this.communityname = communityname;
	}
	public String getCommunityname() {
		return communityname;
	}
	public void setCommunityid(int communityid) {
		this.communityid = communityid;
	}
	public int getCommunityid() {
		return communityid;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}
	public void setAboutthecommunity(String aboutthecommunity) {
		this.aboutthecommunity = aboutthecommunity;
	}
	public String getAboutthecommunity() {
		return aboutthecommunity;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getCategory() {
		return category;
	}
}
