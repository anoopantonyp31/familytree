package com.dory.memberbiodata;
import org.hibernate.Session;

public interface BiodataDAO 
{

	public BiodataBean displaybiodatadetails(Session session,BiodataBean biodataBean,int q);
	
	public boolean update(Session session, BiodataBean biodataBean);
	
	
	
}
