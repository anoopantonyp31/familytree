package com.dory.memberbiodata;

import java.util.Date;

public class BiodataBean 
{
	 private int memberid;
	 private String membername;
	 private String nickname;
	 private int visibility;
	 private String birthplace;
	 private String birthstate;
	 private String birthcountry;
	 private int birthorder;
	 private int basefamilyid;
	 private int houseid;
	 private String sex;
	 private String currentstatus;
	 private String address;
	 private Date dob;
	 private String fathername;
	 private String mothername;
	 private int publicorprivate;
	 private String membernumber;
	 private String defaultdate;
	 
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getNickname() {
		return nickname;
	}
	public void setVisibility(int visibility) {
		this.visibility = visibility;
	}
	public int getVisibility() {
		return visibility;
	}
	public void setBirthplace(String birthplace) {
		this.birthplace = birthplace;
	}
	public String getBirthplace() {
		return birthplace;
	}
	public void setBirthstate(String birthstate) {
		this.birthstate = birthstate;
	}
	public String getBirthstate() {
		return birthstate;
	}
	public void setBirthcountry(String birthcountry) {
		this.birthcountry = birthcountry;
	}
	public String getBirthcountry() {
		return birthcountry;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Date getDob() {
		return dob;
	}
	public void setFathername(String fathername) {
		this.fathername = fathername;
	}
	public String getFathername() {
		return fathername;
	}
	public void setMothername(String mothername) {
		this.mothername = mothername;
	}
	public String getMothername() {
		return mothername;
	}
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	public void setDefaultdate(String defaultdate) {
		this.defaultdate = defaultdate;
	}
	public String getDefaultdate() {
		return defaultdate;
	}
	public void setMembernumber(String membernumber) {
		this.membernumber = membernumber;
	}
	public String getMembernumber() {
		return membernumber;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getSex() {
		return sex;
	}
	public void setCurrentstatus(String currentstatus) {
		this.currentstatus = currentstatus;
	}
	public String getCurrentstatus() {
		return currentstatus;
	}
	public void setBirthorder(int birthorder) {
		this.birthorder = birthorder;
	}
	public int getBirthorder() {
		return birthorder;
	}
	public void setBasefamilyid(int basefamilyid) {
		this.basefamilyid = basefamilyid;
	}
	public int getBasefamilyid() {
		return basefamilyid;
	}
	public void setHouseid(int houseid) {
		this.houseid = houseid;
	}
	public int getHouseid() {
		return houseid;
	}

	
}
