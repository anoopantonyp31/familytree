package com.dory.memberbiodata;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;

public class BiodataDAOImpl implements BiodataDAO

{

	
	public BiodataBean displaybiodatadetails(Session session,BiodataBean biodataBean,int q)
	{

		Collection biodatacol = new ArrayList();
		try {
			List query = session.createQuery("from BiodataBean ex where ex.memberid='"+q+"'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				biodataBean = (BiodataBean) it.next();
				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return biodataBean;
	}
	
	public boolean update(Session session, BiodataBean biodataBean) {
		session.beginTransaction();
		session.update(biodataBean);
		session.getTransaction().commit();
		return true;

	}

	  
	
}
