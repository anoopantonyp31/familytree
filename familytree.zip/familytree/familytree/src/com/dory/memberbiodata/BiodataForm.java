package com.dory.memberbiodata;

import java.util.Date;

import org.apache.struts.action.ActionForm;

public class BiodataForm extends ActionForm 
{

	 private int memberid;
	 private int publicorprivate;
	 private String membername;
	 private String nickname;
	 private int visibility;
	 private String birthplace;
	 private String birthstate;
	 private String birthcountry;
	 private String address;
	 private String dob;
	 private String fathername;
	 private String mothername;
	 private String membernumber;
	 private int community;
	 private int groups;
	 private int family;
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getNickname() {
		return nickname;
	}
	public void setVisibility(int visibility) {
		this.visibility = visibility;
	}
	public int getVisibility() {
		return visibility;
	}
	public void setBirthplace(String birthplace) {
		this.birthplace = birthplace;
	}
	public String getBirthplace() {
		return birthplace;
	}
	public void setBirthstate(String birthstate) {
		this.birthstate = birthstate;
	}
	public String getBirthstate() {
		return birthstate;
	}
	public void setBirthcountry(String birthcountry) {
		this.birthcountry = birthcountry;
	}
	public String getBirthcountry() {
		return birthcountry;
	}
	
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDob() {
		return dob;
	}
	public void setFathername(String fathername) {
		this.fathername = fathername;
	}
	public String getFathername() {
		return fathername;
	}
	public void setMothername(String mothername) {
		this.mothername = mothername;
	}
	public String getMothername() {
		return mothername;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	public void setCommunity(int community) {
		this.community = community;
	}
	public int getCommunity() {
		return community;
	}
	public void setFamily(int family) {
		this.family = family;
	}
	public int getFamily() {
		return family;
	}
	public void setGroups(int groups) {
		this.groups = groups;
	}
	public int getGroups() {
		return groups;
	}
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	public void setMembernumber(String membernumber) {
		this.membernumber = membernumber;
	}
	public String getMembernumber() {
		return membernumber;
	}
}
