package com.dory.memberbiodata;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import antlr.StringUtils;

import com.dory.aboutme.AboutBean;
import com.dory.aboutme.AboutDAOImpl;
import com.dory.aboutme.AboutForm;
import com.dory.hibernate.HibernateUtil;

public class BiodataAction extends Action

{
 
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//used to get the action value
					String k = request.getParameter("action");
					
				BiodataForm biodataForm = (BiodataForm) form;
				BiodataBean biodataBean = new BiodataBean();
                HttpSession httpsession = request.getSession();
                Session session = HibernateUtil.getSessionFactory()
				.openSession();
		      
				//to get the session from the login action
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             biodataBean.setMemberid(q);
	            
				
				BiodataDAOImpl biodataDAO = new BiodataDAOImpl();
				
				//if value of action=insert then enters below statement
				//function to insert the data from aboutme.jsp into about_member tables 
				if ("update".equals(k)) 
				{
					System.out.println("member value========"+biodataForm.getMembernumber());
					
					biodataBean = biodataDAO.displaybiodatadetails(session,biodataBean,q);
					
					//StringUtils.isBlank(biodataForm.getMembernumber());
					//String membernum1=Integer.toString(biodataForm.getMembernumber());
					
					
					
				if("*".equals(biodataForm.getMembernumber()))
				{
					System.out.println("inside if=====================");
					String membernum=Integer.toString(q);
					biodataBean.setMembernumber(membernum);
					//biodataBean.setMembernumber(biodataForm.getMembernumber());
				}
				else
				{
					System.out.println("inside else=====================");
					//String membernum=Integer.toString(q);
					//biodataBean.setMembernumber(membernum);
					biodataBean.setMembernumber(biodataForm.getMembernumber());
				}
					
				    biodataBean.setMembername(biodataForm.getMembername());
					biodataBean.setNickname(biodataForm.getNickname());
					biodataBean.setBirthplace(biodataForm.getBirthplace());
					biodataBean.setBirthstate(biodataForm.getBirthstate());
					biodataBean.setBirthcountry(biodataForm.getBirthcountry());
					biodataBean.setAddress(biodataForm.getAddress());
					String tdat=biodataForm.getDob();
					System.out.println("String date================================"+tdat);
					Date todate=new SimpleDateFormat("dd-MM-yyyy").parse(tdat);
					System.out.println("Date format================================"+todate);
					biodataBean.setDob(todate);
					System.out.println("Date from beannnnnnnn======================"+biodataBean.getDob());
					biodataBean.setFathername(biodataForm.getFathername());
					biodataBean.setMothername(biodataForm.getMothername());
					//*********************visibility part***********************//
					//--------------------------------------
					int privateorprivate1=biodataForm.getPublicorprivate();
					System.out.println("visibility from the form==================="+privateorprivate1);
					int family=biodataForm.getFamily();
					int groups=biodataForm.getGroups();
					int community=biodataForm.getCommunity();
					//String s = formatter.format(date);

					if(privateorprivate1==1)
					{
						//String visibility=privateorprivate1+"0"+"0"+"0";
						int visibility=8;
						System.out.println("===========in public======="+visibility);
						biodataBean.setVisibility(visibility);
					}
					if(privateorprivate1==0)
					{
						//String visibility=privateorprivate1+"0"+"0"+"0";
						int visibility=0;
						System.out.println("===========in private======="+visibility);
						biodataBean.setVisibility(visibility);
					}
					
					if(privateorprivate1==500)
					{
				
					
					 
						if((community==0)&&(family==0)&&(groups==0))
						{
							//String visibility="0"+"0"+"0"+"0";
							int visibility=0;
							System.out.println("===========1111111======="+visibility);
							biodataBean.setVisibility(visibility);
						}
						
						else if((community==0)&&(family==1)&&(groups==0))
						{
							int visibility=1;
							System.out.println("===========222222======="+visibility);
							biodataBean.setVisibility(visibility);
						}
						
						else if((community==1)&&(family==0)&&(groups==0))
						{
							int visibility=2;
							System.out.println("===========3333333======="+visibility);
							biodataBean.setVisibility(visibility);
						}
						
						else if((community==1)&&(family==1)&&(groups==0))
						{
							int visibility=3;
							System.out.println("===========44444444======="+visibility);
							biodataBean.setVisibility(visibility);
						}
						
						
						else if((community==0)&&(family==0)&&(groups==1))
						{
							int visibility=4;
							System.out.println("===========666666666======="+visibility);
							biodataBean.setVisibility(visibility);
						}
						
						
						else if((community==0)&&(family==1)&&(groups==1))
						{
							int visibility=5;
							System.out.println("===========7777777======="+visibility);
							biodataBean.setVisibility(visibility);
						}
						
						
						else if((community==1)&&(family==0)&&(groups==1))
						{
							int visibility=6;
							System.out.println("===========8888888======="+visibility);
							biodataBean.setVisibility(visibility);
						}
						
						
						else if((community==1)&&(family==1)&&(groups==1))
						{
							int visibility=7;
							System.out.println("===========99999999======="+visibility);
							biodataBean.setVisibility(visibility);
						}
						
						
					}
					
					//*********************visibility part***********************//
					
					
										System.out.println("inside insert");
										biodataDAO.update(session,biodataBean);
						
						target="correct";
						
				}	
				
				
				else if ("display".equals(k)) 
				{
							
					biodataBean = biodataDAO.displaybiodatadetails(session,biodataBean,q);
					System.out.println("inside dobbbbbbbbbbbb====="+biodataBean.getDob());
					Date strdate1=biodataBean.getDob();
					System.out.println("the date is in date format======"+strdate1);
					String dateStr = null;
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
					if (strdate1 != null) {
					    dateStr = simpleDateFormat.format(strdate1);
					    System.out.println("the string is in date format======"+dateStr);
					   biodataBean.setDefaultdate(dateStr);
					}
					
				   
					
					{
						
						request.setAttribute("biodata", biodataBean);
						target = "biodata";
					} 
						
				}
				
				
				
				
				
				
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}

	
}
