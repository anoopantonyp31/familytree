package com.dory.searchmember;

import org.apache.struts.action.ActionForm;

public class SearchmemberForm extends ActionForm {

	private String membername;
	private int memberid;
	 private String memberno;
	private String data;
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}
	public void setMemberno(String memberno) {
		this.memberno = memberno;
	}
	public String getMemberno() {
		return memberno;
	}
	
}
