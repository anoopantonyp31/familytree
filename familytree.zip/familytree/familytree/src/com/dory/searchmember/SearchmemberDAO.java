package com.dory.searchmember;

public interface SearchmemberDAO {

}
