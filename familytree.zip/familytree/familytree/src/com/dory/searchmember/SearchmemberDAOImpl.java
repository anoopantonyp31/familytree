package com.dory.searchmember;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.proffessional.ProffessionalBean;

public class SearchmemberDAOImpl {

	
	public Collection searchmember(Session session,SearchmemberBean searchmemberBean,String data,int q) 
	{
			

		Collection memsearch = new ArrayList();
		try {
			List query = session.createQuery("from SearchmemberBean ex where ex.membername like'%"+data+"%'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("serching results============ ");	
				searchmemberBean = (SearchmemberBean) it.next();
				if(searchmemberBean.getMemberid()!=q)
				{
					memsearch.add(searchmemberBean);
				}
				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return memsearch;
	}
}
