package com.dory.searchmember;

public class SearchmemberBean {

	
	 private String membername;
	 private int memberid;
	 private String memberno;
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setMemberno(String memberno) {
		this.memberno = memberno;
	}
	public String getMemberno() {
		return memberno;
	}
}
