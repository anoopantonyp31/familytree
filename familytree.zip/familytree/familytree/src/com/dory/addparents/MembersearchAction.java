package com.dory.addparents;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

public class MembersearchAction extends Action
{

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
	String target = null;
	try {
		if (form != null)
		{

			String action = request.getParameter("action");
			MembersearchBean membersearchBean = new MembersearchBean();
			MembersearchForm membersearchForm = (MembersearchForm) form;
			//HttpSession httpsession = request.getSession();
					

			Session session = HibernateUtil.getSessionFactory()
					.openSession();

             GetmemberDAOImpl getmemberDAOImpl = new GetmemberDAOImpl();
             
             if ("search".equals(action))
             {
            	 
            	int search = membersearchForm.getCriteria();
            	System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMM======"+search);
            	if(search==0)
            	{
            		
            	  String membernumber = membersearchForm.getSelect();
            	  System.out.println("MMMMMMMMMMember nummmmmmmmmmber"+membernumber);
            	  Collection members =  getmemberDAOImpl.displaymemberbynumber(session,membersearchBean,membernumber);
            	  if(members.size()>0)
            	  {
            	  request.setAttribute("members", members);
            	  }
            	  else if(members.size()<=0)
            	  {
            	    String not="notpresent";
					request.setAttribute("notpresent", not);
            	  }
            	  target="success";
            	}
            	else if(search==1)
            	{
            		String member = membersearchForm.getSelect();
            		System.out.println("MMMMMMMMMMember nummmmmmmmmmbernmaeee"+member);
            		 Collection members =  getmemberDAOImpl.displaymemberbyname(session,membersearchBean,member);
            		 request.setAttribute("members", members);
            		 target="success";
            	}
            	 
             }

                	
            }
             
		
		}
		catch (Exception e) 
		{
		System.out.println("Exception=====>" + e);
		target="failure";
		}

	return (mapping.findForward(target));
	}
}
