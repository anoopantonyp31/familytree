package com.dory.addparents;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.confidential.ConfidentialBean;
import com.dory.contact.ContactsBean;
import com.dory.contact.ContactsDAO;
import com.dory.contact.ContactsDAOImpl;
import com.dory.favourites.FavouritesBean;
import com.dory.hibernate.HibernateUtil;
import com.dory.house.HouseBean;
import com.dory.login.LoginBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalBean;
import com.dory.tree.FamilyBean;
import com.dory.tree.Relation2Bean;
import com.dory.tree.RelationsBean;
import com.dory.tree.TreeDAO;
import com.dory.tree.TreeDAOImpl;

public class AddparentAction extends Action 
{

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
	String target = null;
	try {
		if (form != null)
		{
			
			AddparentForm addparentForm = (AddparentForm) form;
			
			FamilyBean addfamilyBean = new FamilyBean();
			FamilyBean addfamilyBean1 = new FamilyBean();
			FamilyBean familyBean = new FamilyBean();
			
			HouseBean addhouseBean = new HouseBean();
			HouseBean addhouseBean1 = new HouseBean();
			ProfileBean getmemberBean0 = new ProfileBean();
			ProfileBean getmemberBean4 = new ProfileBean();
			ProfileBean getmemberBean5 = new ProfileBean();
			ProfileBean getmemberBean = new ProfileBean();
			ProfileBean getmemberBean1 = new ProfileBean();
			ProfileBean getmemberBean2 = new ProfileBean();
			ProfileBean getmemberBean3 = new ProfileBean();
			RelationsBean relationBean = new RelationsBean();
			RelationsBean relationBean2 = new RelationsBean();
			Relation2Bean relationBean3 = new Relation2Bean();
			
			int motherhouseid=0;
			int fatherhouseid=0;
			AboutBean parentaboutBean1 = new AboutBean();
			AboutBean parentaboutBean2 = new AboutBean();
			ConfidentialBean parentconfidentialBean1 = new ConfidentialBean();
			ConfidentialBean parentconfidentialBean2 = new ConfidentialBean();
			
			ContactsBean parentcontactsBean1 = new ContactsBean();
			ContactsBean parentcontactsBean2 = new ContactsBean();
			
			FavouritesBean parentfavouritesBean1 = new FavouritesBean();
			FavouritesBean parentfavouritesBean2 = new FavouritesBean();
			PersonalBean parentpersonalBean1 = new PersonalBean();
			PersonalBean parentpersonalBean2 = new PersonalBean();
			LoginBean usernameBean1 = new LoginBean();
			LoginBean usernameBean2 = new LoginBean();
			System.out.println("inside action");
			//GetmemberBean getmemberBean = new GetmemberBean();
			
			String hide = request.getParameter("action");		
			String k = request.getParameter("action");
			Session session = HibernateUtil.getSessionFactory()
					.openSession();

             GetmemberDAOImpl getmemberDAOImpl = new GetmemberDAOImpl();
             TreeDAO treedao = new TreeDAOImpl();
             ContactsDAO contactDAO = new ContactsDAOImpl();
             HttpSession sonidsession = request.getSession();
             HttpSession httpsession = request.getSession();
             if ("redirect".equals(k)) 
				{
            	 System.out.println("inside redirect");
            	 String sunid=request.getParameter("sonid");
            	 System.out.println("sunid========="+sunid);
            	 int sonid=Integer.parseInt(sunid);
            	 
            	 sonidsession.setAttribute("sonid", sonid);
                 target="addparent";

                }
             
             else if("insert".equals(k))
             {
            	 addfamilyBean.setFamilyno(addparentForm.getFamilyno());
            	 addfamilyBean.setFamilyname(addparentForm.getFamilyname());
            	 
            int familyadmin=addparentForm.getFamilyadmin();
            
            System.out.println("faaaaaaammmmmmmmmmmmmmmilyyyaadminnnnnnnnn------------------"+familyadmin);
            
            if(familyadmin==0)
            {
            	System.out.println("faaaaaaammmmminniiiiiiiiiiffffffffffffff00000000000000000");
            	 String r1=(String)sonidsession.getAttribute("sonid").toString();
				 int q1=Integer.parseInt(r1);
	             System.out.println("sonid===="+q1);
	             addfamilyBean.setFamilyadmin(q1);
            }
            else if(familyadmin==1)
            {
            	System.out.println("faaaaaaammmmminni11111111111111111111111");
            	
            	// first set as 0;
            	int def=0;
            	addfamilyBean.setFamilyadmin(def);
            }
            else if(familyadmin==2)
            {
            	System.out.println("faaaaaaammmmminn2222222222222222222222222");
            	// for other member id
            	addfamilyBean.setFamilyadmin(addparentForm.getMemberid());
            }
            	
          //to get the session from the login action and enter created by
			String r=(String)httpsession.getAttribute("mid").toString();
			 int q=Integer.parseInt(r);
             System.out.println("rambooo"+q);
             addfamilyBean.setCreatedby(q);
            	
             String r1=(String)sonidsession.getAttribute("sonid").toString();
			 int q1=Integer.parseInt(r1);
             System.out.println("sonid===="+q1);
   
             Serializable id=getmemberDAOImpl.insertfamily(session,addfamilyBean);
             int flyid=(Integer)id;
             File f=new File(getServlet().getServletContext().getRealPath("/")+"families/"+flyid);
				System.out.print("after ffffffffff");
				
				if(!f.exists())
					f.mkdirs();
				
				// insert into house table 
				 int housedet=addparentForm.getHousedetails();
				 int housedet2=addparentForm.getHousedetails1();
				 System.out.println("memberrrrrrrrmotherererere===="+housedet2);
				 if(housedet==1 || housedet2==3 && housedet==1)
				 {
					 //retrive sons house id 
					 System.out.println("member id"+q);
					// getmemberBean.setMemberid(q);
					Collection gtmemberBean = getmemberDAOImpl.displaymember1(session, getmemberBean0,q1);
					for (Iterator it = gtmemberBean.iterator(); it.hasNext();)
					{
						getmemberBean0 = (ProfileBean) it.next();
					System.out.println("houuuuuuseeeeeeeid============"+getmemberBean0.getHouseid());
					
					
					}
					int houseid=getmemberBean0.getHouseid();
					 fatherhouseid=houseid;
		             motherhouseid=houseid;
					//getmemberBean.setHouseid(houseid);
					// setting family id to basefamily id and house id to profile table
					//flyid;
		             // houseid
					//getmemberBean.setHouseid(houseid);
					//getmemberBean.setHouseid(houseid);
					getmemberBean.setBasefamilyid(flyid);
					System.out.println("houseid========"+houseid);
					 System.out.println("familyid======="+flyid);
				 }
				 else if(housedet==2 || housedet2==3 && housedet==2)
				 {
					 System.out.println("inside house det 2");
					 addhouseBean.setHousename(addparentForm.getHousename());
					 addhouseBean.setCity(addparentForm.getCity());
					 addhouseBean.setAddress(addparentForm.getAddress());
					 addhouseBean.setRemark(addparentForm.getRemark());
					 addhouseBean.setStatus(addparentForm.getStatus());
					 addhouseBean.setVisibility("0");
					 System.out.println("house name========="+addparentForm.getHousename());
					 System.out.println("city name=========="+addparentForm.getCity());
					 System.out.println("address============"+addparentForm.getAddress());
					 System.out.println("remark============="+addparentForm.getRemark());
					 System.out.println("status============="+addparentForm.getStatus());
					
					 System.out.println("before house insert");
					 
					 Serializable iid=getmemberDAOImpl.inserthouse(session,addhouseBean);
		             int houseid=(Integer)iid;
					// setting family id to basefamily and house id to profile table
		             //flyid;
		             // houseid
		             fatherhouseid=houseid;
		             motherhouseid=houseid;
		            // getmemberBean.setHouseid(houseid);
		             System.out.println("beforeeeeeeeeeeeeeeee house insert inside house det 2"+getmemberBean.getHouseid());
		             System.out.println("after house insert");
					 getmemberBean.setBasefamilyid(flyid);
					 System.out.println("houseid==                                                        ======"+houseid);
					 System.out.println("familyid====                                                     ==="+flyid);
				 }
				 
				 
				 
				 
			
				 if(housedet2==1)
				 {
					 //retrive sons house id 
					 System.out.println("member id"+q);
					// getmemberBean.setMemberid(q);
					Collection gtmemberBean = getmemberDAOImpl.displaymember1(session, getmemberBean0,q1);
					for (Iterator it = gtmemberBean.iterator(); it.hasNext();)
					{
						getmemberBean0 = (ProfileBean) it.next();
					System.out.println("houuuuuuseeeeeeeid============"+getmemberBean0.getHouseid());
					
					
					}
					int houseid=getmemberBean0.getHouseid();
					motherhouseid=houseid;
					//getmemberBean.setHouseid(houseid);
					// setting family id to basefamily id and house id to profile table
					//flyid;
		             // houseid
					//getmemberBean.setHouseid(houseid);
					getmemberBean.setBasefamilyid(flyid);
					System.out.println("houseid========"+houseid);
					 System.out.println("familyid======="+flyid);
				 }
				 else if(housedet2==2)
				 {
					 System.out.println("inside house det2222222222222222222222222222222 2");
					 addhouseBean1.setHousename(addparentForm.getMohousename());
					 addhouseBean1.setCity(addparentForm.getMocity());
					 addhouseBean1.setAddress(addparentForm.getMohaddress());
					 addhouseBean1.setRemark(addparentForm.getMohaddress());
					 addhouseBean1.setStatus(addparentForm.getMohremark());
					 addhouseBean1.setVisibility("0");
					 System.out.println("house name===mother======"+addparentForm.getMohousename());
					 System.out.println("city name====mother======"+addparentForm.getMocity());
					 System.out.println("address======mother======"+addparentForm.getMohaddress());
					 System.out.println("remark======mother======="+addparentForm.getMohaddress());
					 System.out.println("status======mother======="+addparentForm.getMohremark());
					
					 System.out.println("before house insert");
					 
					 Serializable iid1=getmemberDAOImpl.inserthouse1(session,addhouseBean1);
		             int mohouseid=(Integer)iid1;
		             motherhouseid=mohouseid;
					// setting family id to basefamily and house id to profile table
		             //flyid;
		             // houseid
		             System.out.println("after house insert");
		            // getmemberBean.setHouseid(mohouseid);
					 getmemberBean.setBasefamilyid(flyid);
					 System.out.println("houseid========"+mohouseid);
					 System.out.println("familyid======="+flyid);
				 }
			
				 
				//setting father details to the bean
				 System.out.println("inside father insert");
				 getmemberBean1.setName(addparentForm.getFamembername());
				 getmemberBean1.setNickname(addparentForm.getFanickname());
				 getmemberBean1.setBirthplace(addparentForm.getFabirthplace());
				 getmemberBean1.setBirthstate(addparentForm.getFabirthstate());
				 getmemberBean1.setHouseid(fatherhouseid);
				 getmemberBean1.setBirthcountry(addparentForm.getFabirthcountry());
				 getmemberBean1.setAddress(addparentForm.getFaaddress());
				 getmemberBean1.setBirthorder(addparentForm.getFabirthorder());
				 String sex="m";
				 getmemberBean1.setSex(sex);
				 System.out.println("Stringbbbeaaaaaaaaaaaaaaaannnnnnnnnn1111111sss=="+getmemberBean1.getSex());
				 getmemberBean1.setStatus(addparentForm.getFacurrentstatus());
				  String fatherdob=addparentForm.getFadob();
				  
				
				  
					System.out.println("String date================================"+fatherdob);
					if(fatherdob !="" )
					{
					Date fadate=new SimpleDateFormat("dd-MM-yyyy").parse(fatherdob);
					
					System.out.println("Date format================================"+fadate);
					getmemberBean1.setDob(fadate);
					}
					getmemberBean1.setBasefamilyid(getmemberBean.getBasefamilyid());
					//getmemberBean1.setHouseid(getmemberBean.getHouseid());

					
					//set to bean
					getmemberBean1.setMembernumber(addparentForm.getFamembernumber());
					
					//
					
					
					System.out.println("getFamembername========="+addparentForm.getFamembername());
					 System.out.println("getFanickname========="+addparentForm.getFanickname());
					 System.out.println("getFabirthplace========="+addparentForm.getFabirthplace());
					 System.out.println("getFabirthstate========="+addparentForm.getFabirthstate());
					 System.out.println("getFabirthcountry========="+addparentForm.getFabirthcountry());
					 System.out.println("getFaaddress========="+addparentForm.getFaaddress());
					 System.out.println("getFabirthorder========="+addparentForm.getFabirthorder());
					 System.out.println("getFacurrentstatus========="+addparentForm.getFacurrentstatus());
		
				 
				 Serializable fatherid=getmemberDAOImpl.insertmemberprofile(session,getmemberBean1);
	             int fatherprofileid=(Integer)fatherid;
	             System.out.println("father profile id========"+fatherprofileid);
	             
	             HttpSession httpsessionfaid = request.getSession();
	             httpsessionfaid.setAttribute("fatherid", fatherprofileid);
	             
	             
	             
	             System.out.println("family adminnnnnnnnnnn afterrereeeeeeeeeeeeeee insertinhgggggg father======================"+addfamilyBean.getFamilyadmin());
	             int admin=addfamilyBean.getFamilyadmin();
	             if(admin==0)
	             {
	            	 addfamilyBean1.setFamilyid(flyid);
	            	 getmemberDAOImpl.updatefamilyadmin(session,addfamilyBean1,fatherprofileid);
	             }
	             
	             
	             if("*".equals(addparentForm.getFamembernumber()))
					{
						//retrive the memberid and update the table
	            	Collection getmember = getmemberDAOImpl.displaymember1(session, getmemberBean4, fatherprofileid);
	            	for (Iterator it = getmember.iterator(); it.hasNext();)
					{
	            		getmemberBean4 = (ProfileBean) it.next();
					    System.out.println("mememmemmemmberrererrnnumbeeereereeerreeeeeeeeeid============"+getmemberBean.getMembernumber());
					    String fatherprofileid1 =Integer.toString(fatherprofileid);
					    getmemberBean4.setMembernumber(fatherprofileid1);
					    
					    getmemberDAOImpl.updatefamember(session,getmemberBean4);
					
					
					}
	            	
					}
					
	             
	             
	           
	          
	             //setting mother details to the bean
	             
	             getmemberBean2.setName(addparentForm.getMomembername());
				 getmemberBean2.setNickname(addparentForm.getMonickname());
				 getmemberBean2.setBirthplace(addparentForm.getMobirthplace());
				 getmemberBean2.setBirthstate(addparentForm.getMobirthstate());
				 getmemberBean2.setBirthcountry(addparentForm.getMobirthcountry());
				 getmemberBean2.setAddress(addparentForm.getMoaddress());
				 getmemberBean2.setBirthorder(addparentForm.getMobirthorder());
				 String masex="f";
				 getmemberBean2.setSex(masex);
				 getmemberBean2.setBasefamilyid(getmemberBean.getBasefamilyid());
				 getmemberBean2.setHouseid(motherhouseid);
				 getmemberBean2.setStatus(addparentForm.getMocurrentstatus());
				 String mafatherdob=addparentForm.getModob();
				 getmemberBean2.setMembernumber(addparentForm.getMomembernumber());
				
				  
					System.out.println("String date================================"+mafatherdob);
					if(mafatherdob !="")
					{
					Date mafadate=new SimpleDateFormat("dd-MM-yyyy").parse(mafatherdob);
					System.out.println("Date format================================"+mafadate);
					getmemberBean2.setDob(mafadate);
					}

					getmemberBean2.setMembernumber(addparentForm.getMomembernumber());
	             
	             Serializable motherid=getmemberDAOImpl.insertmemberprofile1(session,getmemberBean2);
	             int motherprofileid=(Integer)motherid;
	             System.out.println("mother profile id========"+motherprofileid);
	             
	             
	             HttpSession httpsessionfmoid = request.getSession();
	             httpsessionfaid.setAttribute("motherid", motherprofileid);
	             
	             
	             
	             if("*".equals(addparentForm.getMomembernumber()))
					{
						//retrive the memberid and update the table
	            	Collection getmember1 = getmemberDAOImpl.displaymember1(session, getmemberBean5, motherprofileid);
	            	for (Iterator it = getmember1.iterator(); it.hasNext();)
					{
	            		getmemberBean5 = (ProfileBean) it.next();
					    System.out.println("mememmemmemmberrererrnnumbeeereereeerreeeeeeeeeid============"+getmemberBean5.getMembernumber());
					    String motherprofileid1 =Integer.toString(motherprofileid);
					    getmemberBean5.setMembernumber(motherprofileid1);
					    
					    getmemberDAOImpl.updatemomember(session,getmemberBean5);
					
					
					}
	            	
					}
	             
	             
	             // ===============insert into relation table
	           //fatherprofileid
	             System.out.println("father profile id==bbbbbbinsertttt======"+fatherprofileid);
	             getmemberBean0 = treedao.profile(session, fatherprofileid);
	             relationBean.setProfile(getmemberBean0);
	             System.out.println("father member id==bbbbbbinsertttt======"+relationBean.getMemberid());
	             relationBean.setFatherid(0);
	             relationBean.setMotherid(0);
	             relationBean.setSpouseid(0);
	             relationBean.setRelationshipid(0);
	             familyBean = treedao.retrievefamid(session,flyid);             // TO RETRIEVE FAMILYID......
	 		     relationBean.setFamily(familyBean);
	             //relationBean1.setFamilyid(flyid);
	             treedao.relationinsert(session,relationBean);
	             
	             // motherprofileid
	             System.out.println("mother profile id===binsssssert====="+motherprofileid);
	             getmemberBean0 = treedao.profile(session, motherprofileid);
	             relationBean2.setProfile(getmemberBean0);
	             System.out.println("father member id==afteeinsertttt======"+relationBean2.getMemberid());
	             relationBean2.setFatherid(0);
	             relationBean2.setMotherid(0);
	             relationBean2.setSpouseid(fatherprofileid);
	             relationBean2.setRelationshipid(0);
	             familyBean = treedao.retrievefamid(session,flyid);             // TO RETRIEVE FAMILYID......
	             relationBean2.setFamily(familyBean);
	             treedao.relationinsert(session,relationBean2);
	             
	             //flyid
	             //=============================================
	             //update sons basefamily id, mother id, fatherid
	             String r11=(String)sonidsession.getAttribute("sonid").toString();
				 int memberidson=Integer.parseInt(r11);
	             System.out.println("sonidiiiiiiiiiiddddddto update the base family===="+memberidson);
	             getmemberBean3.setMemberid(memberidson);
	             getmemberDAOImpl.updatebasefamily(session,getmemberBean3,flyid);
	             relationBean3.setFatherid(fatherprofileid);
	             relationBean3.setMotherid(motherprofileid);
	             getmemberDAOImpl.updateson(session,relationBean3,memberidson);
	             
	             
	             //insert in to profile tables of the member
	             parentaboutBean1.setMemberid(fatherprofileid);
	             parentaboutBean1.setVisibility("0");
	             getmemberDAOImpl.insertaboutme(session,parentaboutBean1);
	             
	             
	             parentaboutBean2.setMemberid(motherprofileid);
	             parentaboutBean2.setVisibility("0");
	             getmemberDAOImpl.insertaboutme(session,parentaboutBean2);
	           //insert in to per_confidential_details of the member
	             
	            
	             parentconfidentialBean1.setMemberid(fatherprofileid);
	             getmemberDAOImpl.insertconfidential(session,parentconfidentialBean1);
	             
	             
	             parentconfidentialBean2.setMemberid(motherprofileid);
	             getmemberDAOImpl.insertconfidential(session,parentconfidentialBean2);
	             
	             //....Insertion into contact table.......
	             parentcontactsBean1.setVisibility("0");
	             getmemberBean0 = treedao.profile(session, fatherprofileid);
	             parentcontactsBean1.setProfile(getmemberBean0);
	             contactDAO.insert(session, parentcontactsBean1);
	             
	             
	             parentcontactsBean2.setVisibility("0");
	             getmemberBean0 = treedao.profile(session, motherprofileid);
	             parentcontactsBean2.setProfile(getmemberBean0);
	             contactDAO.insert(session, parentcontactsBean2);
	             //.......................................................
	             
	             
	             //....Insertion into member_favourites table....... 
	             parentfavouritesBean1.setVisibility("0");
	             parentfavouritesBean1.setMemberid(fatherprofileid);
	             getmemberDAOImpl.insertfavourites(session,parentfavouritesBean1);
	             
	             
	             parentfavouritesBean2.setVisibility("0");	             
	             parentfavouritesBean2.setMemberid(motherprofileid);
	             getmemberDAOImpl.insertfavourites(session,parentfavouritesBean2);
	             //.......................................................
	         
	           //....Insertion into member_personal table.......
	             
	             parentpersonalBean1.setVisibility("0");	
	             parentpersonalBean1.setMemberid(fatherprofileid);
	             parentpersonalBean1.setMaritalstatus(1);
	             getmemberDAOImpl.insertpersonal(session,parentpersonalBean1);
	             
	             
	             parentpersonalBean2.setVisibility("0");
	             parentpersonalBean1.setMaritalstatus(1);
	             parentpersonalBean2.setMemberid(motherprofileid);
	             getmemberDAOImpl.insertpersonal(session,parentpersonalBean2);
	             
	             //.......................................................
	             
	           //....Insertion into member_login table....... 
	             usernameBean1.setIsactive(0);	
	             usernameBean1.setMemberid(fatherprofileid);
	             getmemberDAOImpl.insertlogin(session,usernameBean1);
	             
	             usernameBean2.setIsactive(0);	
	             usernameBean2.setMemberid(motherprofileid);
	             getmemberDAOImpl.insertlogin(session,usernameBean2);
	             
	           //.......................................................
	             
            	 target="addparent1"; 
             }
     		
     		if("hide".equals(hide))
     		{
     			String utype=(String)httpsession.getAttribute("utype").toString();
     			if("sadmin".equals(utype))
     			{
     			System.out.println("inside hide for parrent");
     			request.setAttribute("change", "change");
     			request.setAttribute("home", "home");
     			}
     			target="home";
     		}
             
		
		}
	}
		catch (Exception e) 
		{
		System.out.println("Exception=====>" + e);
		target="failure";
		}

	return (mapping.findForward(target));
	}
}