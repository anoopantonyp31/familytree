package com.dory.addparents;

import org.apache.struts.action.ActionForm;

public class AddparentForm extends ActionForm 
{
	//father details
	 private int famemberid;
	 private String famembername;
	 private String fanickname;
	 private String fabirthplace;
	 private String fabirthstate;
	 private String fabirthcountry;
	 private String facurrentstatus;
	 private String faaddress;
	 private String fadob;
	 private int fabirthorder;
	 private String famembernumber;
	 
	 //mother details
	 private int momemberid;
	 private String momembername;
	 private int mobirthorder;
	 private String monickname;
	 private String mobirthplace;
	 private String mocurrentstatus;
	 private String mobirthstate;
	 private String mobirthcountry;
	 private String moaddress;
	 private String modob;
	 private String momembernumber;

	 
	 //family details
	 private String familyname;
	 private String familyno ;
	 private int familyadmin ;
	 private int memberid;
	 private int createdby;
	 private int familyid;
	 
	 //house details
	//father 
	 private int housedetails;
	 private String housename;
	 private String city ;
	 private String address ;
	 private String remark;
	 private String status;
	 private int houseid;
	//mother 
	 private int housedetails1;
	 private String mohousename;
	 private String mocity ;
	 private String mohaddress ;
	 private String mohremark;
	 private String mohstatus;
	 private int mohouseid;
	 
	 
	public void setFamemberid(int famemberid) {
		this.famemberid = famemberid;
	}
	public int getFamemberid() {
		return famemberid;
	}
	public void setFamembername(String famembername) {
		this.famembername = famembername;
	}
	public String getFamembername() {
		return famembername;
	}
	public void setFanickname(String fanickname) {
		this.fanickname = fanickname;
	}
	public String getFanickname() {
		return fanickname;
	}
	public void setFabirthplace(String fabirthplace) {
		this.fabirthplace = fabirthplace;
	}
	public String getFabirthplace() {
		return fabirthplace;
	}
	public void setFabirthstate(String fabirthstate) {
		this.fabirthstate = fabirthstate;
	}
	public String getFabirthstate() {
		return fabirthstate;
	}
	public void setFabirthcountry(String fabirthcountry) {
		this.fabirthcountry = fabirthcountry;
	}
	public String getFabirthcountry() {
		return fabirthcountry;
	}
	public void setFaaddress(String faaddress) {
		this.faaddress = faaddress;
	}
	public String getFaaddress() {
		return faaddress;
	}
	public void setFadob(String fadob) {
		this.fadob = fadob;
	}
	public String getFadob() {
		return fadob;
	}


	public void setMomemberid(int momemberid) {
		this.momemberid = momemberid;
	}
	public int getMomemberid() {
		return momemberid;
	}
	public void setMomembername(String momembername) {
		this.momembername = momembername;
	}
	public String getMomembername() {
		return momembername;
	}
	public void setMonickname(String monickname) {
		this.monickname = monickname;
	}
	public String getMonickname() {
		return monickname;
	}
	public void setMobirthplace(String mobirthplace) {
		this.mobirthplace = mobirthplace;
	}
	public String getMobirthplace() {
		return mobirthplace;
	}
	public void setMobirthstate(String mobirthstate) {
		this.mobirthstate = mobirthstate;
	}
	public String getMobirthstate() {
		return mobirthstate;
	}
	public void setMobirthcountry(String mobirthcountry) {
		this.mobirthcountry = mobirthcountry;
	}
	public String getMobirthcountry() {
		return mobirthcountry;
	}
	public void setMoaddress(String moaddress) {
		this.moaddress = moaddress;
	}
	public String getMoaddress() {
		return moaddress;
	}
	public void setModob(String modob) {
		this.modob = modob;
	}
	public String getModob() {
		return modob;
	}
	
	public void setFamilyname(String familyname) {
		this.familyname = familyname;
	}
	public String getFamilyname() {
		return familyname;
	}
	public void setFamilyno(String familyno) {
		this.familyno = familyno;
	}
	public String getFamilyno() {
		return familyno;
	}
	public void setFamilyadmin(int familyadmin) {
		this.familyadmin = familyadmin;
	}
	public int getFamilyadmin() {
		return familyadmin;
	}
	public void setCreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getCreatedby() {
		return createdby;
	}
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}
	public void setHousename(String housename) {
		this.housename = housename;
	}
	public String getHousename() {
		return housename;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCity() {
		return city;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setHouseid(int houseid) {
		this.houseid = houseid;
	}
	public int getHouseid() {
		return houseid;
	}
	public void setHousedetails(int housedetails) {
		this.housedetails = housedetails;
	}
	public int getHousedetails() {
		return housedetails;
	}
	public void setFabirthorder(int fabirthorder) {
		this.fabirthorder = fabirthorder;
	}
	public int getFabirthorder() {
		return fabirthorder;
	}
	public void setMobirthorder(int mobirthorder) {
		this.mobirthorder = mobirthorder;
	}
	public int getMobirthorder() {
		return mobirthorder;
	}
	public void setFacurrentstatus(String facurrentstatus) {
		this.facurrentstatus = facurrentstatus;
	}
	public String getFacurrentstatus() {
		return facurrentstatus;
	}
	public void setMocurrentstatus(String mocurrentstatus) {
		this.mocurrentstatus = mocurrentstatus;
	}
	public String getMocurrentstatus() {
		return mocurrentstatus;
	}
	public void setFamembernumber(String famembernumber) {
		this.famembernumber = famembernumber;
	}
	public String getFamembernumber() {
		return famembernumber;
	}
	public void setMomembernumber(String momembernumber) {
		this.momembernumber = momembernumber;
	}
	public String getMomembernumber() {
		return momembernumber;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setHousedetails1(int housedetails1) {
		this.housedetails1 = housedetails1;
	}
	public int getHousedetails1() {
		return housedetails1;
	}
	public void setMohousename(String mohousename) {
		this.mohousename = mohousename;
	}
	public String getMohousename() {
		return mohousename;
	}
	public void setMocity(String mocity) {
		this.mocity = mocity;
	}
	public String getMocity() {
		return mocity;
	}
	public void setMohaddress(String mohaddress) {
		this.mohaddress = mohaddress;
	}
	public String getMohaddress() {
		return mohaddress;
	}
	public void setMohremark(String mohremark) {
		this.mohremark = mohremark;
	}
	public String getMohremark() {
		return mohremark;
	}
	public void setMohstatus(String mohstatus) {
		this.mohstatus = mohstatus;
	}
	public String getMohstatus() {
		return mohstatus;
	}
	public void setMohouseid(int mohouseid) {
		this.mohouseid = mohouseid;
	}
	public int getMohouseid() {
		return mohouseid;
	}

}
