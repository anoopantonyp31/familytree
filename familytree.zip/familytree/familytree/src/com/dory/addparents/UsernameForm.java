package com.dory.addparents;

import org.apache.struts.action.ActionForm;

public class UsernameForm extends ActionForm

{
  	private String fausername;
  	private String faremark;
  	private String mousername;
  	private String fapassword;
  	private String mopassword;
  	private String moremark;
	public void setFausername(String fausername) {
		this.fausername = fausername;
	}
	public String getFausername() {
		return fausername;
	}
	public void setMousername(String mousername) {
		this.mousername = mousername;
	}
	public String getMousername() {
		return mousername;
	}
	public void setFapassword(String fapassword) {
		this.fapassword = fapassword;
	}
	public String getFapassword() {
		return fapassword;
	}
	public void setMopassword(String mopassword) {
		this.mopassword = mopassword;
	}
	public String getMopassword() {
		return mopassword;
	}
	public void setFaremark(String faremark) {
		this.faremark = faremark;
	}
	public String getFaremark() {
		return faremark;
	}
	public void setMoremark(String moremark) {
		this.moremark = moremark;
	}
	public String getMoremark() {
		return moremark;
	}
}
