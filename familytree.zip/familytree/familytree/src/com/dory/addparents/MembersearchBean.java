package com.dory.addparents;

public class MembersearchBean 
{

	private String select;
	private int criteria;
	private int memberid;
	private String membernumber;
	private String membername;
	public void setSelect(String select) {
		this.select = select;
	}
	public String getSelect() {
		return select;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setMembernumber(String membernumber) {
		this.membernumber = membernumber;
	}
	public String getMembernumber() {
		return membernumber;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
	public void setCriteria(int criteria) {
		this.criteria = criteria;
	}
	public int getCriteria() {
		return criteria;
	}
}
