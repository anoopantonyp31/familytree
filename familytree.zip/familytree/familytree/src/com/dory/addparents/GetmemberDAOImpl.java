package com.dory.addparents;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.confidential.ConfidentialBean;
import com.dory.favourites.FavouritesBean;
import com.dory.house.HouseBean;
import com.dory.login.LoginBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalBean;
import com.dory.tree.FamilyBean;
import com.dory.tree.Relation2Bean;


public class GetmemberDAOImpl implements  GetmemberDAO
{

	public Collection displaymember(Session session,ProfileBean getmemberBean)
	{
		MemberidBean memberidBean = new MemberidBean();
		Collection displaymember = new ArrayList();
		try
		{		
			List query = session.createSQLQuery("select * from member_relations ds where fatherid='0' and motherid='0' and spouseid='0' and relationshipid=0").addEntity("ds",MemberidBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						memberidBean = (MemberidBean) it.next();
						int memberid = memberidBean.getMemberid();
						System.out.println("displiiiiiidddddd"+memberid);
						
						List query1 = session.createSQLQuery("select * from member_profile dt where memberid='"+memberid+"'").addEntity("ds",ProfileBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						      {
									System.out.println("displaystandard====Iterator========");
									getmemberBean = (ProfileBean) it1.next();
									System.out.println("displllllllllllllllllllaaaaaaaaaaaaaaaaaaa====="+getmemberBean.getName());
									System.out.println("displllllllllllllllllllaaaaaaaaaaaahouseeeeeeid==="+getmemberBean.getHouseid());
									displaymember.add(getmemberBean);
						      }
			      }
		}
		catch(Exception e)
		{
			
			System.out.println("Exception in memberDao=="+e);
			
		}
		return displaymember;
	}
	
	
	public Collection displaymember1(Session session,ProfileBean getmemberBean,int q)
	{
		//MemberidBean memberidBean = new MemberidBean();
		Collection displaymember = new ArrayList();
		try
		{		
						
						List query1 = session.createSQLQuery("select * from member_profile dt where memberid='"+q+"'").addEntity("dt",ProfileBean.class).list();
						System.out.println("displaystandard====query========"+query1);
								
						      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						      {
									System.out.println("displaystandard====Iterator========");
									getmemberBean = (ProfileBean) it1.next();
									//System.out.println("displllllllllllllllllllaaaaaaaaaaaaaaaaaaa====="+getmemberBean.getMembername());
									System.out.println("displllllllllllllllllllaaaaaaaaaaaahouseeeeeeid==="+getmemberBean.getHouseid());
									displaymember.add(getmemberBean);
						      }
			      
		}
		catch(Exception e)
		{
			
			System.out.println("Exception in memberDaoparenttttttttt=="+e);
			
		}
		return displaymember;
	}
	public Serializable insertfamily(Session session, FamilyBean addfamilyBean) {
		Serializable id;
		session.beginTransaction();
		System.out.println("sososososos");
		id=session.save(addfamilyBean);
		session.getTransaction().commit();
		return id;

	}
	
	public Serializable inserthouse(Session session, HouseBean addhouseBean) {
		Serializable iid;
		session.beginTransaction();
		System.out.println("sososososos");
		iid=session.save(addhouseBean);
		session.getTransaction().commit();
		return iid;

	}
	
	public Serializable inserthouse1(Session session, HouseBean addhouseBean1) {
		Serializable iid1;
		session.beginTransaction();
		System.out.println("sososososos");
		iid1=session.save(addhouseBean1);
		session.getTransaction().commit();
		return iid1;

	}
	
	public Serializable insertmemberprofile(Session session, ProfileBean getmemberBean) {
		Serializable fatherid;
		session.beginTransaction();
		System.out.println("sososososos");
		fatherid=session.save(getmemberBean);
		session.getTransaction().commit();
		return fatherid;

	}
	
	public Serializable insertmemberprofile1(Session session, ProfileBean getmemberBean) {
		Serializable motherid;
		session.beginTransaction();
		System.out.println("sososososos");
		motherid=session.save(getmemberBean);
		session.getTransaction().commit();
		return motherid;

	}
	/*public boolean insertfather(Session session, AddrelationBean relationBean1)
	{
		System.out.println("father memberid daoimpl"+relationBean1.getMemberid());
		session.beginTransaction();
		session.save(relationBean1);
		session.getTransaction().commit();
		return true;
		
	}
	public boolean insertmother(Session session, AddrelationBean relationBean2)
	{
		System.out.println("mother memberid daoimpl"+relationBean2.getMemberid());
		session.beginTransaction();
		session.save(relationBean2);
		session.getTransaction().commit();
		return true;
		
	}*/
	public boolean updatebasefamily(Session session,ProfileBean getmemberBean3,int flyid)
	{
		
		try
		{
			List query1 = session.createSQLQuery("select * from member_profile dt where memberid='"+getmemberBean3.getMemberid()+"'").addEntity("dt",ProfileBean.class).list();
			System.out.println("displaystandard====query========"+query1);
					
			      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			      {
			    	  System.out.println("Exiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii"+getmemberBean3.getMemberid());
			    	  getmemberBean3 = (ProfileBean) it1.next();
			    	  getmemberBean3.setBasefamilyid(flyid);
			    	  System.out.println("Exiiiiiiiiiiiiiiiiiiiiiibaseiddddddiiiiiiiiii"+getmemberBean3.getBasefamilyid());
			    	  
			      }
			      session.beginTransaction();
			      System.out.println("Exiiiiiiiibeforeee transactionnnnnnnnnnnnnnnnnnn"+getmemberBean3.getBasefamilyid());
					session.update(getmemberBean3);
					 System.out.println("Exiiiiiiiibeforeee transactionnnnnafter transanctionnnnnnnnnn");
					session.getTransaction().commit();
					 System.out.println("Essssssssssssssssafter commmmmmmmmmmmmmmmmiittttttttttttttt"); 
		}
		catch(Exception e)
		{
			System.out.println("Exception in updatebasefamilyidDAo=======");
		}
		return true;
	}
	
	
	public boolean updateson(Session session,Relation2Bean relationBean3,int memberidson)
	{
		
		try
		{
			int fatherid=relationBean3.getFatherid();
			int motherid=relationBean3.getMotherid();
			System.out.println("mmmmmmmmmmmmmmmmmmmmmmm"+memberidson);
			List query1 = session.createSQLQuery("select * from member_relations dt where memberid='"+memberidson+"'").addEntity("dt",Relation2Bean.class).list();
			System.out.println("displaystandard====query========"+query1);
					
			      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			      {
			    	  relationBean3 = (Relation2Bean) it1.next();
			    	  System.out.println("displaystandarfffffffffffffffid==="+fatherid);
			    	  relationBean3.setFatherid(fatherid);
			    	  System.out.println("displaystandammmmmmmmmmmmmmmmfid==="+motherid);
			    	  relationBean3.setMotherid(motherid);
			      }
			      session.beginTransaction();
					session.update(relationBean3);
					session.getTransaction().commit();
		}
		catch(Exception e)
		{
			System.out.println("Exception in updateson's relations=======");
		}
		return true;
		
	}
	
	
	public boolean insertaboutme(Session session,AboutBean parentaboutBean1)
	{
		session.beginTransaction();
		session.save(parentaboutBean1);
		session.getTransaction().commit();
		return true;
		
	}
	
	public boolean updatefamember(Session session,ProfileBean getmemberBean3)
	{
		session.beginTransaction();
		session.update(getmemberBean3);
		session.getTransaction().commit();
		return true;
		
		
	}
	public boolean updatemomember(Session session,ProfileBean getmemberBean5)
	{
		session.beginTransaction();
		session.update(getmemberBean5);
		session.getTransaction().commit();
		return true;
		
		
	}
	
	
	public boolean updatefamilyadmin(Session session,FamilyBean addfamilyBean1,int fatherprofileid)
	{
		
		try
		{
			
			List query1 = session.createSQLQuery("select * from family_detail dt where familyid='"+addfamilyBean1.getFamilyid()+"'").addEntity("dt",FamilyBean.class).list();
			System.out.println("displaystandard====query========"+query1);
					
			      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			      {
			    	  addfamilyBean1 = (FamilyBean) it1.next();
			    	  addfamilyBean1.setFamilyadmin(fatherprofileid);
			    	  
			      }
			        session.beginTransaction();
					session.update(addfamilyBean1);
					session.getTransaction().commit();
			
			
		}
		catch(Exception e)
		{
			System.out.println("Exception in updatefamilyiiiiiiiddddao relations=======");
		}
		return true;
	}
	
	public boolean insertconfidential(Session session,ConfidentialBean parentconfidentialBean1)
	{
		session.beginTransaction();
		session.save(parentconfidentialBean1);
		session.getTransaction().commit();
		return true;
		
	}
	
	
	/*public boolean insertcontact(Session session,ParentcontactsBean parentcontactsBean1)
	{
		
		session.beginTransaction();
		session.save(parentcontactsBean1);
		session.getTransaction().commit();
		return true;
		
	}*/
	

	public boolean insertfavourites(Session session,FavouritesBean parentfavouritesBean1)
	{
		
		session.beginTransaction();
		session.save(parentfavouritesBean1);
		session.getTransaction().commit();
		return true;
	}

	
	public boolean insertpersonal(Session session,PersonalBean parentpersonalBean1)
	{
		session.beginTransaction();
		session.save(parentpersonalBean1);
		session.getTransaction().commit();
		return true;
		
	}
	
	public boolean insertlogin(Session session,LoginBean usernameBean1)
	{
		
		session.beginTransaction();
		session.save(usernameBean1);
		session.getTransaction().commit();
		return true;
		
	}

	
	public Collection login(Session session,LoginBean usernameBean,String fauname)
	{
		Collection login = new ArrayList();
		try
		{
			List query1 = session.createSQLQuery("select * from member_login dt where username='"+fauname+"'").addEntity("dt",LoginBean.class).list();
			System.out.println("displaystandard====query========"+query1);
					
			      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			      {
			    	  usernameBean = (LoginBean) it1.next();
			    	  login.add(usernameBean);  
			      }
			
			
		}
		catch(Exception e)
		{
			System.out.println("EXCEPTION IN LOGIN CHECK"+e);
		}
		return login;
	}
	
	
	public boolean loginupdate(Session session,LoginBean usernameBean2,int id)
	{
	 try
	 {
		 String username = usernameBean2.getUname();
		 String passwrd = usernameBean2.getPass();
		 String remark = usernameBean2.getRemark();
		 
		 List query1 = session.createSQLQuery("select * from member_login dt where memberid='"+id+"'").addEntity("dt",LoginBean.class).list();
			System.out.println("displaystandard====query========"+query1);
					
			      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			      {
			    	  usernameBean2 = (LoginBean) it1.next();
			    	  usernameBean2.setIsactive(1);
			    	  usernameBean2.setUname(username);
			    	  usernameBean2.setPass(passwrd);
			    	  usernameBean2.setRemark(remark);
			    	  usernameBean2.setUsertype("user");
			    	  
			      }
			      session.beginTransaction();
				  session.update(usernameBean2);
				  session.getTransaction().commit();

		 
	 }
	 
		catch(Exception e)
		{
		 
			System.out.println("Exception in login udatedadadaddao"+e);
			
		}
		return true;
	}
	
	public boolean loginupdate1(Session session,LoginBean usernameBean3,int id)
	{
	 try
	 {
		 String username = usernameBean3.getUname();
		 String passwrd = usernameBean3.getPass();
		 String remark = usernameBean3.getRemark();
		 
		 List query1 = session.createSQLQuery("select * from member_login dt where memberid='"+id+"'").addEntity("dt",LoginBean.class).list();
			System.out.println("displaystandard====query========"+query1);
					
			      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			      {
			    	  usernameBean3 = (LoginBean) it1.next();
			    	  usernameBean3.setIsactive(1);
			    	  usernameBean3.setUname(username);
			    	  usernameBean3.setPass(passwrd);
			    	  usernameBean3.setRemark(remark);
			    	  usernameBean3.setUsertype("user");
			    	  
			      }
			      session.beginTransaction();
				  session.update(usernameBean3);
				  session.getTransaction().commit();

		 
	 }
	 
		catch(Exception e)
		{
		 
			System.out.println("Exception in login udatedadadaddao"+e);
			
		}
		return true;
	}
	
	
	public Collection displaymemberbynumber(Session session,MembersearchBean membersearchBean,String membernumber)
	{
		Collection names = new ArrayList();
		try
		{
			
			List query1 = session.createSQLQuery("select * from member_profile dt where membernumber='"+membernumber+"'").addEntity("dt",MembersearchBean.class).list();
			System.out.println("displaystandard====query========"+query1);
					
			      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			      {
			    	  membersearchBean = (MembersearchBean) it1.next();
			    	  names.add(membersearchBean);
			      }
		}
		
		catch (Exception e) 
		{
		
			System.out.println("Exception in member numberDAO=========="+e);
			
		}
		return names;
	}
	
	public Collection displaymemberbyname(Session session,MembersearchBean membersearchBean,String member)
	{
		Collection names = new ArrayList();
		try
		{
			List query = session.createQuery("from MembersearchBean ex where ex.membername like'%"+member+"%'")
			.list();
	System.out.println("====queryyyy=====> "+query);
	for (Iterator it = query.iterator(); it.hasNext();) 
	{
		System.out.println("serching results============ ");	
		membersearchBean = (MembersearchBean) it.next();
		names.add(membersearchBean);
	}
			
			
		}
		catch (Exception e) 
		{
			System.out.print("exception in membernamedao============"+e);
		}
		return names;
	}
	
	public boolean updateusertype(Session session,LoginBean usernameBean,int memberid)
	{
		try
		{
			List query1 = session.createSQLQuery("select * from member_login dt where memberid='"+memberid+"'").addEntity("dt",LoginBean.class).list();
			System.out.println("displaystandard====query========"+query1);
					
			      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			      {
			    	  usernameBean = (LoginBean) it1.next();
			    	  usernameBean.setUsertype("user");
			    	  
			      }
			      session.beginTransaction();
				  session.update(usernameBean);
				  session.getTransaction().commit();
			
		}
		
		catch (Exception e)
		{
			System.out.println("EXXXXXXXXXXXXXXX"+e);
		}
		return true;
	}
	
}