package com.dory.addparents;

import org.apache.struts.action.ActionForm;

public class GetmemberForm extends ActionForm 
{

	 private int memberid;
	 private String membername;
	 private String address;
	 private String fathername;
	 private String mothername;
	 private int basefamilyid;
	 private int houseid;
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}

	public void setFathername(String fathername) {
		this.fathername = fathername;
	}
	public String getFathername() {
		return fathername;
	}
	public void setMothername(String mothername) {
		this.mothername = mothername;
	}
	public String getMothername() {
		return mothername;
	}

	public void setBasefamilyid(int basefamilyid) {
		this.basefamilyid = basefamilyid;
	}
	public int getBasefamilyid() {
		return basefamilyid;
	}
	public void setHouseid(int houseid) {
		this.houseid = houseid;
	}
	public int getHouseid() {
		return houseid;
	}
}
