package com.dory.addparents;

public class MemberidBean
{

	private  int relationid;
	private int memberid;
	public void setRelationid(int relationid) {
		this.relationid = relationid;
	}
	public int getRelationid() {
		return relationid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
}
