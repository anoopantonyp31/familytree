package com.dory.addparents;

import java.io.Serializable;
import java.util.Collection;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.confidential.ConfidentialBean;
import com.dory.favourites.FavouritesBean;
import com.dory.house.HouseBean;
import com.dory.login.LoginBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalBean;
import com.dory.tree.FamilyBean;
import com.dory.tree.Relation2Bean;


public interface GetmemberDAO 

{

	public Collection displaymember(Session session,ProfileBean getmemberBean);
	public Collection displaymember1(Session session,ProfileBean getmemberBean,int q);
	
	public Serializable inserthouse(Session session, HouseBean addhouseBean); 
	public Serializable inserthouse1(Session session, HouseBean addhouseBean1); 
	public Serializable insertfamily(Session session, FamilyBean addfamilyBean); 
	public Serializable insertmemberprofile(Session session, ProfileBean getmemberBean);
	//public boolean insertfather(Session session, AddrelationBean relationBean1); 
	//public boolean insertmother(Session session, AddrelationBean relationBean2);
	public boolean updatebasefamily(Session session,ProfileBean getmemberBean3,int flyid);
	public boolean updateson(Session session,Relation2Bean relationBean3,int memberidson);
	public boolean insertaboutme(Session session,AboutBean parentaboutBean1);
	public boolean updatefamember(Session session,ProfileBean getmemberBean3);
	public boolean updatemomember(Session session,ProfileBean getmemberBean5);
	public boolean updatefamilyadmin(Session session,FamilyBean addfamilyBean1,int fatherprofileid);
	public boolean insertconfidential(Session session,ConfidentialBean parentconfidentialBean1);
	//public boolean insertcontact(Session session,ParentcontactsBean parentcontactsBean1);
	public boolean insertfavourites(Session session,FavouritesBean parentfavouritesBean1);
	public boolean insertpersonal(Session session,PersonalBean parentpersonalBean1);
	public boolean insertlogin(Session session,LoginBean usernameBean1);
	public Collection login(Session session,LoginBean usernameBean,String fauname);
	public boolean loginupdate(Session session,LoginBean usernameBean2,int id); 
	public boolean loginupdate1(Session session,LoginBean usernameBean2,int id);
	public Collection displaymemberbynumber(Session session,MembersearchBean membersearchBean,String membernumber);
	public Collection displaymemberbyname(Session session,MembersearchBean membersearchBean,String member);
	public boolean updateusertype(Session session,LoginBean usernameBean,int memberid);
	
	

}