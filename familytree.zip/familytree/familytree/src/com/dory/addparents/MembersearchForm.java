package com.dory.addparents;

import org.apache.struts.action.ActionForm;

public class MembersearchForm extends ActionForm
{

	private int criteria;
	private String select;
	public void setCriteria(int criteria) {
		this.criteria = criteria;
	}
	public int getCriteria() {
		return criteria;
	}
	public void setSelect(String select) {
		this.select = select;
	}
	public String getSelect() {
		return select;
	}
}
