package com.dory.addparents;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.login.LoginBean;

public class UsernameAction extends Action
{

	

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
	String target = null;
	try {
		if (form != null)
		{

			LoginBean usernameBean = new LoginBean();
			LoginBean usernameBean1 = new LoginBean();
			LoginBean usernameBean2 = new LoginBean();
			LoginBean usernameBean3 = new LoginBean();
			HttpSession httpsession = request.getSession();
			UsernameForm usernameForm = (UsernameForm) form;		

			Session session = HibernateUtil.getSessionFactory()
					.openSession();

             GetmemberDAOImpl getmemberDAOImpl = new GetmemberDAOImpl();
             String fauname = usernameForm.getFausername();
             String mouname = usernameForm.getMousername();
             Collection login = getmemberDAOImpl.login(session,usernameBean,fauname);
             
             
             if(login.size()>0)
             {
            	 
            	 request.setAttribute("fausername", "fausername");
            	 target="username";
             }
             
             Collection login1 = getmemberDAOImpl.login(session,usernameBean1,mouname);
             
             if(login1.size()>0)
             {
            	 
            	 request.setAttribute("mousername", "mousername");
            	 target="username";
             }
             if(login.isEmpty() && login1.isEmpty())
             {
            	 HttpSession httpsessionfaid = request.getSession();
            	 HttpSession httpsessionmoid = request.getSession();
            	 
            	 
            	 String fathid=(String)httpsessionfaid.getAttribute("fatherid").toString();
            	 
				 int fatherid=Integer.parseInt(fathid);
				 System.out.println("iiiiiiiiiidddddddddddddddddddd"+fatherid);
				 String mothid=(String)httpsessionmoid.getAttribute("motherid").toString();
				 int motherid=Integer.parseInt(mothid);
            	 
            	 
  
            	 usernameBean2.setPass(usernameForm.getFapassword());
            	 usernameBean2.setUname(usernameForm.getFausername());
            	 usernameBean2.setRemark(usernameForm.getFaremark());

				 
            	 getmemberDAOImpl.loginupdate(session,usernameBean2,fatherid);
            	 
            
            	 usernameBean3.setPass(usernameForm.getMopassword());
            	 usernameBean3.setUname(usernameForm.getMousername());
            	 usernameBean3.setRemark(usernameForm.getMoremark());
           
            	 getmemberDAOImpl.loginupdate1(session,usernameBean3,motherid);
            	 target="parent";
             }

                	
                	
                	
                 }
             
		
		}
		catch (Exception e) 
		{
		System.out.println("Exception=====>" + e);
		target="failure";
		}

	return (mapping.findForward(target));
	}
	
}
