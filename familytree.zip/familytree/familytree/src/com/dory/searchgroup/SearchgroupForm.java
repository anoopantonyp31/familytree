package com.dory.searchgroup;

import org.apache.struts.action.ActionForm;

public class SearchgroupForm extends ActionForm  {
	
	private String groupname;
	private int groupid;
	private String data;
	private String aboutgroup;
	private String groupcategory;
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}
	public int getGroupid() {
		return groupid;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}
	public void setAboutgroup(String aboutgroup) {
		this.aboutgroup = aboutgroup;
	}
	public String getAboutgroup() {
		return aboutgroup;
	}
	public void setGroupcategory(String groupcategory) {
		this.groupcategory = groupcategory;
	}
	public String getGroupcategory() {
		return groupcategory;
	}
	
	
}
