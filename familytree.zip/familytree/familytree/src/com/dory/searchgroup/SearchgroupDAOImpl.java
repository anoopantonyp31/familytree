package com.dory.searchgroup;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.searchmember.SearchmemberBean;

public class SearchgroupDAOImpl {

	

	public Collection searchgroup(Session session, SearchgroupBean  searchgroupBean,String dat,int q) 
	{
			

		Collection memsearch = new ArrayList();
		try {
			List query = session.createQuery("from SearchgroupBean ex where ex.groupname like'%"+dat+"%' and ex.groupowner='"+q+"'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("serching results============ ");	
				searchgroupBean = (SearchgroupBean) it.next();
				memsearch.add(searchgroupBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return memsearch;
	}
}
