package com.dory.searchgroup;

public class SearchgroupBean {

	private String groupname;
	private int groupid;
	private int groupowner;
	
	private String aboutgroup;
	private String groupcategory;
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}
	public int getGroupid() {
		return groupid;
	}
	public void setAboutgroup(String aboutgroup) {
		this.aboutgroup = aboutgroup;
	}
	public String getAboutgroup() {
		return aboutgroup;
	}
	public void setGroupcategory(String groupcategory) {
		this.groupcategory = groupcategory;
	}
	public String getGroupcategory() {
		return groupcategory;
	}
	public void setGroupowner(int groupowner) {
		this.groupowner = groupowner;
	}
	public int getGroupowner() {
		return groupowner;
	}
	
	
}
