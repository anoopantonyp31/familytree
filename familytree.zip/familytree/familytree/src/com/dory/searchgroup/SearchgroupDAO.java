package com.dory.searchgroup;

public interface SearchgroupDAO {

}
