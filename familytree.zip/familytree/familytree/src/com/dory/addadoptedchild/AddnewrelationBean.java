package com.dory.addadoptedchild;

public class AddnewrelationBean 
{
private int relationshipid;
private int relationselect;
private String relationship;
public void setRelationshipid(int relationshipid) {
	this.relationshipid = relationshipid;
}
public int getRelationshipid() {
	return relationshipid;
}
public void setRelationship(String relationship) {
	this.relationship = relationship;
}
public String getRelationship() {
	return relationship;
}
public void setRelationselect(int relationselect) {
	this.relationselect = relationselect;
}
public int getRelationselect() {
	return relationselect;
}

}
