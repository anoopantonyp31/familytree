package com.dory.addadoptedchild;
import org.apache.struts.action.ActionForm;
public class AddadoptedchildForm extends ActionForm
{
private int memberid;
private String name;
private String sex;
private String m;
private String f;
private String dob;
private int adoptedby;
private String self;
private String couple;
private int spouseselect; 
private int relation; 
private int spouseid; 
private String uname; 
private String pass;
private String childname;
private int relationshipid;
private String relationship;
private int relationselect;
private String newrelation;
public void setMemberid(int memberid) {
	this.memberid = memberid;
}
public int getMemberid() {
	return memberid;
}
public void setSex(String sex) {
	this.sex = sex;
}
public String getSex() {
	return sex;
}
public void setM(String m) {
	this.m = m;
}
public String getM() {
	return m;
}
public void setF(String f) {
	this.f = f;
}
public String getF() {
	return f;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getDob() {
	return dob;
}
public void setSelf(String self) {
	this.self = self;
}
public String getSelf() {
	return self;
}
public void setCouple(String couple) {
	this.couple = couple;
}
public String getCouple() {
	return couple;
}
public void setSpouseselect(int spouseselect) {
	this.spouseselect = spouseselect;
}
public int getSpouseselect() {
	return spouseselect;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getUname() {
	return uname;
}
public void setPass(String pass) {
	this.pass = pass;
}
public String getPass() {
	return pass;
}
public void setSpouseid(int spouseid) {
	this.spouseid = spouseid;
}
public int getSpouseid() {
	return spouseid;
}
public void setChildname(String childname) {
	this.childname = childname;
}
public String getChildname() {
	return childname;
}
public void setName(String name) {
	this.name = name;
}
public String getName() {
	return name;
}
public void setAdoptedby(int adoptedby) {
	this.adoptedby = adoptedby;
}
public int getAdoptedby() {
	return adoptedby;
}
public void setRelationshipid(int relationshipid) {
	this.relationshipid = relationshipid;
}
public int getRelationshipid() {
	return relationshipid;
}
public void setRelationship(String relationship) {
	this.relationship = relationship;
}
public String getRelationship() {
	return relationship;
}
public void setRelationselect(int relationselect) {
	this.relationselect = relationselect;
}
public int getRelationselect() {
	return relationselect;
}
public void setNewrelation(String newrelation) {
	this.newrelation = newrelation;
}
public String getNewrelation() {
	return newrelation;
}
public void setRelation(int relation) {
	this.relation = relation;
}
public int getRelation() {
	return relation;
} 

}


