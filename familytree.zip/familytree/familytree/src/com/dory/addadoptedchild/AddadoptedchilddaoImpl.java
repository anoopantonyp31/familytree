package com.dory.addadoptedchild;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.confidential.ConfidentialBean;
import com.dory.contact.ContactsBean;
import com.dory.login.LoginBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalBean;
import com.dory.tree.Relation2Bean;

public class AddadoptedchilddaoImpl 
{
	public Serializable insert(Session session, ProfileBean addadoptedchildBean) {
		Serializable id;
		session.beginTransaction();
		System.out.println("sososososos");
		id=session.save(addadoptedchildBean);
		session.getTransaction().commit();
		return id;
}
	public boolean insert1(Session session, LoginBean loginBean)
	{
		session.beginTransaction();
		session.save(loginBean);
		session.getTransaction().commit();
		return true;
		
	}
	public boolean insertrelation(Session session, Relation2Bean relationBean)
	{
		session.beginTransaction();
		session.save(relationBean);
		session.getTransaction().commit();
		return true;
		
	}
	public boolean insertabout(Session session, AboutBean aboutBean)
	{
		session.beginTransaction();
		session.save(aboutBean);
		session.getTransaction().commit();
		return true;
		
	}
	public boolean insertconfidential(Session session, ConfidentialBean confidentialBean)
	{
		session.beginTransaction();
		session.save(confidentialBean);
		session.getTransaction().commit();
		return true;
		
	}	
	public boolean insertcontact(Session session, ContactsBean adoptedchildcontactBean)
	{
		session.beginTransaction();
		session.save(adoptedchildcontactBean);
		session.getTransaction().commit();
		return true;		
	}
	public boolean insertpersonal(Session session, PersonalBean personalBean)
	{
		session.beginTransaction();
		session.save(personalBean);
		session.getTransaction().commit();
		return true;
		
	}
	public boolean insertnewrelation(Session session, AddnewrelationBean addnewrelationBean)
	{
		session.beginTransaction();
		session.save(addnewrelationBean);
		session.getTransaction().commit();
		return true;
		
	}
	public Collection displayspouse(Session session,Relation2Bean relationBean,int d)
	{
		//MemberidBean memberidBean = new MemberidBean();
		Collection spouse = new ArrayList();
		ProfileBean profileBean= new ProfileBean();
		try
		{	
			
			List query1 = session.createSQLQuery("select * from member_relations dt where spouseid='"+d+"'").addEntity("dt",Relation2Bean.class).list();
			        for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						  {
			        	System.out.println("geinthe n11111111111111111111 querryyyyyyyy");
									relationBean = (Relation2Bean) it1.next();	
									System.out.println("geinthe n1111==============================="+relationBean.getSpouseid());
									System.out.println("geinthe n1111=====nmememmee=========================="+relationBean.getMemberid());
									List query2 = session.createSQLQuery("select * from member_profile pt where memberid='"+relationBean.getMemberid()+"'").addEntity("pt",ProfileBean.class).list();
							        for (Iterator it2 = query2.iterator(); it2.hasNext();) 
										  {
							        	
							        	profileBean = (ProfileBean) it2.next();
							        	System.out.println("getN67u67u7ji7kjyukj"+profileBean.getName());
							        	relationBean.setName(profileBean.getName());
							        	System.out.println("getName=="+relationBean.getName());	
							        	System.out.println("getName=="+relationBean.getName());								        	
										System.out.println("getSpouseid=="+relationBean.getSpouseid());	
										  }
							        
							        spouse.add(relationBean);
									
						  }
		}
		catch(Exception e)
		{
			
			System.out.println("Exception in memberDaoparenttttttttt=="+e);
			
		}
		return spouse;
	}
	public Collection displaycheklogin(Session session,LoginBean loginBean,String user)
	{
		
		
		Collection cheklogin=new ArrayList();
		List query = session.createSQLQuery("select * from member_login ds where username='"+user+"'").addEntity("ds",LoginBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
        {
    	  loginBean = (LoginBean) it.next();  
    	  cheklogin.add(loginBean);
		}
      
      return cheklogin;
	}
	public Collection displaychekmale(Session session,ProfileBean profileBean,int mid)
	{
		
		
		Collection chekmale=new ArrayList();
		List query = session.createSQLQuery("select * from member_profile ks where memberid='"+mid+"'").addEntity("ks",ProfileBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
        {
    	  profileBean = (ProfileBean) it.next();  
    	  chekmale.add(profileBean);
		}
      System.out.println("impl sex=="+ profileBean.getSex());
     
      return chekmale;
	}
	
	public Collection displayfamily(Session session,Relation2Bean relationBean1,int mid)
	{
		
		
		Collection family=new ArrayList();
		List query = session.createSQLQuery("select * from member_relations bs where memberid='"+mid+"'").addEntity("bs",Relation2Bean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
        {
    	  relationBean1 = (Relation2Bean) it.next();  
    	  System.out.println("after target==fafafafafammiiiiiiiiilyidaooooooo==========="+relationBean1.getFamilyid());
			 
    	 family.add(relationBean1);
		}
      System.out.println("impl sex=="+ relationBean1.getFamilyid());
     
      return family;
	}	
	
	public Collection displayrelation(Session session,AddnewrelationBean addnewrelationBean)
	{
		
		
		Collection relation=new ArrayList();
		List query = session.createSQLQuery("select * from relations ys").addEntity("ys",AddnewrelationBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
        {
    	  addnewrelationBean = (AddnewrelationBean) it.next();  
    	  System.out.println("after target==fafafafafammiiiiiiiiilyidaooooooo==========="+addnewrelationBean.getRelationship());
			 
    	  relation.add(addnewrelationBean);
		}
      System.out.println("impl sex=="+ addnewrelationBean.getRelationshipid());
     
      return relation;
	}	
	
	
	public Collection displayspousehead(Session session,Relation2Bean relationBean,int d)
	{
		//MemberidBean memberidBean = new MemberidBean();
		Collection spouse = new ArrayList();
		ProfileBean profileBean= new ProfileBean();
		try
		{	
			
			List query1 = session.createSQLQuery("select * from member_relations dt where memberid='"+d+"'").addEntity("dt",Relation2Bean.class).list();
			        for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						  {
			        	System.out.println("geinthe n11111111111111111111 querryyyyyyyy");
									relationBean = (Relation2Bean) it1.next();	
									System.out.println("geinthe n1111==============================="+relationBean.getSpouseid());
									System.out.println("geinthe n1111=====nmememmee=========================="+relationBean.getMemberid());
									List query2 = session.createSQLQuery("select * from member_profile pt where memberid='"+relationBean.getSpouseid()+"'").addEntity("pt",ProfileBean.class).list();
							        for (Iterator it2 = query2.iterator(); it2.hasNext();) 
										  {
							        	
							        	profileBean = (ProfileBean) it2.next();
							        	System.out.println("getN67u67u7ji7kjyukj"+profileBean.getName());
							        	relationBean.setName(profileBean.getName());
							        	System.out.println("getName=="+relationBean.getName());	
							        	System.out.println("getName=="+relationBean.getName());								        	
										System.out.println("getSpouseid=="+relationBean.getSpouseid());	
										  }
							        
							        spouse.add(relationBean);
									
						  }
		}
		catch(Exception e)
		{
			
			System.out.println("Exception in memberDaoparenttttttttt=="+e);
			
		}
		return spouse;
	}
}
