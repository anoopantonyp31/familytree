package com.dory.addadoptedchild;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.confidential.ConfidentialBean;
import com.dory.contact.ContactsBean;
import com.dory.hibernate.HibernateUtil;
import com.dory.login.LoginBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalBean;
import com.dory.tree.Relation2Bean;
import com.dory.tree.TreeDAO;
import com.dory.tree.TreeDAOImpl;
public class AddadoptedchildAction extends DispatchAction
	{
		
		//display relations to combobox
		public ActionForward displyspouse(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception 
				{
			String target =null;
			try {
				
				if (form != null) 
				{

					AddadoptedchildForm addadoptedchildForm =(AddadoptedchildForm)form;				
					//RelationBean relationBean= new RelationBean();
					Relation2Bean relationBean= new Relation2Bean();
					
					AddnewrelationBean addnewrelationBean= new AddnewrelationBean();
					BeanUtils.copyProperties(relationBean,addadoptedchildForm);
					
					Session session = HibernateUtil.getSessionFactory()
					.openSession();
					HttpSession httpsession = request.getSession();
					String r=(String)httpsession.getAttribute("mid").toString();
					int d=Integer.parseInt(r);
					
					AddadoptedchilddaoImpl addadoptedchilddaoImpl=new AddadoptedchilddaoImpl();
					// Spouse Relation Combo
		             Collection relation = addadoptedchilddaoImpl.displayrelation(session,addnewrelationBean); 
		             for (Iterator iterator = relation.iterator(); iterator.hasNext();) 
	    	          { 
		            	 addnewrelationBean = (AddnewrelationBean) iterator.next();
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationshipid());
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationship());
					  }
		             
					
			        System.out.println("session======111111=====>"+session);
			        request.setAttribute("relation", relation);
			        request.setAttribute("newrelations", "newrelations");			        
			       request.setAttribute("spousenot", "spousenot");
					}
			
				 target="adopt";
				 System.out.println("after target=====>"+target);
	}
			

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}
			 System.out.println("after findForward=====>"+target);
			return (mapping.findForward(target));
			
			}

		public ActionForward insert(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception 
				{
			String target =null;
			try {
				
				if (form != null) 
				{

					AddadoptedchildForm addadoptedchildForm =(AddadoptedchildForm)form;
					ProfileBean addadoptedchildBean= new ProfileBean();
					ProfileBean profilebean = new ProfileBean();
					TreeDAO treedao = new TreeDAOImpl();
					//RelationBean relationBean= new RelationBean();
					ContactsBean contactsBean = new ContactsBean();
					Relation2Bean relationBean= new Relation2Bean();
					Relation2Bean relationBean1= new Relation2Bean();
					//AdoptedrelationBean relationBean1= new AdoptedrelationBean();
					PersonalBean personalBean=new PersonalBean(); 
					AboutBean aboutBean= new AboutBean(); 
					BeanUtils.copyProperties(relationBean,addadoptedchildForm);
					LoginBean loginBean = new LoginBean();
					ConfidentialBean confidentialBean= new ConfidentialBean();
					ProfileBean profileBean = new ProfileBean();
					HttpSession httpsession = request.getSession();
					String r=(String)httpsession.getAttribute("mid").toString();
					int mid=Integer.parseInt(r);
					String famid=(String)httpsession.getAttribute("famid").toString();
					int familyid=Integer.parseInt(famid);
					Session session = HibernateUtil.getSessionFactory().openSession();
					AddadoptedchilddaoImpl addadoptedchilddaoImpl=new AddadoptedchilddaoImpl();
					String user=addadoptedchildForm.getUname();
					Collection cheklogin = addadoptedchilddaoImpl.displaycheklogin(session,loginBean,user); 
					for (Iterator iterator = cheklogin.iterator(); iterator.hasNext();) 
	    	          { 
						loginBean = (LoginBean) iterator.next();	
			        	
	    		      }
					 Collection family = addadoptedchilddaoImpl.displayfamily(session,relationBean1,mid); 
		             for (Iterator iterator = family.iterator(); iterator.hasNext();) 
	    	          { 
						 relationBean1 = (Relation2Bean) iterator.next();
						 System.out.println("after target==fafafafafammiiiiiiiiilyidaction==========="+relationBean1.getFamilyid());
					  }
		             int fid=relationBean1.getFamilyid();		             
					if(cheklogin.isEmpty())
					{		
						//member profile
					    addadoptedchildBean.setName(addadoptedchildForm.getName());					    
					    Date dob=new SimpleDateFormat("dd-MM-yyyy").parse(addadoptedchildForm.getDob());					    
					    addadoptedchildBean.setDob(dob);
					    addadoptedchildBean.setBasefamilyid(fid);
					    addadoptedchildBean.setSex(addadoptedchildForm.getSex());	
			             Serializable id=addadoptedchilddaoImpl.insert(session,addadoptedchildBean);
			             //updation of member number
			             int idd = (Integer) id;
			             profilebean = treedao.profile(session, idd);
			 		    String membernumber = Integer.toString(idd);
			 		    profilebean.setMembernumber(membernumber);
			 		    treedao.updatememnumber(session, profilebean);
			             //Login insert
			             int member=(Integer)id;
			             System.out.println("memberid target=====>"+member);
			             loginBean.setUname(addadoptedchildForm.getUname());
						 loginBean.setPass(addadoptedchildForm.getPass());
						 loginBean.setUsertype("user");
						 loginBean.setIsactive(1);
						 loginBean.setMemberid(member);
						 
					     addadoptedchilddaoImpl.insert1(session,loginBean);
					     //Relation insert
					     Collection chekmale = addadoptedchilddaoImpl.displaychekmale(session,profileBean,mid);					     
					     
							for (Iterator iterator = chekmale.iterator(); iterator.hasNext();) 
			    	          { 
								profileBean = (ProfileBean) iterator.next();
			    		      } 							
							 
							
							String sex=profileBean.getSex();
							if(sex.equals("m"))
							{	
								
								System.out.println("after target==inside maleeeeee=="+fid);
								int t=addadoptedchildForm.getRelationselect();
								if(t==1)
								{
									relationBean.setFatherid(mid);
									int s=addadoptedchildForm.getSpouseselect();
									relationBean.setMotherid(s);
									System.out.println("after tradiooooooooo=="+s);
								}
								else
								{
									relationBean.setFatherid(0);									
									relationBean.setMotherid(0);									
								}
								
								relationBean.setMemberid(member);
								relationBean.setRelatshipid(addadoptedchildForm.getRelationselect());
								System.out.println("after relationnnnnnnnn=="+relationBean.getRelatshipid());
								relationBean.setFamilyid(fid);
								System.out.println("after target==inside fmalllllllrelationBean.setFamilyid(fid);"+relationBean.getFamilyid());	
								addadoptedchilddaoImpl.insertrelation(session,relationBean);
							}
							if(sex.equals("f"))
							{
								int s=addadoptedchildForm.getSpouseselect();
								System.out.println("after tradiooooooooo=="+s);
								System.out.println("after target==inside ffffffffeeeeemaleeeeee=="+fid);
								int t=addadoptedchildForm.getRelationselect();
								if(t==1)
								{
									relationBean.setMotherid(mid);
									relationBean.setFatherid(s);
								}
								else
								{
									relationBean.setMotherid(0);
									relationBean.setFatherid(0);
								}
								relationBean.setMemberid(member);							
								relationBean.setRelatshipid(addadoptedchildForm.getRelationselect());
								System.out.println("after relationnnnnnnnn=="+relationBean.getRelatshipid());
								relationBean.setFamilyid(fid);	
								System.out.println("after target==inside fffffrelationBean.setFamilyid(fid);"+relationBean.getFamilyid());	
								addadoptedchilddaoImpl.insertrelation(session,relationBean);
							}
							//insert About Member
							aboutBean.setMemberid(member);
							aboutBean.setVisibility("0");
							addadoptedchilddaoImpl.insertabout(session,aboutBean);
							//insert confidential permenent table
							confidentialBean.setMemberid(member);
							addadoptedchilddaoImpl.insertconfidential(session,confidentialBean);
							//insert Member contact details
							
							profileBean = treedao.profile(session, member);
							contactsBean.setProfile(profileBean);
							contactsBean.setVisibility("0");
							
							/*adoptedchildcontactBean.setMemberid(member);
							adoptedchildcontactBean.setVisibility("0");*/
							addadoptedchilddaoImpl.insertcontact(session,contactsBean);
							//insert Personal details
							personalBean.setMemberid(member);
							personalBean.setMaritalstatus(0);
							personalBean.setVisibility("0");
							addadoptedchilddaoImpl.insertpersonal(session,personalBean);
							int head = treedao.findhead(session,familyid);
							Collection members = treedao.viewmembers(session, familyid,head);
						    System.out.println("After viewmember function=====>"
							    + members.size());
						    request.setAttribute("view", members);
							 target="success";
					}
					else
					{
						System.out.println("request.setAttribute(username, username);=====>");
						request.setAttribute("username", "username");
						target="username";
					}
					}
			
				
				 System.out.println("after target=====>"+target);
	}
			

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}
			 System.out.println("after findForward=====>"+target);
			return (mapping.findForward(target));
			
			}
		//disply is couple
		
		public ActionForward disply(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception 
				{
			String target =null;
			try {
				
				if (form != null) 
				{

					AddadoptedchildForm addadoptedchildForm =(AddadoptedchildForm)form;
					//AddadoptedchildBean addadoptedchildBean= new AddadoptedchildBean();
					AddnewrelationBean addnewrelationBean= new AddnewrelationBean();
					//RelationBean relationBean= new RelationBean();
					Relation2Bean relationBean= new Relation2Bean();
					TreeDAOImpl treedao = new TreeDAOImpl();
					BeanUtils.copyProperties(relationBean,addadoptedchildForm);	
					
					Session session = HibernateUtil.getSessionFactory()
					.openSession();
					HttpSession httpsession = request.getSession();
					String r=(String)httpsession.getAttribute("mid").toString();
					int d=Integer.parseInt(r);
					String familyid=(String)httpsession.getAttribute("famid").toString();
					int famid=Integer.parseInt(familyid);
					String usertype = (String)httpsession.getAttribute("utype").toString();
					System.out.println("session======111111=====>"+session);
					//profileBean.setMemberid(d);
			        System.out.println("session======111String familyid=(String)httpsession.getAttribute(famid).toString();111=====>"+famid);
			        AddadoptedchilddaoImpl addadoptedchilddaoImpl=new AddadoptedchilddaoImpl();	
			        
			        Collection relation = addadoptedchilddaoImpl.displayrelation(session,addnewrelationBean); 
		             for (Iterator iterator = relation.iterator(); iterator.hasNext();) 
	    	          { 
		            	 addnewrelationBean = (AddnewrelationBean) iterator.next();
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationshipid());
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationship());
					  }
		            int head = treedao.findhead(session,famid);
		            System.out.println("head head head head head head head head head head head head head ======"+head);
		            if("sadmin".equals(usertype))
		            {
		            	System.out.println("after ifsaddddmmmmmminnnnnnnnnlationnnnnnnn da iiiifffffffffffffffffffffffffffffffff");
		            	 Collection spouse = addadoptedchilddaoImpl.displayspouse(session,relationBean,d);
				         request.setAttribute("spouse", spouse);
		            }
		            	
		            else if(head==d)
		            {
		            	System.out.println("after if(head==d)==fRelationnnnnnnn da iiiifffffffffffffffffffffffffffffffff");
		            	 Collection spouse = addadoptedchilddaoImpl.displayspouse(session,relationBean,d);
				         request.setAttribute("spouse", spouse);
		            	
		            }
		            else
		            {
		            	System.out.println("after if(else==d)==fRelationnnnnnnn da elllsssssssssssssssssss");
		            	Collection spouse = addadoptedchilddaoImpl.displayspousehead(session,relationBean,d);
		                request.setAttribute("spouse", spouse);
		            }
	/*		       	
			        for (Iterator iterator = spouse.iterator(); iterator.hasNext();) 
	    	          { 
			        	relationBean = (Relation2Bean) iterator.next();	
			        	 System.out.println("session======111111"+relationBean.getSpouseid());
	    		      }*/
			        addadoptedchildForm.setSpouseid(relationBean.getSpouseid());
			        System.out.println("session======getSpouseid"+relationBean.getSpouseid());
			        addadoptedchildForm.setName(relationBean.getName());
			        System.out.println("session======getName"+relationBean.getName());
			   
			        request.setAttribute("relation", relation);
			        request.setAttribute("newrelations", "newrelations");	
					}
			
				 target="adopt";
				 System.out.println("after target=====>"+target);
	}
			

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}
			 System.out.println("after findForward=====>"+target);
			return (mapping.findForward(target));
			
			}
		//display new relation
		public ActionForward newrelation(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception 
				{
			String target =null;
			try {
				
				if (form != null) 
				{
					AddadoptedchildForm addadoptedchildForm =(AddadoptedchildForm)form;
					AddnewrelationBean addnewrelationBean= new AddnewrelationBean();
					BeanUtils.copyProperties(addnewrelationBean,addadoptedchildForm);
					Session session = HibernateUtil.getSessionFactory()
					.openSession();
					 AddadoptedchilddaoImpl addadoptedchilddaoImpl=new AddadoptedchilddaoImpl();	
					 Collection relation = addadoptedchilddaoImpl.displayrelation(session,addnewrelationBean); 
		             for (Iterator iterator = relation.iterator(); iterator.hasNext();) 
	    	          { 
		            	 addnewrelationBean = (AddnewrelationBean) iterator.next();
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationshipid());
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationship());
					  }		            
					 request.setAttribute("spousenot","spousenot"); 					 
				     request.setAttribute("relation", relation);

					}
			
				 target="adopt";
				 System.out.println("after target=====>"+target);
	}
			

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}
			 System.out.println("after findForward=====>"+target);
			return (mapping.findForward(target));
			
			}
		//is adopt self 
		public ActionForward spouse(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception 
				{
			String target =null;
			try {
				
				if (form != null) 
				{
					AddadoptedchildForm addadoptedchildForm =(AddadoptedchildForm)form;
					AddnewrelationBean addnewrelationBean= new AddnewrelationBean();
					BeanUtils.copyProperties(addnewrelationBean,addadoptedchildForm);
					Session session = HibernateUtil.getSessionFactory()
					.openSession();
					 AddadoptedchilddaoImpl addadoptedchilddaoImpl=new AddadoptedchilddaoImpl();	
					 Collection relation = addadoptedchilddaoImpl.displayrelation(session,addnewrelationBean); 
		             for (Iterator iterator = relation.iterator(); iterator.hasNext();) 
	    	          { 
		            	 addnewrelationBean = (AddnewrelationBean) iterator.next();
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationshipid());
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationship());
					  }
					
					 request.setAttribute("spousenot","spousenot"); 
					 
				     request.setAttribute("relation", relation);
				     request.setAttribute("newrelations", "newrelations");	
					}
			
				 target="adopt";
				 System.out.println("after target=====>"+target);
	}
			

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}
			 System.out.println("after findForward=====>"+target);
			return (mapping.findForward(target));
			
			}
		

		public ActionForward addnewrelation(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception 
				{
			String target =null;
			try {
				
				if (form != null) 
				{
					AddadoptedchildForm addadoptedchildForm =(AddadoptedchildForm)form;
					AddnewrelationBean addnewrelationBean= new AddnewrelationBean();
					BeanUtils.copyProperties(addnewrelationBean,addadoptedchildForm);
					Session session = HibernateUtil.getSessionFactory()
					.openSession();
					 AddadoptedchilddaoImpl addadoptedchilddaoImpl=new AddadoptedchilddaoImpl();						 
		             //insert new relation
		             addnewrelationBean.setRelationship(addadoptedchildForm.getNewrelation());
		             addadoptedchilddaoImpl.insertnewrelation(session,addnewrelationBean);
		             Collection relation = addadoptedchilddaoImpl.displayrelation(session,addnewrelationBean); 
		             for (Iterator iterator = relation.iterator(); iterator.hasNext();) 
	    	          { 
		            	 addnewrelationBean = (AddnewrelationBean) iterator.next();
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationshipid());
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationship());
					  }
					
					 request.setAttribute("spousenot","spousenot"); 					 
				     request.setAttribute("relation", relation);
				     request.setAttribute("newrelations", "newrelations");	
					}
			
				 target="adopt";
				 System.out.println("after target=====>"+target);
	}
			

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}
			 System.out.println("after findForward=====>"+target);
			return (mapping.findForward(target));
			
			}
		//display new relation not
		public ActionForward newrelationno(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception 
				{
			String target =null;
			try {
				
				if (form != null) 
				{
					AddadoptedchildForm addadoptedchildForm =(AddadoptedchildForm)form;
					AddnewrelationBean addnewrelationBean= new AddnewrelationBean();
					Relation2Bean relationBean= new Relation2Bean();
					BeanUtils.copyProperties(addnewrelationBean,addadoptedchildForm);
					Session session = HibernateUtil.getSessionFactory()
					.openSession();
					HttpSession httpsession = request.getSession();
					String r=(String)httpsession.getAttribute("mid").toString();
					int d=Integer.parseInt(r);
					 AddadoptedchilddaoImpl addadoptedchilddaoImpl=new AddadoptedchilddaoImpl();
					 Collection relation = addadoptedchilddaoImpl.displayrelation(session,addnewrelationBean);
					 Collection spouse = addadoptedchilddaoImpl.displayspouse(session,relationBean,d);
					 for (Iterator iterator = relation.iterator(); iterator.hasNext();) 
	    	          { 
		            	 addnewrelationBean = (AddnewrelationBean) iterator.next();
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationshipid());
						 System.out.println("after target==fRelationnnnnnnn daction==========="+addnewrelationBean.getRelationship());
					  }
					  for (Iterator iterator = spouse.iterator(); iterator.hasNext();) 
	    	          { 
			        	relationBean = (Relation2Bean) iterator.next();	
			        	
	    		      }
					 request.setAttribute("relation",relation);
					 request.setAttribute("spouse",spouse);
					 request.setAttribute("newrelations","newrelations");
					}
			
				 target="adopt";
				 System.out.println("after target=====>"+target);
	}
			

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}
			 System.out.println("after findForward=====>"+target);
			return (mapping.findForward(target));
			
			}	
		
}
