package com.dory.login;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

public class LoginForm extends ActionForm{

	private static final long serialVersionUID = 1L;
	private String uname;
	private String pass;
	private int isactive;
	private String remark;
	private String membernumber;
	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request)
	   {
	   	ActionErrors actionerrors = new ActionErrors();
	   	{
	   		try
	   		{
	   		if(uname == null || "".equals(uname))
	   		{
	   			actionerrors.add("unameerror",new ActionMessage("error.uname"));
	   		}
	   		
	   	}
	   		catch(Exception e)
	   			{
	   				System.out.println("Exceptionnnnnnnnnnnnnnnn==========>"+e);
	   			}
	   	
	   	return actionerrors;
	   }
	   }
	
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getPass() {
		return pass;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUname() {
		return uname;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}

	public void setMembernumber(String membernumber) {
		this.membernumber = membernumber;
	}

	public String getMembernumber() {
		return membernumber;
	}

	public void setIsactive(int isactive) {
		this.isactive = isactive;
	}

	public int getIsactive() {
		return isactive;
	}
	
	
	
	
	
}
