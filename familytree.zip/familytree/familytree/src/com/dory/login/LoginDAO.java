package com.dory.login;

import org.hibernate.Session;

public interface LoginDAO {

	public LoginBean validLogin(Session session,LoginBean loginBean,String uname);
	public int familyid(Session session,int uid);
	public boolean insert(Session session, LoginBean loginBean);
	
}
