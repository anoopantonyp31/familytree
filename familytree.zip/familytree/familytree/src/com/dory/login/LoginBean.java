package com.dory.login;

public class LoginBean {

	private int loginid;
	private int memberid;
	private String uname;
	private String membernumber;
	private String pass;
	private String usertype;
	private int isactive;
	private String remark;
	
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getPass() {
		return pass;
	}
	
	
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUname() {
		return uname;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setLoginid(int loginid) {
		this.loginid = loginid;
	}
	public int getLoginid() {
		return loginid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setMembernumber(String membernumber) {
		this.membernumber = membernumber;
	}
	public String getMembernumber() {
		return membernumber;
	}
	public void setIsactive(int isactive) {
		this.isactive = isactive;
	}
	public int getIsactive() {
		return isactive;
	}
	
	
	
	
}
