package com.dory.login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

public class LoginAction extends Action {
	private static Logger log=Logger.getLogger(LoginAction.class);	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		    String target = null;
		try {
			if (form != null) 
				
			{
				String action=request.getParameter("action");
				
				
				//----------------session declaration-------------------------------------
				
				HttpSession session1=request.getSession();
				HttpSession session2=request.getSession();
				HttpSession session3=request.getSession();
				HttpSession session4=request.getSession();
				HttpSession session5=request.getSession();
				HttpSession authintication=request.getSession();
				HttpSession usertype=request.getSession();
				
				//-----------------------------------------------------	
				
				
				
				
				if("login".equals(action))
				{
				// Use the NameForm to get the request parameters
				System.out.print("===in=====login");
				LoginForm loginForm = (LoginForm) form;
				LoginBean loginBean = new LoginBean();
				System.out.println("<<<<<<<========LOGIN==========>>>>>");
				
				Session session = HibernateUtil.getSessionFactory()
						.openSession();
				System.out.println("session======888888=====>"+session);
				    LoginDAO loginDAO = new LoginDAOImpl();
				    log.info("aaaaaaaaaaaaaaaaaaaaa");
					int uid=0;
					String username=loginForm.getUname();
					String pass=loginForm.getPass();
					System.out.println("session=====formmmmmmmpasssworddddddddddddddd=========="+pass);
					//method for validate login
					loginBean = loginDAO.validLogin(session,loginBean, username);
					String orgpass=loginBean.getPass();
					int states=loginBean.getIsactive();
					System.out.println("session===beaannnnn ============passssssworddddddddd========="+orgpass);
					System.out.println("============getMembernumber========="+loginBean.getMembernumber());
					//create session for usernumber
					String membernumber = loginBean.getMembernumber();					
					
					
					
					
					session5.setAttribute("membernumber",membernumber);
				
					
				
					
					
                     if(pass.equals(orgpass)&&states==1)
					 
					{
                    	 System.out.println("in if(pass.equals(orgpass))@@@@@");
					//create session for userid
					uid = loginBean.getMemberid();
					//HttpSession session1=request.getSession();
					session1.setAttribute("mid",uid);
					
					//create session for username
					String uname = loginBean.getUname();
					//HttpSession session2=request.getSession();
					session2.setAttribute("uname",uname);
					
					//create session for usertype
					String utype = loginBean.getUsertype();
					//HttpSession session3=request.getSession();
					session3.setAttribute("utype",utype);
					
					//create session for familyid
				     int famid = loginDAO.familyid(session,uid);
				     System.out.println("Value of famid: "+famid);
				    // HttpSession session4=request.getSession();
				     session4.setAttribute("famid",famid);
				     
				   //  HttpSession authintication=request.getSession();
				     int authincate=101;
				     authintication.setAttribute("authincate",authincate);
				     
				     
				  //   HttpSession session6=request.getSession();
				   //  int set=0;
				   //  session4.setAttribute("uid2",set);
				     
				    // HttpSession session8=request.getSession();
				    // String uutype="kkk";
				    // session8.setAttribute("utype",uutype);
				     
                     if(utype.equals("sadmin"))
                     {
                    	// HttpSession usertype=request.getSession();
                    	 String sadmin="sadmin";
                    	 System.out.println("inside s admin--------------------@@@@@@@@");
                    	 usertype.setAttribute("usertype",sadmin);
				        target="sadmin";
                     }
                     else if(utype.equals("madmin"))
                     {
                    	 //HttpSession usertype=request.getSession();
                    	 String madmin="madmin";
                    	 usertype.setAttribute("usertype",madmin);
                    	 target="madmin";	 
                     }
                     else if(utype.equals("user"))
                     {
                    	// HttpSession usertype=request.getSession();
                    	 String user="user";
                    	 usertype.setAttribute("usertype",user);
                    	 target="user";
                     }
                    
					}
                     else if(pass.equals(orgpass)&&states==0)
                     {
                    	 request.setAttribute("failure1", "failure1");
                    	 target="failure";
                     }
                     else
                     {
						  
						  System.out.println("session in the iiiiiiiiiiiiiffffffffffff blockkkkkkk");
                    	
                    	 request.setAttribute("failure", "failure");
                    	 target="failure";
                     }
					
				
		        }
				if("logout".equals(action))
					
				{
					
                    //-------------------logout---------------------------
					
					 session1.invalidate();
					 session2.invalidate();
					 session3.invalidate();
					 session4.invalidate();
					 session5.invalidate();
					 authintication.invalidate();
					 usertype.invalidate();					
					//---------------------------------------------
					
					
					
					
					
					target="lout";
					
				}
					
			}
	    	 
		}
			catch (Exception e) {
            System.out.println("Exception in LoginAction=====>"+e);
            response.sendRedirect("login.jsp");
		}

		return (mapping.findForward(target));
	}
	
}
