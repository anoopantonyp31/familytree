package com.dory.login;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import com.dory.tree.*;
public class LoginDAOImpl implements LoginDAO{
	
	public boolean insert(Session session, LoginBean loginBean) {
		  session.beginTransaction();
		  session.save(loginBean);
		  session.getTransaction().commit();
		  return true;

		 }
	
	public int familyid(Session session,int uid){
		  
		  int fid = 0;
		  RelationsBean relationbean = new RelationsBean();
		  try
		  {
		   System.out.println("Login====uid========"+uid);
		      
		   List query = session.createQuery("select new RelationsBean(fa.familyid) from RelationsBean re " +
		                              "join re.profile pr " +
		                              "join re.family fa " +
		                              "where pr.memberid='"+uid+"'").list();
		       System.out.println("Loginpage====query========"+query);

		  for (Iterator it = query.iterator(); it.hasNext();) {
		   System.out.println("Login====Iterator========");
		   relationbean = (RelationsBean) it.next();
		   System.out.println("Relationbean====familyid========"+relationbean.getFamilyid());
		   fid=relationbean.getFamilyid();
		   
		   
		  }
		  
		  }catch(HibernateException he){
		   System.out.println("errorrrrrrrr"+he);
		  }
		  return fid;
		 }
	
	public LoginBean validLogin(Session session,LoginBean loginBean,String uname ){
		
		//Collection log =new ArrayList();
		String cat = null;
		MembernumberBean membernumberBean= new MembernumberBean();
		try
		{
			List query = session.createSQLQuery("select * from member_login fs where username='"+uname+"'").addEntity("fs",LoginBean.class).list();     		

		for (Iterator it = query.iterator(); it.hasNext();) 
		{
			loginBean = (LoginBean) it.next();
			List query1 = session.createSQLQuery("select * from member_profile ds where memberid='"+loginBean.getMemberid()+"'").addEntity("ds",MembernumberBean.class).list();     		

			for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			{
				membernumberBean = (MembernumberBean) it1.next();
				System.out.println("========membernumberBean====getMembernumber========="+membernumberBean.getMembernumber());
			}
			loginBean.setMembernumber(membernumberBean.getMembernumber());
			System.out.println("============after iterator========="+loginBean.getMembernumber());
		}
		
		}
		catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return loginBean;
	}
	
	

}
