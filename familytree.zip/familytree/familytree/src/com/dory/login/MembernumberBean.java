package com.dory.login;

public class MembernumberBean 
{
private int memberid;
private String membernumber;
public void setMemberid(int memberid) {
	this.memberid = memberid;
}
public int getMemberid() {
	return memberid;
}
public void setMembernumber(String membernumber) {
	this.membernumber = membernumber;
}
public String getMembernumber() {
	return membernumber;
}
}
