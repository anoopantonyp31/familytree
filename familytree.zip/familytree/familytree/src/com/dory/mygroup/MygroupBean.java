package com.dory.mygroup;

public class MygroupBean {
	
	 private String groupname;
	 private int groupid;
	 private int groupownerid;
	 private String groupcategory;
	 private String groupdesc;
	 
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}
	public int getGroupid() {
		return groupid;
	}
	public void setGroupownerid(int groupownerid) {
		this.groupownerid = groupownerid;
	}
	public int getGroupownerid() {
		return groupownerid;
	}
	public void setGroupcategory(String groupcategory) {
		this.groupcategory = groupcategory;
	}
	public String getGroupcategory() {
		return groupcategory;
	}
	public void setGroupdesc(String groupdesc) {
		this.groupdesc = groupdesc;
	}
	public String getGroupdesc() {
		return groupdesc;
	}

}
