package com.dory.mygroup;

public class GroupmembersdBean 
{
 private int groupmemberid;
 private int groupid;
 private int memberid;
 private String status;
public void setGroupmemberid(int groupmemberid) {
	this.groupmemberid = groupmemberid;
}
public int getGroupmemberid() {
	return groupmemberid;
}
public void setGroupid(int groupid) {
	this.groupid = groupid;
}
public int getGroupid() {
	return groupid;
}
public void setMemberid(int memberid) {
	this.memberid = memberid;
}
public int getMemberid() {
	return memberid;
}
public void setStatus(String status) {
	this.status = status;
}
public String getStatus() {
	return status;
}
}
