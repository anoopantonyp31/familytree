package com.dory.mygroup;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
public class MygroupAction extends Action {
	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
				String k = request.getParameter("action");
				MygroupForm mygroupForm = (MygroupForm) form;
				MygroupBean mygroupBean = new MygroupBean();
				HttpSession httpsession = request.getSession();
							
				mygroupBean.setGroupname(mygroupForm.getGroupname());
				mygroupBean.setGroupid(mygroupForm.getGroupid());
				Session session = HibernateUtil.getSessionFactory()
						.openSession();
				System.out.println("session======111111=====>" + session);
				MygroupDAOImpl mygroupDAO = new MygroupDAOImpl();
							
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	      
	             if ("insert".equals(k)) 
					{
	            	 System.out.println("inside insert==========>");
	            	 BeanUtils.copyProperties(mygroupBean, mygroupForm);
	            	 mygroupBean.setGroupownerid(q);
	            	 mygroupDAO.insert(session,mygroupBean);
	            	 Collection exeobj = mygroupDAO.displaygroups(session,mygroupBean,q);
	            	 if(exeobj.size()>0)
						{
						 request.setAttribute("exeobj", exeobj);
						}
						else
						{
							request.setAttribute("novalues", "novalues");
						}
					 System.out.println("after settings===========>");	
					 target = "mygroup";
						System.out.println("session======insert=====>"+target);
					
	         		}		
				
	             
	             if ("edit".equals(k)) 
					{
	            	 

	            	 BeanUtils.copyProperties(mygroupBean, mygroupForm);
	         				System.out.println("eeddddddddddddddddddddiiiiiiiiiiittttt after session");
	
	         				int a[]=mygroupForm.getExeobjname2();
	         				System.out.println("a====================>"+a);
	         				for(int i=0;i<a.length;i++)
	         				{
	         					System.out.println("IN THE LOOP+++++++++++++++++++");
	         				  
	         					/* delete district name */	
	         				    System.out.println("CHECKBOXID======================================================="+a[i]);
	         				    int b = a[i];
	         				    mygroupForm.setGroupid(b);
	         				    System.out.println("CHECKBOXID==============bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"+b);
	         				    Collection eidt22 = mygroupDAO.edit(session,mygroupBean,b);
	         				    
	         					if(eidt22.size()>0)
	         					{
	         					
	         					    for (Iterator iterator = eidt22.iterator(); iterator.hasNext();) 
	         				    	    { 
	         					    	 mygroupBean = (MygroupBean) iterator.next();
	         					    	System.out.println("dispnammememmememememmememeemmemactionbeam=========="+mygroupBean.getGroupname());
	         							System.out.println("dis===========================actionnnnbebeb============="+mygroupBean.getGroupdesc());
	         				    		}
	         				    	
	         					   mygroupForm.setGname(mygroupBean.getGroupname());
	         					   mygroupForm.setGdesc(mygroupBean.getGroupdesc());
	         					    System.out.println("iquotanameggggggggggggggggggggggggggggggggggg=acform===="+mygroupForm.getGname());
	         					    System.out.println("iquotanameiiiiiiiiiiiiidddddddddddeeccccccccccccc==acform==="+mygroupForm.getGdesc());
	         					   System.out.println("iquoupdaaaateedittttttiiiiiiidddddddddddddddddddd=========="+mygroupForm.getGroupid());
	         					  request.setAttribute("b","b");
	         					   String s="edit22"; 
	         					   String d="exeobj";
	         					  String r1=(String)httpsession.getAttribute("mid").toString();
	         					 int q1=Integer.parseInt(r);
	         		             System.out.println("rambooo"+q1);
	         					   request.setAttribute("edit22",s);
	         					}
	         		
	         				      }	
	         				target="mygroup";
	         		}
	             
	             
	             
				   if("display".equals(k))
                {
                	Collection exeobj = mygroupDAO.displaygroups(session,mygroupBean,q);
					System.out.println("session======222222222222=====>"+ exeobj.size());
					System.out.println("session======in display=====>"+ exeobj.size());
					if(exeobj.size()>0)
					{
					 request.setAttribute("exeobj", exeobj);
					}
					else
					{
						request.setAttribute("novalues", "novalues");
					}
					target = "mygroup";
					
                }
					
				   if ("update".equals(k)) 
					{
					
					   int s=mygroupForm.getGroupid();
					   System.out.println("udateidididididiii============"+s);
					   System.out.println("upuppdaddateeeeenammemmeme=="+mygroupForm.getGname());
					   System.out.println("upuppdaddateeeeenammemdecdec==="+mygroupForm.getGroupdesc());
					   mygroupBean.setGroupname(mygroupForm.getGname());
					   mygroupBean.setGroupcategory(mygroupForm.getGcategory());
					   mygroupBean.setGroupdesc(mygroupForm.getGdesc());
					   mygroupBean.setGroupownerid(q);
	            	   mygroupDAO.update(session,mygroupBean);
	            	  Collection exeobj = mygroupDAO.displaygroups(session,mygroupBean,q);
						if(exeobj.size()>0)
						{
						 request.setAttribute("exeobj", exeobj);
						}
						else
						{
							request.setAttribute("novalues", "novalues");
						}
						target = "mygroup";
						
					
	         		}		
				   if("delete".equals(k))
	                { 
					    String s[]=request.getParameterValues("exeobjname2");
					    System.out.println("arraylength=====>>>>"+s.length);
					    for(int i=0;i<s.length;i++)
					    {
					    	System.out.println("=======in arraylength=====");
					    	int gid=Integer.parseInt(s[i]);
					    	System.out.println("=======gid====="+gid);
					    	mygroupBean.setGroupid(gid);
					    	mygroupDAO.delete(session, mygroupBean);
					    }
	                	Collection exeobj = mygroupDAO.displaygroups(session,mygroupBean,q);
						System.out.println("session======222222222222=====>"+ exeobj.size());
						
						System.out.println("session======in delete=====>"+ exeobj.size());
						if(exeobj.size()>0)
						{
						 request.setAttribute("exeobj", exeobj);
						}
						else
						{
							request.setAttribute("novalues", "novalues");
						}
						target = "mygroup";
						
	                }
           
		        }	
			}
		
			catch (Exception e)
			{
			System.out.println("Exception===in MygroupException==>" + e);
		}

		return (mapping.findForward(target));
	
	
}

}
