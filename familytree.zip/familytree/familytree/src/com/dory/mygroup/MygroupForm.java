package com.dory.mygroup;

import org.apache.struts.action.ActionForm;

public class MygroupForm extends ActionForm{
	
	 private String groupname;
	 private int groupid;
	 private int groupownerid;
	 private String groupcategory;
	 private String groupdesc;
	 private String gid;
	 private String gname;
	 private String gcategory;
	 private String gdesc;
	 private int exeobjname2[];
	 
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}
	public int getGroupid() {
		return groupid;
	}
	public void setGroupownerid(int groupownerid) {
		this.groupownerid = groupownerid;
	}
	public int getGroupownerid() {
		return groupownerid;
	}
	public void setGroupcategory(String groupcategory) {
		this.groupcategory = groupcategory;
	}
	public String getGroupcategory() {
		return groupcategory;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
	public String getGid() {
		return gid;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getGname() {
		return gname;
	}
	public void setGroupdesc(String groupdesc) {
		this.groupdesc = groupdesc;
	}
	public String getGroupdesc() {
		return groupdesc;
	}
	public void setGcategory(String gcategory) {
		this.gcategory = gcategory;
	}
	public String getGcategory() {
		return gcategory;
	}
	public void setGdesc(String gdesc) {
		this.gdesc = gdesc;
	}
	public String getGdesc() {
		return gdesc;
	}
	public void setExeobjname2(int exeobjname2[]) {
		this.exeobjname2 = exeobjname2;
	}
	public int[] getExeobjname2() {
		return exeobjname2;
	}

}
