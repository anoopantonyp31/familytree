package com.dory.mygroup;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalForm;

import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.ArrayList;
public class GroupmembersAction extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
	    try{
			if (form != null)
			{
				
	             
				System.out.println("=======in GroupMemberAction======");
				String s=request.getParameter("action");
				System.out.println("===action======"+s);
				GroupmemberBean groupmemberBean=new GroupmemberBean();
				MygroupBean mygroupBean = new MygroupBean();
				MygroupDAOImpl mygroupDAO = new MygroupDAOImpl();
				GroupmemberForm groupmemberForm = (GroupmemberForm) form;
				MygroupDAOImpl daoImpl=new MygroupDAOImpl();
				HttpSession httpsession = request.getSession();
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
		        System.out.println("session===in GroupMemAction==111111=====>"+session);
		        ProfileBean profileBean=new ProfileBean();
		        ArrayList results = new ArrayList();
				String result = "";
				
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             
				if(s.equals("insert"))
				{
					String status="active";
					int gid=groupmemberForm.getGroupid1();
					System.out.println("cccccccccgggggggggroouppppppppppppppppiiiiiiiiiiiidddddddddddddddd"+gid);
					String groupid=request.getParameter("groupid");
					System.out.println("cccccccccgggggggggroouppppppppppppppppiiiiiiiiiiii"+groupid);
					String passid=request.getParameter("passid");
					int gid1= Integer.parseInt(groupid);
					System.out.print("groupid========="+groupid);
					System.out.print("passid========="+passid);
					groupmemberBean.setGroupid(gid1);
					groupmemberBean.setStatus(status);
					StringTokenizer st = new StringTokenizer(passid, ",");
					System.out.println("ccccccccccccccccccc"+st);
					while (st.hasMoreTokens()) 
					{
						System.out.println("inside while");
						result = st.nextToken();
						System.out.println("first results==========="+result);
					//	results.add(result);
						//for (int i = 0; i < results.size(); i++) {
							System.out.println("token results======"+result);
							int result1= Integer.parseInt(result);
							groupmemberBean.setMemberid(result1);
							System.out.println("token results111111======"+groupmemberBean.getMemberid());
							daoImpl.insertmember(session,groupmemberBean);
							System.out.println("After innnnnnnnnnnnnnnsseeeeeeeerttttttttttttttt");
							
							//for (Iterator it = members.iterator(); it.hasNext();) {
							//	System.out.println("session======diiiiitterrrrrrrrrrratoorrrr aaaacctttttioooooooonnnn=====> ");	
							//	profileBean = (ProfileBean) it.next();
							//	System.out.println("sesmmmmmmmmmeeeeeeeeeeeeeeeeemmmber nnnnaammmmmmmmmeeee"+profileBean.getName());	
						//	}
							//executiveBean.setExecutiveposid(Integer.parseInt(result));
							// session = HibernateUtil.getSessionFactory()
							//.openSession();
						// delStatus=	executiveDAO.deleteexepos(session, executiveBean);
							session.close();
							//
							
							System.out.println("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
						//}

					}
					Session session1 = HibernateUtil.getSessionFactory()
					.openSession();
					Collection members=daoImpl.getmembers(session1,profileBean,gid1);
					if(members.size()>0)
					{
					 request.setAttribute("members", members);
					}
					else
					{
						request.setAttribute("novalues", "novalues");
					}
					System.out.println("===in viewwww====inside insert==");
					//String s1=request.getParameter("gid");
					//int gid=Integer.parseInt(s1);
					System.out.println("===gid======"+gid1);
					//Collection members=daoImpl.getmembers1(session,profileBean,gid1);
					//System.out.println("===before settings=========");
					//request.setAttribute("members", members);
					HttpSession sessiongroup=request.getSession();
					sessiongroup.setAttribute("groupid",gid1);
					
					//System.out.println("===collection size======"+members.size());
					target="groupmember";
					
					System.out.println("inside insert");
					//MygroupDAO.insertmem(session,groupmemberBean);
				}
				
		        if(s.equals("view"))
				{
					System.out.println("===in viewwww======");
					String s1=request.getParameter("gid");
					int gid=Integer.parseInt(s1);
					System.out.println("===gid======"+gid);
					Collection members=daoImpl.getmembers(session,profileBean,gid);
					if(members.size()>0)
					{
					 request.setAttribute("members", members);
					}
					else
					{
						request.setAttribute("novalues", "novalues");
					}
					HttpSession sessiongroup=request.getSession();
					sessiongroup.setAttribute("groupid",gid);
					
					System.out.println("===collection size======"+members.size());
					target="groupmember";
				}
		        
		        if(s.equals("delete"))
				{
		        	System.out.println("inside deleteacttttttttttttiiiiiiiiiiiiiiiiiiiiooooooooooooooonnnnnnnnnnnnnn");
		        	int gid=groupmemberForm.getGroupid1();
					String memberid1 =groupmemberForm.getMemberid1();
					System.out.println("the memberrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr id are====="+memberid1);
					System.out.println("the group idddddddddddddddddddddddddddddddddddddddddddddddddddddd are====="+gid);
					StringTokenizer st = new StringTokenizer(groupmemberForm.getMemberid1(), ",");
					System.out.println("ccccccccccccccccccc"+st);
					
					
					
					while (st.hasMoreTokens()) 
					{
						System.out.println("inside while");
						result = st.nextToken();
						System.out.println("first results intttttttheeeeeeeeeeeeeeeeeee deeeeelleeeeeeeeeeettttttttreeeeee==========="+result);
					//	results.add(result);
						//for (int i = 0; i < results.size(); i++) {
							System.out.println("token resultssssssssssssssssssssssssssssssssssssssssssssssssssssssssss======"+result);
							daoImpl.delete1(session,result,gid);
							//executiveBean.setExecutiveposid(Integer.parseInt(result));
						// delStatus=	executiveDAO.deleteexepos(session, executiveBean);
							System.out.println("hhhhhhhhhhhh");
						//}

					}
					Collection members=daoImpl.getmembers(session,profileBean,gid);
					if(members.size()>0)
					{
					 request.setAttribute("members", members);
					}
					else
					{
						request.setAttribute("novalues", "novalues");
					}

					HttpSession sessiongroup=request.getSession();
					sessiongroup.setAttribute("groupid",gid);
					
					//System.out.println("===collection size======"+members.size());
					target="groupmember";
					
					
					
					
					
				}
				
            }
		   }
		catch (Exception e)
		{
			System.out.println("Exception===groupMemberAction==>" + e);
		}

		return (mapping.findForward(target));
    }
  }