package com.dory.mygroup;

public interface MygroupDAO {

}
