package com.dory.mygroup;

public class GroupmemberBean 
{


		
		 private int groupid;
		 private int memberid;
		 private String status;
		 private int groupmemberid;
		 private int groupid1;
		 private String memberid1;
		 
		public void setGroupid(int groupid) {
			this.groupid = groupid;
		}
		public int getGroupid() {
			return groupid;
		}
		public void setMemberid(int memberid) {
			this.memberid = memberid;
		}
		public int getMemberid() {
			return memberid;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getStatus() {
			return status;
		}
		public void setGroupmemberid(int groupmemberid) {
			this.groupmemberid = groupmemberid;
		}
		public int getGroupmemberid() {
			return groupmemberid;
		}
		public void setGroupid1(int groupid1) {
			this.groupid1 = groupid1;
		}
		public int getGroupid1() {
			return groupid1;
		}
		public void setMemberid1(String memberid1) {
			this.memberid1 = memberid1;
		}
		public String getMemberid1() {
			return memberid1;
		}
	
}
