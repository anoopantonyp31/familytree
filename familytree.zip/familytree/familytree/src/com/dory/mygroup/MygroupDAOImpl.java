package com.dory.mygroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.memberprofile.ProfileBean;


public class MygroupDAOImpl {

	public boolean insert(Session session, MygroupBean mygroupBean) {
		session.beginTransaction();
		session.save(mygroupBean);
		session.getTransaction().commit();
		return true;

	}
	
	public boolean insertmember(Session session, GroupmemberBean groupmemberBean) {
		System.out.println("inside impl results111111======"+groupmemberBean.getMemberid());
		if(session !=null){
			System.out.println("session=================>"+session);
			session.close();
			 session = HibernateUtil.getSessionFactory().openSession();
		}		
		
		session.beginTransaction();
		session.save(groupmemberBean);
		session.getTransaction().commit();
		return true;

	}
	
	public boolean delete(Session session, MygroupBean mygroupBean) 
	{
		int gid1=mygroupBean.getGroupid();
		GroupmembersdBean groupmembersdBean = new GroupmembersdBean();
		session.beginTransaction();
		System.out.println("iiiiiiiiiiiiiidddddddddddddddddddd"+gid1);
		session.delete(mygroupBean);
		
		List query = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' ").addEntity("ds",GroupmembersdBean.class).list();
		System.out.println("displaystandard====query========"+query);
				
		      for (Iterator it = query.iterator(); it.hasNext();) 
		      {
					System.out.println("displaystandard====Iterator========11111111111111111");
					groupmembersdBean = (GroupmembersdBean) it.next();
					session.delete(groupmembersdBean);
					
		      }
		
		session.getTransaction().commit();
		return true;

	}
	
	public boolean delete1(Session session, String result, int gid) {
		try
		{
			session.beginTransaction();
			
			
		Query query= session.createQuery("delete from GroupmemberBean ex where ex.memberid='"+result+"' and ex.groupid='"+gid+"'");
		System.out.println("Rowsssssssss: "+query);
		
		int row=query.executeUpdate();
		System.out.println("Rowsssssssss: "+row);
		session.getTransaction().commit();
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return true;

	}
	public boolean update(Session session, MygroupBean mygroupBean) {
		session.beginTransaction();
		session.update(mygroupBean);
		session.getTransaction().commit();
		return true;

	}
	
	public Collection displaygroups(Session session,MygroupBean mygroupBean,int q) {

		Collection executivecol = new ArrayList();
		try {
			System.out.println("session======displayexecutivepos=====> "+q);	
			List query = session.createQuery("from MygroupBean ex where ex.groupownerid='"+q+"'order by groupid")
					.list();
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				mygroupBean = (MygroupBean) it.next();
				executivecol.add(mygroupBean);
			}
		} 
		
		catch (Exception e) 
		{
			System.out.println("EEEEEEEEEExxxxxxxxxxxxceptionnnnnnnindispallalallalllalalalalallll"+e);
		}
		session.close();
		return executivecol;
	}
	
	public Collection getmembers(Session session,ProfileBean profileBean,int q) {

		Collection memcol = new ArrayList();
		try {
			System.out.println("insssssssssseerrrttttttdaoimmmmmmpppppppppllllllllllllllllllllllllllllllllliiiiiidddddddddddddddddddddddd "+q);	
			GroupmemberBean groupmemberBean=new GroupmemberBean();
			List query = session.createSQLQuery("select * from group_members gm where groupid='"+q+"'").addEntity("gm",GroupmemberBean.class).list();
			//System.out.println("Query for getmembers========>>>>>"+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("iittttteerrrrrrrrrrrrraaaaaattttoooooooorrrrrrrrrrrrrrrrrrr=====> ");	
				groupmemberBean = (GroupmemberBean) it.next();
				System.out.println("member id in daoimpllllllllllllllllll iiiiisssssssss.....>>>>>>"+groupmemberBean.getMemberid());
				List query1 = session.createSQLQuery("select * from member_profile mp where memberid='"+groupmemberBean.getMemberid()+"'").addEntity("mp",ProfileBean.class).list();
				for (Iterator it1 = query1.iterator(); it1.hasNext();) {
				System.out.println("nickname in======getmembers=====> "+profileBean.getNickname());
				profileBean=(ProfileBean)it1.next();
				System.out.println("name in======getmembers meeeeemmmbberrrrrrrrrrr na mmmeeeeeeeeeeeeeeeeeeeeeeeeeeee>>>>>>>"+profileBean.getName());
				memcol.add(profileBean);
				System.out.println("membername in======getmembers=====> "+profileBean.getName());	
				}
		    } 
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
		return memcol;
	}
	
	
	public Collection getmembers1(Session session,ProfileBean profileBean,int q) {

		Collection memcol = new ArrayList();
		try {
			System.out.println("session======getmembers=====> "+q);	
			GroupmemberBean groupmemberBean=new GroupmemberBean();
			List query = session.createSQLQuery("select * from group_members gm where groupid='"+q+"'").addEntity("gm",GroupmemberBean.class).list();
			System.out.println("Query for getmembers========>>>>>"+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======getmembers=====> ");	
				groupmemberBean = (GroupmemberBean) it.next();
				List query1 = session.createSQLQuery("select * from member_profile mp where memberid='"+groupmemberBean.getMemberid()+"'").addEntity("mp",ProfileBean.class).list();
				for (Iterator it1 = query1.iterator(); it1.hasNext();) {
				System.out.println("nickname in======getmembers=====> "+profileBean.getNickname());
				profileBean=(ProfileBean)it1.next();
				memcol.add(profileBean);
				System.out.println("membername in======getmembers=====> "+profileBean.getName());	
				}
		    } 
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		session.close();
		return memcol;
	}
	
	
	
	public Collection getmemb(Session session1, ProfileBean profileBean,int q) {

		Collection memcol = new ArrayList();
		try {
			System.out.println("insssssssssseerrrttttttdaoiiiidddddddddddddddddddddddd "+q);	
			GroupmemberBean groupmemberBean=new GroupmemberBean();
			List query1 = session1.createSQLQuery("select * from group_members m where groupid='"+q+"'").addEntity("m",GroupmemberBean.class).list();
			//System.out.println("Query for getmembers========>>>>>"+query);
			for (Iterator it1 = query1.iterator(); it1.hasNext();) {
				System.out.println("iittttteerrrrrrrrrrrrraaaaaattttoooooooorrrrrrrrrrrrrrrrrrr=====> ");	
				groupmemberBean = (GroupmemberBean) it1.next();
				System.out.println("member id in daoimpllllllllllllllllll iiiiisssssssss.....>>>>>>"+groupmemberBean.getMemberid());
				List query2 = session1.createSQLQuery("select * from member_profile p where memberid='"+groupmemberBean.getMemberid()+"'").addEntity("p",ProfileBean.class).list();
				for (Iterator it2 = query2.iterator(); it2.hasNext();) {
				//System.out.println("nickname in======getmembers=====> "+profileBean.getNickname());
				profileBean=(ProfileBean)it2.next();
				System.out.println("name in======getmembers meeeeemmmbberrrrrrrrrrr na mmmeeeeeeeeeeeeeeeeeeeeeeeeeeee>>>>>>>"+profileBean.getName());
				memcol.add(profileBean);
				System.out.println("membername in======getmembers=====> "+profileBean.getName());	
				}
		    } 
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		session1.close();
		return memcol;
	}
	
	
	
	
	
	
	public Collection edit(Session session,MygroupBean mygroupBean,int b) {

		Collection edit22 = new ArrayList();
		try {
			System.out.println("session======displayexiididididididididiiid=====> "+b);	
			List query = session.createSQLQuery("select * from groups ds where groupid='"+b+"' ").addEntity("ds",MygroupBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========11111111111111111");
						mygroupBean = (MygroupBean) it.next();
						System.out.println("dispnammememmememememmememeemmem=========="+mygroupBean.getGroupname());
						System.out.println("dis========================================"+mygroupBean.getGroupdesc());

						
			      }
			      edit22.add(mygroupBean);
		} 
		
		catch (Exception e) 
		{
			
			System.out.println("EEEEEEEEXXXXXXXXXXXXcecececcccptittion"+e);
		}
		session.close();
		return edit22;
	}
	

	public Collection displaygroup(Session session1,MygroupBean mygroupBean1,int q) {

		Collection executivecol = new ArrayList();
		try {
			System.out.println("session======displayexecutivepoiiiiiiiiiiiiiiiddddddddddds=====> "+q);	
			List query = session1.createSQLQuery("select * from groups ds where groupowner='"+q+"' ").addEntity("ds",MygroupBean.class).list();
				
			for (Iterator it = query.iterator(); it.hasNext();) 
			{
				System.out.println("session======displayexecutivepos=====> ");	
				mygroupBean1 = (MygroupBean) it.next();
				executivecol.add(mygroupBean1);
			}
		} 
		
		catch (Exception e) 
		{
			System.out.println("EEEEEEEEEExxxxxxxxxxxxceptionnnnnnnindispallalallalllalalalalallll"+e);
		}
		session1.close();
		return executivecol;
	}
	
	
}
