package com.dory.familysearch;

import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.hibernate.Session;
import com.dory.hibernate.HibernateUtil;
import com.dory.tree.TreeDAO;
import com.dory.tree.TreeDAOImpl;

public class FamilysearchAction extends DispatchAction
{
	
	public ActionForward searchfamily(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target =null;
		try {
			
			if (form != null) 
			{

				System.out.println("after target==fRelationnnnnnnn daction");
				FamilysearchForm familysearchForm =(FamilysearchForm)form;	
				FamilysearchBean familysearchBean= new FamilysearchBean();
				BeanUtils.copyProperties(familysearchBean,familysearchForm);
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
				String fname=familysearchForm.getData();
				FamilysearchdaoImpl familysearchdaoImpl=new FamilysearchdaoImpl();
			    Collection familydetails = familysearchdaoImpl.displayfamilydetails(session,familysearchBean,fname); 
			    for (Iterator iterator = familydetails.iterator(); iterator.hasNext();) 
  	              { 
			    	familysearchBean = (FamilysearchBean) iterator.next();
			    	
			    	familysearchForm.setFamilyid(familysearchBean.getFamilyid());
			    	 System.out.println("getFamilyid=="+familysearchForm.getFamilyid());
			    	familysearchForm.setFamilyadmin(familysearchBean.getFamilyadmin());
			    	System.out.println("Familyadmin=="+familysearchForm.getFamilyadmin());
			    	familysearchForm.setFamilyname(familysearchBean.getFamilyname());
			    	System.out.println("Familyname=="+familysearchForm.getFamilyname());
			    	familysearchForm.setFamilyno(familysearchBean.getFamilyno());
			    	System.out.println("Familyno=="+familysearchForm.getFamilyno());
			    	familysearchForm.setName(familysearchBean.getName());
			    	System.out.println("getName=="+familysearchForm.getName());
				  }
				
				request.setAttribute("familydetails", familydetails);
				}
		
			 target="success";
			 System.out.println("after target=====>"+target);
}
		

		catch (Exception e) 
		{
			System.out.println("Exception=====>"+e);
		}
		 System.out.println("after findForward=====>"+target);
		return (mapping.findForward(target));
		
		}
	//search
	public ActionForward familyname(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target =null;
		try {
			
			if (form != null) 
			{

				System.out.println("after target==fRelationnnnnnnn daction");
				FamilysearchForm familysearchForm =(FamilysearchForm)form;	
				FamilysearchBean familysearchBean= new FamilysearchBean();
				BeanUtils.copyProperties(familysearchBean,familysearchForm);
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
				FamilysearchdaoImpl familysearchdaoImpl=new FamilysearchdaoImpl();
				String otherfid=request.getParameter("famid");
				int otherfamid=Integer.parseInt(otherfid);
				
				 HttpSession otherfamilyid=request.getSession();
			    
				 otherfamilyid.setAttribute("otherfamilyid",otherfamid);
				
				
				familysearchBean = familysearchdaoImpl.displayfamily1(session,familysearchBean,otherfamid);
				request.setAttribute("familydetails", familysearchBean);
				}
		
			 target="family";
			 System.out.println("after target=====>"+target);
}
		

		catch (Exception e) 
		{
			System.out.println("Exception=====>"+e);
		}
		 System.out.println("after findForward=====>"+target);
		return (mapping.findForward(target));
		
		}
	
	//display family members
	
	public ActionForward familymembers(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target =null;
		try {
			
			if (form != null) 
			{

				System.out.println("after target==fRelationnnnnnnn daction");
				FamilysearchForm familysearchForm =(FamilysearchForm)form;	
				FamilysearchBean familysearchBean= new FamilysearchBean();
				BeanUtils.copyProperties(familysearchBean,familysearchForm);
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
				FamilysearchdaoImpl familysearchdaoImpl=new FamilysearchdaoImpl();
				String otherfid=request.getParameter("famid");
				int otherfamid=Integer.parseInt(otherfid);
				
				
				}
		
			 target="family";
			 System.out.println("after target=====>"+target);
}
		

		catch (Exception e) 
		{
			System.out.println("Exception=====>"+e);
		}
		 System.out.println("after findForward=====>"+target);
		return (mapping.findForward(target));
		
		}
	
	
	
	public ActionForward view(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target =null;
		TreeDAO treedao = new TreeDAOImpl();
		try {
			
			if (form != null) 
			{

				System.out.println("after target==fRelationnnnnnnn daction");
				FamilysearchForm familysearchForm =(FamilysearchForm)form;	
				FamilysearchBean familysearchBean= new FamilysearchBean();
				//BeanUtils.copyProperties(familysearchBean,familysearchForm);
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
				FamilysearchdaoImpl familysearchdaoImpl=new FamilysearchdaoImpl();
				String otherfid=request.getParameter("famid");
				int otherfamid=Integer.parseInt(otherfid);
				int head = treedao.findhead(session,otherfamid);
				Collection members = treedao.viewmembers(session, otherfamid,head);
			    System.out.println("After viewmember function=====>"
				    + members.size());
			    request.setAttribute("view", members);
				
				
				}
		
			 target="view";
			 System.out.println("after target=====>"+target);
}
		

		catch (Exception e) 
		{
			System.out.println("Exception=====>"+e);
		}
		 System.out.println("after findForward=====>"+target);
		return (mapping.findForward(target));
		
		}
	
	

}
