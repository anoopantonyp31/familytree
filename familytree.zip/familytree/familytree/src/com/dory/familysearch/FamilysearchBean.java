package com.dory.familysearch;

public class FamilysearchBean 
{
	private String data;
	private int familyid;
	private String familyname;
	private String familyno;
	private int createdby;
	private int familyadmin;
	private String name;
	private String description;
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}
	public void setFamilyname(String familyname) {
		this.familyname = familyname;
	}
	public String getFamilyname() {
		return familyname;
	}
	public void setFamilyno(String familyno) {
		this.familyno = familyno;
	}
	public String getFamilyno() {
		return familyno;
	}
	public void setCreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getCreatedby() {
		return createdby;
	}
	public void setFamilyadmin(int familyadmin) {
		this.familyadmin = familyadmin;
	}
	public int getFamilyadmin() {
		return familyadmin;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDescription() {
		return description;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
}
