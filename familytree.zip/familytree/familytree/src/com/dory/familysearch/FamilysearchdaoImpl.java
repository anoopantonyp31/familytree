package com.dory.familysearch;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.memberprofile.ProfileBean;
public class FamilysearchdaoImpl 

{

	public Collection displayfamilydetails(Session session,FamilysearchBean familysearchBean,String fname)
	{
		
		ProfileBean profileBean= new ProfileBean();
		Collection familydetails=new ArrayList();
		List query = session.createSQLQuery("select * from family_detail ds where familyname like'%"+fname+"%'").addEntity("ds",FamilysearchBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
        {
    	  familysearchBean = (FamilysearchBean) it.next();  
    	  List query1 = session.createSQLQuery("select * from member_profile gs where memberid='"+familysearchBean.getFamilyadmin()+"'").addEntity("gs",ProfileBean.class).list();
  		
          for (Iterator it1 = query1.iterator(); it1.hasNext();) 
            {
        	  profileBean = (ProfileBean) it1.next(); 
        	  familysearchBean.setName(profileBean.getName());
    		}
          familydetails.add(familysearchBean);
		}
      
      return familydetails;
	}
	
	
	public FamilysearchBean displayfamily1(Session session,FamilysearchBean familysearchBean,int otherfamid)
	{
		
		
			List query1 = session.createSQLQuery("select * from family_detail ps where familyid="+otherfamid+" ").addEntity("ps",FamilysearchBean.class).list();
			  for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			  {
					System.out.println("displaystandard====2wwwwwwwww========");
					familysearchBean = (FamilysearchBean) it1.next();
			}
		 return familysearchBean;
		
	}
	
	
	
	
}
