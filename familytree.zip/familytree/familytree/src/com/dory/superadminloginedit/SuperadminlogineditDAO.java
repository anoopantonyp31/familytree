package com.dory.superadminloginedit;

public interface SuperadminlogineditDAO {

}
