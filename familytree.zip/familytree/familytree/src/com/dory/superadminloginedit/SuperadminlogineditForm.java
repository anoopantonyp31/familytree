package com.dory.superadminloginedit;

import org.apache.struts.action.ActionForm;

public class SuperadminlogineditForm extends ActionForm {

	 private String username;
	 private String password;
	 private String usertype;
	 private int isactive;
	 private String remark;
	 private int memberid;
	 private int defaultmemberid;
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUsername() {
		return username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword() {
		return password;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getUsertype() {
		return usertype;
	}
	
	public void setDefaultmemberid(int defaultmemberid) {
		this.defaultmemberid = defaultmemberid;
	}
	public int getDefaultmemberid() {
		return defaultmemberid;
	}
	public void setIsactive(int isactive) {
		this.isactive = isactive;
	}
	public int getIsactive() {
		return isactive;
	}
	
}
