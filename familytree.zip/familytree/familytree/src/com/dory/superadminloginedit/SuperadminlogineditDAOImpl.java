package com.dory.superadminloginedit;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.aboutme.AboutDAO;
import com.dory.login.LoginBean;

public class SuperadminlogineditDAOImpl  implements SuperadminlogineditDAO {

	
	
	public SuperadminlogineditBean displaymemberdet(Session session,
			SuperadminlogineditBean superadminlogineditBean,int q) {

		Collection aboutcol = new ArrayList();
		try {
			List query = session.createQuery("from SuperadminlogineditBean ex where ex.memberid='"+q+"'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				superadminlogineditBean = (SuperadminlogineditBean) it.next();
				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return superadminlogineditBean;
	}
	
	
	public boolean update(Session session, SuperadminlogineditBean superadminlogineditBean) {
		session.beginTransaction();
		session.update(superadminlogineditBean);
		session.getTransaction().commit();
		return true;

	}
	
	public Collection displaycheklogin(Session session,LoginBean loginBean,String user,int memberid)
	{
		
		
		Collection cheklogin=new ArrayList();
		List query = session.createSQLQuery("select * from member_login ds where username='"+user+"' and memberid!='"+memberid+"'").addEntity("ds",LoginBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
        {
    	  loginBean = (LoginBean) it.next();  
    	  cheklogin.add(loginBean);
		}
      
      return cheklogin;
	}
	
	
}
