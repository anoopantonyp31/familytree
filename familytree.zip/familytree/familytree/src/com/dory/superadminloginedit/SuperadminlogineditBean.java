package com.dory.superadminloginedit;

public class SuperadminlogineditBean {

	 private String username;
	 private String password;
	 private String remark;
	 private int memberid;
	 private int loginid;
	 private String usertype;
	 private int isactive;
	 
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUsername() {
		return username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword() {
		return password;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setLoginid(int loginid) {
		this.loginid = loginid;
	}
	public int getLoginid() {
		return loginid;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setIsactive(int isactive) {
		this.isactive = isactive;
	}
	public int getIsactive() {
		return isactive;
	}
	
}
