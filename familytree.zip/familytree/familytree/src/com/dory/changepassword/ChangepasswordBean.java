package com.dory.changepassword;

public class ChangepasswordBean

{
 
	private int memberid;
	private String password;
	private int loginid;
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword() {
		return password;
	}
	public void setLoginid(int loginid) {
		this.loginid = loginid;
	}
	public int getLoginid() {
		return loginid;
	}
}
