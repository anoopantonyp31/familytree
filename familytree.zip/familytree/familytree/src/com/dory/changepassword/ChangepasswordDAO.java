package com.dory.changepassword;

import org.hibernate.Session;

public interface ChangepasswordDAO 
{
 public ChangepasswordBean	passwordcheck(Session session,ChangepasswordBean changepasswordBean);
 
 
 public boolean update(Session session,ChangepasswordBean changepasswordBean);
	
}
