package com.dory.changepassword;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.community.Membername1Bean;

public class ChangepasswordDAOImpl implements ChangepasswordDAO 
{

	public ChangepasswordBean	passwordcheck(Session session,ChangepasswordBean changepasswordBean)
	{
		
		try
		{
			Collection pwdcol = new ArrayList();
			
			List query1 = session.createSQLQuery("select * from member_login cs where memberid='"+changepasswordBean.getMemberid()+"' ").addEntity("cs",ChangepasswordBean.class).list();
	   		   System.out.println("displaystandard====communitytytytytyyq122222222222========"+query1);
	   		   		
	   		         for (Iterator it1= query1.iterator(); it1.hasNext();) 
	   		         {
	   		   			System.out.println("displaystandard====Iterator========");
	   		   		    changepasswordBean = (ChangepasswordBean) it1.next();
	   		   	        //viewrequestBean.setMembername(membername1Bean.getMembername());
	   		   		pwdcol.add(changepasswordBean);
	   		         }
		}
		catch(Exception e)
		{
			System.out.println("exception in dao check pwddddd====="+e);	
			
		}
		return(changepasswordBean);
	}
	
	public boolean update(Session session,ChangepasswordBean changepasswordBean)
	{
		String paswrd = changepasswordBean.getPassword();
		List query1 = session.createSQLQuery("select * from member_login cs where memberid='"+changepasswordBean.getMemberid()+"' ").addEntity("cs",ChangepasswordBean.class).list();
		  
		   		
		         for (Iterator it1= query1.iterator(); it1.hasNext();) 
		         {
		   			System.out.println("displaystandard====Iterator========");
		   		    changepasswordBean = (ChangepasswordBean) it1.next();
		   	        
		         }
		         changepasswordBean.setPassword(paswrd);
		session.beginTransaction();
		session.update(changepasswordBean);
		session.getTransaction().commit();
		return true;
		
	}
}
