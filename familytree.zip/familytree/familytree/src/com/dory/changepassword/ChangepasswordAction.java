package com.dory.changepassword;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.searchgroup.SearchgroupBean;
import com.dory.searchgroup.SearchgroupDAOImpl;
import com.dory.searchgroup.SearchgroupForm;

public class ChangepasswordAction extends Action

{

	

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//used to get the action value
					String k = request.getParameter("action");
					
				ChangepasswordForm changepasswordForm = (ChangepasswordForm) form;
				ChangepasswordBean changepasswordBean = new ChangepasswordBean();
                HttpSession httpsession = request.getSession();
                Session session = HibernateUtil.getSessionFactory()
				.openSession();
		       System.out.println("session======111111=====>" + session);
				//BeanUtils.copyProperties(aboutBean, aboutForm);
				
				/*aboutBean.setAchivements(aboutForm
						.getAchivements());
				aboutBean.setMyself(aboutForm.getMyself());
				aboutBean.setRemark(aboutForm.getRemark());*/
				
				
				
				
				//to get the session from the login action
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             changepasswordBean.setMemberid(q);
	            
				
		      ChangepasswordDAOImpl changepasswordDAO = new ChangepasswordDAOImpl();
		       
	             
				//if value of action=insert then enters below statement
				//function to insert the data from aboutme.jsp into about_member tables 
				if ("checkpassword".equals(k)) 
				{
					
					//String data=searchgroupForm.getData();
					System.out.println("================inside search============");
					changepasswordBean = changepasswordDAO.passwordcheck(session,changepasswordBean);
					String oldpwd1 = changepasswordBean.getPassword();
					System.out.println("================oldpwd================="+changepasswordBean.getPassword());
					String oldpwd2 = changepasswordForm.getOldpassword();
					System.out.println("================oldpwd=======fform=========="+changepasswordForm.getOldpassword());
					int id = changepasswordBean.getLoginid();
					if(oldpwd1.equals(oldpwd2))
					{
						System.out.println("================oldpintheeeeeifffffffffff==========");
						request.setAttribute("password", "password");
						target="correct";
					}
					else
					{
						request.setAttribute("invalid", "invalid");
						target="correct";
					}
				}
				else if("update".equals(k))
				{
					
					changepasswordBean.setPassword(changepasswordForm.getNewpassword());
					changepasswordBean.setMemberid(q);
					changepasswordDAO.update(session,changepasswordBean);
					request.setAttribute("ok", "ok");
					target="correct";
						
				}	
				
					
			
				
				
				
				
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}
}
