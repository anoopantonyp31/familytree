package com.dory.changepassword;

import org.apache.struts.action.ActionForm;

public class ChangepasswordForm extends ActionForm 

{

	private int memberid;
	private int loginid;
	private String password;
	private String oldpassword;
	private String newpassword;
	private String confirmpassword;
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword() {
		return password;
	}
	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}
	public String getOldpassword() {
		return oldpassword;
	}
	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}
	public String getNewpassword() {
		return newpassword;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public void setLoginid(int loginid) {
		this.loginid = loginid;
	}
	public int getLoginid() {
		return loginid;
	}
	
}
