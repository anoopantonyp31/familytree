package com.dory.newsdelete;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.hibernate.Session;

import com.dory.deletediscussionforum.DeletediscussionforumBean;
import com.dory.deletediscussionforum.DeletediscussionforumForm;
import com.dory.deletediscussionforum.DeletediscussionforumdaoImpl;
import com.dory.hibernate.HibernateUtil;
public class NewsdeleteAction extends DispatchAction
{
	public ActionForward displaynews(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException
	{
		//String target = new String("success");
		String target=null;
		try
		{
			
				if (form != null)
				{
					NewsdeleteForm newsdeleteForm = (NewsdeleteForm) form;
					NewsdeleteBean newsdeleteBean = new NewsdeleteBean(); 
				   BeanUtils.copyProperties(newsdeleteBean,newsdeleteForm);				  
				   Session session =HibernateUtil.getSessionFactory().openSession();
				   System.out.println("session======111111=====>"+session);
				   
				   NewsdeletedaoImpl newsdeletedaoImpl = new NewsdeletedaoImpl();
				   Collection news = newsdeletedaoImpl.displaynews(session,newsdeleteBean);
				   
				   for(Iterator it=news.iterator();it.hasNext();)
				   {
					   newsdeleteBean=(NewsdeleteBean)it.next();
					   System.out.println("getData........>>>>>>>>"+newsdeleteBean.getData());
					   System.out.println("getMemberid...........>>>>>>>>"+newsdeleteBean.getMemberid());
					   System.out.println("getNewsid........>>>>>>>>"+newsdeleteBean.getNewsid());
					   System.out.println("getSentdate...........>>>>>>>>"+newsdeleteBean.getSentdate());
					   System.out.println("getSubject...........>>>>>>>>"+newsdeleteBean.getSubject());
				   }
				   request.setAttribute("news", news);
				   target="newsdelete";
				}
				   
				
		}
		catch (Exception e)
		{
                 System.out.println("Exception=====>"+e);
                 target="failure";
		}
		
		return (mapping.findForward(target));
		
	}
	public ActionForward deletenews1(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = new String("success");
		try {
			
			if (form != null) 
			{


				NewsdeleteForm newsdeleteForm = (NewsdeleteForm) form;
				NewsdeleteBean newsdeleteBean = new NewsdeleteBean(); 
			   BeanUtils.copyProperties(newsdeleteBean,newsdeleteForm);	
				Session session = HibernateUtil.getSessionFactory().openSession();
				System.out.println("DELETE after session");
				 NewsdeletedaoImpl newsdeletedaoImpl = new NewsdeletedaoImpl();
				int a[]=newsdeleteForm.getNewsdet();
				System.out.println("a====>"+a);
				for(int i=0;i<a.length;i++)
				{
					System.out.println("IN THE LOOP+++++++++++++++++++");
					newsdeleteBean.setNewsid(a[i]);	
				    System.out.println("CHECKBOXID======================================================="+a[i]);
				    newsdeletedaoImpl.delete(session,newsdeleteBean);
					
				}
				 Collection news = newsdeletedaoImpl.displaynews(session,newsdeleteBean);
				request.setAttribute("news", news);
				target="newsdelete";
			      }				


		}

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}

			return (mapping.findForward(target));
			}
}