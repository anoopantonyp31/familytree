package com.dory.newsdelete;

public class NewsdeleteBean 
{
	private int newsid;
	private String subject;
	private String data;
	private String sentdate;
	private String name;
	private int memberid;
	public void setNewsid(int newsid) {
		this.newsid = newsid;
	}
	public int getNewsid() {
		return newsid;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubject() {
		return subject;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}
	public void setSentdate(String sentdate) {
		this.sentdate = sentdate;
	}
	public String getSentdate() {
		return sentdate;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
}
