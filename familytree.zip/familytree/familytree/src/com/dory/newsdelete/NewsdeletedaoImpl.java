package com.dory.newsdelete;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.dory.confidential.ConfidentialmainBean;
import com.dory.memberprofile.ProfileBean;
import org.hibernate.Session;
public class NewsdeletedaoImpl
{

    public boolean delete(Session session,NewsdeleteBean newsdeleteBean)
	
	{		
	session.beginTransaction();     
	session.delete(newsdeleteBean);
	session.getTransaction().commit();
	return true;
	} 
	public Collection displaynews(Session session,NewsdeleteBean newsdeleteBean) 
	
	{
		ProfileBean profileBean= new ProfileBean();
		Collection news=new ArrayList();
		try
		{
		List query = session.createSQLQuery("select * from newsletter ds ").addEntity("ds",NewsdeleteBean.class).list();
		System.out.println("displayclass====query========"+query);		
        for (Iterator it = query.iterator(); it.hasNext();) 
         {
        	newsdeleteBean = (NewsdeleteBean) it.next();
			System.out.println("deletediscussionforumBean.getStartby"+newsdeleteBean.getMemberid());
			int s=newsdeleteBean.getMemberid();
			System.out.println("getStartby"+s);
			List query1 = session.createSQLQuery("select * from member_profile  ps where memberid='"+s+"' ").addEntity("ps",ProfileBean.class).list();
			System.out.println("displayclass====query========"+query);		
	        for (Iterator it1 = query1.iterator(); it1.hasNext();) 
	         {
				System.out.println("displayyear====Iterator========");
				profileBean = (ProfileBean) it1.next();
				newsdeleteBean.setName(profileBean.getName());
		     }
	        System.out.println("deletediscussionforumBean IMPL"+newsdeleteBean.getName());
	        news.add(newsdeleteBean);
	     }
		}catch(Exception he){
			System.out.println("errorrrrrrrr"+he);
		}
		
		return news;
	}
	
	

}