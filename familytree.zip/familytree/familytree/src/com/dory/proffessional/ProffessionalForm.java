package com.dory.proffessional;

import org.apache.struts.action.ActionForm;

public class ProffessionalForm extends ActionForm {
	
	private String occupation;
	 private String companyname;
	 private String designation;
	 private String officeno;
	 private int test;
	 
	 private String jobcity;
	 private String jobaddress;
	
	 private String remark;
	 private int jobid;
	 private int exeobjname2[];
	 private int publicorprivate;
	 private int community;
	 private int groups;
	 private int family;
	 
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getCompanyname() {
		return companyname;
	}
	
	public void setOfficeno(String officeno) {
		this.officeno = officeno;
	}
	public String getOfficeno() {
		return officeno;
	}
	
	public void setJobcity(String jobcity) {
		this.jobcity = jobcity;
	}
	public String getJobcity() {
		return jobcity;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setJobid(int jobid) {
		this.jobid = jobid;
	}
	public int getJobid() {
		return jobid;
	}
	
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDesignation() {
		return designation;
	}
	public void setJobaddress(String jobaddress) {
		this.jobaddress = jobaddress;
	}
	public String getJobaddress() {
		return jobaddress;
	}
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	public void setCommunity(int community) {
		this.community = community;
	}
	public int getCommunity() {
		return community;
	}
	public void setGroups(int groups) {
		this.groups = groups;
	}
	public int getGroups() {
		return groups;
	}
	public void setFamily(int family) {
		this.family = family;
	}
	public int getFamily() {
		return family;
	}
	public void setTest(int test) {
		this.test = test;
	}
	public int getTest() {
		return test;
	}
	public void setExeobjname2(int exeobjname2[]) {
		this.exeobjname2 = exeobjname2;
	}
	public int[] getExeobjname2() {
		return exeobjname2;
	}

}
