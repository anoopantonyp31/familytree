package com.dory.proffessional;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;
import com.dory.hibernate.HibernateUtil;
public class ProffessionalAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//String a1= request.getParameter("fromWhere");
					String k = request.getParameter("action");
					String kt = request.getParameter("action1");
					//String k1 = request.getParameter("action1");
				// Use the NameForm to get the request parameters
					ProffessionalForm proffessionalForm = (ProffessionalForm) form;
				ProffessionalBean proffessionalBean = new ProffessionalBean();
				HttpSession httpsession = request.getSession();
				BeanUtils.copyProperties(proffessionalBean, proffessionalForm);
				//proffessionalBean.setAchivements(proffessionalForm
					//	.getAchivements());
				//proffessionalBean.setMyself(proffessionalForm.getMyself());
				// executiveBean.setExecutiveposid(executiveForm.getExecutiveposid());
				//String executive = aboutForm.getExecutivepos();
				//System.out.println("exe===========>" + executive);
				
				
				//*********************visibility part***********************//
				//--------------------------------------
				int privateorprivate1=proffessionalForm.getPublicorprivate();
				
				int family=proffessionalForm.getFamily();
				int groups=proffessionalForm.getGroups();
				int community=proffessionalForm.getCommunity();
				
				
				
				String privateorprivate2 = String.valueOf(privateorprivate1);
						
				
				if("1".equals(privateorprivate2))
				{
					//String visibility=privateorprivate1+"0"+"0"+"0";
					String visibility="8";
					System.out.println("===========in public======="+visibility);
					proffessionalBean.setVisibility(visibility);
				}
				
				if("500".equals(privateorprivate2))
				{
				String family2 = String.valueOf(family);
				String groups2 = String.valueOf(groups);
				String community2 = String.valueOf(community);
				
				 
					if("0".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
					{
						//String visibility="0"+"0"+"0"+"0";
						String visibility="0";
						System.out.println("===========1111111======="+visibility);
						proffessionalBean.setVisibility(visibility);
					}
					
					else if("0".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
					{
						String visibility="1";
						System.out.println("===========222222======="+visibility);
						proffessionalBean.setVisibility(visibility);
					}
					
					else if("1".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
					{
						String visibility="2";
						System.out.println("===========3333333======="+visibility);
						proffessionalBean.setVisibility(visibility);
					}
					
					else if("1".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
					{
						String visibility="3";
						System.out.println("===========44444444======="+visibility);
						proffessionalBean.setVisibility(visibility);
					}
					
					
					else if("0".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
					{
						String visibility="4";
						System.out.println("===========666666666======="+visibility);
						proffessionalBean.setVisibility(visibility);
					}
					
					
					else if("0".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
					{
						String visibility="5";
						System.out.println("===========7777777======="+visibility);
						proffessionalBean.setVisibility(visibility);
					}
					
					
					else if("1".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
					{
						String visibility="6";
						System.out.println("===========8888888======="+visibility);
						proffessionalBean.setVisibility(visibility);
					}
					
					
					else if("1".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
					{
						String visibility="7";
						System.out.println("===========99999999======="+visibility);
						proffessionalBean.setVisibility(visibility);
					}
					
					
				}
				
				//*********************visibility part***********************//
				
				
				
				

				Session session = HibernateUtil.getSessionFactory()
						.openSession();
				System.out.println("session======111111=====>" + session);
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             proffessionalBean.setMemberid(q);
				
				ProffessionalDAOImpl proffessionalDAO = new ProffessionalDAOImpl();

				

				if ("insert".equals(k)) 
				{
							
				
										System.out.println("inside insert");
						proffessionalDAO.insert(session,proffessionalBean);
						

			               
            //ProffessionalDAOImpl proffessionalDAO=new MygroupDAOImpl(); 
            //MygroupBean mygroupBean=new MygroupBean();
         	Collection exeobj = proffessionalDAO.displayproffessional(session,proffessionalBean,q);
				System.out.println("session======222222222222=====>"
						+ exeobj.size());
				
				
					System.out.println("session======333333333=====>"
							+ exeobj.size());
					request.setAttribute("exeobj", exeobj);
					target = "correct";
				 
         
						
						
												
				}
				
				
				else if("display".equals(kt))
				{
					Collection exeobj = proffessionalDAO.displayproffessional(session,proffessionalBean,q);
					System.out.println("session======222222222222=====>"+ exeobj.size());
					if(exeobj.isEmpty())
					{
						request.setAttribute("pro", "pro");
						request.setAttribute("update", "update");
					}
					else
					{
						request.setAttribute("exeobj", exeobj);
						request.setAttribute("update", "update");
					}
					target = "proffessional";
			}
				
				
				else if("edit".equals(k))
				{
					System.out.println("inside edit====");
					int a[]=proffessionalForm.getExeobjname2();
					for(int i=0;i<a.length;i++)					
					   {
					    int b = a[i];
					    System.out.println("CHECKBOXID==============bbbbbbbbbbbbbbbbbb"+b);					    
					    Collection exeobj = proffessionalDAO.edit(session,proffessionalBean,b);
						if(exeobj.size()>0)
						{
							System.out.println("in district.size>0=====>"+exeobj.size());
							
						    
						    for (Iterator iterator = exeobj.iterator(); iterator.hasNext();) 
					    	    { 
						    	proffessionalBean = (ProffessionalBean) iterator.next();
					    		}
						    proffessionalForm.setJobid(proffessionalBean.getJobid());
						    proffessionalForm.setOccupation(proffessionalBean.getOccupation());						    
						    proffessionalForm.setCompanyname(proffessionalBean.getCompanyname());						   
						    proffessionalForm.setDesignation(proffessionalBean.getDesignation());
						    proffessionalForm.setOfficeno(proffessionalBean.getOfficeno());
						    proffessionalForm.setJobcity(proffessionalBean.getJobcity());
						    proffessionalForm.setJobaddress(proffessionalBean.getJobaddress());
						    proffessionalForm.setRemark(proffessionalBean.getRemark());
					   }
						request.setAttribute("add","add");
					      }			
					target="edit";
						
					}
				else if("update".equals(k))
				{
							
					String s=request.getParameter("t");
					int id=Integer.parseInt(s);
					System.out.println("Exception id========="+id);
					proffessionalBean.setJobid(id);	
				    proffessionalDAO.update(session,proffessionalBean);
				    request.setAttribute("add", "add");
				    target="update";
				}
				
				else if("delete".equals(k))
				{
					int c[]=proffessionalForm.getExeobjname2();	
					for(int i=0;i<c.length;i++)
					{
						System.out.println("IN THE LOOP+++++++++++++++++++");
						proffessionalBean.setJobid(c[i]);
					    System.out.println("CHECKBOXID================================"+c[i]);
					    proffessionalDAO.delete(session,proffessionalBean);
					    target="update";
					}
				}
			}
			
			
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}

}
