package com.dory.proffessional;

public class ProffessionalBean {

	
	private String occupation;
	 private String companyname;
	 private String designation;
	 private String officeno;

	 private String jobcity;
	 private String jobaddress;
	 private String visibility;
	 private String remark;
	 private int jobid;
	 private int memberid;
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getCompanyname() {
		return companyname;
	}
	
	public void setOfficeno(String officeno) {
		this.officeno = officeno;
	}
	public String getOfficeno() {
		return officeno;
	}
	
	public void setJobcity(String jobcity) {
		this.jobcity = jobcity;
	}
	public String getJobcity() {
		return jobcity;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setJobid(int jobid) {
		this.jobid = jobid;
	}
	public int getJobid() {
		return jobid;
	}
	
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDesignation() {
		return designation;
	}
	public void setJobaddress(String jobaddress) {
		this.jobaddress = jobaddress;
	}
	public String getJobaddress() {
		return jobaddress;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public String getVisibility() {
		return visibility;
	}
	
	

}
