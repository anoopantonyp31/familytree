package com.dory.proffessional;

public interface ProffessionalDAO {

}
