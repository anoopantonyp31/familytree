package com.dory.proffessional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Session;
public class ProffessionalDAOImpl {
	
	public boolean insert(Session session, ProffessionalBean proffessionalBean) {
		session.beginTransaction();
		session.save(proffessionalBean);
		session.getTransaction().commit();
		return true;

	}
	public boolean update(Session session, ProffessionalBean proffessionalBean)
    {
	session.beginTransaction(); 
	session.update(proffessionalBean);
	session.getTransaction().commit();
	return true;
    }
	public boolean delete(Session session,ProffessionalBean proffessionalBean)
	
	{		
	session.beginTransaction();     
	session.delete(proffessionalBean);
	session.getTransaction().commit();
	return true;
	}

	public Collection displayproffessional(Session session,
			ProffessionalBean proffessionalBean,int q) {

		Collection executivecol = new ArrayList();
		try {
			List query = session.createQuery("from ProffessionalBean ex where ex.memberid='"+q+"'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				proffessionalBean = (ProffessionalBean) it.next();
				executivecol.add(proffessionalBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return executivecol;
	}

	//johnson
	public Collection edit(Session session, ProffessionalBean proffessionalBean,int b)
	{
		
		Collection exeobj=new ArrayList();
		List query = session.createSQLQuery("select * from member_job_detail ds where memberjobid="+b+"").addEntity("ds",ProffessionalBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
      {
			System.out.println("displaystandard====Iterator========");
			proffessionalBean = (ProffessionalBean) it.next();
			System.out.println("displaymemberjobid===="+proffessionalBean.getJobid());
			System.out.println("displaymemberjobid===="+proffessionalBean.getCompanyname());
			System.out.println("displaymemberjobid===="+proffessionalBean.getOccupation());
			exeobj.add(proffessionalBean);
		}
      return exeobj;
	}

}

