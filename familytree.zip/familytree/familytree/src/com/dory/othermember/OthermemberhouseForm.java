

/**
 * Date:23/11/2010
 * @author Upesh.A
 */

package com.dory.othermember;

import org.apache.struts.action.ActionForm;

public class OthermemberhouseForm extends ActionForm

{
 
	private String housename;
	 private String city ;
	 private String address ;
	 private String remark;

	 public void setHousename(String housename) {
		this.housename = housename;
	}
	public String getHousename() {
		return housename;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	public String getCity() {
		return city;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	
}
