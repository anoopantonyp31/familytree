
/**
 * Date:23/11/2010
 * @author Upesh.A
 */

package com.dory.othermember;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

//Action for accessing the other member profile

public class OthermemberAction extends Action{



	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//used to get the action value
					String k = request.getParameter("action");
					
				OthermemberForm othermemberForm = (OthermemberForm) form;
				OthermemberBean othermemberBean = new OthermemberBean();
                HttpSession httpsession = request.getSession();
                Session session = HibernateUtil.getSessionFactory()
				.openSession();

				
				//to get the session from the login action
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             
	            
				
				OthermemberDAOImpl othermemberDAO = new OthermemberDAOImpl();
				
				//if value of action=insert then enters below statement
			 
			
		
			
					
					if("setuserid".equals(k))
					{
						System.out.println("inside settings");
						String uid=request.getParameter("uid");
						int uid1=Integer.parseInt(uid);
						HttpSession session3=request.getSession();
						session3.setAttribute("uid1",uid1);
						target="correct";
					}
					
					
						
					
				
				
				
				
				
				
				
				
				
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}
}
