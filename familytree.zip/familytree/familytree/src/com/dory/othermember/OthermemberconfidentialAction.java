

/**
 * Date:23/11/2010
 * @author Upesh.A
 */

package com.dory.othermember;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

//Action for confidential details

public class OthermemberconfidentialAction extends Action 
{
  
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
	String target = null;
	try {
		if (form != null)
		{

			
			HttpSession httpsession = request.getSession();

			Session session = HibernateUtil.getSessionFactory()
					.openSession();
			System.out.println("session======111111=====>" + session);
			
			//Getting the memberid
			
			String r=(String)httpsession.getAttribute("mid").toString();
			 int q=Integer.parseInt(r);
             System.out.println("rambooo"+q);
             

             //Getting the userid(visitor's id)
             
             String r1=(String)httpsession.getAttribute("uid1").toString();
			 int q1=Integer.parseInt(r1);
                	
			        //Setting the attributes to display message("access denied")
			        String view="cannotaccess"; 
                	request.setAttribute("cannotaccess", view);
                	target="otherconfidential";
                	
            }
		}
		
		catch (Exception e) 
		{
		System.out.println("Exception=====>" + e);
		target="failure";
		}
		System.out.println("contargettttttttttt="+target);
	return (mapping.findForward(target));
	}
}
