
//Created by:Upesh.A
//Created on:18/11/2010

package com.dory.othermember;

//Bean for getting the member contact details

public class OthermembercontactBean 
 {
  private int contactid;
  private int memberid;
  private String landlineno;
  private String mobileno;
  private String emailid;
  private String remark;
  private String visibility;
public void setContactid(int contactid) {
	this.contactid = contactid;
}
public int getContactid() {
	return contactid;
}
public void setMemberid(int memberid) {
	this.memberid = memberid;
}
public int getMemberid() {
	return memberid;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
public String getMobileno() {
	return mobileno;
}
public void setLandlineno(String landlineno) {
	this.landlineno = landlineno;
}
public String getLandlineno() {
	return landlineno;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getEmailid() {
	return emailid;
}
public void setRemark(String remark) {
	this.remark = remark;
}
public String getRemark() {
	return remark;
}
public void setVisibility(String visibility) {
	this.visibility = visibility;
}
public String getVisibility() {
	return visibility;
}
 }
