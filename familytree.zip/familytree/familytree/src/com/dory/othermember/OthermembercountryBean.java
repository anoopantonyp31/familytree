
//Created by:Upesh.A
//Created on:18/11/2010


package com.dory.othermember;

//Bean for getting the country name

public class OthermembercountryBean 
 {
	private int countryid;
	 private String institutecountry1;

	public void setInstitutecountry1(String institutecountry1) {
		this.institutecountry1 = institutecountry1;
	}
	public String getInstitutecountry1() {
		return institutecountry1;
	}
	public void setCountryid(int countryid) {
		this.countryid = countryid;
	}
	public int getCountryid() {
		return countryid;
	}
 }
