package com.dory.othermember;
import java.util.Date;

public class OthermemberscrapBean 

{

	
	private int scrapbookid;
	private String sentby1;
	private int sentby;
	private int sentto;
	private String visibility;
	private String scraptext;
	private Date posteddate;
	public void setScrapbookid(int scrapbookid) {
		this.scrapbookid = scrapbookid;
	}
	public int getScrapbookid() {
		return scrapbookid;
	}
	public void setSentby(int sentby) {
		this.sentby = sentby;
	}
	public int getSentby() {
		return sentby;
	}
	public void setSentto(int sentto) {
		this.sentto = sentto;
	}
	public int getSentto() {
		return sentto;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public String getVisibility() {
		return visibility;
	}
	public void setScraptext(String scraptext) {
		this.scraptext = scraptext;
	}
	public String getScraptext() {
		return scraptext;
	}
	public void setPosteddate(Date posteddate) {
		this.posteddate = posteddate;
	}
	public Date getPosteddate() {
		return posteddate;
	}
	public void setSentby1(String sentby1) {
		this.sentby1 = sentby1;
	}
	public String getSentby1() {
		return sentby1;
	}

}
