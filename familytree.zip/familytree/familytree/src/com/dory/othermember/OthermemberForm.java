

/**
 * Date:16/11/2010
 * @author Upesh.A
 */


package com.dory.othermember;

import org.apache.struts.action.ActionForm;

public class OthermemberForm extends ActionForm 
 {
	 
	private int memberid;

	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}

	public int getMemberid() {
		return memberid;
	}
 }
