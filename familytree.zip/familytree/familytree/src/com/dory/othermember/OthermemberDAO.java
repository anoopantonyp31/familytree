

/**
 * Date:16/11/2010
 * @author Upesh.A
 */

package com.dory.othermember;

import java.util.Collection;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.educational.EducationalBean;
import com.dory.favourites.FavouritesBean;
import com.dory.house.HouseBean;
import com.dory.memberbiodata.BiodataBean;
import com.dory.personal.PersonalBean;
import com.dory.proffessional.ProffessionalBean;

public interface OthermemberDAO 
 {
	//Method for display the personal details
	
	public Collection displayotherpersonal(Session session,PersonalBean OthermemberpersonalBean,int q,int q1);
	
	//Method for display the contact details
	
	public Collection displayothercontact(Session session,OthermembercontactBean othermembercontactBean,int q,int q1);
	
	//Method for display the educational details
	
	public Collection displayothereducation(Session session,EducationalBean othermembereduBean,int q,int q1);
	
	//Method for display the professional details
	
	public Collection displayotherprofession(Session session,ProffessionalBean othermemberprofessionBean,int q,int q1);
	
	//Method for display the favourite details of the member
	
	public Collection displayotherfavourite(Session session,FavouritesBean othermemberfavouriteBean,int q,int q1);
	
	//Method for display the member details
	
	public Collection displayotheraboutme(Session session,AboutBean othermemberaboutmeBean,int q,int q1);
	
	//Method for display the house details
	
	public Collection displayotherbiodata(Session session,BiodataBean biodataBean,int q,int q1);
	
	public Collection displayotherhouse(Session session,HouseBean othermemberhouseBean,int q,int q1);
	
	
	public Collection displaysuperaboutme(Session session,AboutBean othermemberaboutmeBean,int q,int q1);
	
	
	public Collection displaysupercontact(Session session,OthermembercontactBean othermembercontactBean,int q,int q1);
	
	
	public Collection displaysupereducation(Session session,EducationalBean othermembereduBean,int q,int q1);
	
	
	public Collection displaysuperfavourite(Session session,FavouritesBean othermemberfavouriteBean,int q,int q1);
	
	
	public Collection displaysuperhouse(Session session,HouseBean othermemberhouseBean,int q,int q1);
	
	
	public Collection displaysuperpersonal(Session session,PersonalBean othermemberpersonalBean,int q,int q1);
	
	
	public Collection displaysuperprofession(Session session,ProffessionalBean othermemberprofessionBean,int q,int q1);
	
	
	public Collection displaysuperbiodata(Session session,BiodataBean biodataBean,int q,int q1);
	
	
	public Collection viewscraps(Session session,OthermemberscrapBean othermemberscrapBean,int uid1);
	
	
	public boolean insert(Session session,OthermemberscrapBean othermemberscrapBean);
	
	
	public OthermemberscrapBean checkmember(Session session,OthermemberscrapBean othermemberscrapBean);
	
	
	public boolean delete(Session session,OthermemberscrapBean othermemberscrapBean);
	
	
	
 }
