

/**
 * Date:23/11/2010
 * @author Upesh.A
 */

package com.dory.othermember;

import org.apache.struts.action.ActionForm;

public class OthermemberfavouriteForm extends ActionForm 
{
	private String activities;
	private String interests;
	private String movies;
	private String tvshows;
	private String music;
	private String books;
	private String sports;
	private String remark;
	private String hobbies;
	public void setActivities(String activities) {
		this.activities = activities;
	}
	public String getActivities() {
		return activities;
	}
	public void setInterests(String interests) {
		this.interests = interests;
	}
	public String getInterests() {
		return interests;
	}
	public void setMovies(String movies) {
		this.movies = movies;
	}
	public String getMovies() {
		return movies;
	}
	public void setTvshows(String tvshows) {
		this.tvshows = tvshows;
	}
	public String getTvshows() {
		return tvshows;
	}
	public void setMusic(String music) {
		this.music = music;
	}
	public String getMusic() {
		return music;
	}
	public void setBooks(String books) {
		this.books = books;
	}
	public String getBooks() {
		return books;
	}
	public void setSports(String sports) {
		this.sports = sports;
	}
	public String getSports() {
		return sports;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}

	
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	public String getHobbies() {
		return hobbies;
	}
	
}
