package com.dory.othermember;

public class ScrapsentbyBean 
{
 private int memberid;
 private String sentby1;
public void setMemberid(int memberid) {
	this.memberid = memberid;
}
public int getMemberid() {
	return memberid;
}
public void setSentby1(String sentby1) {
	this.sentby1 = sentby1;
}
public String getSentby1() {
	return sentby1;
}

}
