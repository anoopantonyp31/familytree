

/**
 * Date:19/11/2010
 * @author Upesh.A
 */

package com.dory.othermember;

import org.apache.struts.action.ActionForm;

public class OthermembereduForm extends ActionForm 
{
 
	private String institutecountry1;
	 private int startyear;
	 private int endyear;
	 private String remark;
	 private String educationaltype;
	 private String institutename;
	 private String instituteplace;
	 private String institutestate;
	public void setInstitutecountry1(String institutecountry1) {
		this.institutecountry1 = institutecountry1;
	}
	public String getInstitutecountry1() {
		return institutecountry1;
	}
	public void setStartyear(int startyear) {
		this.startyear = startyear;
	}
	public int getStartyear() {
		return startyear;
	}
	public void setEndyear(int endyear) {
		this.endyear = endyear;
	}
	public int getEndyear() {
		return endyear;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setEducationaltype(String educationtype) {
		this.educationaltype = educationtype;
	}
	public String getEducationaltype() {
		return educationaltype;
	}
	public void setInstitutename(String institutename) {
		this.institutename = institutename;
	}
	public String getInstitutename() {
		return institutename;
	}
	public void setInstituteplace(String instituteplace) {
		this.instituteplace = instituteplace;
	}
	public String getInstituteplace() {
		return instituteplace;
	}
	public void setInstitutestate(String institutestate) {
		this.institutestate = institutestate;
	}
	public String getInstitutestate() {
		return institutestate;
	}
}
