package com.dory.othermember;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.community.CommunitycheckBean;
import com.dory.educational.EducationalBean;
import com.dory.favourites.FavouritesBean;
import com.dory.house.HouseBean;
import com.dory.memberbiodata.BiodataBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.mygroup.GroupmemberBean;
import com.dory.mygroup.MygroupBean;
import com.dory.personal.PersonalBean;
import com.dory.proffessional.ProffessionalBean;

public class OthermemberDAOImpl implements OthermemberDAO
 {
	
	//Method for display the personal details 
	
	public Collection displayotherpersonal(Session session,PersonalBean othermemberpersonalBean,int q,int q1)
	{
		Collection standardcol=new ArrayList();
		OthermemberBean othermemberBean = new OthermemberBean();
		GroupmemberBean othergroupBean = new GroupmemberBean();
		MygroupBean groupownerBean = new MygroupBean();
		CommunitycheckBean communityownerBean = new CommunitycheckBean();
		Communitymember1Bean communitymember1Bean = new Communitymember1Bean();
		try
		{
			
			
			//Selecting data from member_personal_detail table where memberid="q1"
		List query = session.createSQLQuery("select * from member_personal_detail ds where memberid='"+q1+"' ").addEntity("ds",PersonalBean.class).list();
System.out.println("displaystandard====query========"+query);
		
      for (Iterator it = query.iterator(); it.hasNext();) {
	
			othermemberpersonalBean = (PersonalBean) it.next();
			//Getting the maritial status  
       	 int d=othermemberpersonalBean.getMaritalstatus();
    
       	 //Converting the integer status to corresponding values
       	 
    	 if(d==0)	 
    	 {
    		 System.out.println("if 00000000000");
    		othermemberpersonalBean.setMaritalstatus1("Unmarried");
    		System.out.println("uusttattus===="+othermemberpersonalBean.getMaritalstatus1());
    	 }
    	 else if(d==1)
    	 {
    		 System.out.println("if 1111111111");
    		 othermemberpersonalBean.setMaritalstatus1("Married");
    		 System.out.println("uusttattus===="+othermemberpersonalBean.getMaritalstatus1());
    	 }
    	 else
    	 {
    		 System.out.println("if 22222222222");
    		 othermemberpersonalBean.setMaritalstatus1("Divorced"); 
    		 System.out.println("uusttattus===="+othermemberpersonalBean.getMaritalstatus1());
    	 }
			//Getting the visibility set by the member
    	 
			String s=othermemberpersonalBean.getVisibility();

			//setting up the visibility lelvels
			
			//for public only
			if("8".equals(s))
			{
				//adding the values to the collection
				standardcol.add(othermemberpersonalBean);
			}
			
			//for family only
			else if("1".equals(s))
			{
				
				int fid1=0;//familyid of member
				int fid2=0;//familyid of the visitor
				//Selecting data from member_relations table where memberid="q1"
				List query1 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
				      {
							
							othermemberBean = (OthermemberBean) it1.next();
						  fid1=othermemberBean.getFamilyid();
							  
				
			          }
				      //Selecting data from member_relations table where memberid="q"
				      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									othermemberBean = (OthermemberBean) it2.next();
									fid2=othermemberBean.getFamilyid();
									
						
					          }
			
						      if(fid1==fid2)
						      {
						    	  //adding the values to the collection
						    	  standardcol.add(othermemberpersonalBean); 
						      }
			}
			
			//for group only
			
			else if("4".equals(s))
			{
				System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
				int gid1=0;//Groupid of the group owner(other member)
				int flag =0;//flag to know if the member is in that group
				
				//Selecting data from groups table where groupowner="q1"
				
				List query1 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
				      {
							System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
							groupownerBean = (MygroupBean) it1.next();
							
							//Groupid of the group owner(other member)
							
						    gid1=groupownerBean.getGroupid();
							
						  //Selecting data from group_members table where groupid="gid1" and memberid="q"
						    
							 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
							 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								 
						      {
								    flag=1;//Setting the flag value to 1
								    othergroupBean = (GroupmemberBean) it2.next();
									
									
						      }		
							
							 
			          }
				      
				      if(flag==1)
				    		  {
				      standardcol.add(othermemberpersonalBean);//adding the values to the collection
				    		  }
			}
			
			//for community only
			
			else if("2".equals(s))
			{
				
				int cid=0;//Communityid of the community owner(other member)
				int flag =0;//flag to know if the member is in that community
				
				//Selecting data from community table where createdby="q1"
				
				List query1 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
				      {
							
							communityownerBean = (CommunitycheckBean) it1.next();
						    cid=communityownerBean.getCommunityid();
							
						  //Selecting data from community_members table where communityid=cid1 and memberid='q' and status='active'
						    
							 List query2 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
							 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								 
						      {
								    flag=1;//Setting the flag value to 1
									communitymember1Bean = (Communitymember1Bean) it2.next();
										
									
						      }		
							
							 
			          }
				      
				      if(flag==1)
				     {
				     //adding the values to the collection	  
				    	  
				      standardcol.add(othermemberpersonalBean);
				     }
			}
	             //for family & community		
			
				      else if("3".equals(s))
				      {
				    	  
				    	  int fid1=0;//familyid of the visitor
						  int fid2=0;//familyid of the other member
						  
						  //Selecting data from member_relations table where memberid="q1"
						  
				    	  List query1 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										othermemberBean = (OthermemberBean) it1.next();
									  fid1=othermemberBean.getFamilyid();
										  
							
						          }
							      
							      //Selecting data from member_relations table where memberid="q"
							      
							      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it2.next();
												fid2=othermemberBean.getFamilyid();
												
									
								          }
									      
									      int cid=0;//communityid
										  int flag =0;//flag to know if the member is in that community
										  
										  //Selecting data from community table where createdby="q1"
										  
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
													    
													    //Selecting data from community_members table where communityid='cid'
													    
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag=1;
															   
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
									      
									      if(fid1==fid2 || flag==1)
									      {
									    	  standardcol.add(othermemberpersonalBean); //adding the values to the collection
									      }
									      					      
	     
				      }
			
				      else if("7".equals(s))//for group,community & family
				      {
				    	  
				    	  int fid1=0;//familyid of member
						 int fid2=0;//familyid of the visitor
						 
						 //Selecting data from member_relations table where memberid="q1"
						 
				    	  List query1 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();

									
							      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
							      {
										
									  othermemberBean = (OthermemberBean) it1.next();
									  fid1=othermemberBean.getFamilyid();
										  
							
						          }
							      
							      //Selecting data from member_relations table where memberid="q"
							      
							      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
									      {
												
												othermemberBean = (OthermemberBean) it2.next();
												fid2=othermemberBean.getFamilyid();
												
									
								          }
									      
									      int cid=0;//communityid of the member
										  int flag =0;//flag to know whether in the member is in the group
									      int gid1=0;//groupid of the member
										  int flag1 =0;//flag to know whether the member is in the community
										  
										//Selecting data from community table where createdby="q1"
										  
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														
													  //Selecting data from community_members table where communityid='cid' and memberid='q' and status='active'
													    
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag=1;
															    
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
											      
											    //Selecting data from groups table where groupowner="q1"

													List query5 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
															
													      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
													      {
															
																groupownerBean = (MygroupBean) it5.next();
															    gid1=groupownerBean.getGroupid();
																
															  //Selecting data from group_members table where groupid='gid1' and memberid="q"
															    
																 List query6 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
																 for (Iterator it6 = query6.iterator(); it6.hasNext();) 
																	 
															      {
																	    flag1=1;
																	   
																	    othergroupBean = (GroupmemberBean) it6.next();
																		
																		
																		
															      }		
																
																 
												          } 
									      
									      if(fid1==fid2 || flag==1 || flag1==1)//Whether the member is in the family or group or in the community
									      {
									    	  standardcol.add(othermemberpersonalBean);  //adding the values to the collection
									      }
									      					      
	     
				      }
			
			          //for group & family
			
				      else if("6".equals(s))
				      {
				    	  int gid1=0;//groupid of the member
							int flag =0;//flag to know whether the member is in the group
							
							//Selecting data from groups table where groupowner="q1"
							
							List query1 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
							      {
										
							    	  groupownerBean = (MygroupBean) it1.next();
									    gid1=groupownerBean.getGroupid();
										
									   //Selecting data from group_members table where groupid='gid1' and memberid="q"
									    
										 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
										 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
											 
									      {
											    flag=1;
											    
											    othergroupBean = (GroupmemberBean) it2.next();
												
												
												
									      }		
										
										 
						          }
				    	  
									      
									      int cid=0;//communityid of the member
										  int flag1 =0;//flag to know whether the member is in the community
										  
										  //Selecting data from community table where createdby='q1'
										  
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														
													  //Selecting data from community_members table where communityid='cid' and memberid='q' and status='active'
													    
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag1=1;
															    
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
									      
									      if(flag==1 || flag1==1)
									      {
									    	  standardcol.add(othermemberpersonalBean);  //adding the values to the collection
									      }
									      					      
	     
				      }
			
			           //for both group and family
			
				      else if("5".equals(s))
				      {
				    	  int gid1=0;//groupid of the member
							int flag =0;//flag to know whether the member is in the group
							
							//Selecting data from groups table where groupowner="q1"
							
							List query1 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
							
									
							      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
							      {
										
							    	  groupownerBean = (MygroupBean) it1.next();
									    gid1=groupownerBean.getGroupid();
										
									  //Selecting data from group_members table where groupid="gid1"
									    
										 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
										 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
											 
									      {
											    flag=1;
											    othergroupBean = (GroupmemberBean) it2.next();
												
												
												
									      }		
										
										 
						          }
				    	  
							      int fid1=0;//familyid of the member
									int fid2=0;//familyid of the visitor(other member)
									
									 //Selecting data from member_relations table where memberid="q1"
									
									List query4 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
									
											
									      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
									      {
												
												othermemberBean = (OthermemberBean) it4.next();
											  fid1=othermemberBean.getFamilyid();
												  
									
								          }
									      
									    //Selecting data from member_relations table where memberid="q"
									      
									      List query5 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();

													
											      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
											      {
														
														othermemberBean = (OthermemberBean) it5.next();
														fid2=othermemberBean.getFamilyid();
														
											
										          }
								
											      if(flag==1 || fid1==fid2)
											      {
											    	  standardcol.add(othermemberpersonalBean); //adding the values to the collection
											      }		  
									      
									   			      
	     
				      }
			
			}
			
      
		
	
		}
	catch(Exception he){
			System.out.println("errorrrrrrrr"+he);
		}
		
		return standardcol;//returning the collection
	}
	
	
	
	
	
	
//memthod to display the contact details	
	
	
	public Collection displayothercontact(Session session,OthermembercontactBean othermembercontactBean,int q,int q1)
	{
		
		Collection displayothercontact=new ArrayList();
		OthermemberBean othermemberBean = new OthermemberBean();
		GroupmemberBean GroupmemberBean = new GroupmemberBean();
		MygroupBean MygroupBean = new MygroupBean();
		CommunitycheckBean communityownerBean = new CommunitycheckBean();
		Communitymember1Bean communitymember1Bean = new Communitymember1Bean();
		
		try
		{
			
		    List query = session.createSQLQuery("select * from member_contact_detail ds where memberid='"+q1+"' ").addEntity("ds",OthermembercontactBean.class).list();
		    for (Iterator it = query.iterator(); it.hasNext();) 
		    {
		    	othermembercontactBean = (OthermembercontactBean) it.next();
		    	String s = othermembercontactBean.getVisibility();
		    	
		    	if("8".equals(s))
				{
					
		    		displayothercontact.add(othermembercontactBean);
				}
				else if("1".equals(s))
				{
					System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
					int fid1=0;
					int fid2=0;
					List query1 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
					System.out.println("displaystandard====query========"+query);
							
					      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
					      {
								System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
								othermemberBean = (OthermemberBean) it1.next();
							  fid1=othermemberBean.getFamilyid();
								  
					
				          }
					      
					      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										othermemberBean = (OthermemberBean) it2.next();
										fid2=othermemberBean.getFamilyid();
										
							
						          }
				
							      if(fid1==fid2)
							      {
							    	  displayothercontact.add(othermembercontactBean); 
							      }
				}
		    	
		    	
				else if("4".equals(s))
				{
					System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
					int gid1=0;
					int flag =0;
					List query1 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
					System.out.println("displaystandard====query========"+query);
							
					      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
					      {
								System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
								MygroupBean = (MygroupBean) it1.next();
							    gid1=MygroupBean.getGroupid();
								System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
								 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
								 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
									 
							      {
									    flag=1;
									    System.out.println("In===========================flag================================...........>>>>>"+flag);
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										GroupmemberBean = (GroupmemberBean) it2.next();
										
										
										
							      }		
								
								 
				          }
					      
					      if(flag==1)
					    		  {
					    	  displayothercontact.add(othermembercontactBean);
					      System.out.println("display iiiiiisssssizzzzeeeeeeeee"+displayothercontact.size());
					    		  }
				}
				
				else if("2".equals(s))
				{
					System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
					int cid=0;
					int flag =0;
					List query1 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
					System.out.println("displaystandard====query========"+query);
							
					      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
					      {
								System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
								communityownerBean = (CommunitycheckBean) it1.next();
							    cid=communityownerBean.getCommunityid();
								System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
								 List query2 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
								 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
									 
							      {
									    flag=1;
									    System.out.println("In===========================flag================================...........>>>>>"+flag);
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										communitymember1Bean = (Communitymember1Bean) it2.next();
										
										
										
							      }		
								
								 
				          }
					      
					      if(flag==1)
					     {
					    	  displayothercontact.add(othermembercontactBean);
					      System.out.println("display iiiiiisssssizzzzeeeeeeeee"+displayothercontact.size());
					     }
				}
		    	
		    	
				 else if("3".equals(s))
			      {
			    	  
			    	  int fid1=0;
					  int fid2=0;
			    	  List query1 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									othermemberBean = (OthermemberBean) it1.next();
								  fid1=othermemberBean.getFamilyid();
									  
						
					          }
						      
						      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
								System.out.println("displaystandard====query========"+query);
										
								      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								      {
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											othermemberBean = (OthermemberBean) it2.next();
											fid2=othermemberBean.getFamilyid();
											
								
							          }
								      
								      int cid=0;
									  int flag =0;
										List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
										System.out.println("displaystandard====query========"+query);
												
										      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
										      {
													System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
													communityownerBean = (CommunitycheckBean) it3.next();
												    cid=communityownerBean.getCommunityid();
													System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
													 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
													 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
														 
												      {
														    flag=1;
														    System.out.println("In===========================flag================================...........>>>>>"+flag);
															System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
															communitymember1Bean = (Communitymember1Bean) it4.next();
															
															
															
												      }		
													
													 
									          }
								      
								      if(fid1==fid2 || flag==1)
								      {
								    	  displayothercontact.add(othermembercontactBean); 
								      }
								      					      
    
			      }
		
			      else if("7".equals(s))
			      {
			    	  
			    	  int fid1=0;
					  int fid2=0;
			    	  List query1 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									othermemberBean = (OthermemberBean) it1.next();
								  fid1=othermemberBean.getFamilyid();
									  
						
					          }
						      
						      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
								System.out.println("displaystandard====query========"+query);
										
								      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								      {
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											othermemberBean = (OthermemberBean) it2.next();
											fid2=othermemberBean.getFamilyid();
											
								
							          }
								      
								      int cid=0;
									  int flag =0;
										List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
										System.out.println("displaystandard====query========"+query);
												
										      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
										      {
													System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
													communityownerBean = (CommunitycheckBean) it3.next();
												    cid=communityownerBean.getCommunityid();
													System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
													 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
													 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
														 
												      {
														    flag=1;
														    System.out.println("In===========================flag================================...........>>>>>"+flag);
															System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
															communitymember1Bean = (Communitymember1Bean) it4.next();
															
															
															
												      }		
													
													 
									          }
										      
										      int gid1=0;
												int flag1 =0;
												List query5 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
												System.out.println("displaystandard====query========"+query);
														
												      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
												      {
															System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
															MygroupBean = (MygroupBean) it5.next();
														    gid1=MygroupBean.getGroupid();
															System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
															 List query6 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
															 for (Iterator it6 = query6.iterator(); it6.hasNext();) 
																 
														      {
																    flag1=1;
																    System.out.println("In===========================flag================================...........>>>>>"+flag);
																	System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																	GroupmemberBean = (GroupmemberBean) it6.next();
																	
																	
																	
														      }		
															
															 
											          } 
								      
								      if(fid1==fid2 || flag==1 || flag1==1)
								      {
								    	  displayothercontact.add(othermembercontactBean);
								      }
								      					      
    
			      }
		
		
			      else if("6".equals(s))
			      {
			    	  int gid1=0;
						int flag =0;
						List query1 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									MygroupBean = (MygroupBean) it1.next();
								    gid1=MygroupBean.getGroupid();
									System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
									 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
									 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
										 
								      {
										    flag=1;
										    System.out.println("In===========================flag================================...........>>>>>"+flag);
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											GroupmemberBean = (GroupmemberBean) it2.next();
											
											
											
								      }		
									
									 
					          }
			    	  
								      
								      int cid=0;
									  int flag1 =0;
										List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
										System.out.println("displaystandard====query========"+query);
												
										      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
										      {
													System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
													communityownerBean = (CommunitycheckBean) it3.next();
												    cid=communityownerBean.getCommunityid();
													System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
													 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
													 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
														 
												      {
														    flag1=1;
														    System.out.println("In===========================flag================================...........>>>>>"+flag);
															System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
															communitymember1Bean = (Communitymember1Bean) it4.next();
															
															
															
												      }		
													
													 
									          }
								      
								      if(flag==1 || flag1==1)
								      {
								    	  displayothercontact.add(othermembercontactBean);
								      }
								      					      
    
			      }
		
		
			      else if("5".equals(s))
			      {
			    	  int gid1=0;
						int flag =0;
						List query1 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									MygroupBean = (MygroupBean) it1.next();
								    gid1=MygroupBean.getGroupid();
									System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
									 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
									 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
										 
								      {
										    flag=1;
										    System.out.println("In===========================flag================================...........>>>>>"+flag);
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											GroupmemberBean = (GroupmemberBean) it2.next();
											
											
											
								      }		
									
									 
					          }
			    	  
						      int fid1=0;
								int fid2=0;
								List query4 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
								System.out.println("displaystandard====query========"+query);
										
								      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
								      {
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											othermemberBean = (OthermemberBean) it4.next();
										  fid1=othermemberBean.getFamilyid();
											  
								
							          }
								      
								      List query5 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
										System.out.println("displaystandard====query========"+query);
												
										      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
										      {
													System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
													othermemberBean = (OthermemberBean) it5.next();
													fid2=othermemberBean.getFamilyid();
													
										
									          }
							
										      if(flag==1 || fid1==fid2)
										      {
										    	  displayothercontact.add(othermembercontactBean); 
										      }		  
								      
								   			      
    
			      }
		    	
		    	
		    	
		    	
		    }
		   // displayothercontact.add(othermembercontactBean);
		}  
		catch(Exception he){
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displayothercontact;
	}
	
	
	//memthod to display the education details
	
	
	public Collection displayothereducation(Session session,EducationalBean othermembereduBean,int q,int q1)
	{
		
		Collection displayothereducation=new ArrayList();
		OthermembercountryBean othermembercountryBean = new OthermembercountryBean();
		OthermemberBean othermemberBean = new OthermemberBean();
		GroupmemberBean GroupmemberBean = new GroupmemberBean();
		MygroupBean MygroupBean = new MygroupBean();
		CommunitycheckBean communityownerBean = new CommunitycheckBean();
		Communitymember1Bean communitymember1Bean = new Communitymember1Bean();
		try
		{
			
			
			//Selecting data from receipients_of_invitation table where memberid="q"
		List query = session.createSQLQuery("select * from member_education ds where memberid='"+q1+"' ").addEntity("ds",EducationalBean.class).list();
		for (Iterator it = query.iterator(); it.hasNext();) 
		{
			System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
			othermembereduBean = (EducationalBean) it.next();
			String coid=othermembereduBean.getInstitutecountry();
			String s = othermembereduBean.getVisibility();
			int countryid1 = Integer.parseInt(coid);	
			
			List query1 = session.createSQLQuery("select * from countries ts where countryid='"+countryid1+"' ").addEntity("ts",OthermembercountryBean.class).list();
			
			for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			{
				System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
				othermembercountryBean = (OthermembercountryBean) it1.next();
				othermembereduBean.setInstitutecountry1(othermembercountryBean.getInstitutecountry1());;
				System.out.println("In the ccccccccccouuuuuuntttttrrrrrrrrrryyyyyyyname===="+othermembereduBean.getInstitutecountry1());
			}	
			
			
		
		
		if("8".equals(s))
		{
			
			displayothereducation.add(othermembereduBean);
		}
		else if("1".equals(s))
		{
			System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
			int fid1=0;
			int fid2=0;
			List query2 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
			      {
						System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
						othermemberBean = (OthermemberBean) it2.next();
					  fid1=othermemberBean.getFamilyid();
						  
			
		          }
			      
			      List query3 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
					System.out.println("displaystandard====query========"+query);
							
					      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
					      {
								System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
								othermemberBean = (OthermemberBean) it3.next();
								fid2=othermemberBean.getFamilyid();
								
					
				          }
		
					      if(fid1==fid2)
					      {
					    	  displayothereducation.add(othermembereduBean); 
					      }
		}
		
		else if("4".equals(s))
		{
			System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
			int gid1=0;
			int flag =0;
			List query4 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
			      {
						System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
						MygroupBean = (MygroupBean) it4.next();
					    gid1=MygroupBean.getGroupid();
						System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
						 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
						 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
							 
					      {
							    flag=1;
							    System.out.println("In===========================flag================================...........>>>>>"+flag);
								System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
								GroupmemberBean = (GroupmemberBean) it2.next();
								
								
								
					      }		
						
						 
		          }
			      
			      if(flag==1)
			    		  {
			    	  displayothereducation.add(othermembereduBean);
			      System.out.println("display iiiiiisssssizzzzeeeeeeeee"+displayothereducation.size());
			    		  }
		}
		
		else if("2".equals(s))
		{
			System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
			int cid=0;
			int flag =0;
			List query6 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it6 = query6.iterator(); it6.hasNext();) 
			      {
						System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
						communityownerBean = (CommunitycheckBean) it6.next();
					    cid=communityownerBean.getCommunityid();
						System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
						 List query2 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
						 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
							 
					      {
							    flag=1;
							    System.out.println("In===========================flag================================...........>>>>>"+flag);
								System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
								communitymember1Bean = (Communitymember1Bean) it2.next();
								
								
								
					      }		
						
						 
		          }
			      
			      if(flag==1)
			     {
			    	  displayothereducation.add(othermembereduBean);
			      System.out.println("display iiiiiisssssizzzzeeeeeeeee"+displayothereducation.size());
			     }
		}
			      else if("3".equals(s))
			      {
			    	  
			    	  int fid1=0;
					  int fid2=0;
			    	  List query7 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
								
						      for (Iterator it7 = query7.iterator(); it7.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									othermemberBean = (OthermemberBean) it7.next();
								  fid1=othermemberBean.getFamilyid();
									  
						
					          }
						      
						      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
								System.out.println("displaystandard====query========"+query);
										
								      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								      {
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											othermemberBean = (OthermemberBean) it2.next();
											fid2=othermemberBean.getFamilyid();
											
								
							          }
								      
								      int cid=0;
									  int flag =0;
										List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
										System.out.println("displaystandard====query========"+query);
												
										      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
										      {
													System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
													communityownerBean = (CommunitycheckBean) it3.next();
												    cid=communityownerBean.getCommunityid();
													System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
													 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
													 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
														 
												      {
														    flag=1;
														    System.out.println("In===========================flag================================...........>>>>>"+flag);
															System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
															communitymember1Bean = (Communitymember1Bean) it4.next();
															
															
															
												      }		
													
													 
									          }
								      
								      if(fid1==fid2 || flag==1)
								      {
								    	  displayothereducation.add(othermembereduBean);
								      }
								      					      
     
			      }
		
			      else if("7".equals(s))
			      {
			    	  
			    	  int fid1=0;
					  int fid2=0;
			    	  List query8 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it8 = query8.iterator(); it8.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									othermemberBean = (OthermemberBean) it8.next();
								  fid1=othermemberBean.getFamilyid();
									  
						
					          }
						      
						      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
								System.out.println("displaystandard====query========"+query);
										
								      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								      {
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											othermemberBean = (OthermemberBean) it2.next();
											fid2=othermemberBean.getFamilyid();
											
								
							          }
								      
								      int cid=0;
									  int flag =0;
										List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
										System.out.println("displaystandard====query========"+query);
												
										      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
										      {
													System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
													communityownerBean = (CommunitycheckBean) it3.next();
												    cid=communityownerBean.getCommunityid();
													System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
													 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
													 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
														 
												      {
														    flag=1;
														    System.out.println("In===========================flag================================...........>>>>>"+flag);
															System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
															communitymember1Bean = (Communitymember1Bean) it4.next();
															
															
															
												      }		
													
													 
									          }
										      
										      int gid1=0;
												int flag1 =0;
												List query5 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
												System.out.println("displaystandard====query========"+query);
														
												      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
												      {
															System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
															MygroupBean = (MygroupBean) it5.next();
														    gid1=MygroupBean.getGroupid();
															System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
															 List query6 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
															 for (Iterator it6 = query6.iterator(); it6.hasNext();) 
																 
														      {
																    flag1=1;
																    System.out.println("In===========================flag================================...........>>>>>"+flag);
																	System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																	GroupmemberBean = (GroupmemberBean) it6.next();
																	
																	
																	
														      }		
															
															 
											          } 
								      
								      if(fid1==fid2 || flag==1 || flag1==1)
								      {
								    	  displayothereducation.add(othermembereduBean); 
								      }
								      					      
     
			      }
		
		
			      else if("6".equals(s))
			      {
			    	  int gid1=0;
						int flag =0;
						List query9 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it9 = query9.iterator(); it9.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									MygroupBean = (MygroupBean) it9.next();
								    gid1=MygroupBean.getGroupid();
									System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
									 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
									 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
										 
								      {
										    flag=1;
										    System.out.println("In===========================flag================================...........>>>>>"+flag);
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											GroupmemberBean = (GroupmemberBean) it2.next();
											
											
											
								      }		
									
									 
					          }
			    	  
								      
								      int cid=0;
									  int flag1 =0;
										List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
										System.out.println("displaystandard====query========"+query);
												
										      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
										      {
													System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
													communityownerBean = (CommunitycheckBean) it3.next();
												    cid=communityownerBean.getCommunityid();
													System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
													 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
													 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
														 
												      {
														    flag1=1;
														    System.out.println("In===========================flag================================...........>>>>>"+flag);
															System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
															communitymember1Bean = (Communitymember1Bean) it4.next();
															
															
															
												      }		
													
													 
									          }
								      
								      if(flag==1 || flag1==1)
								      {
								    	  displayothereducation.add(othermembereduBean);
								      }
								      					      
     
			      }
		
		
			      else if("5".equals(s))
			      {
			    	  int gid1=0;
						int flag =0;
						List query10 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it10 = query10.iterator(); it10.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									MygroupBean = (MygroupBean) it10.next();
								    gid1=MygroupBean.getGroupid();
									System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
									 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
									 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
										 
								      {
										    flag=1;
										    System.out.println("In===========================flag================================...........>>>>>"+flag);
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											GroupmemberBean = (GroupmemberBean) it2.next();
											
											
											
								      }		
									
									 
					          }
			    	  
						      int fid1=0;
								int fid2=0;
								List query4 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
								System.out.println("displaystandard====query========"+query);
										
								      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
								      {
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											othermemberBean = (OthermemberBean) it4.next();
										  fid1=othermemberBean.getFamilyid();
											  
								
							          }
								      
								      List query5 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
										System.out.println("displaystandard====query========"+query);
												
										      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
										      {
													System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
													othermemberBean = (OthermemberBean) it5.next();
													fid2=othermemberBean.getFamilyid();
													
										
									          }
							
										      if(flag==1 || fid1==fid2)
										      {
										    	  displayothereducation.add(othermembereduBean);
										      }		  
								      
								   			      
     
			      }
		
		}
		}
		
		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displayothereducation;
		
	 }
	
	
	//memthod to display the professional details
	
	
	
	public Collection displayotherprofession(Session session,ProffessionalBean othermemberprofessionBean,int q,int q1)
	{
		
		Collection displayotherprofession=new ArrayList();
		OthermemberBean othermemberBean = new OthermemberBean();
		GroupmemberBean GroupmemberBean = new GroupmemberBean();
		MygroupBean MygroupBean = new MygroupBean();
		CommunitycheckBean communityownerBean = new CommunitycheckBean();
		Communitymember1Bean communitymember1Bean = new Communitymember1Bean();
		try
	   {
			
	  	 List query = session.createSQLQuery("select * from member_job_detail ds where memberid='"+q1+"' ").addEntity("ds",ProffessionalBean.class).list();
	  	for (Iterator it = query.iterator(); it.hasNext();)
	  	{
			System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
			othermemberprofessionBean = (ProffessionalBean) it.next();
			String s = othermemberprofessionBean.getVisibility();
			
			
			
			if("8".equals(s))
			{
				
				displayotherprofession.add(othermemberprofessionBean);
			}
			else if("1".equals(s))
			{
				System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
				int fid1=0;
				int fid2=0;
				List query2 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
				      {
							System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
							othermemberBean = (OthermemberBean) it2.next();
						  fid1=othermemberBean.getFamilyid();
							  
				
			          }
				      
				      List query3 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									othermemberBean = (OthermemberBean) it3.next();
									fid2=othermemberBean.getFamilyid();
									
						
					          }
			
						      if(fid1==fid2)
						      {
						    	  displayotherprofession.add(othermemberprofessionBean);
						      }
			}
			
			else if("4".equals(s))
			{
				System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
				int gid1=0;
				int flag =0;
				List query4 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
				      {
							System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
							MygroupBean = (MygroupBean) it4.next();
						    gid1=MygroupBean.getGroupid();
							System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
							 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
							 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								 
						      {
								    flag=1;
								    System.out.println("In===========================flag================================...........>>>>>"+flag);
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									GroupmemberBean = (GroupmemberBean) it2.next();
									
									
									
						      }		
							
							 
			          }
				      
				      if(flag==1)
				    		  {
				    	  displayotherprofession.add(othermemberprofessionBean);
				      System.out.println("display iiiiiisssssizzzzeeeeeeeee"+displayotherprofession.size());
				    		  }
			}
			
			else if("2".equals(s))
			{
				System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
				int cid=0;
				int flag =0;
				List query6 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it6 = query6.iterator(); it6.hasNext();) 
				      {
							System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
							communityownerBean = (CommunitycheckBean) it6.next();
						    cid=communityownerBean.getCommunityid();
							System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
							 List query2 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
							 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								 
						      {
								    flag=1;
								    System.out.println("In===========================flag================================...........>>>>>"+flag);
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									communitymember1Bean = (Communitymember1Bean) it2.next();
									
									
									
						      }		
							
							 
			          }
				      
				      if(flag==1)
				     {
				    	  displayotherprofession.add(othermemberprofessionBean);
				      System.out.println("display iiiiiisssssizzzzeeeeeeeee"+displayotherprofession.size());
				     }
			}
				      else if("3".equals(s))
				      {
				    	  
				    	  int fid1=0;
						  int fid2=0;
				    	  List query7 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
									
							      for (Iterator it7 = query7.iterator(); it7.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										othermemberBean = (OthermemberBean) it7.next();
									  fid1=othermemberBean.getFamilyid();
										  
							
						          }
							      
							      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it2.next();
												fid2=othermemberBean.getFamilyid();
												
									
								          }
									      
									      int cid=0;
										  int flag =0;
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag=1;
															    System.out.println("In===========================flag================================...........>>>>>"+flag);
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
									      
									      if(fid1==fid2 || flag==1)
									      {
									    	  displayotherprofession.add(othermemberprofessionBean);
									      }
									      					      
	     
				      }
			
				      else if("7".equals(s))
				      {
				    	  
				    	  int fid1=0;
						  int fid2=0;
				    	  List query8 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it8 = query8.iterator(); it8.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										othermemberBean = (OthermemberBean) it8.next();
									  fid1=othermemberBean.getFamilyid();
										  
							
						          }
							      
							      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it2.next();
												fid2=othermemberBean.getFamilyid();
												
									
								          }
									      
									      int cid=0;
										  int flag =0;
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag=1;
															    System.out.println("In===========================flag================================...........>>>>>"+flag);
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
											      
											      int gid1=0;
													int flag1 =0;
													List query5 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
													System.out.println("displaystandard====query========"+query);
															
													      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
													      {
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																MygroupBean = (MygroupBean) it5.next();
															    gid1=MygroupBean.getGroupid();
																System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
																 List query6 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
																 for (Iterator it6 = query6.iterator(); it6.hasNext();) 
																	 
															      {
																	    flag1=1;
																	    System.out.println("In===========================flag================================...........>>>>>"+flag);
																		System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																		GroupmemberBean = (GroupmemberBean) it6.next();
																		
																		
																		
															      }		
																
																 
												          } 
									      
									      if(fid1==fid2 || flag==1 || flag1==1)
									      {
									    	  displayotherprofession.add(othermemberprofessionBean); 
									      }
									      					      
	     
				      }
			
			
				      else if("6".equals(s))
				      {
				    	  int gid1=0;
							int flag =0;
							List query9 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it9 = query9.iterator(); it9.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										MygroupBean = (MygroupBean) it9.next();
									    gid1=MygroupBean.getGroupid();
										System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
										 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
										 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
											 
									      {
											    flag=1;
											    System.out.println("In===========================flag================================...........>>>>>"+flag);
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												GroupmemberBean = (GroupmemberBean) it2.next();
												
												
												
									      }		
										
										 
						          }
				    	  
									      
									      int cid=0;
										  int flag1 =0;
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag1=1;
															    System.out.println("In===========================flag================================...........>>>>>"+flag);
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
									      
									      if(flag==1 || flag1==1)
									      {
									    	  displayotherprofession.add(othermemberprofessionBean);
									      }
									      					      
	     
				      }
			
			
				      else if("5".equals(s))
				      {
				    	  int gid1=0;
							int flag =0;
							List query10 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it10 = query10.iterator(); it10.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										MygroupBean = (MygroupBean) it10.next();
									    gid1=MygroupBean.getGroupid();
										System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
										 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
										 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
											 
									      {
											    flag=1;
											    System.out.println("In===========================flag================================...........>>>>>"+flag);
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												GroupmemberBean = (GroupmemberBean) it2.next();
												
												
												
									      }		
										
										 
						          }
				    	  
							      int fid1=0;
									int fid2=0;
									List query4 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it4.next();
											  fid1=othermemberBean.getFamilyid();
												  
									
								          }
									      
									      List query5 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														othermemberBean = (OthermemberBean) it5.next();
														fid2=othermemberBean.getFamilyid();
														
											
										          }
								
											      if(flag==1 || fid1==fid2)
											      {
											    	  displayotherprofession.add(othermemberprofessionBean);
											      }		  
									      
									   			      
	     
				      }
			
			//displayotherprofession.add(othermemberprofessionBean);
	  	}
	  	 
	   }
		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displayotherprofession;
	}
	
	
	//memthod to display the member favourite details
	
	public Collection displayotherfavourite(Session session,FavouritesBean othermemberfavouriteBean,int q,int q1)
	{
		
		
		Collection displayotherfavourite=new ArrayList();
		OthermemberBean othermemberBean = new OthermemberBean();
		GroupmemberBean GroupmemberBean = new GroupmemberBean();
		MygroupBean MygroupBean = new MygroupBean();
		CommunitycheckBean communityownerBean = new CommunitycheckBean();
		Communitymember1Bean communitymember1Bean = new Communitymember1Bean();
		try
	   {
			
	  	 List query = session.createSQLQuery("select * from member_favourites ds where memberid='"+q1+"' ").addEntity("ds",FavouritesBean.class).list();
	  	for (Iterator it = query.iterator(); it.hasNext();)
	  	{
			System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
			othermemberfavouriteBean = (FavouritesBean) it.next();
			String s = othermemberfavouriteBean.getVisibility();
			
			
			if("8".equals(s))
			{
				System.out.println("display iiiii88888888888888888888888888888888");
				displayotherfavourite.add(othermemberfavouriteBean);
			}
			else if("1".equals(s))
			{
				System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
				int fid1=0;
				int fid2=0;
				List query2 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
				      {
							System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
							othermemberBean = (OthermemberBean) it2.next();
						  fid1=othermemberBean.getFamilyid();
							  
				
			          }
				      
				      List query3 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									othermemberBean = (OthermemberBean) it3.next();
									fid2=othermemberBean.getFamilyid();
									
						
					          }
			
						      if(fid1==fid2)
						      {
						    	  displayotherfavourite.add(othermemberfavouriteBean);
						      }
			}
			
			else if("4".equals(s))
			{
				System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
				int gid1=0;
				int flag =0;
				List query4 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
				      {
							System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
							MygroupBean = (MygroupBean) it4.next();
						    gid1=MygroupBean.getGroupid();
							System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
							 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
							 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								 
						      {
								    flag=1;
								    System.out.println("In===========================flag================================...........>>>>>"+flag);
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									GroupmemberBean = (GroupmemberBean) it2.next();
									
									
									
						      }		
							
							 
			          }
				      
				      if(flag==1)
				    		  {
				    	  displayotherfavourite.add(othermemberfavouriteBean);
				      
				    		  }
			}
			
			else if("2".equals(s))
			{
				System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
				int cid=0;
				int flag =0;
				List query6 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it6 = query6.iterator(); it6.hasNext();) 
				      {
							System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
							communityownerBean = (CommunitycheckBean) it6.next();
						    cid=communityownerBean.getCommunityid();
							System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
							 List query2 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
							 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								 
						      {
								    flag=1;
								    System.out.println("In===========================flag================================...........>>>>>"+flag);
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									communitymember1Bean = (Communitymember1Bean) it2.next();
									
									
									
						      }		
							
							 
			          }
				      
				      if(flag==1)
				     {
				    	  displayotherfavourite.add(othermemberfavouriteBean);
				    
				     }
			}
				      else if("3".equals(s))
				      {
				    	  
				    	  int fid1=0;
						  int fid2=0;
				    	  List query7 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
									
							      for (Iterator it7 = query7.iterator(); it7.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										othermemberBean = (OthermemberBean) it7.next();
									  fid1=othermemberBean.getFamilyid();
										  
							
						          }
							      
							      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it2.next();
												fid2=othermemberBean.getFamilyid();
												
									
								          }
									      
									      int cid=0;
										  int flag =0;
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag=1;
															    System.out.println("In===========================flag================================...........>>>>>"+flag);
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
									      
									      if(fid1==fid2 || flag==1)
									      {
									    	  displayotherfavourite.add(othermemberfavouriteBean);
									      }
									      					      
	     
				      }
			
				      else if("7".equals(s))
				      {
				    	  
				    	  int fid1=0;
						  int fid2=0;
				    	  List query8 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it8 = query8.iterator(); it8.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										othermemberBean = (OthermemberBean) it8.next();
									  fid1=othermemberBean.getFamilyid();
										  
							
						          }
							      
							      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it2.next();
												fid2=othermemberBean.getFamilyid();
												
									
								          }
									      
									      int cid=0;
										  int flag =0;
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag=1;
															    System.out.println("In===========================flag================================...........>>>>>"+flag);
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
											      
											      int gid1=0;
													int flag1 =0;
													List query5 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
													System.out.println("displaystandard====query========"+query);
															
													      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
													      {
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																MygroupBean = (MygroupBean) it5.next();
															    gid1=MygroupBean.getGroupid();
																System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
																 List query6 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
																 for (Iterator it6 = query6.iterator(); it6.hasNext();) 
																	 
															      {
																	    flag1=1;
																	    System.out.println("In===========================flag================================...........>>>>>"+flag);
																		System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																		GroupmemberBean = (GroupmemberBean) it6.next();
																		
																		
																		
															      }		
																
																 
												          } 
									      
									      if(fid1==fid2 || flag==1 || flag1==1)
									      {
									    	  displayotherfavourite.add(othermemberfavouriteBean);
									      }
									      					      
	     
				      }
			
			
				      else if("6".equals(s))
				      {
				    	  int gid1=0;
							int flag =0;
							List query9 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it9 = query9.iterator(); it9.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										MygroupBean = (MygroupBean) it9.next();
									    gid1=MygroupBean.getGroupid();
										System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
										 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
										 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
											 
									      {
											    flag=1;
											    System.out.println("In===========================flag================================...........>>>>>"+flag);
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												GroupmemberBean = (GroupmemberBean) it2.next();
												
												
												
									      }		
										
										 
						          }
				    	  
									      
									      int cid=0;
										  int flag1 =0;
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag1=1;
															    System.out.println("In===========================flag================================...........>>>>>"+flag);
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
									      
									      if(flag==1 || flag1==1)
									      {
									    	  displayotherfavourite.add(othermemberfavouriteBean);
									      }
									      					      
	     
				      }
			
			
				      else if("5".equals(s))
				      {
				    	  int gid1=0;
							int flag =0;
							List query10 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it10 = query10.iterator(); it10.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										MygroupBean = (MygroupBean) it10.next();
									    gid1=MygroupBean.getGroupid();
										System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
										 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
										 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
											 
									      {
											    flag=1;
											    System.out.println("In===========================flag================================...........>>>>>"+flag);
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												GroupmemberBean = (GroupmemberBean) it2.next();
												
												
												
									      }		
										
										 
						          }
				    	  
							      int fid1=0;
									int fid2=0;
									List query4 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it4.next();
											  fid1=othermemberBean.getFamilyid();
												  
									
								          }
									      
									      List query5 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														othermemberBean = (OthermemberBean) it5.next();
														fid2=othermemberBean.getFamilyid();
														
											
										          }
								
											      if(flag==1 || fid1==fid2)
											      {
											    	  displayotherfavourite.add(othermemberfavouriteBean);
											      }		  
									      
									   			      
	     
				      }
	  	}	
	  	//displayotherfavourite.add(othermemberfavouriteBean);
	   }
		
		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displayotherfavourite;	
		
		
	}
	
	//memthod to display the member details
	
	
	public Collection displayotheraboutme(Session session,AboutBean othermemberaboutmeBean,int q,int q1)
	{
		
		Collection displayotheraboutme=new ArrayList();
		OthermemberBean othermemberBean = new OthermemberBean();
		GroupmemberBean GroupmemberBean = new GroupmemberBean();
		MygroupBean MygroupBean = new MygroupBean();
		CommunitycheckBean communityownerBean = new CommunitycheckBean();
		Communitymember1Bean communitymember1Bean = new Communitymember1Bean();
		try
	   {
			
	  	 List query = session.createSQLQuery("select * from about_member where memberid='"+q1+"' ").addEntity("ds",AboutBean.class).list();
	  	for (Iterator it = query.iterator(); it.hasNext();)
	  	{
			System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
			othermemberaboutmeBean = (AboutBean) it.next();
			String s = othermemberaboutmeBean.getVisibility();
			
			
			
			if("8".equals(s))
			{
				System.out.println("display iiiii88888888888888888888888888888888");
				displayotheraboutme.add(othermemberaboutmeBean);
			}
			else if("1".equals(s))
			{
				System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
				int fid1=0;
				int fid2=0;
				List query2 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
				      {
							System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
							othermemberBean = (OthermemberBean) it2.next();
						  fid1=othermemberBean.getFamilyid();
							  
				
			          }
				      
				      List query3 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									othermemberBean = (OthermemberBean) it3.next();
									fid2=othermemberBean.getFamilyid();
									
						
					          }
			
						      if(fid1==fid2)
						      {
						    	  displayotheraboutme.add(othermemberaboutmeBean);
						      }
			}
			
			else if("4".equals(s))
			{
				System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
				int gid1=0;
				int flag =0;
				List query4 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
				      {
							System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
							MygroupBean = (MygroupBean) it4.next();
						    gid1=MygroupBean.getGroupid();
							System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
							 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
							 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								 
						      {
								    flag=1;
								    System.out.println("In===========================flag================================...........>>>>>"+flag);
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									GroupmemberBean = (GroupmemberBean) it2.next();
									
									
									
						      }		
							
							 
			          }
				      
				      if(flag==1)
				    		  {
				    	        
				    	       displayotheraboutme.add(othermemberaboutmeBean);
				      
				    		  }
			}
			
			else if("2".equals(s))
			{
				System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
				int cid=0;
				int flag =0;
				List query6 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it6 = query6.iterator(); it6.hasNext();) 
				      {
							System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
							communityownerBean = (CommunitycheckBean) it6.next();
						    cid=communityownerBean.getCommunityid();
							System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
							 List query2 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
							 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								 
						      {
								    flag=1;
								    System.out.println("In===========================flag================================...........>>>>>"+flag);
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									communitymember1Bean = (Communitymember1Bean) it2.next();
									
									
									
						      }		
							
							 
			          }
				      
				      if(flag==1)
				     {
				    	 
				    	  displayotheraboutme.add(othermemberaboutmeBean);
				    
				     }
			}
				      else if("3".equals(s))
				      {
				    	  
				    	  int fid1=0;
						  int fid2=0;
				    	  List query7 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
									
							      for (Iterator it7 = query7.iterator(); it7.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										othermemberBean = (OthermemberBean) it7.next();
									  fid1=othermemberBean.getFamilyid();
										  
							
						          }
							      
							      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it2.next();
												fid2=othermemberBean.getFamilyid();
												
									
								          }
									      
									      int cid=0;
										  int flag =0;
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag=1;
															    System.out.println("In===========================flag================================...........>>>>>"+flag);
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
									      
									      if(fid1==fid2 || flag==1)
									      {
									    	  displayotheraboutme.add(othermemberaboutmeBean);
									      }
									      					      
	     
				      }
			
				      else if("7".equals(s))
				      {
				    	  
				    	  int fid1=0;
						  int fid2=0;
				    	  List query8 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it8 = query8.iterator(); it8.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										othermemberBean = (OthermemberBean) it8.next();
									  fid1=othermemberBean.getFamilyid();
										  
							
						          }
							      
							      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it2.next();
												fid2=othermemberBean.getFamilyid();
												
									
								          }
									      
									      int cid=0;
										  int flag =0;
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag=1;
															    System.out.println("In===========================flag================================...........>>>>>"+flag);
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
											      
											      int gid1=0;
													int flag1 =0;
													List query5 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
													System.out.println("displaystandard====query========"+query);
															
													      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
													      {
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																MygroupBean = (MygroupBean) it5.next();
															    gid1=MygroupBean.getGroupid();
																System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
																 List query6 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
																 for (Iterator it6 = query6.iterator(); it6.hasNext();) 
																	 
															      {
																	    flag1=1;
																	    System.out.println("In===========================flag================================...........>>>>>"+flag);
																		System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																		GroupmemberBean = (GroupmemberBean) it6.next();
																		
																		
																		
															      }		
																
																 
												          } 
									      
									      if(fid1==fid2 || flag==1 || flag1==1)
									      {
									    	  displayotheraboutme.add(othermemberaboutmeBean);
									      }
									      					      
	     
				      }
			
			
				      else if("6".equals(s))
				      {
				    	  int gid1=0;
							int flag =0;
							List query9 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it9 = query9.iterator(); it9.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										MygroupBean = (MygroupBean) it9.next();
									    gid1=MygroupBean.getGroupid();
										System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
										 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
										 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
											 
									      {
											    flag=1;
											    System.out.println("In===========================flag================================...........>>>>>"+flag);
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												GroupmemberBean = (GroupmemberBean) it2.next();
												
												
												
									      }		
										
										 
						          }
				    	  
									      
									      int cid=0;
										  int flag1 =0;
											List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														communityownerBean = (CommunitycheckBean) it3.next();
													    cid=communityownerBean.getCommunityid();
														System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
														 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
														 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
															 
													      {
															    flag1=1;
															    System.out.println("In===========================flag================================...........>>>>>"+flag);
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communitymember1Bean = (Communitymember1Bean) it4.next();
																
																
																
													      }		
														
														 
										          }
									      
									      if(flag==1 || flag1==1)
									      {
									    	  displayotheraboutme.add(othermemberaboutmeBean);
									      }
									      					      
	     
				      }
			
			
				      else if("5".equals(s))
				      {
				    	  int gid1=0;
							int flag =0;
							List query10 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
							System.out.println("displaystandard====query========"+query);
									
							      for (Iterator it10 = query10.iterator(); it10.hasNext();) 
							      {
										System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
										MygroupBean = (MygroupBean) it10.next();
									    gid1=MygroupBean.getGroupid();
										System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
										 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
										 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
											 
									      {
											    flag=1;
											    System.out.println("In===========================flag================================...........>>>>>"+flag);
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												GroupmemberBean = (GroupmemberBean) it2.next();
												
												
												
									      }		
										
										 
						          }
				    	  
							      int fid1=0;
									int fid2=0;
									List query4 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it4.next();
											  fid1=othermemberBean.getFamilyid();
												  
									
								          }
									      
									      List query5 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														othermemberBean = (OthermemberBean) it5.next();
														fid2=othermemberBean.getFamilyid();
														
											
										          }
								
											      if(flag==1 || fid1==fid2)
											      {
											    	  displayotheraboutme.add(othermemberaboutmeBean);
											      }		  
									      
									   			      
	     
				      }
	  	}
		
	}

		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displayotheraboutme;
	}
	
	//memthod to display the member house details
	
	public Collection displayotherhouse(Session session,HouseBean othermemberhouseBean,int q,int q1)
	{
	
		Collection displayotherhouse=new ArrayList();
		HouseBean gethouseBean = new HouseBean();
		OthermemberBean othermemberBean = new OthermemberBean();
		GroupmemberBean GroupmemberBean = new GroupmemberBean();
		MygroupBean MygroupBean = new MygroupBean();
		CommunitycheckBean communityownerBean = new CommunitycheckBean();
		Communitymember1Bean communitymember1Bean = new Communitymember1Bean();
		try
	   {
			
	  	// List query = session.createSQLQuery("select * from member_relations where memberid='"+q1+"' ").addEntity("ds",GetfamilyBean.class).list();
	  //	for (Iterator it = query.iterator(); it.hasNext();)
	  //{
	  	//	getfamilyBean = (GetfamilyBean) it.next();
			//int famid = getfamilyBean.getFamilyid();
			ProfileBean profileBean =new ProfileBean();
			List query1 = session.createSQLQuery("select * from member_profile where memberid='"+q1+"' ").addEntity("ds",ProfileBean.class).list();
		  	for (Iterator it1 = query1.iterator(); it1.hasNext();)
		  	{
		  		profileBean = (ProfileBean) it1.next();
				int housid = profileBean.getHouseid();
				
				List query2 = session.createSQLQuery("select * from member_house_detail where houseid='"+housid+"' ").addEntity("ds",HouseBean.class).list();
			  	for (Iterator it2 = query2.iterator(); it2.hasNext();)
			  	{
			  		othermemberhouseBean = (HouseBean) it2.next();
					String s = othermemberhouseBean.getVisibility();
					
					
					
					
					if("8".equals(s))
					{
						System.out.println("display iiiii88888888888888888888888888888888");
						displayotherhouse.add(othermemberhouseBean) ;
					}
					else if("1".equals(s))
					{
						System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
						int fid1=0;
						int fid2=0;
						List query18 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
						//System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it18 = query18.iterator(); it18.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									othermemberBean = (OthermemberBean) it18.next();
								  fid1=othermemberBean.getFamilyid();
									  
						
					          }
						      
						      List query3 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
								//System.out.println("displaystandard====query========"+query);
										
								      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
								      {
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											othermemberBean = (OthermemberBean) it3.next();
											fid2=othermemberBean.getFamilyid();
											
								
							          }
					
								      if(fid1==fid2)
								      {
								    	  displayotherhouse.add(othermemberhouseBean) ;
								      }
					}
					
					else if("4".equals(s))
					{
						System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
						int gid1=0;
						int flag =0;
						List query4 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
						//System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									MygroupBean = (MygroupBean) it4.next();
								    gid1=MygroupBean.getGroupid();
									System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
									 List query17 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
									 for (Iterator it17 = query17.iterator(); it17.hasNext();) 
										 
								      {
										    flag=1;
										    System.out.println("In===========================flag================================...........>>>>>"+flag);
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											GroupmemberBean = (GroupmemberBean) it2.next();
											
											
											
								      }		
									
									 
					          }
						      
						      if(flag==1)
						    		  {
						    	        
						    	  displayotherhouse.add(othermemberhouseBean) ;
						      
						    		  }
					}
					
					else if("2".equals(s))
					{
						System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
						int cid=0;
						int flag =0;
						List query6 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
						//System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it6 = query6.iterator(); it6.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									communityownerBean = (CommunitycheckBean) it6.next();
								    cid=communityownerBean.getCommunityid();
									System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
									 List query16 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
									 for (Iterator it16 = query16.iterator(); it16.hasNext();) 
										 
								      {
										    flag=1;
										    System.out.println("In===========================flag================================...........>>>>>"+flag);
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											communitymember1Bean = (Communitymember1Bean) it16.next();
											
											
											
								      }		
									
									 
					          }
						      
						      if(flag==1)
						     {
						    	 
						    	  displayotherhouse.add(othermemberhouseBean) ;
						    
						     }
					}
						      else if("3".equals(s))
						      {
						    	  
						    	  int fid1=0;
								  int fid2=0;
						    	  List query7 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
											
									      for (Iterator it7 = query7.iterator(); it7.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it7.next();
											  fid1=othermemberBean.getFamilyid();
												  
									
								          }
									      
									      List query15 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
											//System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it15 = query15.iterator(); it15.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														othermemberBean = (OthermemberBean) it15.next();
														fid2=othermemberBean.getFamilyid();
														
											
										          }
											      
											      int cid=0;
												  int flag =0;
													List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
													//System.out.println("displaystandard====query========"+query);
															
													      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
													      {
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communityownerBean = (CommunitycheckBean) it3.next();
															    cid=communityownerBean.getCommunityid();
																System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
																 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
																 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
																	 
															      {
																	    flag=1;
																	    System.out.println("In===========================flag================================...........>>>>>"+flag);
																		System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																		communitymember1Bean = (Communitymember1Bean) it4.next();
																		
																		
																		
															      }		
																
																 
												          }
											      
											      if(fid1==fid2 || flag==1)
											      {
											    	  displayotherhouse.add(othermemberhouseBean) ;
											      }
											      					      
			     
						      }
					
						      else if("7".equals(s))
						      {
						    	  
						    	  int fid1=0;
								  int fid2=0;
						    	  List query8 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
									//System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it8 = query8.iterator(); it8.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it8.next();
											  fid1=othermemberBean.getFamilyid();
												  
									
								          }
									      
									      List query14 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
											//System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it14 = query14.iterator(); it14.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														othermemberBean = (OthermemberBean) it14.next();
														fid2=othermemberBean.getFamilyid();
														
											
										          }
											      
											      int cid=0;
												  int flag =0;
													List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
													//System.out.println("displaystandard====query========"+query);
															
													      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
													      {
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communityownerBean = (CommunitycheckBean) it3.next();
															    cid=communityownerBean.getCommunityid();
																System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
																 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
																 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
																	 
															      {
																	    flag=1;
																	    System.out.println("In===========================flag================================...........>>>>>"+flag);
																		System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																		communitymember1Bean = (Communitymember1Bean) it4.next();
																		
																		
																		
															      }		
																
																 
												          }
													      
													      int gid1=0;
															int flag1 =0;
															List query5 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
															//System.out.println("displaystandard====query========"+query);
																	
															      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
															      {
																		System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																		MygroupBean = (MygroupBean) it5.next();
																	    gid1=MygroupBean.getGroupid();
																		System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
																		 List query6 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
																		 for (Iterator it6 = query6.iterator(); it6.hasNext();) 
																			 
																	      {
																			    flag1=1;
																			    System.out.println("In===========================flag================================...........>>>>>"+flag);
																				System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																				GroupmemberBean = (GroupmemberBean) it6.next();
																				
																				
																				
																	      }		
																		
																		 
														          } 
											      
											      if(fid1==fid2 || flag==1 || flag1==1)
											      {
											    	  displayotherhouse.add(othermemberhouseBean) ;
											      }
											      					      
			     
						      }
					
					
						      else if("6".equals(s))
						      {
						    	  int gid1=0;
									int flag =0;
									List query9 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
									//System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it9 = query9.iterator(); it9.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												MygroupBean = (MygroupBean) it9.next();
											    gid1=MygroupBean.getGroupid();
												System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
												 List query13 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
												 for (Iterator it13 = query13.iterator(); it13.hasNext();) 
													 
											      {
													    flag=1;
													    System.out.println("In===========================flag================================...........>>>>>"+flag);
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														GroupmemberBean = (GroupmemberBean) it13.next();
														
														
														
											      }		
												
												 
								          }
						    	  
											      
											      int cid=0;
												  int flag1 =0;
													List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
													//System.out.println("displaystandard====query========"+query);
															
													      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
													      {
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																communityownerBean = (CommunitycheckBean) it3.next();
															    cid=communityownerBean.getCommunityid();
																System.out.println("In the idddddddddd offffff tcreatedddddd bbbbbyyyyyyyyyyyyyy"+cid);
																 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
																 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
																	 
															      {
																	    flag1=1;
																	    System.out.println("In===========================flag================================...........>>>>>"+flag);
																		System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																		communitymember1Bean = (Communitymember1Bean) it4.next();
																		
																		
																		
															      }		
																
																 
												          }
											      
											      if(flag==1 || flag1==1)
											      {
											    	  displayotherhouse.add(othermemberhouseBean) ;
											      }
											      					      
			     
						      }
					
					
						      else if("5".equals(s))
						      {
						    	  int gid1=0;
									int flag =0;
									List query10 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
									//System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it10 = query10.iterator(); it10.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												MygroupBean = (MygroupBean) it10.next();
											    gid1=MygroupBean.getGroupid();
												System.out.println("In the idddddddddd offffff the  other mememmemememeber"+gid1);
												 List query12 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
												 for (Iterator it12 = query12.iterator(); it12.hasNext();) 
													 
											      {
													    flag=1;
													    System.out.println("In===========================flag================================...........>>>>>"+flag);
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														GroupmemberBean = (GroupmemberBean) it12.next();
														
														
														
											      }		
												
												 
								          }
						    	  
									      int fid1=0;
											int fid2=0;
											List query4 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
											//System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														othermemberBean = (OthermemberBean) it4.next();
													  fid1=othermemberBean.getFamilyid();
														  
											
										          }
											      
											      List query5 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
													//System.out.println("displaystandard====query========"+query);
															
													      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
													      {
																System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
																othermemberBean = (OthermemberBean) it5.next();
																fid2=othermemberBean.getFamilyid();
																
													
												          }
										
													      if(flag==1 || fid1==fid2)
													      {
													    	  displayotherhouse.add(othermemberhouseBean) ;
													      }		  
											      
											   			      
			     
						      }
					
					
					
					
					
					//displayotherhouse.add(othermemberhouseBean) ;
			  	}
		  	}
	  		
	  	
		
	   }
		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displayotherhouse;
    }
	
	
	
	
	
	public Collection displaysuperaboutme(Session session,AboutBean othermemberaboutmeBean,int q,int q1)
	{
		Collection displaysuperaboutme = new ArrayList();
		
		try
		   {
				
		  	 List query = session.createSQLQuery("select * from about_member where memberid='"+q1+"' ").addEntity("ds",AboutBean.class).list();
		  	for (Iterator it = query.iterator(); it.hasNext();)
		  	{
				System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
				othermemberaboutmeBean = (AboutBean) it.next();
				displaysuperaboutme.add(othermemberaboutmeBean);
		  	}	
		  	
		   }
		
		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displaysuperaboutme;
	}
	
	
	
	public Collection displaysupercontact(Session session,OthermembercontactBean othermembercontactBean,int q,int q1)
	{
		Collection displaysupercontact = new ArrayList();
		
		try
		{
			
		    List query = session.createSQLQuery("select * from member_contact_detail ds where memberid='"+q1+"' ").addEntity("ds",OthermembercontactBean.class).list();
		    for (Iterator it = query.iterator(); it.hasNext();) 
		    {
		    	othermembercontactBean = (OthermembercontactBean) it.next();
		    	displaysupercontact.add(othermembercontactBean);
		
		    }
		}
		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displaysupercontact;
	}
	
	
	
	
	public Collection displaysupereducation(Session session,EducationalBean othermembereduBean,int q,int q1)
	{
		
		OthermembercountryBean othermembercountryBean = new OthermembercountryBean();
		Collection displaysupereducation = new ArrayList();
		
		try
		{
			
			
			//Selecting data from receipients_of_invitation table where memberid="q"
		List query = session.createSQLQuery("select * from member_education ds where memberid='"+q1+"' ").addEntity("ds",EducationalBean.class).list();
		for (Iterator it = query.iterator(); it.hasNext();) 
		{
			System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
			othermembereduBean = (EducationalBean) it.next();
			String coid=othermembereduBean.getInstitutecountry();
			int countryid1 = Integer.parseInt(coid);	
			
			List query1 = session.createSQLQuery("select * from countries ts where countryid='"+countryid1+"' ").addEntity("ts",OthermembercountryBean.class).list();
			
			for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			{
				System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
				othermembercountryBean = (OthermembercountryBean) it1.next();
				othermembereduBean.setInstitutecountry1(othermembercountryBean.getInstitutecountry1());
		
			}
			displaysupereducation.add(othermembereduBean);
		}
		
		}
		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displaysupereducation;
	}
	
	
	
	public Collection displaysuperfavourite(Session session,FavouritesBean othermemberfavouriteBean,int q,int q1)
	
	{
		Collection displaysuperfavourite = new ArrayList();
		
		try
		   {
				
		  	 List query = session.createSQLQuery("select * from member_favourites ds where memberid='"+q1+"' ").addEntity("ds",FavouritesBean.class).list();
		  	for (Iterator it = query.iterator(); it.hasNext();)
		  	{
				System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
				othermemberfavouriteBean = (FavouritesBean) it.next();
				displaysuperfavourite.add(othermemberfavouriteBean);
				
		  	}
		   }
			catch(Exception he)
			{
				System.out.println("errorrrrrrrr"+he);
			}
			
			return displaysuperfavourite;
		
	}
	
	
	
	
	public Collection displaysuperhouse(Session session,HouseBean othermemberhouseBean,int q,int q1)
	{
		
		Collection displaysuperhouse = new ArrayList();
		HouseBean gethouseBean = new HouseBean();
		try
		{
			
		
		// List query = session.createSQLQuery("select * from member_relations where memberid='"+q1+"' ").addEntity("ds",GetfamilyBean.class).list();
		  //	for (Iterator it = query.iterator(); it.hasNext();)
		  //	{
		  		//getfamilyBean = (GetfamilyBean) it.next();
				//int famid = getfamilyBean.getFamilyid();
			    ProfileBean profileBean =new ProfileBean();
				List query1 = session.createSQLQuery("select * from member_profile where memberid='"+q1+"' ").addEntity("ds",ProfileBean.class).list();
			  	for (Iterator it1 = query1.iterator(); it1.hasNext();)
			  	{
			  		profileBean = (ProfileBean) it1.next();
					int housid = profileBean.getHouseid();
					
					List query2 = session.createSQLQuery("select * from member_house_detail where houseid='"+housid+"' ").addEntity("ds",HouseBean.class).list();
				  	for (Iterator it2 = query2.iterator(); it2.hasNext();)
				  	{
				  		othermemberhouseBean = (HouseBean) it2.next();
				  		displaysuperhouse.add(othermemberhouseBean);
		
				  	}
			  	}
		  	
		}
		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displaysuperhouse;
	}
	
	public Collection displaysuperpersonal(Session session,PersonalBean othermemberpersonalBean,int q,int q1)
	{
		Collection displaysuperpersonal = new ArrayList();
		
		try
		{
			
			
			//Selecting data from member_personal_detail table where memberid="q1"
		List query = session.createSQLQuery("select * from member_personal_detail ds where memberid='"+q1+"' ").addEntity("ds",PersonalBean.class).list();
System.out.println("displaystandard====query========"+query);
		
      for (Iterator it = query.iterator(); it.hasNext();) {
	
			othermemberpersonalBean = (PersonalBean) it.next();
			//Getting the maritial status  
       	 int d=othermemberpersonalBean.getMaritalstatus();
    
       	 //Converting the integer status to corresponding values
       	 
    	 if(d==0)	 
    	 {
    		 System.out.println("if 00000000000");
    		othermemberpersonalBean.setMaritalstatus1("Unmarried");
    		System.out.println("uusttattus===="+othermemberpersonalBean.getMaritalstatus1());
    	 }
    	 else if(d==1)
    	 {
    		 System.out.println("if 1111111111");
    		 othermemberpersonalBean.setMaritalstatus1("Married");
    		 System.out.println("uusttattus===="+othermemberpersonalBean.getMaritalstatus1());
    	 }
    	 else
    	 {
    		 System.out.println("if 22222222222");
    		 othermemberpersonalBean.setMaritalstatus1("Divorced"); 
    		 System.out.println("uusttattus===="+othermemberpersonalBean.getMaritalstatus1());
    	 }
    	 displaysuperpersonal.add(othermemberpersonalBean);
      }
		}
		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displaysuperpersonal;
		
		
	}
	
	public Collection displaysuperprofession(Session session,ProffessionalBean othermemberprofessionBean,int q,int q1)
	{
		Collection displaysuperprofession = new ArrayList();
		
		try
		   {
				
		  	 List query = session.createSQLQuery("select * from member_job_detail ds where memberid='"+q1+"' ").addEntity("ds",ProffessionalBean.class).list();
		  	for (Iterator it = query.iterator(); it.hasNext();)
		  	{
				System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
				othermemberprofessionBean = (ProffessionalBean) it.next();
				displaysuperprofession.add(othermemberprofessionBean);
				
		  	}
		   }
		catch(Exception he)
		{
			System.out.println("errorrrrrrrr"+he);
		}
		
		return displaysuperprofession;
		
	}
	
	
	
	public Collection viewscraps(Session session,OthermemberscrapBean othermemberscrapBean,int uid1)
	{
		
	  ScrapsentbyBean scrapsentbyBean = new ScrapsentbyBean();
	  Collection scrap = new ArrayList();	
	  try
	  {
		  
		  int sentby = othermemberscrapBean.getSentby();
		  System.out.println("In the qqqqyyeeeeeeeerrrrothermemberscrapBean.getSentby())))))))))))))))))))))===="+sentby);
		  List query1 = session.createSQLQuery("select * from scrapbook_details ds where sentby='"+uid1+"' and visibility='private' and sentto='"+uid1+"' ").addEntity("ds",OthermemberscrapBean.class).list();
		  	for (Iterator it1 = query1.iterator(); it1.hasNext();)
		  	{
				System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
				othermemberscrapBean = (OthermemberscrapBean) it1.next();
				List query2 = session.createSQLQuery("select * from member_profile os where memberid='"+othermemberscrapBean.getSentby()+"' ").addEntity("os",ScrapsentbyBean.class).list();
			  	for (Iterator it2 = query2.iterator(); it2.hasNext();)
			  	{
					System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
					scrapsentbyBean = (ScrapsentbyBean) it2.next();
					othermemberscrapBean.setSentby1(scrapsentbyBean.getSentby1());
			  	}
				
				scrap.add(othermemberscrapBean);
				
		  	} 
		  List query = session.createSQLQuery("select * from scrapbook_details ds where sentto='"+uid1+"' and visibility='public' ").addEntity("ds",OthermemberscrapBean.class).list();
		  	for (Iterator it = query.iterator(); it.hasNext();)
		  	{
				System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
				othermemberscrapBean = (OthermemberscrapBean) it.next();
				System.out.println("In visssssssssssiibiliiiiityyyyyyyyyy======="+othermemberscrapBean.getVisibility());
				List query2 = session.createSQLQuery("select * from member_profile os where memberid='"+othermemberscrapBean.getSentby()+"' ").addEntity("os",ScrapsentbyBean.class).list();
			  	for (Iterator it2 = query2.iterator(); it2.hasNext();)
			  	{
					System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
					scrapsentbyBean = (ScrapsentbyBean) it2.next();
					othermemberscrapBean.setSentby1(scrapsentbyBean.getSentby1());
			  	}
				
				scrap.add(othermemberscrapBean);
				System.out.println("In the qqqqyyscrap.scrap.scrap.scrap.scrap.scrap.scrap..sizeimplllll===="+scrap.size());
				
		  	} 
		  	
		  
	  }
	  
		
	catch(Exception e)
	{
		
		System.out.print("ExCePTiON iN Other ScRaP dDDDDAOOO"+e);
		
	}
		
	return scrap;		
	}
	
	
	public boolean insert(Session session,OthermemberscrapBean othermemberscrapBean)
	{
		
		session.beginTransaction();
		session.save(othermemberscrapBean);
		session.getTransaction().commit();
		return true;
		
		
	}
	
	
	public OthermemberscrapBean checkmember(Session session,OthermemberscrapBean othermemberscrapBean)
	{
		try
		{
			
		
		List query1 = session.createSQLQuery("select * from scrapbook_details ds where scrapbookid='"+othermemberscrapBean.getScrapbookid()+"' ").addEntity("ds",OthermemberscrapBean.class).list();
	  	for (Iterator it1 = query1.iterator(); it1.hasNext();)
	  	 {
			System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
			othermemberscrapBean = (OthermemberscrapBean) it1.next();
	  	 }
		
		}
		catch(Exception e)
		{
			
			System.out.println("exception in check"+e);
		}
		return othermemberscrapBean;
		
	}
	
	public boolean delete(Session session,OthermemberscrapBean othermemberscrapBean)
	{
		
		session.beginTransaction();
		session.delete(othermemberscrapBean);
		session.getTransaction().commit();
		return true;
	}
	
	
	
	public Collection displayotherbiodata(Session session,BiodataBean biodataBean,int q,int q1)
	{
		
		Collection standardcol=new ArrayList();
		OthermemberBean othermemberBean = new OthermemberBean();
		GroupmemberBean GroupmemberBean = new GroupmemberBean();
		MygroupBean MygroupBean = new MygroupBean();
		CommunitycheckBean communityownerBean = new CommunitycheckBean();
		Communitymember1Bean communitymember1Bean = new Communitymember1Bean();
		
		try
		{
		List query = session.createSQLQuery("select * from member_profile ds where memberid='"+q1+"' ").addEntity("ds",BiodataBean.class).list();
		System.out.println("displaystandard====query========"+query);
				
		      for (Iterator it = query.iterator(); it.hasNext();) 
		      {
			
		    	  biodataBean = (BiodataBean) it.next();
		    	  String sex = biodataBean.getSex();
		    	  if(sex.equals("m"))
		    	  {
		    		  biodataBean.setSex("Male");
		    	  }
		    	  else if(sex.equals("f"))
		    	  {
		    		  biodataBean.setSex("Female");
		    	  }
		    	  
		    	//Getting the visibility set by the member
		     	 
					int s = biodataBean.getVisibility();
					
					//setting up the visibility lelvels
					
					//for public only
					if(s==8)
					{
						//adding the values to the collection
						standardcol.add(biodataBean);
					}
					
					//for family only
					else if(s==1)
					{
						
						int fid1=0;//familyid of member
						int fid2=0;//familyid of the visitor
						//Selecting data from member_relations table where memberid="q1"
						List query1 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						      {
									
									othermemberBean = (OthermemberBean) it1.next();
								  fid1=othermemberBean.getFamilyid();
									  
						
					          }
						      //Selecting data from member_relations table where memberid="q"
						      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
								System.out.println("displaystandard====query========"+query);
										
								      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
								      {
											System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
											othermemberBean = (OthermemberBean) it2.next();
											fid2=othermemberBean.getFamilyid();
											
								
							          }
					
								      if(fid1==fid2)
								      {
								    	  //adding the values to the collection
								    	  standardcol.add(biodataBean); 
								      }
					}
					
					//for group only
					
					else if(s==4)
					{
						System.out.println("display iiiiiiiinnnnnnnnthe  11111111111111111111");
						int gid1=0;//Groupid of the group owner(other member)
						int flag =0;//flag to know if the member is in that group
						
						//Selecting data from groups table where groupowner="q1"
						
						List query1 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						      {
									System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
									MygroupBean = (MygroupBean) it1.next();
									
									//Groupid of the group owner(other member)
									
								    gid1=MygroupBean.getGroupid();
									
								  //Selecting data from group_members table where groupid="gid1" and memberid="q"
								    
									 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
									 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
										 
								      {
										    flag=1;//Setting the flag value to 1
											GroupmemberBean = (GroupmemberBean) it2.next();
											
											
								      }		
									
									 
					          }
						      
						      if(flag==1)
						    		  {
						      standardcol.add(biodataBean);//adding the values to the collection
						    		  }
					}
					
					//for community only
					
					else if(s==2)
					{
						
						int cid=0;//Communityid of the community owner(other member)
						int flag =0;//flag to know if the member is in that community
						
						//Selecting data from community table where createdby="q1"
						
						List query1 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
						System.out.println("displaystandard====query========"+query);
								
						      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
						      {
									
									communityownerBean = (CommunitycheckBean) it1.next();
								    cid=communityownerBean.getCommunityid();
									
								  //Selecting data from community_members table where communityid=cid1 and memberid='q' and status='active'
								    
									 List query2 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
									 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
										 
								      {
										    flag=1;//Setting the flag value to 1
											communitymember1Bean = (Communitymember1Bean) it2.next();
												
											
								      }		
									
									 
					          }
						      
						      if(flag==1)
						     {
						     //adding the values to the collection	  
						    	  
						      standardcol.add(biodataBean);
						     }
					}
			             //for family & community		
					
						      else if(s==3)
						      {
						    	  
						    	  int fid1=0;//familyid of the visitor
								  int fid2=0;//familyid of the other member
								  
								  //Selecting data from member_relations table where memberid="q1"
								  
						    	  List query1 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
									      {
												System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
												othermemberBean = (OthermemberBean) it1.next();
											  fid1=othermemberBean.getFamilyid();
												  
									
								          }
									      
									      //Selecting data from member_relations table where memberid="q"
									      
									      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
											      {
														System.out.println("In the qqqqyyeeeeeeeerrrrrrrryyyyyyyyyyy1111111111111========");
														othermemberBean = (OthermemberBean) it2.next();
														fid2=othermemberBean.getFamilyid();
														
											
										          }
											      
											      int cid=0;//communityid
												  int flag =0;//flag to know if the member is in that community
												  
												  //Selecting data from community table where createdby="q1"
												  
													List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
													System.out.println("displaystandard====query========"+query);
															
													      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
													      {
																
																communityownerBean = (CommunitycheckBean) it3.next();
															    cid=communityownerBean.getCommunityid();
															    
															    //Selecting data from community_members table where communityid='cid'
															    
																 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
																 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
																	 
															      {
																	    flag=1;
																	   
																		communitymember1Bean = (Communitymember1Bean) it4.next();
																		
																		
																		
															      }		
																
																 
												          }
											      
											      if(fid1==fid2 || flag==1)
											      {
											    	  standardcol.add(biodataBean); //adding the values to the collection
											      }
											      					      
			     
						      }
					
						      else if(s==7)//for group,community & family
						      {
						    	  
						    	  int fid1=0;//familyid of member
								 int fid2=0;//familyid of the visitor
								 
								 //Selecting data from member_relations table where memberid="q1"
								 
						    	  List query1 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();

											
									      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
									      {
												
											  othermemberBean = (OthermemberBean) it1.next();
											  fid1=othermemberBean.getFamilyid();
												  
									
								          }
									      
									      //Selecting data from member_relations table where memberid="q"
									      
									      List query2 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();
											System.out.println("displaystandard====query========"+query);
													
											      for (Iterator it2 = query2.iterator(); it2.hasNext();) 
											      {
														
														othermemberBean = (OthermemberBean) it2.next();
														fid2=othermemberBean.getFamilyid();
														
											
										          }
											      
											      int cid=0;//communityid of the member
												  int flag =0;//flag to know whether in the member is in the group
											      int gid1=0;//groupid of the member
												  int flag1 =0;//flag to know whether the member is in the community
												  
												//Selecting data from community table where createdby="q1"
												  
													List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
													System.out.println("displaystandard====query========"+query);
															
													      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
													      {
																
																communityownerBean = (CommunitycheckBean) it3.next();
															    cid=communityownerBean.getCommunityid();
																
															  //Selecting data from community_members table where communityid='cid' and memberid='q' and status='active'
															    
																 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
																 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
																	 
															      {
																	    flag=1;
																	    
																		communitymember1Bean = (Communitymember1Bean) it4.next();
																		
																		
																		
															      }		
																
																 
												          }
													      
													    //Selecting data from groups table where groupowner="q1"

															List query5 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
																	
															      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
															      {
																	
																		MygroupBean = (MygroupBean) it5.next();
																	    gid1=MygroupBean.getGroupid();
																		
																	  //Selecting data from group_members table where groupid='gid1' and memberid="q"
																	    
																		 List query6 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
																		 for (Iterator it6 = query6.iterator(); it6.hasNext();) 
																			 
																	      {
																			    flag1=1;
																			   
																				GroupmemberBean = (GroupmemberBean) it6.next();
																				
																				
																				
																	      }		
																		
																		 
														          } 
											      
											      if(fid1==fid2 || flag==1 || flag1==1)//Whether the member is in the family or group or in the community
											      {
											    	  standardcol.add(biodataBean);  //adding the values to the collection
											      }
											      					      
			     
						      }
					
					          //for group & family
					
						      else if(s==6)
						      {
						    	  int gid1=0;//groupid of the member
									int flag =0;//flag to know whether the member is in the group
									
									//Selecting data from groups table where groupowner="q1"
									
									List query1 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
									System.out.println("displaystandard====query========"+query);
											
									      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
									      {
												
												MygroupBean = (MygroupBean) it1.next();
											    gid1=MygroupBean.getGroupid();
												
											   //Selecting data from group_members table where groupid='gid1' and memberid="q"
											    
												 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
												 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
													 
											      {
													    flag=1;
													    
														GroupmemberBean = (GroupmemberBean) it2.next();
														
														
														
											      }		
												
												 
								          }
						    	  
											      
											      int cid=0;//communityid of the member
												  int flag1 =0;//flag to know whether the member is in the community
												  
												  //Selecting data from community table where createdby='q1'
												  
													List query3 = session.createSQLQuery("select * from community ts where createdby='"+q1+"' ").addEntity("ts",CommunitycheckBean.class).list();
													System.out.println("displaystandard====query========"+query);
															
													      for (Iterator it3 = query3.iterator(); it3.hasNext();) 
													      {
																
																communityownerBean = (CommunitycheckBean) it3.next();
															    cid=communityownerBean.getCommunityid();
																
															  //Selecting data from community_members table where communityid='cid' and memberid='q' and status='active'
															    
																 List query4 = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+q+"' and status='active' ").addEntity("ds",Communitymember1Bean.class).list();
																 for (Iterator it4 = query4.iterator(); it4.hasNext();) 
																	 
															      {
																	    flag1=1;
																	    
																		communitymember1Bean = (Communitymember1Bean) it4.next();
																		
																		
																		
															      }		
																
																 
												          }
											      
											      if(flag==1 || flag1==1)
											      {
											    	  standardcol.add(biodataBean);  //adding the values to the collection
											      }
											      					      
			     
						      }
					
					           //for both group and family
					
						      else if(s==5)
						      {
						    	  int gid1=0;//groupid of the member
									int flag =0;//flag to know whether the member is in the group
									
									//Selecting data from groups table where groupowner="q1"
									
									List query1 = session.createSQLQuery("select * from groups ts where groupowner='"+q1+"' ").addEntity("ts",MygroupBean.class).list();
									
											
									      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
									      {
												
												MygroupBean = (MygroupBean) it1.next();
											    gid1=MygroupBean.getGroupid();
												
											  //Selecting data from group_members table where groupid="gid1"
											    
												 List query2 = session.createSQLQuery("select * from group_members ds where groupid='"+gid1+"' and memberid='"+q+"'").addEntity("ds",GroupmemberBean.class).list();
												 for (Iterator it2 = query2.iterator(); it2.hasNext();) 
													 
											      {
													    flag=1;
														GroupmemberBean = (GroupmemberBean) it2.next();
														
														
														
											      }		
												
												 
								          }
						    	  
									      int fid1=0;//familyid of the member
											int fid2=0;//familyid of the visitor(other member)
											
											 //Selecting data from member_relations table where memberid="q1"
											
											List query4 = session.createSQLQuery("select * from member_relations ss where memberid='"+q1+"' ").addEntity("ss",OthermemberBean.class).list();
											
													
											      for (Iterator it4 = query4.iterator(); it4.hasNext();) 
											      {
														
														othermemberBean = (OthermemberBean) it4.next();
													  fid1=othermemberBean.getFamilyid();
														  
											
										          }
											      
											    //Selecting data from member_relations table where memberid="q"
											      
											      List query5 = session.createSQLQuery("select * from member_relations ds where memberid='"+q+"' ").addEntity("ds",OthermemberBean.class).list();

															
													      for (Iterator it5 = query5.iterator(); it5.hasNext();) 
													      {
																
																othermemberBean = (OthermemberBean) it5.next();
																fid2=othermemberBean.getFamilyid();
																
													
												          }
										
													      if(flag==1 || fid1==fid2)
													      {
													    	  standardcol.add(biodataBean); //adding the values to the collection
													      }		  	
		      
						      }
		      }
		}

	catch (Exception e) 
	{
		System.out.println("exception in bbiiiiioooooodataaaa"+e);
	}
	return standardcol;
	}
	
	
	public Collection displaysuperbiodata(Session session,BiodataBean biodataBean,int q,int q1)
	{
		
		Collection standardcol=new ArrayList();
		try
		{
		List query = session.createSQLQuery("select * from member_profile ds where memberid='"+q1+"' ").addEntity("ds",BiodataBean.class).list();
		System.out.println("displaystandard====query========"+query);
				
		      for (Iterator it = query.iterator(); it.hasNext();) 
		      {
			
		    	  biodataBean = (BiodataBean) it.next();
		    	  String sex = biodataBean.getSex();
		    	  if(sex.equals("m"))
		    	  {
		    		  biodataBean.setSex("Male");
		    	  }
		    	  else if(sex.equals("f"))
		    	  {
		    		  biodataBean.setSex("Female");
		    	  }
		    	  standardcol.add(biodataBean);
		      }
		}
		catch (Exception e) 
		{
			System.out.println("exception in bbiiiiioooooodataaaa"+e);
		}
		
		return standardcol;
	}
 }		


