package com.dory.othermember;

import org.apache.struts.action.ActionForm;

public class OthermemberbiodataForm extends ActionForm
{

	

		 private int memberid;
		 private String membername;
		 private String nickname;
		 private String birthplace;
		 private String birthstate;
		 private String birthcountry;
		 private String address;
		 private String dob;
		 private String currentstatus;
		 private String sex;
		 private String fathername;
		 private String mothername;
		 private String membernumber;
		public void setMemberid(int memberid) {
			this.memberid = memberid;
		}
		public int getMemberid() {
			return memberid;
		}
		public void setMembername(String membername) {
			this.membername = membername;
		}
		public String getMembername() {
			return membername;
		}
		public void setNickname(String nickname) {
			this.nickname = nickname;
		}
		public String getNickname() {
			return nickname;
		}
		
		public void setBirthplace(String birthplace) {
			this.birthplace = birthplace;
		}
		public String getBirthplace() {
			return birthplace;
		}
		public void setBirthstate(String birthstate) {
			this.birthstate = birthstate;
		}
		public String getBirthstate() {
			return birthstate;
		}
		public void setBirthcountry(String birthcountry) {
			this.birthcountry = birthcountry;
		}
		public String getBirthcountry() {
			return birthcountry;
		}
		
		public void setDob(String dob) {
			this.dob = dob;
		}
		public String getDob() {
			return dob;
		}
		public void setFathername(String fathername) {
			this.fathername = fathername;
		}
		public String getFathername() {
			return fathername;
		}
		public void setMothername(String mothername) {
			this.mothername = mothername;
		}
		public String getMothername() {
			return mothername;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getAddress() {
			return address;
		}

		public void setMembernumber(String membernumber) {
			this.membernumber = membernumber;
		}
		public String getMembernumber() {
			return membernumber;
		}
		public void setCurrentstatus(String currentstatus) {
			this.currentstatus = currentstatus;
		}
		public String getCurrentstatus() {
			return currentstatus;
		}
		public void setSex(String sex) {
			this.sex = sex;
		}
		public String getSex() {
			return sex;
		}


}
