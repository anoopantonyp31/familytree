

/**
 * Date:19/11/2010
 * @author Upesh.A
 */


package com.dory.othermember;

import org.apache.struts.action.ActionForm;

public class OthermemberprofessionForm extends ActionForm 
 {
	private String occupation;
	 private String companyname;
	 private String designation;
	 private String officeno;

	 private String jobcity;
	 private String jobaddress;
	 private String remark;
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getCompanyname() {
		return companyname;
	}
	
	public void setOfficeno(String officeno) {
		this.officeno = officeno;
	}
	public String getOfficeno() {
		return officeno;
	}
	
	public void setJobcity(String jobcity) {
		this.jobcity = jobcity;
	}
	public String getJobcity() {
		return jobcity;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDesignation() {
		return designation;
	}
	public void setJobaddress(String jobaddress) {
		this.jobaddress = jobaddress;
	}
	public String getJobaddress() {
		return jobaddress;
	}

 }
