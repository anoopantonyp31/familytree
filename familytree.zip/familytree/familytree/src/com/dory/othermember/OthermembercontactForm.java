

/**
 * Date:18/11/2010
 * @author Upesh.A
 */

package com.dory.othermember;

import org.apache.struts.action.ActionForm;

public class OthermembercontactForm extends ActionForm
{
	  private String landlineno;
	  private String mobileno;
	  private String emailid;
	  private String remark;
	public void setLandlineno(String landlineno) {
		this.landlineno = landlineno;
	}
	public String getLandlineno() {
		return landlineno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}

}
