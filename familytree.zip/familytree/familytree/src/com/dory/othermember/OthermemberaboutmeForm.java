

/**
 * Date:23/11/2010
 * @author Upesh.A
 */

package com.dory.othermember;
import org.apache.struts.action.ActionForm;

public class OthermemberaboutmeForm extends ActionForm
{
	 private String myself;
	 private String achievements;
	 private String remark;
	public void setMyself(String myself) {
		this.myself = myself;
	}
	public String getMyself() {
		return myself;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setAchievements(String achievements) {
		this.achievements = achievements;
	}
	public String getAchievements() {
		return achievements;
	}
}
