

/**
 * Date:18/11/2010
 * @author Upesh.A
 */

package com.dory.othermember;

import org.apache.struts.action.ActionForm;

public class OthermemberconfidentialForm extends ActionForm 
{

}
