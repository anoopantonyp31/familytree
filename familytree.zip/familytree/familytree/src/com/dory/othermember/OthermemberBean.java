
//Created by:Upesh.A
//Created on:16/11/2010

package com.dory.othermember;

//Bean for getting memberid

public class OthermemberBean
 {
	private int familyid;
	private int memberid;
	private int relationid;
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}

	public void setRelationid(int relationid) {
		this.relationid = relationid;
	}
	public int getRelationid() {
		return relationid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
 }
