package com.dory.othermember;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.addparents.AddparentForm;
import com.dory.hibernate.HibernateUtil;

public class OthermemberscrapAction extends Action 
{
	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
	String target = null;
	try {
		if (form != null)
		{
			
			OthermemberscrapForm othermemberscrapForm = (OthermemberscrapForm) form;
			OthermemberscrapBean othermemberscrapBean = new OthermemberscrapBean();
			OthermemberscrapBean othermemberscrapBean1 = new OthermemberscrapBean();
			
			Session session = HibernateUtil.getSessionFactory()
			.openSession();
			HttpSession httpsession = request.getSession();
	System.out.println("session======111111111111111111111111111111111111111111111111111=====>" + session);
	String scrapbook = request.getParameter("action");
	//Getting the memberid
	
	String r=(String)httpsession.getAttribute("mid").toString();
	 int q=Integer.parseInt(r);
     System.out.println("rambooo"+q);
     
   //Getting the userid(visitor's id)
     
     String r1=(String)httpsession.getAttribute("uid1").toString();
	 int q1=Integer.parseInt(r1);
     System.out.println("uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuid"+q1);
     OthermemberDAOImpl othermemberdaoImpl = new OthermemberDAOImpl();
     
     
     if("scrapbook".equals(scrapbook))
     {
			System.out.println("Inside scrapppppppppppp view==========>");
			othermemberscrapBean.setSentby(q);
			//othermemberscrapBean = othermemberdaoImpl.checkmember(session, othermemberscrapBean);
			Collection scrap = othermemberdaoImpl.viewscraps(session,othermemberscrapBean,q1);
			
			System.out.println("After view function=====>"+scrap);
			
			request.setAttribute("scrap", scrap);
			target = "scrapbook";
			System.out.println("Target after function call=====>"+target);
			
	 }
     
     if("insert".equals(scrapbook)){
    	 
			
			System.out.println("Inside scrap insert==========>");
			
			/*DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:MM:SS");
			Calendar cal = Calendar.getInstance();
			
			System.out.println("System date: "+dateFormat.format(cal.getTime()));
			String dat=dateFormat.format(cal.getTime());
			Date date = dateFormat.parse(dat);*/
			
			java.util.Date date=new java.util.Date();
			System.out.println("System date===========>: "+date);
			othermemberscrapBean.setPosteddate(date);
			othermemberscrapBean.setScraptext(othermemberscrapForm.getScraptext());
			othermemberscrapBean.setVisibility(othermemberscrapForm.getVisibility());
			othermemberscrapBean.setSentby(q);
			othermemberscrapBean.setSentto(q1);
			 System.out.println("scrapbean====scrrrap=============>"+othermemberscrapBean.getScraptext());
			System.out.println("scrapbean=====Visibility11111======>"+othermemberscrapBean.getVisibility());
			System.out.println("scrapbean=====Sentby======>"+othermemberscrapBean.getSentby());
			System.out.println("scrapbean=====Posted date======>"+othermemberscrapBean.getPosteddate());
			othermemberdaoImpl.insert(session,othermemberscrapBean);
			othermemberscrapBean=othermemberdaoImpl.checkmember(session, othermemberscrapBean);
			
			Collection scrap = othermemberdaoImpl.viewscraps(session,othermemberscrapBean,q1);
			System.out.println("After view function=====>"+scrap);
			request.setAttribute("scrap", scrap);
			target = "scrapbook";
			System.out.println("Target after function call=====>"+target);
		}
     
     if("deletea".equals(scrapbook))
		{
			System.out.println("=====in delete======");
			String scrapid1=request.getParameter("t");
			int scrapid=Integer.parseInt(scrapid1);
				System.out.println("======in delete for====="+scrapid);
				othermemberscrapBean.setScrapbookid(scrapid);
				othermemberscrapBean = othermemberdaoImpl.checkmember(session, othermemberscrapBean);
				int sentby=othermemberscrapBean.getSentby();
				if(sentby==q)
				{
					
					othermemberdaoImpl.delete(session, othermemberscrapBean);
					 Collection scrap = othermemberdaoImpl.viewscraps(session,othermemberscrapBean,q1);
					 System.out.println("After view function=====>"+scrap);
					 request.setAttribute("scrap", scrap);
					 target = "scrapbook";
					
				}
				else
				{
				 Collection scrap1 = othermemberdaoImpl.viewscraps(session,othermemberscrapBean,q1);
				 
				 System.out.println("After view function==sssssssssssssssssssiiiiiiiiiizeeeeeeeeee===>"+scrap1.size());
				 request.setAttribute("scrap", scrap1);
				 target = "scrapbook";
				}
				
		}
     
		}
	}
	catch(Exception e)
	{
		System.out.println("Exception in other member scrap action===="+e);
		
	}
	return (mapping.findForward(target));

}
	
}
