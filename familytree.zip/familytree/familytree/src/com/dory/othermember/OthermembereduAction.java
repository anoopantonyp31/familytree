
/**
 * Date:19/11/2010
 * @author Upesh.A
 */

package com.dory.othermember;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.educational.EducationalBean;
import com.dory.hibernate.HibernateUtil;

//Action for getting the education details

public class OthermembereduAction extends Action 
 {
  
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
	String target = null;
	try {
		if (form != null)
		{
	
			EducationalBean othermembereduBean = new EducationalBean();
			HttpSession httpsession = request.getSession();
			
			
			Session session = HibernateUtil.getSessionFactory()
					.openSession();
			System.out.println("session======111111=====>" + session);
			
			//Getting the memberid
			
			String r=(String)httpsession.getAttribute("mid").toString();
			 int q=Integer.parseInt(r);
             System.out.println("rambooo"+q);
             
           //Getting the userid(visitor's id)
             
             String r1=(String)httpsession.getAttribute("uid1").toString();
			 int q1=Integer.parseInt(r1);
             System.out.println("uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuid"+q1);
             OthermemberDAOImpl othermemberdaoImpl = new OthermemberDAOImpl();
             
             String usertype=(String)httpsession.getAttribute("usertype");
  			System.out.println("usererererertytytpepepepepep======"+usertype);
  			
             if(usertype.equals("sadmin"))
             {
             	 Collection othereducation = othermemberdaoImpl.displaysupereducation(session,othermembereduBean,q,q1);
            	 if(othereducation.size()>0)
            	 {
            	   request.setAttribute("othereducation", othereducation);
 			       target="othereducation";
            	 }
            	
            	 
            	 
             }
             
             
           //Method for getting the educational details
             else
             {
             
             Collection othereducation = othermemberdaoImpl.displayothereducation(session,othermembereduBean,q,q1);
            
             
            	 
            	 //Setting attributes if returned values  
            	 
            	 
            	 if(othereducation.size()>0)
            	 {
            	   request.setAttribute("othereducation", othereducation);
			       target="othereducation";
            	 }
            	 
            	//Setting attributes if not returned values 
            	 
            	 else if(othereducation.size()<=0)
                 {
                	String view="cannotaccess"; 
                	request.setAttribute("cannotaccess", view);
                	target="othereducation";
                	
                 }
             }
		}
		}
		catch (Exception e) 
		{
		System.out.println("Exception=====>" + e);
		target="failure";
		}

	return (mapping.findForward(target));
	}
 }
