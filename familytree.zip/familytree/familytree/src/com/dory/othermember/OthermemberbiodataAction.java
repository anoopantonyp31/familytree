package com.dory.othermember;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.memberbiodata.BiodataBean;

public class OthermemberbiodataAction extends Action
{

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
	String target = null;
	try {
		if (form != null)
		{
			  
			   BiodataBean biodataBean = new BiodataBean();
			HttpSession httpsession = request.getSession();

			
			

			Session session = HibernateUtil.getSessionFactory()
					.openSession();
			System.out.println("session======111111=====>" + session);
			
			String usertype=(String)httpsession.getAttribute("usertype");
			System.out.println("usererererertytytpepepepepep======"+usertype);
			
			//Getting the memberid
			
			String r=(String)httpsession.getAttribute("mid").toString();
			 int q=Integer.parseInt(r);
             System.out.println("rambooo"+q);
             
           //Getting the userid(visitor's id)
             
             String r1=(String)httpsession.getAttribute("uid1").toString();
			 int q1=Integer.parseInt(r1);
             OthermemberDAOImpl othermemberdaoImpl = new OthermemberDAOImpl();
             
            if(usertype.equals("sadmin"))
             {
            	Collection biodata = othermemberdaoImpl.displaysuperbiodata(session,biodataBean,q,q1);
            	 if(biodata.size()>0)
            	 {
            	   request.setAttribute("biodata", biodata);
			       
            	 }
            	 target="biodata";
            	 
             }
             
             //Method for getting the member details

             else
             {
             
             Collection biodata = othermemberdaoImpl.displayotherbiodata(session,biodataBean,q,q1);
             
            
             
            	//Setting attributes if returned values 
            	 
            	 if(biodata.size()>0)
            	 {
            	   request.setAttribute("biodata", biodata);
			      
            	 }
            	 
            	//Setting attributes if not returned values 
            	 else if(biodata.size()<=0)
                 {
                	String view="cannotaccess"; 
                	request.setAttribute("cannotaccess", view);
                	
                	
                 }
            	 target="biodata";
             }
            
		}
		}
		catch (Exception e) 
		{
		System.out.println("Exception=====>" + e);
		target="failure";
		}

	return (mapping.findForward(target));
	}
}
