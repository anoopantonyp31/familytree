package com.dory.community;

import com.dory.memberprofile.ProfileBean;

public class CommunitymemberBean {
	
	private int communitymemberid;
	private int memberid;
	private int communityid;
	private String status;
	
	private String communityname;
	private String name;
	
	private CreatecommunityBean create;
	private ProfileBean profile1;
	
	public CommunitymemberBean(){
		
	}

    public CommunitymemberBean(int communityid,String communityname){
		this.communityname=communityname;
		this.communityid=communityid;
	}
    
    public CommunitymemberBean(String name,int memberid){
		this.name=name;
		this.memberid=memberid;
	}
	
	
	public void setCommunitymemberid(int communitymemberid) {
		this.communitymemberid = communitymemberid;
	}
	public int getCommunitymemberid() {
		return communitymemberid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setCommunityid(int communityid) {
		this.communityid = communityid;
	}
	public int getCommunityid() {
		return communityid;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}

	
	public void setCommunityname(String communityname) {
		this.communityname = communityname;
	}
	public String getCommunityname() {
		return communityname;
	}
	public void setCreate(CreatecommunityBean create) {
		this.create = create;
	}
	public CreatecommunityBean getCreate() {
		return create;
	}


	public void setProfile1(ProfileBean profile1) {
		this.profile1 = profile1;
	}


	public ProfileBean getProfile1() {
		return profile1;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getName() {
		return name;
	}

	
	
	

}
