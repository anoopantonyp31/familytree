package com.dory.community;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

public class CommunityrequestAction extends DispatchAction

{

	public ActionForward request(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
				System.out.println("inside action");
				ViewrequestForm viewrequestForm = (ViewrequestForm) form;
				Session session = HibernateUtil.getSessionFactory()
			    .openSession();
				HttpSession httpsession = request.getSession();
				System.out.println("before session cid");
				String coid=(String)httpsession.getAttribute("commid").toString();
				 int cid=Integer.parseInt(coid);
				 
				 System.out.println("session======11iiiiiiiiiiidddddddddddcccccccccc==="+cid);
				 CommunityDAO communityDAO = new CommunityDAOImpl();
				Collection pending = communityDAO.displayAllpending(session,cid);
				if(pending.size()>0)
				{		
				request.setAttribute("pending", pending);
				}
				else
				{
					request.setAttribute("notpresent", "notpresent");
					
				}

				target = "community";
				  
				 

			}
		}
		
		catch (Exception e) 
		{
		System.out.println("Exceptionrequuuueesstttt=====>" + e);
		target="failure";
		}

	return (mapping.findForward(target));

			}
	
	
	public ActionForward accept(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
				ViewrequestForm viewrequestForm = (ViewrequestForm) form;
				ViewrequestBean viewrequestBean = new ViewrequestBean();
				Session session = HibernateUtil.getSessionFactory()
			    .openSession();
				HttpSession httpsession = request.getSession();
				String coid=(String)httpsession.getAttribute("commid").toString();
				 int cid=Integer.parseInt(coid);
				 System.out.println("session======11iiiiiiiiiiidddddddddddcccccccccc==="+cid);
				 int memid = Integer.parseInt(request.getParameter("memid"));
				 System.out.println("session======memememm11iiiiiiiiiiidddddddddddcccccccccc==="+memid);
				 viewrequestBean.setMemberid(memid);
			
				 CommunityDAO communityDAO = new CommunityDAOImpl();
				 communityDAO.accept(session,viewrequestBean,cid);
				Collection pending = communityDAO.displayAllpending(session,cid);
				if(pending.size()>0)
				{		
				request.setAttribute("pending", pending);
				}
				else
				{
					request.setAttribute("notpresent", "notpresent");
					
				}

				target = "community";
				  
				 

			}
		}
		
		catch (Exception e) 
		{
		System.out.println("Exception=====>" + e);
		target="failure";
		}

	return (mapping.findForward(target));

			}
	
	
	public ActionForward reject(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
				ViewrequestForm viewrequestForm = (ViewrequestForm) form;
				ViewrequestBean viewrequestBean = new ViewrequestBean();
				Session session = HibernateUtil.getSessionFactory()
			    .openSession();
				HttpSession httpsession = request.getSession();
				String coid=(String)httpsession.getAttribute("commid").toString();
				 int cid=Integer.parseInt(coid);
				 System.out.println("session======11iiiiiiiiiiidddddddddddcccccccccc==="+cid);
				 int memid = Integer.parseInt(request.getParameter("memid"));
				 System.out.println("session======memememm11iiiiiiiiiiidddddddddddcccccccccc==="+memid);
				 viewrequestBean.setMemberid(memid);
				 CommunityDAO communityDAO = new CommunityDAOImpl();
				 communityDAO.reject(session,viewrequestBean,cid);
				Collection pending = communityDAO.displayAllpending(session,cid);
				if(pending.size()>0)
				{		
				request.setAttribute("pending", pending);
				}
				else
				{
					request.setAttribute("notpresent", "notpresent");
					
				}

				target = "community";
				  
				 

			}
		}
		
		catch (Exception e) 
		{
		System.out.println("Exception=====>" + e);
		target="failure";
		}

	return (mapping.findForward(target));

			}
	}
