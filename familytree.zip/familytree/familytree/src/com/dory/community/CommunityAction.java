package com.dory.community;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.memberprofile.ProfileBean;

public class CommunityAction extends Action {


	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
				
				
				//HttpSession httpsession = request.getSession();
				//Retrieving memberid
				//String r=(String)httpsession.getAttribute("mid").toString();
				// int q=Integer.parseInt(r);
				  
				 
					String k = request.getParameter("action");
					String k1 = request.getParameter("action");
					String k2 = request.getParameter("action");
					String redirect = request.getParameter("roo");
					String joining = request.getParameter("joincomm");
					String k3 = request.getParameter("action");
						
				System.out.println("Value for community id: "+redirect);
				System.out.println("Value for k: "+k);
				System.out.println("Value for k1: "+k1);
				System.out.println("Value for k2: "+k2);
				System.out.println("Value for k3: "+k3);
				System.out.println("Value for joining: "+joining);
				String value= redirect;
				
				CommunityForm createcommunityForm = (CommunityForm) form;
				//ViewrequestForm viewrequestForm = (ViewrequestForm) form;
				CreatecommunityBean createcommunityBean = new CreatecommunityBean();
				ViewrequestBean viewrequestBean = new ViewrequestBean();
				CommunitymemberBean communitymemberBean = new CommunitymemberBean();
				Create2Bean create2Bean = new Create2Bean();
				ProfileBean profileBean = new ProfileBean();
				ProfileBean profileBean1 = new ProfileBean();
				HttpSession httpsession1 = request.getSession();
				HttpSession comun = request.getSession();
				BeanUtils.copyProperties(createcommunityBean, createcommunityForm);
				
				
				
				Session session = HibernateUtil.getSessionFactory()
			    .openSession();
				System.out.println("session======111111=====>" + session);
				HttpSession httpsession = request.getSession();
				String r=(String)httpsession.getAttribute("mid").toString();
				int memid=Integer.parseInt(r);
	            System.out.println("Member ID======> "+memid);
	            
	            
				CommunityDAO communityDAO = new CommunityDAOImpl();
				
				
				
				
				
				
				
				if("display1".equals(k3))
				{
                     // collection to display all the communities in the database
					System.out.println("display111111111111111111111");
					
					String coid=(String)httpsession.getAttribute("commid").toString();
					 int cid=Integer.parseInt(r);
					Collection pending = communityDAO.displayAllpending(session,cid);
					request.setAttribute("pending", pending);
					Collection col = communityDAO.memberdisplay(session,cid);
					request.setAttribute("col", col);  
					target = "community";
					
				}
				
				
				
				
				
				
				
				
				
				
				
				
				else if("display".equals(k1))
				{
                     // collection to display all the communities in the database
					Collection exeobj = communityDAO.displayAllCommunity(session);
					System.out.println("After======Allcommunity=====>"+ exeobj.size());
					System.out.println("After======Allcommunity=====>"+ exeobj.size());
					
					
					
					//collection to display the communities created by the member
					Collection exeobj1 = communityDAO.displayMemberCommunity(session,memid);
					System.out.println("After======Membercommunity=====>"+ exeobj1.size());
					System.out.println("After======Membercommunity=====>"+ exeobj1.size());
					//String comm=(String)httpsession.getAttribute("commid").toString();
					//int cid=Integer.parseInt(comm);  
					
					request.setAttribute("exeobj",exeobj);
					request.setAttribute("exeobj1",exeobj1);
					target = "community";
					
				}
				
				
				else if("join".equals(joining))
				{
                    // function to join a member into a community............
					
					String comm=(String)httpsession.getAttribute("commid").toString();
					int cid=Integer.parseInt(comm);
		            System.out.println("Community ID======> "+cid);
		            System.out.println("Member ID====Inside join loop==> "+memid);
		            
		            createcommunityBean=communityDAO.retrievecommu222(session,cid);
		            int cretid= createcommunityBean.getMemberid();
		            System.out.println("Member ID====created idddd==> "+cretid);
		            profileBean1=communityDAO.retrievemem(session,cretid);
		            System.out.println("created Member ID====profilebean1==> "+profileBean1.getName());
		            profileBean=communityDAO.retrievemem(session,memid);
		            System.out.println("joining Member ID====profilebean==> "+profileBean.getName());
		            createcommunityBean.setProfile(profileBean1);
		            
		            communitymemberBean.setCreate(createcommunityBean);
		            communitymemberBean.setProfile1(profileBean);
		            communitymemberBean.setStatus("pending");
		            System.out.println("communitymemberBean====Status==> "+communitymemberBean.getStatus());
		            System.out.println("communitymemberBean====Status==> "+communitymemberBean.getStatus());
		            
					communityDAO.memberinsert(session,communitymemberBean);
					request.setAttribute("join","join");
					request.setAttribute("joining","joining");
					System.out.println("After======Joining=====>");
					System.out.println("After======Joining=====>");
					
					createcommunityBean=communityDAO.communityhome(session,cid);
					request.setAttribute("create", createcommunityBean);
					Collection col = communityDAO.memberdisplay(session,cid);
					request.setAttribute("col", col);  
					target = "joining";
					
				}
				
				else if("unjoin".equals(joining))
				{
                    // function to join a member into a community............
					
					String comm=(String)httpsession.getAttribute("commid").toString();
					int cid=Integer.parseInt(comm);
		            System.out.println("Community ID   unjoooiiiiii======> "+cid);
		            System.out.println("Member ID====Inside juuuuunnnnnnoin loop==> "+memid);
		            viewrequestBean.setMemberid(memid);
		            communityDAO.communityunjoin(session,viewrequestBean,cid);
		            
		            createcommunityBean=communityDAO.communityhome(session,cid);
					request.setAttribute("create", createcommunityBean);
					Collection col = communityDAO.memberdisplay(session,cid);
					request.setAttribute("col", col);  
					target = "joining";
					
				}
				
				
				
				
				
				else if("discrep".equals(k2))
				{
					// to display the discreption,name,owner,date of the community from the uploadcommunityphoto.jsp
					createcommunityBean.setProfile(profileBean);
					CommunitycheckBean communitycheckBean = new CommunitycheckBean();
					  
					String ro=(String)comun.getAttribute("cid").toString();
			             int idd=Integer.parseInt(ro);
					//----------------
					createcommunityBean=communityDAO.communityhome(session,idd);
					request.setAttribute("create", createcommunityBean);
					
					System.out.println("create community member name%%%%%%%% "+createcommunityBean.getName());
					System.out.println("create community community name%%%%%%%% "+createcommunityBean.getCommunityname());
					System.out.println("create community description%%%%%%%% "+createcommunityBean.getCommunity_description());
					//------------
					
					communitycheckBean=communityDAO.communitycheck(session,idd);
					
			        String s = "check";
			        String e = "abc";
		   			System.out.println("displayStan===commmmmidddACtionnnnnnnnnnnnnnnnnnnnnnnnn====="+communitycheckBean.getCommunityid());
		   			System.out.println("displayStandard====icreatediddddiddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd===ACtionnnnnnnnnnnnnnnnnnnnnnnnn====="+communitycheckBean.getCreatedby());
                    int  crid=communitycheckBean.getCreatedby();
                    String s1="join";
				    if(crid==memid)
				    {
				    	System.out.println("iiiiiiiiiiiiiiiiifffffffffffffffffffffffffffff");
				    	request.setAttribute("check", s);
				    	request.setAttribute("abc", e);
				    	
				    }
				    viewrequestBean.setCommunityid(idd);
				    System.out.println("iiicommmmunityyyyyyidddd in nanananmwwweeeeee==+++++++++"+viewrequestBean.getCommunityid());
				    Collection communitymembercheck = communityDAO.communitymembercheck(session,viewrequestBean,memid);
				  //  System.out.println("iiiiiimememmememememememememmememmmeememem====="+asd);				    if(communitymembercheck)
				    	
				    if(communitymembercheck.size()>0)
				    {
				    	System.out.println("iiiiiiffffffffffffffBBBBBBBBBBBBBBBBBBBB");
				    	request.setAttribute("join", s1);
				    }
				    
				Collection col = communityDAO.memberdisplay(session,idd);
				request.setAttribute("col", col);  
					target = "communityhome";	
				}
				
				else if ("insert".equals(k)) 
				{
					
					
					CommunitycheckBean communitycheckBean = new CommunitycheckBean();
					//insert data into community table
					profileBean=communityDAO.retrievemem(session,memid);  
                    createcommunityBean.setProfile(profileBean);
                    System.out.println("member name ");
					System.out.println("inside insert");
					Serializable id=communityDAO.insert(session,createcommunityBean);
					int idd=(Integer)id;
					// idd is the communityid from the community table
					System.out.println("idddddddddddddd"+idd);
					
					//-----------------------------------------------------
					if(idd!='0')
					{
						//insert data into community_member table 
						System.out.println("inside second insert%%%%%%%%");
						createcommunityBean=communityDAO.retrievecommu(session,idd);
						profileBean=communityDAO.retrievemem(session,memid);
						communitymemberBean.setCreate(createcommunityBean);
						communitymemberBean.setProfile1(profileBean);
						//communitymemberBean.setMemberid(memid);
						
						System.out.println("after setting id"+communitymemberBean.getCommunityid());
						String status="active";
						System.out.println("after status===="+status);
						System.out.println("inside second insert%%%%%%%%");
						communitymemberBean.setStatus(status);
						
						System.out.println("inserting");
						communityDAO.memberinsert(session, communitymemberBean);
						//insert1 is used to insert into community_member table
					}
					
					
					// to create folder with the community id=iid
					File f=new File(getServlet().getServletContext().getRealPath("/")+"community/"+idd);
					System.out.print("after ffffffffff");
					
					if(!f.exists())
						f.mkdirs();
					
					//set community id id idd to cid
					comun.setAttribute("cid",idd);
					
					HttpSession session1=request.getSession();
					session1.setAttribute("commid",idd);
					
					//----------------
					// to display community name, discreption,date,owner in communityhome.jsp
					createcommunityBean=communityDAO.communityhome(session,idd);
					request.setAttribute("create", createcommunityBean);
					
					System.out.println("create community member name%%%%%%%% "+createcommunityBean.getName());
					System.out.println("create community community name%%%%%%%% "+createcommunityBean.getCommunityname());
					System.out.println("create community description%%%%%%%% "+createcommunityBean.getCommunity_description());
					//------------
					//new---------------------
					
					// to get the memberid,member name and to display the photos of the members in the corresponding community
					//Collection col=communityDAO.communitymembers(session, idd);
					//System.out.print("after community members------->"+col.size());
					//request.setAttribute("col", col);				
					//--------------------------
					
					communitycheckBean=communityDAO.communitycheck(session,idd);
					
			        String s = "check";
			        String e = "abc";
		   			System.out.println("displayStan===commmmmidddACtionnnnnnnnnnnnnnnnnnnnnnnnn====="+communitycheckBean.getCommunityid());
		   			System.out.println("displayStandard====icreatediddddiddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd===ACtionnnnnnnnnnnnnnnnnnnnnnnnn====="+communitycheckBean.getCreatedby());
                    int  crid=communitycheckBean.getCreatedby();
                    String s1="join";
				    if(crid==memid)
				    {
				    	System.out.println("iiiiiiiiiiiiiiiiifffffffffffffffffffffffffffff");
				    	request.setAttribute("check", s);
				    	request.setAttribute("abc", e);
				    	
				    }
				    viewrequestBean.setCommunityid(idd);
				    System.out.println("iiicommmmunityyyyyyidddd in nanananmwwweeeeee==+++++++++"+viewrequestBean.getCommunityid());
				    Collection communitymembercheck = communityDAO.communitymembercheck(session,viewrequestBean,memid);
				  //  System.out.println("iiiiiimememmememememememememmememmmeememem====="+asd);				    if(communitymembercheck)
				    	
				    if(communitymembercheck.size()>0)
				    {
				    	System.out.println("iiiiiiffffffffffffffBBBBBBBBBBBBBBBBBBBB");
				    	request.setAttribute("join", s1);
				    }
				    
				Collection col = communityDAO.memberdisplay(session,idd);
				request.setAttribute("col", col);    
					
					target = "communityhome";	
				}
				
				else if(value.equals(redirect))
				{	
				System.out.println("minuuuuuuuuuu11111"+value);
				System.out.println("minuuuuuuuuuu22222");
				CommunitycheckBean communitycheckBean = new CommunitycheckBean();
				int commid = Integer.parseInt(value);

				createcommunityBean=communityDAO.communityhome(session,commid);
				
				HttpSession session1=request.getSession();
				session1.setAttribute("commid",commid);
				
				request.setAttribute("create", createcommunityBean);
				
				System.out.println("bindhu=====>  "+createcommunityBean.getName());
				System.out.println("ameesh======>"+createcommunityBean.getCommunityname());
				System.out.println("sreekala=======>  "+createcommunityBean.getCommunity_description());
				//------------
				
				System.out.println("mimemeberiiiiiiiiiiiiiiiiddddddddddd================"+memid);
			
				communitycheckBean=communityDAO.communitycheck(session,commid);
				
			        String s = "check";
			        String e = "abc";
		   			System.out.println("displayStan===commmmmidddACtionnnnnnnnnnnnnnnnnnnnnnnnn====="+communitycheckBean.getCommunityid());
		   			System.out.println("displayStandard====icreatediddddiddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd===ACtionnnnnnnnnnnnnnnnnnnnnnnnn====="+communitycheckBean.getCreatedby());
                    int  crid=communitycheckBean.getCreatedby();
                    String s1="join";
				    if(crid==memid)
				    {
				    	System.out.println("iiiiiiiiiiiiiiiiifffffffffffffffffffffffffffff");
				    	request.setAttribute("check", s);
				    	request.setAttribute("abc", e);
				    	
				    }
				    viewrequestBean.setCommunityid(commid);
				    System.out.println("iiicommmmunityyyyyyidddd in nanananmwwweeeeee==+++++++++"+viewrequestBean.getCommunityid());
				    Collection communitymembercheck = communityDAO.communitymembercheck(session,viewrequestBean,memid);
				  //  System.out.println("iiiiiimememmememememememememmememmmeememem====="+asd);				    if(communitymembercheck)
				    	
				    if(communitymembercheck.size()>0)
				    {
				    	System.out.println("iiiiiiffffffffffffffBBBBBBBBBBBBBBBBBBBB");
				    	request.setAttribute("join", s1);
				    }
				    
				Collection col = communityDAO.memberdisplay(session,commid);
				request.setAttribute("col", col);    
				
				target = "communityhome";
				
				}
				
					
				}	
			
			System.out.println("target==================================================================target=====>"+ target);
		} 
			catch (Exception e) 
			{
			System.out.println("Exception in community action=====>" + e);
			}

		return (mapping.findForward(target));
}
}
