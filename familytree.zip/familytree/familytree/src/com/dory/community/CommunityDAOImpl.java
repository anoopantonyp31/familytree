package com.dory.community;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.displayinvitation.DisplayinvitationBean;
import com.dory.memberprofile.ProfileBean;

public class CommunityDAOImpl implements CommunityDAO {

	
	public Serializable insert(Session session, CreatecommunityBean createcommunityBean) {
		Serializable id;
		session.beginTransaction();
		System.out.println("sososososos");
		id=session.save(createcommunityBean);
		session.getTransaction().commit();
		return id;

	}
	
	//------------------------
	public boolean memberinsert(Session session, CommunitymemberBean communitymemberBean) {
		session.beginTransaction();
		session.save(communitymemberBean);
		session.getTransaction().commit();
		return true;

	}

	
	//-------------------------
	
	public Collection displayAllCommunity(Session session){
		Collection comm = new ArrayList();
		Create2Bean create2Bean= new Create2Bean();
		try {
			
			List query = session.createQuery("from Create2Bean ex").list();
			System.out.println("List======query=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				
				create2Bean = (Create2Bean) it.next();
				System.out.println("createcommunityBean======community name=====> "+create2Bean.getCommunityname());
				comm.add(create2Bean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return comm;
	}
	
	
	
	public Collection displayMemberCommunity(Session session,int q){
		Collection executivecol1 = new ArrayList();
		CreatecommunityBean createcommunityBean= new CreatecommunityBean();
		CommunitymemberBean communitymemberBean= new CommunitymemberBean();
		try {
			
			System.out.println("Inside======Member community=====> ");
			System.out.println("Inside======Member community=====> ");
			System.out.println("session======displayexecutivepos=====> "+q);	
			List query = session.createQuery("select new CommunitymemberBean(m.communityid,m.communityname) from CommunitymemberBean c " +
					                         "join c.create m " +
					                         "join c.profile1 p " +
					                         "where p.memberid='"+q+"'").list();
			System.out.println("Query======222222222222222=====> "+q);
			System.out.println("Query======222222222222222=====> "+q);
			System.out.println("Query======222222222222222=====> "+q);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("Iterator======22222222222222222=====> ");	
				communitymemberBean = (CommunitymemberBean) it.next();
				System.out.println("communitymemberBean======community name22222222222222222=====> "+communitymemberBean.getCommunityname());
				System.out.println("communitymemberBean======community name22222222222222222=====> "+communitymemberBean.getCommunityname());
				
				executivecol1.add(communitymemberBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return executivecol1;
	}
	
	
	public CreatecommunityBean retrievecommu(Session session,int id){
		
		CreatecommunityBean createcommunityBean= new CreatecommunityBean();
		try {
			System.out.println("Inside retrieve community......."+id);
			System.out.println("Inside retrieve community......."+id);
			System.out.println("Inside retrieve community......."+id);
			List query = session.createQuery("from CreatecommunityBean ex where ex.communityid='"+id+"'").list();
			System.out.println("List======query=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				
				createcommunityBean = (CreatecommunityBean) it.next();
				System.out.println("createcommunityBean======community name=====> "+createcommunityBean.getCommunityname());
				System.out.println("createcommunityBean======community name=====> "+createcommunityBean.getCommunityname());
				System.out.println("createcommunityBean======community name=====> "+createcommunityBean.getCommunityname());
				
			}
		} 
		
		catch (Exception e) {
			System.out.println("MONSTERRRRRR====>"+e);
		}
		//session.close();
		return createcommunityBean;
	}
	
  public CreatecommunityBean retrievecommu222(Session session,int id){
		
		CreatecommunityBean createcommunityBean= new CreatecommunityBean();
		try {
			System.out.println("Inside retrieve222222 community......."+id);
			System.out.println("Inside retrieve22222222 community......."+id);
			System.out.println("Inside retrieve222222222 community......."+id);
			List query = session.createQuery("select new CreatecommunityBean(ex.communityid,ex.communityname,pr.memberid,ex.community_description,ex.category) from CreatecommunityBean ex " +
					                         "join ex.profile pr " +
					                         "where ex.communityid='"+id+"'").list();
			System.out.println("List======query=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				
				createcommunityBean = (CreatecommunityBean) it.next();
				System.out.println("createcommunityBean======community name=====> "+createcommunityBean.getCommunityname());
				System.out.println("createcommunityBean======community name=====> "+createcommunityBean.getCommunityname());
				System.out.println("createcommunityBean======community name=====> "+createcommunityBean.getCommunityname());
				
			}
		} 
		
		catch (Exception e) {
			System.out.println("MONSTERRRRRR====>"+e);
		}
		//session.close();
		return createcommunityBean;
	}
	
	
	public CreatecommunityBean communityhome(Session session,int q){
		
		CreatecommunityBean createcommunityBean= new CreatecommunityBean();
		
		try {
			
			System.out.println("session======displayexecutivepos=====> "+q);	
			List query = session.createQuery("select new CreatecommunityBean(p.name,c.communityname,c.community_description,c.category) from CreatecommunityBean c " +
					                         "join c.profile p " +
					                         "where c.communityid='"+q+"'").list();
			System.out.println("Query======222222222222222=====> "+q);
			
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("Iterator======22222222222222222=====> ");	
				createcommunityBean = (CreatecommunityBean) it.next();
				System.out.println("communitymemberBean======community name33333333333333333=====> "+createcommunityBean.getCommunityname());
				System.out.println("communitymemberBean======community name33333333333333333=====> "+createcommunityBean.getCommunityname());
				
				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return createcommunityBean;
	}
	
	
	
   public ProfileBean retrievemem(Session session,int mem){
		
	   ProfileBean profileBean= new ProfileBean();
		try {
			System.out.println("Inside retrieve member......."+mem);
			System.out.println("Inside retrieve member......."+mem);
			System.out.println("Inside retrieve member.......");
			List query = session.createQuery("from ProfileBean ex where ex.memberid='"+mem+"'").list();
			System.out.println("List======query=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				
				profileBean = (ProfileBean) it.next();
				System.out.println("profileBean======member name=====> "+profileBean.getName());
				System.out.println("profileBean======member name=====> "+profileBean.getName());
				System.out.println("profileBean======member name=====> "+profileBean.getName());
				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return profileBean;
	}
	
   
 // =======================================upesh================================== 
   
   public CommunitycheckBean communitycheck(Session session,int commid)
   {
	   
	   CommunitycheckBean communitycheckBean= new CommunitycheckBean();
	   try
	   {
	   List query = session.createSQLQuery("select * from community ds where communityid='"+commid+"' ").addEntity("ds",CommunitycheckBean.class).list();
	   System.out.println("displaystandard====query========"+query);
	   		
	         for (Iterator it = query.iterator(); it.hasNext();) 
	         {
	   			System.out.println("displaystandard====Iterator========");
	   			communitycheckBean = (CommunitycheckBean) it.next();
	   			//System.out.println("displayStan===commmmmiddd====="+communitycheckBean.getCommunityid());
	   			//System.out.println("displayStandard====icreatediddddiddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd========"+communitycheckBean.getCreatedby());
	   			
	         }
	   }
	   catch (Exception e) 
	   {
			System.out.println("Exception in checkdao"+e);
	   }
	   return communitycheckBean; 
   }
   
   
   
   public Collection displayAllpending(Session session,int cid)
   {
	   
	   ViewrequestBean viewrequestBean = new ViewrequestBean();
	   Membername1Bean membername1Bean = new Membername1Bean();
	  
	   Collection pending = new ArrayList();
	   try
	   {
		   

		   
	   List query = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and status='pending' ").addEntity("ds",ViewrequestBean.class).list();
	   System.out.println("displaystandard====query========"+query);
	   		
	         for (Iterator it = query.iterator(); it.hasNext();) 
	         {
	   			System.out.println("displaystandard====Iterator========");
	   			viewrequestBean = (ViewrequestBean) it.next();
	   			int mid = viewrequestBean.getMemberid();
	   			System.out.println("displayStan===memememeiddididi============="+viewrequestBean.getMemberid());
	   			//System.out.println("displayStan===commmmmiddd====="+communitycheckBean.getCommunityid());
	   			//System.out.println("displayStandard====icreatediddddiddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd========"+communitycheckBean.getCreatedby());
	   		 List query1 = session.createSQLQuery("select * from member_profile dw where memberid='"+mid+"' ").addEntity("dw",Membername1Bean.class).list();
	  	   System.out.println("displaystandard====query========"+query);
	  	   		
	  	         for (Iterator it1 = query1.iterator(); it1.hasNext();) 
	  	         {
	  	   			System.out.println("displaystandard====Iterator========");
	  	   		    membername1Bean = (Membername1Bean) it1.next();
	  	   		    viewrequestBean.setMembername(membername1Bean.getMembername());
	  	         }
	  	       pending.add(viewrequestBean);
	         }
	   }
   
	   catch (Exception e) 
	   {
			System.out.println("Exception in checkdao"+e);
	   }
	   return pending;
	   
	   
   }
   
   
   
   public boolean accept(Session session,ViewrequestBean viewrequestBean,int cid)
   {
	   try
	   {
	   List query = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and status='pending' and memberid='"+viewrequestBean.getMemberid()+"' ").addEntity("ds",ViewrequestBean.class).list();
	   
	   System.out.println("displaystandard====query========"+query);
	   		
	         for (Iterator it = query.iterator(); it.hasNext();) 
	         {
	        	 
	   			System.out.println("displaystandard====Iterator========");
	   			viewrequestBean = (ViewrequestBean) it.next(); 
	         }
	         viewrequestBean.setStatus("active");
	 		session.beginTransaction();
			session.update(viewrequestBean);
			session.getTransaction().commit();
	   }

	   catch (Exception e) 
	   {
			System.out.println("Exception in aceptdaoooooo"+e);
	   }
	   return true;
   }
   
   
   public boolean reject(Session session,ViewrequestBean viewrequestBean,int cid)
   {
	   try
	   {
	   List query = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and status='pending' and memberid='"+viewrequestBean.getMemberid()+"' ").addEntity("ds",ViewrequestBean.class).list();
	   System.out.println("displaystandard====query========"+query);
	   		
	         for (Iterator it = query.iterator(); it.hasNext();) 
	         {
	   			System.out.println("displaystandard====Iterator========");
	   			viewrequestBean = (ViewrequestBean) it.next(); 
	         }
	 		session.beginTransaction();
			session.delete(viewrequestBean);
			session.getTransaction().commit();
	   }

	   catch (Exception e) 
	   {
			System.out.println("Exception in aceptdaoooooo"+e);
	   }
	   return true;
   }
   
   
   
   public Collection memberdisplay(Session session,int commid)
   {
	   
	   Collection col = new ArrayList();
	   ViewrequestBean viewrequestBean = new ViewrequestBean();
	   System.out.println("display commmmmmmmmmiiiiiiiiiiiiiiiiddddddddddd"+commid);
	   Membername1Bean membername1Bean = new Membername1Bean(); 
	   
	   try
	   {
	   List query = session.createSQLQuery("select * from community_members ds where communityid='"+commid+"' and status='active' ").addEntity("ds",ViewrequestBean.class).list();
	   System.out.println("displaystandard====communitytytytytyyq1========"+query);
	   		
	         for (Iterator it = query.iterator(); it.hasNext();) 
	         {
	   			System.out.println("displaystandard====Iterator========");
	   			viewrequestBean = (ViewrequestBean) it.next(); 
	   			int memid = viewrequestBean.getMemberid();
	   			
	   			List query1 = session.createSQLQuery("select * from member_profile cs where memberid='"+memid+"' ").addEntity("cs",Membername1Bean.class).list();
	   		   System.out.println("displaystandard====communitytytytytyyq122222222222========"+query);
	   		   		
	   		         for (Iterator it1= query1.iterator(); it1.hasNext();) 
	   		         {
	   		   			System.out.println("displaystandard====Iterator========");
	   		   	    	membername1Bean = (Membername1Bean) it1.next();
	   		   	        //viewrequestBean.setMembername(membername1Bean.getMembername());
	   			        col.add(membername1Bean);
	   		         }
	         }
	   }
	   catch (Exception e) 
	   {
			System.out.println("Exception in displaymemdaoooooo"+e);
	   }
	   return col;
	   
   }
   
   
   
   
   public Collection communitymembercheck(Session session,ViewrequestBean viewrequestBean,int memid)
   {
	   
	   Collection communitymembercheck = new ArrayList();

	   try
	   {
	   List query = session.createSQLQuery("select * from community_members ds where memberid='"+memid+"' and communityid='"+viewrequestBean.getCommunityid()+"' ").addEntity("ds",ViewrequestBean.class).list();
	   System.out.println("displaystandard====query========"+query);
	   		
	         for (Iterator it = query.iterator(); it.hasNext();) 
	         {
	   			System.out.println("displaystandard====Iterator========");
	   			viewrequestBean = (ViewrequestBean) it.next();
	   			System.out.println("displayStan===commmmmiddd====="+viewrequestBean.getCommunityid());
	   			System.out.println("displayStandard====icmembetrrriddddiddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd========"+viewrequestBean.getMemberid());
	   			communitymembercheck.add(viewrequestBean);
	         }
	         
	         System.out.println("displaystcooollllsize============="+communitymembercheck.size());
	         
	   }
	   catch (Exception e) 
	   {
			System.out.println("Exception in checnnnnnnnnnkdao"+e);
	   }
	   return communitymembercheck; 
	   
   }
   
   
   
   
   public boolean communityunjoin(Session session,ViewrequestBean viewrequestBean,int cid)
   {
	   try
	   {
	   List query = session.createSQLQuery("select * from community_members ds where communityid='"+cid+"' and memberid='"+viewrequestBean.getMemberid()+"' ").addEntity("ds",ViewrequestBean.class).list();
	   
	   System.out.println("displaystandard====query========"+query);
	   		
	         for (Iterator it = query.iterator(); it.hasNext();) 
	         {
	        	 
	   			System.out.println("displaystandard====Iterator========");
	   			viewrequestBean = (ViewrequestBean) it.next(); 
	         }
	        
	 		session.beginTransaction();
			session.delete(viewrequestBean);
			session.getTransaction().commit();
	   }

	   catch (Exception e) 
	   {
			System.out.println("Exception in deletettdaoooooo"+e);
	   }
	   return true;
   }
   
// =======================================upesh==================================  
   public Collection communitymembers(Session session,int q){
		
	   CommunitymemberBean communitymemberBean= new CommunitymemberBean();
	   Collection col= new ArrayList();
		
		try {
			
			System.out.println("session======displayexecutivepos=====> "+q);	
			List query = session.createQuery("select new CommunitymemberBean(p.name,c.communitymemberid) from CommunitymemberBean c " +
					                         "join c.profile1 p " +
					                         "join c.create cr " +
					                         "where cr.communityid='"+q+"' and c.status='active'").list();
			System.out.println("Query======5555555555555555=====> "+q);
			
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("Iterator======55555555555555555555=====> ");	
				communitymemberBean = (CommunitymemberBean) it.next();
				col.add(communitymemberBean);
				System.out.println("communitymemberBean======community name33333333333333333=====> "+communitymemberBean.getName());
				
				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return col;
	}
   
   
	
	
}
