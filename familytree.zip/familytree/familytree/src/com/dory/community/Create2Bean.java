package com.dory.community;



public class Create2Bean {

	 private int communityid;
	 private int memberid;
	 private String communityname;
	 private String community_description;
	 private String category;
	 
	 
	public void setCommunityid(int communityid) {
		this.communityid = communityid;
	}
	public int getCommunityid() {
		return communityid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setCommunityname(String communityname) {
		this.communityname = communityname;
	}
	public String getCommunityname() {
		return communityname;
	}
	public void setCommunity_description(String community_description) {
		this.community_description = community_description;
	}
	public String getCommunity_description() {
		return community_description;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getCategory() {
		return category;
	}
	
}
