package com.dory.community;

public class ViewrequestBean
{

	private int communitymemberid;
	private int communityid;
	private int memberid;
	private String status;
	private String membername;
	public void setCommunitymemberid(int communitymemberid) {
		this.communitymemberid = communitymemberid;
	}
	public int getCommunitymemberid() {
		return communitymemberid;
	}
	public void setCommunityid(int communityid) {
		this.communityid = communityid;
	}
	public int getCommunityid() {
		return communityid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}

}
