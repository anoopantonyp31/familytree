package com.dory.community;



import org.apache.struts.action.ActionForm;

public class CommunityForm extends ActionForm {


	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int communityid;
	 private String communityname;
	 private String community_description;
	 private String category;
	 
	 
	public void setCommunity_description(String community_description) {
		this.community_description = community_description;
	}
	public String getCommunity_description() {
		return community_description;
	}
	public void setCommunityname(String communityname) {
		this.communityname = communityname;
	}
	public String getCommunityname() {
		return communityname;
	}
	public void setCommunityid(int communityid) {
		this.communityid = communityid;
	}
	public int getCommunityid() {
		return communityid;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getCategory() {
		return category;
	}
	
	
}
