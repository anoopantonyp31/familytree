package com.dory.community;

import java.io.Serializable;
import java.util.Collection;

import org.hibernate.Session;

import com.dory.memberprofile.ProfileBean;

public interface CommunityDAO {

	public Serializable insert(Session session, CreatecommunityBean createcommunityBean);
	public boolean memberinsert(Session session, CommunitymemberBean communitymemberBean);
	public Collection displayAllCommunity(Session session);
	public Collection displayMemberCommunity(Session session,int q);
	public CreatecommunityBean retrievecommu(Session session,int id);
	public CreatecommunityBean communityhome(Session session,int q);
	public ProfileBean retrievemem(Session session,int mem);
	public Collection communitymembers(Session session,int q);
	public CreatecommunityBean retrievecommu222(Session session,int id);
	public CommunitycheckBean communitycheck(Session session,int commid);
	public Collection displayAllpending(Session session,int cid);
	public boolean accept(Session session,ViewrequestBean viewrequestBean,int cid);
	public boolean reject(Session session,ViewrequestBean viewrequestBean,int cid);
	public Collection memberdisplay(Session session,int commid);
	public Collection communitymembercheck(Session session,ViewrequestBean viewrequestBean,int memid);
	
	public boolean communityunjoin(Session session,ViewrequestBean viewrequestBean,int cid);
}
