package com.dory.community;
import java.util.Date;

import com.dory.memberprofile.ProfileBean;

public class CreatecommunityBean {

	 private int communityid;
	 private int memberid;
	 private String communityname;
	 private String community_description;
	 private String category;
	 
	 private String name;
	 
	 private ProfileBean profile;
		
		public CreatecommunityBean(){
			
		}
	 
public CreatecommunityBean(String name,String communityname,String descr,String cat){
			
	this.name=name;
	this.community_description=descr;
	this.communityname=communityname;
	this.category=cat;
	
		}
public CreatecommunityBean(int communityid,String communityname,int created,String descr,String cat){
	this.communityid=communityid;
	this.communityname=communityname;
	this.memberid=created;
	this.community_description=descr;
	this.category=cat;
}
	 
	 
	public void setCommunity_description(String community_description) {
		this.community_description = community_description;
	}
	public String getCommunity_description() {
		return community_description;
	}
	public void setCommunityname(String communityname) {
		this.communityname = communityname;
	}
	public String getCommunityname() {
		return communityname;
	}
	public void setCommunityid(int communityid) {
		this.communityid = communityid;
	}
	public int getCommunityid() {
		return communityid;
	}
	
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}




	public void setProfile(ProfileBean profile) {
		this.profile = profile;
	}




	public ProfileBean getProfile() {
		return profile;
	}




	public void setName(String name) {
		this.name = name;
	}




	public String getName() {
		return name;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCategory() {
		return category;
	}
	
}
