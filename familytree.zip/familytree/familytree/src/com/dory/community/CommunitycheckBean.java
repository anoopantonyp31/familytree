package com.dory.community;

public class CommunitycheckBean
{

	private int communityid;
	private int createdby;
	public void setCreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getCreatedby() {
		return createdby;
	}
	public void setCommunityid(int communityid) {
		this.communityid = communityid;
	}
	public int getCommunityid() {
		return communityid;
	}
}
