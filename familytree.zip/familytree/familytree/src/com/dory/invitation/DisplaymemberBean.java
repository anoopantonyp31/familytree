package com.dory.invitation;

public class DisplaymemberBean {

	
	private int memberid;
	private String membername;
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
}