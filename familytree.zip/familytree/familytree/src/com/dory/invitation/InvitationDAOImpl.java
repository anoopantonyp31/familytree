package com.dory.invitation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.aboutme.AboutDAO;
import com.dory.community.CommunitymemberBean;
import com.dory.hibernate.HibernateUtil;
import com.dory.mygroup.GroupmemberBean;
import com.dory.mygroup.MygroupBean;

public class InvitationDAOImpl  implements InvitationDAO {

	
	
	
		//insertion is being carried out in this bellow function
	public Serializable insert(Session session, InvitationBean invitationBean) {
		Serializable invitationid;
			session.beginTransaction();
			invitationid=session.save(invitationBean);
			session.getTransaction().commit();
			return invitationid;

		}
	
	public boolean insert1(Session session, ReciveinvitationBean reciveinvitationBean) {
		if(session !=null){
			System.out.println("session=================>"+session);
			session.close();
			 session = HibernateUtil.getSessionFactory().openSession();
		}
		session.beginTransaction();
		session.save(reciveinvitationBean);
		session.getTransaction().commit();
		return true;
	
}

	
	public Collection displayinvitation(Session session,InvitationBean invitationBean,int q)
	{
		
		Collection display = new ArrayList();
		try
		{
			System.out.println("session======viiiiiiiiiddddddddd=====> "+q);	
			List query = session.createSQLQuery("select * from invitations gm where memberid='"+q+"'").addEntity("gm",InvitationBean.class).list();
			//System.out.println("Query for getmembers========>>>>>"+query);
			for (Iterator it = query.iterator(); it.hasNext();)
			{
				System.out.println("iittttteerrrrrrrrrrrrraaaaaattttoooooooorrrrrrrrrrrrrrrrrrr=====> ");	
				invitationBean = (InvitationBean) it.next();
				display.add(invitationBean);
			}		
			
		}
		
		catch(Exception e)
		{
			
			System.out.println("Exception in displayyyyyyyyyy======"+e);
		}
		return display;
	}
	
	public boolean delete(Session session,InvitationBean invitationBean)
	{
		ReciveinvitationBean reciveinvitationBean = new ReciveinvitationBean();
		int invitationid = invitationBean.getInvitationid();
		session.beginTransaction();
		session.delete(invitationBean);
		session.getTransaction().commit();
		List query = session.createSQLQuery("select * from receipients_of_invitation gm where invitationid='"+invitationid+"'").addEntity("gm",ReciveinvitationBean.class).list();
		//System.out.println("Query for getmembers========>>>>>"+query);
		for (Iterator it = query.iterator(); it.hasNext();)
		{
			System.out.println("iittttteerrrrrrrrrrrrraaaaaattttoooooooorrrrrrrrrrrrrrrrrrr=====> ");	
			reciveinvitationBean = (ReciveinvitationBean) it.next();
			session.beginTransaction();
			session.delete(reciveinvitationBean);
			session.getTransaction().commit();
			
		}		
		return true;
	}
}