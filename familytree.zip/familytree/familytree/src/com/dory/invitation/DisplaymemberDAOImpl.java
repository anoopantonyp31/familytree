package com.dory.invitation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

public class DisplaymemberDAOImpl {

	
	

		public Collection displaymember(Session session, DisplaymemberBean displaymemberBean) {

			Collection displaymembercol = new ArrayList();
			try {
				List query = session.createQuery("from DisplaymemberBean ex  order by ex.memberid")
						.list();
				for (Iterator it = query.iterator(); it.hasNext();) {
					System.out.println("session======displayexecutivepos=====> ");	
					displaymemberBean = (DisplaymemberBean) it.next();
					displaymembercol.add(displaymemberBean);
				}
			} 
			
			catch (Exception e) {
				e.printStackTrace();
			}
			
			return displaymembercol;
		}
}
