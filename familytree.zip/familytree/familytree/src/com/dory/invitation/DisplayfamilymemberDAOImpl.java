package com.dory.invitation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

public class DisplayfamilymemberDAOImpl {

	

	public Collection displayfamilymembers(Session session, DisplayfamilymemberBean displayfamilymemberBean, int passid) {

		Collection displayfamilymemcol = new ArrayList();
		DisplaymemberBean displaymemberBean = new DisplaymemberBean();
		try {
			List query = session.createQuery(" from DisplayfamilymemberBean  ex  where ex.familyid='"+passid+"' ")
					.list();
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos===1111111111111111111111111111111111111111111111111111==> ");	
				displayfamilymemberBean = (DisplayfamilymemberBean) it.next();
				System.out.println("sessimemmembreid in qqqqqqqqqqq11111111111111=========="+displayfamilymemberBean.getMemberid());
				List query1 = session.createQuery(" from DisplaymemberBean  er  where er.memberid='"+displayfamilymemberBean.getMemberid()+"' ")
				.list();
				for (Iterator it1 = query1.iterator(); it1.hasNext();) 
				{
					System.out.println("session======displayexecutivepos===22222222222222222222222222222222222222222222222==> ");
					displaymemberBean = (DisplaymemberBean) it1.next();
					displayfamilymemberBean.setName(displaymemberBean.getMembername());
					System.out.println("session======displayexecutivepos===memmemebeerrererrenameeeeeeeemeeeeeee========="+displayfamilymemberBean.getName());
					
				}
				displayfamilymemcol.add(displayfamilymemberBean);
				}
				
			
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return displayfamilymemcol;
	}
	
	
}
