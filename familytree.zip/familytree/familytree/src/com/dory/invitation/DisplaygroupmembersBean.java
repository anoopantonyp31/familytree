package com.dory.invitation;
import com.dory.memberprofile.*;

public class DisplaygroupmembersBean {

	private int groupmemberid;
	private int groupid;
	//private String groupname;
	 private int memberid;
	 
	 private String name;
	 
	 
	 private ProfileBean profile;
	 
	public DisplaygroupmembersBean() {
	}
	
	public DisplaygroupmembersBean(String name,int memberid) {
		this.name=name;
		this.memberid=memberid;
	}
		public void setGroupid(int groupid) {
		this.groupid = groupid;
	}
	public int getGroupid() {
		return groupid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setGroupmemberid(int groupmemberid) {
		this.groupmemberid = groupmemberid;
	}
	public int getGroupmemberid() {
		return groupmemberid;
	}
	public void setProfile(ProfileBean profile) {
		this.profile = profile;
	}
	public ProfileBean getProfile() {
		return profile;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
