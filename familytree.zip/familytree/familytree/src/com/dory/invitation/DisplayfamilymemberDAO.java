package com.dory.invitation;

public interface DisplayfamilymemberDAO {

	
}
