package com.dory.invitation;

public class DisplayfamilymemberBean {

	private int memberid;
	private int familyid;
	private int relationid;
	private String name;
	
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setRelationid(int relationid) {
		this.relationid = relationid;
	}
	public int getRelationid() {
		return relationid;
	}
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	
	
}
