package com.dory.invitation;

import java.io.IOException;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;


import com.dory.hibernate.HibernateUtil;

public class InvitationAction extends Action {

	

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//String a1= request.getParameter("fromWhere");
					String k = request.getParameter("action");
					//String k1 = request.getParameter("action1");
				// Use the NameForm to get the request parameters
				InvitationForm invitationForm = (InvitationForm) form;
				InvitationBean invitationBean = new InvitationBean();
				DisplaygroupmembersBean displaygroupmembersBean = new DisplaygroupmembersBean();
				DisplaygroupBean displaygroupBean = new DisplaygroupBean();
				DisplaymemberBean displaymemberBean = new DisplaymemberBean();
				DisplayfamilyBean displayfamilyBean = new DisplayfamilyBean();
				DisplayfamilymemberBean displayfamilymemberBean = new DisplayfamilymemberBean();
				ReciveinvitationBean reciveinvitationBean =new ReciveinvitationBean();
				HttpSession httpsession = request.getSession();
				BeanUtils.copyProperties(invitationBean, invitationForm);
				
				
				//invitationBean.setData(invitationForm
					//	.getData());
				int d;
				Calendar cal=Calendar.getInstance();
				Date dt=cal.getTime();
				
				invitationBean.setSenddate(dt);
				
				
				
				//invitationBean.setLandlineno(contactsForm.getLandlineno());
				// executiveBean.setExecutiveposid(executiveForm.getExecutiveposid());
				//String executive = aboutForm.getExecutivepos();
				//System.out.println("exe===========>" + executive);

				Session session = HibernateUtil.getSessionFactory()
						.openSession();
				System.out.println("session======111111=====>" + session);
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             invitationBean.setMemberid(q);
				
				InvitationDAOImpl invitationDAO = new InvitationDAOImpl();
				DisplaygroupDAOImpl displaygroupDAO = new DisplaygroupDAOImpl();
				DisplaymemberDAOImpl displaymemberDAO = new DisplaymemberDAOImpl();
				DisplaygroupmembersDAOImpl displaygroupmembersDAO = new DisplaygroupmembersDAOImpl();
				DisplayfamilyDAOImpl displayfamilyDAO = new DisplayfamilyDAOImpl();
				DisplayfamilymemberDAOImpl displayfamilymemberDAO = new DisplayfamilymemberDAOImpl();
				
				
				if("displayfamilymembers".equals(k))
				{
					
					System.out.println("inside disp group members");
				int passid=invitationForm.getPassid();
				System.out.println("inside disp group members"+passid);
				
				Collection exeobj4 = displayfamilymemberDAO.displayfamilymembers(session,displayfamilymemberBean, passid);
				System.out.println("grouppppppppppppppp>>>>>>"
						+ exeobj4.size());
				
				
					System.out.println("groups>>>>>>>>>>>>>>>>"
							+ exeobj4.size());
					 d= exeobj4.size();
					//request.setAttribute("size", d);
					request.setAttribute("exeobj4", exeobj4);
					
					Collection exeobj2 = displayfamilyDAO.displayfamily(session,displayfamilyBean);
					System.out.println("grouppppppppppppppp>>>>>>"
							+ exeobj2.size());
					
					
						System.out.println("groups>>>>>>>>>>>>>>>>"
								+ exeobj2.size());
						request.setAttribute("exeobj2", exeobj2);
					
					
					target = "displayfamily";
				}
				
				
				
				
				if("displaymember1".equals(k))
				{
					Collection exeobj3 = displaymemberDAO.displaymember(session,displaymemberBean);
					System.out.println("grouppppppppppppppp>>>>>>"
							+ exeobj3.size());
					
					
						System.out.println("groups>>>>>>>>>>>>>>>>"
								+ exeobj3.size());
						request.setAttribute("exeobj3", exeobj3);
						int passname=invitationForm.getPassname();
						System.out.println("inside selectionlist number"+passname);
						request.setAttribute("pass", passname);
						
						target = "displayfamily";
					 
				}
				
				
				
				
				if("displayfamily".equals(k))
				{
					Collection exeobj2 = displayfamilyDAO.displayfamily(session,displayfamilyBean);
					System.out.println("grouppppppppppppppp>>>>>>"
							+ exeobj2.size());
					
					
						System.out.println("groups>>>>>>>>>>>>>>>>"
								+ exeobj2.size());
						request.setAttribute("exeobj2", exeobj2);
						int passname=invitationForm.getPassname();
						System.out.println("inside selectionlist number"+passname);
						request.setAttribute("pass", passname);
						target = "displayfamily";
					 
				}
				
				
				
				if("displaygroups".equals(k))
				{
					Collection exeobj = displaygroupDAO.displaygroup(session,displaygroupBean, q);
					System.out.println("grouppppppppppppppp>>>>>>"
							+ exeobj.size());
					
					
						System.out.println("groups>>>>>>>>>>>>>>>>"
								+ exeobj.size());
						request.setAttribute("exeobj", exeobj);
						int passname=invitationForm.getPassname();
						System.out.println("inside selectionlist number"+passname);
						request.setAttribute("pass", passname);
						target = "displaygroups";
					 
				}
				
				if("displaygroupmembers".equals(k))
				{
					
					System.out.println("inside disp group members");
				int passid=invitationForm.getPassid();
				System.out.println("inside disp group members"+passid);
				
				Collection exeobj1 = displaygroupmembersDAO.displaygroupmembers(session,displaygroupmembersBean, passid);
				System.out.println("grouppppppppppppppp>>>>>>"
						+ exeobj1.size());
				
				
					System.out.println("groups>>>>>>>>>>>>>>>>"
							+ exeobj1.size());
					 d= exeobj1.size();
					//request.setAttribute("size", d);
					request.setAttribute("exeobj1", exeobj1);
					
					Collection exeobj = displaygroupDAO.displaygroup(session,displaygroupBean, q);
					System.out.println("grouppppppppppppppp>>>>>>"
							+ exeobj.size());
					
					
						System.out.println("groups>>>>>>>>>>>>>>>>"
								+ exeobj.size());
						request.setAttribute("exeobj", exeobj);
					target = "displaygroups";
					
				}
				
				
				
				
				if ("insert".equals(k)) 
				{
							
				
										System.out.println("inside insert");
										
										
										
										Serializable invitationid= invitationDAO.insert(session, invitationBean);
										int invitationidd=(Integer)invitationid;
										System.out.println("invitationnn iddd==="+invitationidd);
										
										if(invitationidd!='0')
										{
										reciveinvitationBean.setInvitationid(invitationidd);
										String status="ok";
										reciveinvitationBean.setStatus(status);
									//	int o;
									
										
										int s[]=invitationForm.getMemberlist();
										System.out.println("inside ssss"+s.length);
										
										for(int i=0;i<s.length;i++)
										{
											System.out.println("elementssss=====1111"+s[i]);
										}
										
										for(int i=0;i<s.length;i++)
										{
											System.out.println("elementssss=====2222"+s[i]);
											reciveinvitationBean.setMemberlist(s[i]);
											invitationDAO.insert1(session, reciveinvitationBean);
										}
										
										target="correct";
										}
										
										
						
				}	
				
				
				if("view".equals(k))
				{
					
				Collection invitation = invitationDAO.displayinvitation(session, invitationBean,q);
				request.setAttribute("invitation", invitation);
					
				target="display";	
					
				}
					
					
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}
}