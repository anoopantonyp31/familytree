package com.dory.invitation;

import java.util.Date;

public class InvitationBean {
	private int receivinvitationid;
	private String subject;
	private int passid;
	 private String data;
	 private Date senddate;
	 private int memberid;
	 private int invitationid;
	 private String status;
	 private String listset;
	 private String[] memberlist;
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubject() {
		return subject;
	}
	
	public void setSenddate(Date senddate) {
		this.senddate = senddate;
	}
	public Date getSenddate() {
		return senddate;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setInvitationid(int invitationid) {
		this.invitationid = invitationid;
	}
	public int getInvitationid() {
		return invitationid;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setReceivinvitationid(int receivinvitationid) {
		this.receivinvitationid = receivinvitationid;
	}
	public int getReceivinvitationid() {
		return receivinvitationid;
	}
	public void setPassid(int passid) {
		this.passid = passid;
	}
	public int getPassid() {
		return passid;
	}
	public void setListset(String listset) {
		this.listset = listset;
	}
	public String getListset() {
		return listset;
	}
	public void setMemberlist(String[] memberlist) {
		this.memberlist = memberlist;
	}
	public String[] getMemberlist() {
		return memberlist;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}
	
	

}
