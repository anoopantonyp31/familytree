package com.dory.invitation;

public class DisplaygroupBean {

	
	private int groupid;
	private String groupname;
	 private int groupowner;
	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}
	public int getGroupid() {
		return groupid;
	}
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupowner(int groupowner) {
		this.groupowner = groupowner;
	}
	public int getGroupowner() {
		return groupowner;
	}
}
