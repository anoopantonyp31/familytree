package com.dory.invitation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;



public class DisplaygroupDAOImpl {

	public Collection displaygroup(Session session, DisplaygroupBean displaygroupBean, int q) {

		Collection displaygroupcol = new ArrayList();
		try {
			List query = session.createQuery("from DisplaygroupBean ex where ex.groupowner='"+q+"' order by ex.groupid")
					.list();
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				displaygroupBean = (DisplaygroupBean) it.next();
				displaygroupcol.add(displaygroupBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return displaygroupcol;
	}
}
