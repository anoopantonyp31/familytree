package com.dory.invitation;

public class DisplayfamilyBean {

	private int familyid;
	private int familyadmin;
	private String familyname;
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}
	public void setFamilyadmin(int familyadmin) {
		this.familyadmin = familyadmin;
	}
	public int getFamilyadmin() {
		return familyadmin;
	}
	public void setFamilyname(String familyname) {
		this.familyname = familyname;
	}
	public String getFamilyname() {
		return familyname;
	}
	
}
