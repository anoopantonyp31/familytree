package com.dory.invitation;

public interface DisplaygroupDAO {

}
