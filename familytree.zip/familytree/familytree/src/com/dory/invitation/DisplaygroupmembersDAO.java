package com.dory.invitation;

public interface DisplaygroupmembersDAO {

}
