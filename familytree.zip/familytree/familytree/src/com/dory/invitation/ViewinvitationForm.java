package com.dory.invitation;

import java.util.Date;

import org.apache.struts.action.ActionForm;

public class ViewinvitationForm extends ActionForm
{

	private int invitationid;
	 private String subject;
	 private Date invitationdate;
	 private String data;
	 private int[] ch_invitation;

	public void setInvitationid(int invitationid) {
		this.invitationid = invitationid;
	}

	public int getInvitationid() {
		return invitationid;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getSubject() {
		return subject;
	}

	public void setInvitationdate(Date invitationdate) {
		this.invitationdate = invitationdate;
	}

	public Date getInvitationdate() {
		return invitationdate;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getData() {
		return data;
	}

	public void setCh_invitation(int[] ch_invitation) {
		this.ch_invitation = ch_invitation;
	}

	public int[] getCh_invitation() {
		return ch_invitation;
	}
}
