package com.dory.invitation;

public interface InvitationDAO {

}
