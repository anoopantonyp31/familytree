package com.dory.invitation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

public class DisplayfamilyDAOImpl {

	
	

	public Collection displayfamily(Session session, DisplayfamilyBean displayfamilyBean) {

		Collection displayfamilycol = new ArrayList();
		try {
			List query = session.createQuery("from DisplayfamilyBean ex  order by ex.familyid")
					.list();
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				displayfamilyBean = (DisplayfamilyBean) it.next();
				displayfamilycol.add(displayfamilyBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return displayfamilycol;
	}
	
	
}
