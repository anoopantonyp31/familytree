package com.dory.invitation;

public class ReciveinvitationBean {
	
	private int receivinvitationid;
	 private int invitationid;
	 private String status;
	 private int memberlist;
	public void setReceivinvitationid(int receivinvitationid) {
		this.receivinvitationid = receivinvitationid;
	}
	public int getReceivinvitationid() {
		return receivinvitationid;
	}
	public void setInvitationid(int invitationid) {
		this.invitationid = invitationid;
	}
	public int getInvitationid() {
		return invitationid;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setMemberlist(int memberlist) {
		this.memberlist = memberlist;
	}
	public int getMemberlist() {
		return memberlist;
	}
	
	
}
