package com.dory.invitation;

import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

public class ViewinvitationAction extends Action
{

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//String a1= request.getParameter("fromWhere");
					String action = request.getParameter("action");
					//String k1 = request.getParameter("action1");
				// Use the NameForm to get the request parameters
				ViewinvitationForm viewinvitationForm = (ViewinvitationForm) form;
                InvitationBean invitationBean = new InvitationBean();
		
				HttpSession httpsession = request.getSession();
		
				
				
				//invitationBean.setData(invitationForm
					//	.getData());
				int d;
				Calendar cal=Calendar.getInstance();
				Date dt=cal.getTime();
				
			//	invitationBean.setSenddate(dt);
				
				
				
				//invitationBean.setLandlineno(contactsForm.getLandlineno());
				// executiveBean.setExecutiveposid(executiveForm.getExecutiveposid());
				//String executive = aboutForm.getExecutivepos();
				//System.out.println("exe===========>" + executive);

				Session session = HibernateUtil.getSessionFactory()
						.openSession();
				System.out.println("session======111111=====>" + session);
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             //invitationBean.setMemberid(q);
				
				InvitationDAOImpl invitationDAO = new InvitationDAOImpl();
			
				
				if("view".equals(action))
				{
					
				Collection invitation = invitationDAO.displayinvitation(session, invitationBean,q);
				request.setAttribute("invitation", invitation);
					
				target="display";	
					
				}
				if("delete".equals(action))
				{
					
					int checklength[]=viewinvitationForm.getCh_invitation();
					System.out.println("a====>"+checklength);
					for(int i=0;i<checklength.length;i++)
					{
						System.out.println("IN THE LOOP+++++++++++++++++++");
						invitationBean.setInvitationid(checklength[i]);
						/* delete district name */	
					    System.out.println("CHECKBOXID======================================================="+checklength[i]);
					    invitationDAO.delete(session,invitationBean);
						
					}
					
					
				Collection invitation = invitationDAO.displayinvitation(session, invitationBean,q);
				request.setAttribute("invitation", invitation);
					
				target="display";	
					
				}
			}
			}
			catch(Exception e)
			{
				System.out.print("Ex"+e);
				
			}
			return (mapping.findForward(target));
		}			

}
