package com.dory.invitation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

public class DisplaygroupmembersDAOImpl {

	
	public Collection displaygroupmembers(Session session, DisplaygroupmembersBean displaygroupmembersBean, int passid) {

		Collection displaygroupmemcol = new ArrayList();
		try {
			List query = session.createQuery("select new DisplaygroupmembersBean(p.name,p.memberid) from DisplaygroupmembersBean ex join ex.profile p where ex.groupid='"+passid+"' ")
					.list();
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				displaygroupmembersBean = (DisplaygroupmembersBean) it.next();
				displaygroupmemcol.add(displaygroupmembersBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return displaygroupmemcol;
	}
}
