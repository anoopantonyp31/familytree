package com.dory.invitation;

import org.apache.struts.action.ActionForm;

public class InvitationForm extends ActionForm {
	private int passid;
	private int passname;
	private String subject;
	 private String data;
	 private String listset;
	 private int[] memberlist;
	 private String data1;
	 
	public String getData1() {
		return data1;
	}
	public void setData1(String data1) {
		this.data1 = data1;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubject() {
		return subject;
	}
	
	public void setPassid(int passid) {
		this.passid = passid;
	}
	public int getPassid() {
		return passid;
	}
	
	
	
	public void setListset(String listset) {
		this.listset = listset;
	}
	public String getListset() {
		return listset;
	}
	public void setPassname(int passname) {
		this.passname = passname;
	}
	public int getPassname() {
		return passname;
	}
	public void setMemberlist(int[] memberlist) {
		this.memberlist = memberlist;
	}
	public int[] getMemberlist() {
		return memberlist;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}
	
	
	
}
