package com.dory.invitation;
import java.util.Date;
public class ViewinvitationBean 
{
 private int invitationid;
 private String subject;
 private Date invitationdate;
 private String data;

public void setInvitationid(int invitationid) {
	this.invitationid = invitationid;
}

public int getInvitationid() {
	return invitationid;
}

public void setSubject(String subject) {
	this.subject = subject;
}

public String getSubject() {
	return subject;
}

public void setInvitationdate(Date invitationdate) {
	this.invitationdate = invitationdate;
}

public Date getInvitationdate() {
	return invitationdate;
}

public void setData(String data) {
	this.data = data;
}

public String getData() {
	return data;
}
	
}
