package com.dory.educational;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.house.CountrylistBean;
import com.dory.proffessional.ProffessionalBean;




public class EducationalDAOImpl implements EducationalDAO {

	public boolean insert(Session session, EducationalBean educationalBean) {
		session.beginTransaction();
		session.save(educationalBean);
		session.getTransaction().commit();
		return true;

	}
	public boolean update(Session session, EducationalBean educationalBean)
    {
	session.beginTransaction(); 
	session.update(educationalBean);
	session.getTransaction().commit();
	return true;
    }
public boolean delete(Session session,EducationalBean educationalBean)
	
	{		
	session.beginTransaction();     
	session.delete(educationalBean);
	session.getTransaction().commit();
	return true;
	}
	
	
	public Collection countrydisplay(Session session, CountrylistBean countrylistBean) {

		Collection countrycol = new ArrayList();
		try {
			List query = session.createQuery("from CountrylistBean ex order by ex.countryid")
					.list();
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				countrylistBean = (CountrylistBean) it.next();
				countrycol.add(countrylistBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return countrycol;
	}
	
	

	public Collection displayeducational(Session session,
			EducationalBean educationalBean,int q) {
		CountrylistBean countrylistBean= new CountrylistBean();
		Collection educationalcol = new ArrayList();
		try {
			List query = session.createQuery("from EducationalBean ex where ex.memberid='"+q+"'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) 
			{
				System.out.println("session======displayexecutivepos=====> ");	
				educationalBean = (EducationalBean) it.next();
				System.out.println("session======dcountrrrryiiiiiiiiidddddddddddd=====> "+educationalBean.getInstitutecountry());
				String s=educationalBean.getInstitutecountry();
				int d=Integer.parseInt(s);
				List query2 = session.createQuery("from CountrylistBean ex where ex.countryid='"+d+"'")
				.list();
		     System.out.println("====queryyyy=====> "+query2);
		     for (Iterator it2 = query2.iterator(); it2.hasNext();) 
		     {
			 System.out.println("session======displayexecutivepos=====> ");	
			 countrylistBean = (CountrylistBean) it2.next();
			 educationalBean.setInstitutecountry(countrylistBean.getName());
			 System.out.println("country "+educationalBean.getInstitutecountry());	
		     }
		     educationalcol.add(educationalBean);
		}
			
			} 
		
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return educationalcol;
	}
	public Collection edit(Session session, EducationalBean educationalBean,int b)
	{
		
		Collection education=new ArrayList();
		List query = session.createSQLQuery("select * from member_education ds where educationid="+b+"").addEntity("ds",EducationalBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
      {
			System.out.println("displaystandard====Iterator========");
			educationalBean = (EducationalBean) it.next();
			System.out.println("displayEducationid===="+educationalBean.getEducationid());			
			education.add(educationalBean);
		}
      return education;
	}	
	
}
