package com.dory.educational;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;


import com.dory.hibernate.HibernateUtil;
import com.dory.house.CountrylistBean;
import com.dory.house.HouseDAOImpl;
import com.dory.proffessional.ProffessionalBean;

public class EducationalAction extends Action  {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//used to get the action value
					String k = request.getParameter("action");
					
				EducationalForm educationalForm = (EducationalForm) form;
				EducationalBean educationalBean = new EducationalBean();
                HttpSession httpsession = request.getSession();
                
				//BeanUtils.copyProperties(educationalBean, educationalForm);
                educationalBean.setEducationaltype(educationalForm.getEducationaltype());
                educationalBean.setEndyear(educationalForm.getEndyear());
                educationalBean.setInstitutecountry(educationalForm.getInstitutecountry());
                
                educationalBean.setInstituteplace(educationalForm.getInstituteplace());
                educationalBean.setInstitutestate(educationalForm.getInstitutestate());
                
                
                educationalBean.setInstitutionname(educationalForm.getInstitutionname());
                educationalBean.setRemark(educationalForm.getRemark());
                educationalBean.setStartyear(educationalForm.getStartyear());
                
			//	aboutBean.setMyself(aboutForm.getMyself());
				
              //*********************visibility part***********************//
				//--------------------------------------
				int privateorprivate1=educationalForm.getPublicorprivate();
				
				int family=educationalForm.getFamily();
				int groups=educationalForm.getGroups();
				int community=educationalForm.getCommunity();
				
				
				
				String privateorprivate2 = String.valueOf(privateorprivate1);
						
				
				if("1".equals(privateorprivate2))
				{
					//String visibility=privateorprivate1+"0"+"0"+"0";
					String visibility="8";
					System.out.println("===========in public======="+visibility);
					educationalBean.setVisibility(visibility);
				}
				
				if("500".equals(privateorprivate2))
				{
				String family2 = String.valueOf(family);
				String groups2 = String.valueOf(groups);
				String community2 = String.valueOf(community);
				
				 
					if("0".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
					{
						//String visibility="0"+"0"+"0"+"0";
						String visibility="0";
						System.out.println("===========1111111======="+visibility);
						educationalBean.setVisibility(visibility);
					}
					
					else if("0".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
					{
						String visibility="1";
						System.out.println("===========222222======="+visibility);
						educationalBean.setVisibility(visibility);
					}
					
					else if("1".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
					{
						String visibility="2";
						System.out.println("===========3333333======="+visibility);
						educationalBean.setVisibility(visibility);
					}
					
					else if("1".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
					{
						String visibility="3";
						System.out.println("===========44444444======="+visibility);
						educationalBean.setVisibility(visibility);
					}
					
					
					else if("0".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
					{
						String visibility="4";
						System.out.println("===========666666666======="+visibility);
						educationalBean.setVisibility(visibility);
					}
					
					
					else if("0".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
					{
						String visibility="5";
						System.out.println("===========7777777======="+visibility);
						educationalBean.setVisibility(visibility);
					}
					
					
					else if("1".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
					{
						String visibility="6";
						System.out.println("===========8888888======="+visibility);
						educationalBean.setVisibility(visibility);
					}
					
					
					else if("1".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
					{
						String visibility="7";
						System.out.println("===========99999999======="+visibility);
						educationalBean.setVisibility(visibility);
					}
					
					
				}
				
				//*********************visibility part***********************//
				
				
				Session session = HibernateUtil.getSessionFactory()
						.openSession();
				System.out.println("session======111111=====>" + session);
				
				//to get the session from the login action
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             educationalBean.setMemberid(q);
	            
				
				EducationalDAOImpl educationalDAO = new EducationalDAOImpl();
				
				//if value of action=insert then enters below statement
				//function to insert the data from aboutme.jsp into about_member tables 
				if ("insert".equals(k)) 
				{
							
				
										System.out.println("inside insert");
						educationalDAO.insert(session, educationalBean);
						
						Collection education = educationalDAO.displayeducational(session,educationalBean,q);
						request.setAttribute("education", education);
						
						target="correct";
						
				}						
					
			
			
			
			else if("display".equals(k))
			{
				CountrylistBean countrylistBean = new CountrylistBean();
				HouseDAOImpl houseDAO = new HouseDAOImpl();
				Collection exeobj = educationalDAO.countrydisplay(session,countrylistBean);
				System.out.println("session======222222222222=====>"
						+ exeobj.size());
				
				{
					System.out.println("session======333333333=====>"
							+ exeobj.size());
					request.setAttribute("exeobj", exeobj);
					
					Collection education = educationalDAO.displayeducational(session,educationalBean,q);
					if(education.isEmpty())
					{
						request.setAttribute("desable", "desable");
						request.setAttribute("save", "save");
					}
					else
					{
					request.setAttribute("education", education);
					request.setAttribute("save", "save");
					}
					target = "educational";
				} 
					
								
			}
			else if("educationedit".equals(k))
			{
				System.out.println("bbbbbbbbbbbbbbbbbb");	
				int a[]=educationalForm.getEducationdet();
				CountrylistBean countrylistBean = new CountrylistBean();
				for(int i=0;i<a.length;i++)					
				   {
				    int b = a[i];
				    System.out.println("CHECKBOXID==============bbbbbbbbbbbbbbbbbb"+b);					    
				    Collection education = educationalDAO.edit(session,educationalBean,b);
					if(education.size()>0)
					{
						System.out.println("in district.size>0=====>"+education.size());
						
					    
					    for (Iterator iterator = education.iterator(); iterator.hasNext();) 
				    	    { 
					    	educationalBean = (EducationalBean) iterator.next();
				    		}
					    educationalForm.setEducationid(educationalBean.getEducationid());					    
					    educationalForm.setEducationaltype(educationalBean.getEducationaltype());
					    educationalForm.setInstitutionname(educationalBean.getInstitutionname());
					    educationalForm.setStartyear(educationalBean.getStartyear());
					    educationalForm.setEndyear(educationalBean.getEndyear());
					    educationalForm.setInstituteplace(educationalBean.getInstituteplace());
					    educationalForm.setInstitutestate(educationalBean.getInstitutestate());
					    educationalForm.setInstitutecountry(educationalBean.getInstitutecountry());
					    educationalForm.setRemark(educationalBean.getRemark());	
					    Collection exeobj = educationalDAO.countrydisplay(session,countrylistBean);
						request.setAttribute("exeobj", exeobj);
						request.setAttribute("add", "add");
				   }
					 
					
				      }			
				target="edit";					
				}
			else if("update".equals(k))
			{
						
				String s=request.getParameter("t");
				int id=Integer.parseInt(s);
				System.out.println("Exception id========="+id);
				educationalBean.setEducationid(id);
				System.out.println("id========="+educationalBean.getEducationid());
				educationalDAO.update(session,educationalBean);
			    target="update";
			}
			else if("delete".equals(k))
			{
				int c[]=educationalForm.getEducationdet();	
				for(int i=0;i<c.length;i++)
				{
					System.out.println("IN THE LOOP+++++++++++++++++++");
					educationalBean.setEducationid(c[i]);
				    System.out.println("CHECKBOXID================================"+c[i]);
				    educationalDAO.delete(session,educationalBean);
				    target="update";
				}}
			}
			
		}
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
			}
			
}
	

