package com.dory.educational;

import org.apache.struts.action.ActionForm;

public class EducationalForm extends ActionForm {

	
	 private int startyear;
	 private int endyear;
	 private int educationid;
	 private int educationdet[];
	 private String educationaltype;
	 private String institutionname;
	 private String instituteplace;
	 private String institutestate;
	 private String institutecountry;
	 private String remark;
	 
	 
	 private int publicorprivate;
	 private int community;
	 private int groups;
	 private int family;
	 
	public void setStartyear(int startyear) {
		this.startyear = startyear;
	}
	public int getStartyear() {
		return startyear;
	}
	public void setEndyear(int endyear) {
		this.endyear = endyear;
	}
	public int getEndyear() {
		return endyear;
	}
	public void setEducationid(int educationid) {
		this.educationid = educationid;
	}
	public int getEducationid() {
		return educationid;
	}
	public void setEducationaltype(String educationaltype) {
		this.educationaltype = educationaltype;
	}
	public String getEducationaltype() {
		return educationaltype;
	}
	public void setInstitutionname(String institutionname) {
		this.institutionname = institutionname;
	}
	public String getInstitutionname() {
		return institutionname;
	}
	public void setInstituteplace(String instituteplace) {
		this.instituteplace = instituteplace;
	}
	public String getInstituteplace() {
		return instituteplace;
	}
	public void setInstitutestate(String institutestate) {
		this.institutestate = institutestate;
	}
	public String getInstitutestate() {
		return institutestate;
	}
	public void setInstitutecountry(String institutecountry) {
		this.institutecountry = institutecountry;
	}
	public String getInstitutecountry() {
		return institutecountry;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	public void setCommunity(int community) {
		this.community = community;
	}
	public int getCommunity() {
		return community;
	}
	public void setGroups(int groups) {
		this.groups = groups;
	}
	public int getGroups() {
		return groups;
	}
	public void setFamily(int family) {
		this.family = family;
	}
	public int getFamily() {
		return family;
	}
	public void setEducationdet(int educationdet[]) {
		this.educationdet = educationdet;
	}
	public int[] getEducationdet() {
		return educationdet;
	}
}
