package com.dory.educational;

public interface EducationalDAO {

}
