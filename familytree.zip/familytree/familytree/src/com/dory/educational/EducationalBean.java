package com.dory.educational;

public class EducationalBean {

	 private int memberid;
	 private int startyear;
	 private int endyear;
	 private int educationid;
	 private String visibility;
	 private String educationaltype;
	 private String institutionname;
	 private String instituteplace;
	 private String institutestate;
	 private String institutecountry;
	 private String institutecountry1;
	 private String remark;
	public void setStartyear(int startyear) {
		this.startyear = startyear;
	}
	public int getStartyear() {
		return startyear;
	}
	public void setEndyear(int endyear) {
		this.endyear = endyear;
	}
	public int getEndyear() {
		return endyear;
	}
	public void setEducationid(int educationid) {
		this.educationid = educationid;
	}
	public int getEducationid() {
		return educationid;
	}
	public void setEducationaltype(String educationaltype) {
		this.educationaltype = educationaltype;
	}
	public String getEducationaltype() {
		return educationaltype;
	}
	public void setInstitutionname(String institutionname) {
		this.institutionname = institutionname;
	}
	public String getInstitutionname() {
		return institutionname;
	}
	public void setInstituteplace(String instituteplace) {
		this.instituteplace = instituteplace;
	}
	public String getInstituteplace() {
		return instituteplace;
	}
	public void setInstitutestate(String institutestate) {
		this.institutestate = institutestate;
	}
	public String getInstitutestate() {
		return institutestate;
	}
	public void setInstitutecountry(String institutecountry) {
		this.institutecountry = institutecountry;
	}
	public String getInstitutecountry() {
		return institutecountry;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public String getVisibility() {
		return visibility;
	}
	public void setInstitutecountry1(String institutecountry1) {
		this.institutecountry1 = institutecountry1;
	}
	public String getInstitutecountry1() {
		return institutecountry1;
	}
	
}
