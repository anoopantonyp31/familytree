package com.dory.familymanage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.dory.memberprofile.ProfileBean;
import com.dory.tree.FamilyBean;
import com.dory.tree.RelationsBean;

public class FamilymanageDAOImpl implements FamilymanageDAO 
{
	
	public Collection searchbyid(Session session,FamilymanageBean familymanageBean,int familyid)
	{   
		ProfileBean getmemberBean = new ProfileBean();
		Collection family = new ArrayList();
		try
		{
			List query = session.createQuery("from FamilymanageBean ex where ex.familyid like'%"+familyid+"%'")
			.list();
	System.out.println("====queryyyy=====> "+query);
	for (Iterator it = query.iterator(); it.hasNext();) {
		System.out.println("serching results============ ");		
		familymanageBean = (FamilymanageBean) it.next();
		System.out.println("family admiiiiiiinnnnnnresults============ "+familymanageBean.getFamilyadmin());
		List query1 = session.createSQLQuery("select * from member_profile ds where memberid='"+familymanageBean.getFamilyadmin()+"' ").addEntity("ds",ProfileBean.class).list();
		System.out.println("displaystandard====query========"+query);
		for (Iterator it1 = query1.iterator(); it1.hasNext();)
		{
			getmemberBean = (ProfileBean) it1.next();
			familymanageBean.setFamilyadmin1(getmemberBean.getName());
		}
		family.add(familymanageBean);
	}
			
		}
		catch (Exception e) 
		{
			System.out.println("Exception in familyID Searchhh======"+e);
		}
		return family;
	}

	public Collection searchbynumber(Session session,FamilymanageBean familymanageBean,String familynumber)
	{
		Collection family = new ArrayList();
		ProfileBean getmemberBean = new ProfileBean();
		try
		{
			List query = session.createQuery("from FamilymanageBean ex where ex.familynumber like'%"+familynumber+"%'")
			.list();
	System.out.println("====queryyyy=====> "+query);
	for (Iterator it = query.iterator(); it.hasNext();) {
		System.out.println("serching results============ ");	
		familymanageBean = (FamilymanageBean) it.next();
		List query1 = session.createSQLQuery("select * from member_profile ds where memberid='"+familymanageBean.getFamilyadmin()+"' ").addEntity("ds",ProfileBean.class).list();
		System.out.println("displaystandard====query========"+query);
		for (Iterator it1 = query1.iterator(); it1.hasNext();)
		{
			getmemberBean = (ProfileBean) it1.next();
			familymanageBean.setFamilyadmin1(getmemberBean.getName());
		}
		family.add(familymanageBean);
	}
			
		}
		catch (Exception e) 
		{
			System.out.println("Exception in familyID Searchhh======"+e);
		}
		return family;
	}
	
	public Collection searchbyname(Session session,FamilymanageBean familymanageBean,String familyname)
	{
		ProfileBean getmemberBean = new ProfileBean();
		Collection family = new ArrayList();
		try
		{
			List query = session.createQuery("from FamilymanageBean ex where ex.familyname like'%"+familyname+"%'")
			.list();
	System.out.println("====queryyyy=====> "+query);
	for (Iterator it = query.iterator(); it.hasNext();) {
		System.out.println("serching results============ ");	
		familymanageBean = (FamilymanageBean) it.next();
		List query1 = session.createSQLQuery("select * from member_profile ds where memberid='"+familymanageBean.getFamilyadmin()+"' ").addEntity("ds",ProfileBean.class).list();
		System.out.println("displaystandard====query========"+query);
		for (Iterator it1 = query1.iterator(); it1.hasNext();)
		{
			getmemberBean = (ProfileBean) it1.next();
			familymanageBean.setFamilyadmin1(getmemberBean.getName());
		}
		family.add(familymanageBean);
	}
			
		}
		catch (Exception e) 
		{
			System.out.println("Exception in familyID Searchhh======"+e);
		}
		return family;
	}
	public Collection viewmembers(Session session,int fid,int memid){
		
		RelationsBean relationbean = new RelationsBean();
		FamilyBean familyBean = new FamilyBean();
		Collection col = new ArrayList();
			try
			{
				/**/
					
							
				List query1 = session.createQuery("select new RelationsBean(pr.name,pr.sex,pr.memberid,re.spouseid,pr.mothername) from RelationsBean re " +
						                          "join re.profile pr " +
						                          "join re.family fa " +
						                          "where (pr.basefamilyid='"+fid+"' or fa.familyid='"+fid+"')").list();
	     		System.out.println("ProfileBean====retrive query========"+query1);

			for (Iterator it1 = query1.iterator(); it1.hasNext();) {
				
				System.out.println("Login====Iterator========");			
				relationbean = (RelationsBean) it1.next();			
				System.out.println("RelationBean====name========"+relationbean.getMembername());
				System.out.println("RelationBean====relation========"+relationbean.getSex());
				System.out.println("RelationBean======member id========"+memid);
				
				if("m".equals(relationbean.getSex())){
					if(memid==relationbean.getMemberid()){
						System.out.println("Head of the family: "+relationbean.getMembername());
						relationbean.setRelation("Head");
					}
					else if(memid==relationbean.getSpouseid()){
						System.out.println("Inside husbandddddddddddddddddd");
						relationbean.setRelation("Husband");
					}
					else{
						System.out.println("Inside sonnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
						relationbean.setRelation("Son");
					}
				}
				
				if("f".equals(relationbean.getSex())){
					if(memid==relationbean.getMemberid()){
						System.out.println("Head of the family: "+relationbean.getMembername());
						relationbean.setRelation("Head");
					}
					else if(memid==relationbean.getSpouseid()){
						System.out.println("Inside wifeeeeeeeeeeeeeee");
						relationbean.setRelation("Wife");
					}
					else{
						System.out.println("Inside daughterrrrrrrrrrrrrrrrrrrr");
					    relationbean.setRelation("Daughter");
				    }
				}
				col.add(relationbean);
				}
			
			}catch(HibernateException he){
				System.out.println("errorrrrrrrr"+he);
			}
			return col;
		}
	
	
	public int findhead(Session session,int fid){
		
		RelationsBean relationbean = new RelationsBean();
		int memid = 0;
		System.out.println("Value====fid========"+fid);
		try{
		List query = session.createQuery("select new RelationsBean(pr.name,pr.memberid) from RelationsBean re " +
	                                     "join re.profile pr " +
	                                     "join re.family fam " +
	                                     "where fam.familyid='"+fid+"' and pr.basefamilyid!='"+fid+"'").list();
	    System.out.println("FamilyBean====retrive query=====1111111111==="+query.size());	
	    if(query.size()>0){
	    for (Iterator it = query.iterator(); it.hasNext();) {

	    System.out.println("Login====Iterator========");			
	    relationbean = (RelationsBean) it.next();			
	    System.out.println("FamilyBean====member id========"+relationbean.getMemberid());
	    System.out.println("FamilyBean====member name========"+relationbean.getMembername());
	    memid = relationbean.getMemberid();
	    }
	    }
	    else{
	    	System.out.println("Inside else====of head finderrrrrrr====");
	    	List query1 = session.createQuery("select new RelationsBean(pr.name,pr.memberid) from RelationsBean re " +
	                "join re.profile pr " +
	                "join re.family fam " +
	                "where fam.familyid='"+fid+"' and re.fatherid='0' and re.motherid='0' and re.spouseid='0'").list();
	        System.out.println("FamilyBean====retrive query=====222222222222==="+query1.size());	
	        for (Iterator it = query1.iterator(); it.hasNext();) {

	        System.out.println("Login====Iterator========");			
	        relationbean = (RelationsBean) it.next();			
	        System.out.println("FamilyBean====member id========"+relationbean.getMemberid()); 
	        System.out.println("FamilyBean====member name========"+relationbean.getMembername());
	        memid = relationbean.getMemberid();
	        }
		}
	    }
		catch(Exception e){
			System.out.println("Top head found: "+e);
		}
		return memid;
	}
	
	public boolean updateadmin(Session session,int familyid,int memberid)
	{
		FamilyBean addfamilyBean = new FamilyBean();
		List query1 = session.createSQLQuery("select * from family_detail ds where familyid='"+familyid+"' ").addEntity("ds",FamilyBean.class).list();
		System.out.println("displaystandard====query========"+query1);
		for (Iterator it1 = query1.iterator(); it1.hasNext();)
		{
			addfamilyBean = (FamilyBean) it1.next();
			addfamilyBean.setFamilyadmin(memberid);
			session.beginTransaction();
			session.update(addfamilyBean);
			session.getTransaction().commit();

		}
	
		return true;
	}
	
}
