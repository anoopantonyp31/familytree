package com.dory.familymanage;

import java.util.Collection;

import org.hibernate.Session;



public interface FamilymanageDAO 
{

	public Collection searchbyid(Session session,FamilymanageBean familymanageBean,int familyid);
	public Collection searchbynumber(Session session,FamilymanageBean familymanageBean,String familynumber);
	public Collection searchbyname(Session session,FamilymanageBean familymanageBean,String familyname);
	public int findhead(Session session,int fid);
	public Collection viewmembers(Session session,int fid,int memid);
	public boolean updateadmin(Session session,int familyid,int memberid);
}
