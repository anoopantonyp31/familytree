package com.dory.familymanage;

import org.apache.struts.action.ActionForm;

public class FamilymanageForm extends ActionForm
{
	private int familyid;
	private String familyadmin1;
	private String familynumber;
	private String familyname;
	private int criteria;
	private String select;
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}
	public void setFamilyadmin1(String familyadmin1) {
		this.familyadmin1 = familyadmin1;
	}
	public String getFamilyadmin1() {
		return familyadmin1;
	}
	public void setFamilynumber(String familynumber) {
		this.familynumber = familynumber;
	}
	public String getFamilynumber() {
		return familynumber;
	}
	public void setFamilyname(String familyname) {
		this.familyname = familyname;
	}
	public String getFamilyname() {
		return familyname;
	}
	public void setCriteria(int criteria) {
		this.criteria = criteria;
	}
	public int getCriteria() {
		return criteria;
	}
	public void setSelect(String select) {
		this.select = select;
	}
	public String getSelect() {
		return select;
	}

}
