package com.dory.familymanage;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

public class AdminviewfamilyAction extends Action
{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
				
					//used to get the action value
					String action = request.getParameter("action");
					FamilymembersForm familymembersForm = (FamilymembersForm) form;
				
					String famid11=request.getParameter("familyid");
					System.out.println("STTTTTTTTTTTTTrrrrr======"+famid11);
					int familyid = Integer.parseInt(famid11);
					   HttpSession httpsession = request.getSession();
		                Session session = HibernateUtil.getSessionFactory()
						.openSession();
		                int memberid = familymembersForm.getMemberid();
		                
		                FamilymanageDAOImpl familymanageDAOImpl = new FamilymanageDAOImpl();
					if ("view".equals(action)) 
						
					{
						
						
						int head = familymanageDAOImpl.findhead(session,familyid);
						Collection members = familymanageDAOImpl.viewmembers(session, familyid,head);
						request.setAttribute("members", members);
						target="members";
						
					}
					
                 if ("insert".equals(action)) 
						
					{
                	 System.out.println("STTinsertttttttttttttttt");
                	 System.out.println("STTmemememmbererrererereridddddddddddd======="+memberid);
                	 familymanageDAOImpl.updateadmin(session,familyid,memberid);
					 target="admin";
						
					}
			}
		}
		catch (Exception e) 
		{
			System.out.println("Exceppptionnnnn==="+e);
		}
		return (mapping.findForward(target));
	}
	
}
