package com.dory.familymanage;

import org.apache.struts.action.ActionForm;

public class FamilymembersForm extends ActionForm
{

	private int memberid;
	private int familyid;
	private String partnername;

	
	
	//PARTNER HOUSE DETAILS


	
	

	public void setPartnername(String partnername) {
		this.partnername = partnername;
	}
	public String getPartnername() {
		return partnername;
	}

	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}

	
}
