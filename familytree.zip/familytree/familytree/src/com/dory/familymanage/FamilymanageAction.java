package com.dory.familymanage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;


public class FamilymanageAction extends Action
{

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//used to get the action value
					String action = request.getParameter("action");
					
				FamilymanageForm familymanageForm = (FamilymanageForm) form;
				FamilymanageBean familymanageBean = new FamilymanageBean();
                HttpSession httpsession = request.getSession();
                Session session = HibernateUtil.getSessionFactory()
				.openSession();
		       System.out.println("session======111111=====>" + session);

				System.out.println("inside action ");

				
				FamilymanageDAOImpl familymanageDAOImpl = new FamilymanageDAOImpl();
				
				//if value of action=searchfamily then enters below statement
				
				if ("familysearch".equals(action)) 
				{
					//Criteria for search
					int select=familymanageForm.getCriteria();
					System.out.println("================inside search============");
					Collection family = new ArrayList();
				  if(select==0)
				  {
					String familid=familymanageForm.getSelect();
					int familyid = Integer.parseInt(familid);
				    family = familymanageDAOImpl.searchbyid(session,familymanageBean,familyid);
				  }
				  else if(select==1)	
				  {
					  String familnumber=familymanageForm.getSelect();  
					  family = familymanageDAOImpl.searchbynumber(session,familymanageBean,familnumber);
				  }
				  else if(select==2)	
				  {
					  String familname=familymanageForm.getSelect();  
					  family = familymanageDAOImpl.searchbyname(session,familymanageBean,familname);
				  }
						
						if (family.size() > 0) 
						{
							System.out.println("session======333333333=====>"
									+ family.size());
							request.setAttribute("family", family);
							target = "success";
						} 
						
					
						else if (family.size()<= 0) 
						{
							String not="notpresent";
							request.setAttribute("notpresent", not);
							target = "success";
						}
						
				}	
				
				
			
				
				
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}
	
}
