package com.dory.tree;

public class ChecksexBean 
{

	private int memberid;
	private String sex;
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getSex() {
		return sex;
	}
	
}
