package com.dory.tree;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import com.dory.house.HouseBean;
import com.dory.login.LoginBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalBean;

import com.dory.addparents.MembersearchBean;


public class TreeDAOImpl implements TreeDAO{

	
	
public boolean relationinsert(Session session, RelationsBean relationBean) {
	session.beginTransaction();
	session.save(relationBean);
	session.getTransaction().commit();
	return true;

	}


public boolean update(Session session, Relation2Bean relationBean) {
	session.beginTransaction();
	session.update(relationBean);
	session.getTransaction().commit();
	return true;

	}


public Serializable insertfamily(Session session, FamilyBean familyBean) 

{
    Serializable id;
	session.beginTransaction();
	id=session.save(familyBean);
	System.out.println("terminator111111>>>>>>"+id);
	session.getTransaction().commit();
	return id;

}

public ProfileBean profile(Session session, int memid) 

{
    ProfileBean profileBean = new ProfileBean();
	List q = session.createQuery("from ProfileBean pr where pr.memberid='"+memid+"'").list();
	for (Iterator it = q.iterator(); it.hasNext();) {

	    System.out.println("Login====Iterator========");			
	    profileBean = (ProfileBean) it.next();		
	}
	return profileBean;

}

public String getfather(Session session, int fathid) 

{
    ProfileBean profileBean = new ProfileBean();
    String father="";
	List q = session.createQuery("from ProfileBean pr where pr.memberid='"+fathid+"'").list();
	for (Iterator it = q.iterator(); it.hasNext();) {

	    System.out.println("Login====Iterator========");			
	    profileBean = (ProfileBean) it.next();	
	    father=profileBean.getName();
	}
	return father;

}

public String getmother(Session session, int momid) 

{
    ProfileBean profileBean = new ProfileBean();
    String mother="";
	List q = session.createQuery("from ProfileBean pr where pr.memberid='"+momid+"'").list();
	for (Iterator it = q.iterator(); it.hasNext();) {

	    System.out.println("Login====Iterator========");			
	    profileBean = (ProfileBean) it.next();	
	    mother=profileBean.getName();
	}
	return mother;

}

public PersonalBean personaldet(Session session, int spoid) 

{
	PersonalBean personalBean = new PersonalBean();
	System.out.println("foooooooooeeeeeeeeeeeee"+spoid);
	List q = session.createQuery("from PersonalBean pr where pr.memberid='"+spoid+"'").list();
	for (Iterator it = q.iterator(); it.hasNext();) {

	    System.out.println("Login====Iterator========");			
	    personalBean = (PersonalBean) it.next();
	    System.out.println("PersonalBean====marital status========"+personalBean.getMaritalstatus());
	}
	return personalBean;

}

public LoginBean logcheck(Session session, int memid) 

{
	LoginBean loginBean = new LoginBean();
	List q = session.createQuery("from LoginBean pr where pr.memberid='"+memid+"'").list();
	for (Iterator it = q.iterator(); it.hasNext();) {

	    System.out.println("Login====Iterator========");			
	    loginBean = (LoginBean) it.next();		
	}
	return loginBean;

}
	
public int findhead(Session session,int fid){
	
	RelationsBean relationbean = new RelationsBean();
	int memid = 0;
	System.out.println("FamilyBean====member id========"+fid);
	try{
	List query = session.createQuery("select new RelationsBean(pr.name,pr.memberid) from RelationsBean re " +
                                     "join re.profile pr " +
                                     "join re.family fam " +
                                     "where fam.familyid='"+fid+"' and pr.basefamilyid!='"+fid+"'").list();
    System.out.println("FamilyBean====retrive query=====1111111111==="+query.size());	
    if(query.size()>0){
    for (Iterator it = query.iterator(); it.hasNext();) {

    System.out.println("Login====Iterator========");			
    relationbean = (RelationsBean) it.next();			
    System.out.println("FamilyBean====member id========"+relationbean.getMemberid());
    System.out.println("FamilyBean====member name========"+relationbean.getMembername());
    memid = relationbean.getMemberid();
    }
    }
    else{
    	System.out.println("Inside else====of head finderrrrrrr====");
    	List query1 = session.createQuery("select new RelationsBean(pr.name,pr.memberid) from RelationsBean re " +
                "join re.profile pr " +
                "join re.family fam " +
                "where fam.familyid='"+fid+"' and re.fatherid='0' and re.motherid='0' and re.spouseid='0' and re.relationshipid='0'").list();
        System.out.println("FamilyBean====retrive query=====222222222222==="+query1.size());	
        for (Iterator it = query1.iterator(); it.hasNext();) {

        System.out.println("Login====Iterator========");			
        relationbean = (RelationsBean) it.next();			
        System.out.println("FamilyBean====member id========"+relationbean.getMemberid()); 
        System.out.println("FamilyBean====member name========"+relationbean.getMembername());
        memid = relationbean.getMemberid();
        }
	}
    }
	catch(Exception e){
		System.out.println("Top head found: "+e);
	}
	return memid;
}

public Collection viewmembers(Session session,int fid,int memid){
		
	RelationsBean relationbean = new RelationsBean();
	RelationdetailBean relationdetBean = new RelationdetailBean();
	FamilyBean familyBean = new FamilyBean();
	Collection col = new ArrayList();
		try
		{
			/**/
				
						
			List query1 = session.createQuery("select new RelationsBean(pr.name,pr.sex,pr.memberid,pr.mothername,re.spouseid,re.relationshipid) from RelationsBean re " +
					                          "join re.profile pr " +
					                          "join re.family fa " +
					                          "where (pr.basefamilyid='"+fid+"' or fa.familyid='"+fid+"')").list();
     		System.out.println("ProfileBean====retrive query========"+query1);

		for (Iterator it1 = query1.iterator(); it1.hasNext();) {
			
			System.out.println("Login====Iterator========");			
			relationbean = (RelationsBean) it1.next();			
			System.out.println("RelationBean====name========"+relationbean.getMembername());
			System.out.println("RelationBean====relation========"+relationbean.getSex());
			System.out.println("RelationBean======member id========"+memid);
			System.out.println("Inside other relation shpiddddddddd"+relationbean.getRelationshipid());
			/*if("m".equals(relationbean.getSex())){
				if(memid==relationbean.getMemberid()){
					System.out.println("Head of the family: "+relationbean.getMembername());
					relationbean.setRelation("Head");
				}
				else if(memid==relationbean.getSpouseid()){
					System.out.println("Inside husbandddddddddddddddddd");
					relationbean.setRelation("Husband");
				}
				else{
					System.out.println("Inside sonnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
					relationbean.setRelation("Son");
				}
			}
			
			if("f".equals(relationbean.getSex())){
				if(memid==relationbean.getMemberid()){
					System.out.println("Head of the family: "+relationbean.getMembername());
					relationbean.setRelation("Head");
				}
				else if(memid==relationbean.getSpouseid()){
					System.out.println("Inside wifeeeeeeeeeeeeeee");
					relationbean.setRelation("Wife");
				}
				else{
					System.out.println("Inside daughterrrrrrrrrrrrrrrrrrrr");
				    relationbean.setRelation("Daughter");
			    }
			}
			col.add(relationbean);
			}*/
			if("m".equals(relationbean.getSex())){
				
				if(memid==relationbean.getMemberid()){
					System.out.println("Head of the family: "+relationbean.getMembername());
					relationbean.setRelation("Head");
				}
				else if(memid==relationbean.getSpouseid()){
					System.out.println("Inside husbandddddddddddddddddd");
					relationbean.setRelation("Husband");
				}
				else if(relationbean.getRelationshipid()>0){
					System.out.println("Inside other relationnnnnnnnn"+relationbean.getRelationshipid());
					Query query = session.createQuery("from RelationdetailBean rb where rb.relationshipid='"+relationbean.getRelationshipid()+"'");
					
					relationdetBean = (RelationdetailBean)query.uniqueResult();
					System.out.println("Relationnnnnnnnn>>>>>>>>....."+relationdetBean.getRelationship());
					relationbean.setRelation(relationdetBean.getRelationship());
				}
				else{
					System.out.println("Inside sonnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
					relationbean.setRelation("Son");
				}
			}
			
			if("f".equals(relationbean.getSex())){
				if(memid==relationbean.getMemberid()){
					System.out.println("Head of the family: "+relationbean.getMembername());
					relationbean.setRelation("Head");
				}
				else if(memid==relationbean.getSpouseid()){
					System.out.println("Inside wifeeeeeeeeeeeeeee");
					relationbean.setRelation("Wife");
				}
				else if(relationbean.getRelationshipid()>0){
					System.out.println("Inside other relationnnnnnnnn"+relationbean.getRelationshipid());
					Query query = session.createQuery("from RelationdetailBean rb where rb.relationshipid='"+relationbean.getRelationshipid()+"'");
					relationdetBean = (RelationdetailBean)query.uniqueResult();
					System.out.println("Relationnnnnnnnn>>>>>>>>....."+relationdetBean.getRelationship());
					relationbean.setRelation(relationdetBean.getRelationship());
				}
				else{
					System.out.println("Inside daughterrrrrrrrrrrrrrrrrrrr");
				    relationbean.setRelation("Daughter");
			    }
			}
			col.add(relationbean);
			}
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return col;
	}


public Collection retrievespouse(Session session,int memid){
	
	RelationsBean relationbean = new RelationsBean();
	Collection spo = new ArrayList();
		try
		{
			List query = session.createQuery("select new RelationsBean(pr.name,pr.memberid) from RelationsBean re " +
					                         "join re.profile pr " +
					                         "where re.spouseid='"+memid+"'").list();
     		System.out.println("ProfileBean====retrive query========"+query);

		for (Iterator it = query.iterator(); it.hasNext();) {
			
			System.out.println("Login====Iterator========");			
			relationbean = (RelationsBean) it.next();			
			System.out.println("RelationBean====spouse name========"+relationbean.getMembername());
			spo.add(relationbean);
			
		}
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return spo;
	}

public FamilyBean retrievefamid(Session session,int famid){
	
	FamilyBean familybean = new FamilyBean();
	Collection spo = new ArrayList();
		try
		{
			List query = session.createQuery("from FamilyBean fa where fa.familyid='"+famid+"'").list();
     		System.out.println("FamilyBean====retrive query========"+query);

		for (Iterator it = query.iterator(); it.hasNext();) {
			
			System.out.println("Login====Iterator========");			
			familybean = (FamilyBean) it.next();			
			System.out.println("FamilyBean====family id========"+familybean.getFamilyid());
						
		}
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return familybean;
	}

public Collection retrievesiblings(Session session,int memid,int famid){
	
	RelationsBean relationbean = new RelationsBean();
	Collection spo = new ArrayList();
	int idd = 0;
		try
		{
			List query = session.createQuery("select new RelationsBean(pr.name,pr.memberid) from RelationsBean re " +
                    "join re.profile pr " +
                    "where pr.memberid='"+memid+"'").list();
            System.out.println("ProfileBean====retrive query========"+query);

            for (Iterator it = query.iterator(); it.hasNext();) {

            System.out.println("Login====Iterator========");			
            relationbean = (RelationsBean) it.next();			
            System.out.println("RelationBean====spouse name========"+relationbean.getMembername());
            idd=relationbean.getMemberid();
            spo.add(relationbean);

            }
					
			
			
			List query1 = session.createQuery("select new RelationsBean(pr.name,pr.memberid) from RelationsBean re " +
					                          "join re.profile pr " +
					                          "where pr.basefamilyid='"+famid+"'").list();
     		System.out.println("ProfileBean====retrive query========"+query1);

		for (Iterator it1 = query1.iterator(); it1.hasNext();) {
			
			System.out.println("Login====Iterator========");			
			relationbean = (RelationsBean) it1.next();			
			System.out.println("RelationBean====spouse name========"+relationbean.getMembername());
			if(idd==relationbean.getMemberid()){
				System.out.println("SUPER  ADMINNNNNNNN========"+relationbean.getMembername());
			}
			else{
				spo.add(relationbean);
			}
			
		}
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return spo;
	}

public RelationdetailBean relationship(Session session,String sex,int checkid){
	
	RelationdetailBean reldetailbean = new RelationdetailBean();
	Collection spo = new ArrayList();
	String rel=null;
	if(checkid==0){
		if("m".equals(sex)){
			rel="son";
		}
		else{
			rel="daughter";
		}
	}
	else{
		if("m".equals(sex)){
			rel="husband";
		}
		else{
			rel="wife";
		}
	}
	
		try
		{
			List query = session.createQuery("from RelationdetailBean re where re.relationship='"+rel+"'").list();
     		System.out.println("RelationdetailBean====retrive query========"+query);

		for (Iterator it = query.iterator(); it.hasNext();) {
			
			System.out.println("Login====Iterator========");			
			reldetailbean = (RelationdetailBean) it.next();			
			System.out.println("RelationdetailBean====relationship id========"+reldetailbean.getRelationshipid());
						
		}
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return reldetailbean;
	}


public int houseid(Session session,int memid){
	
	ProfileBean profileBean = new ProfileBean();
	int id=0;
	System.out.println("Inside houseid IMPL......val of memid: "+memid);
		
	try
		{
			List query = session.createQuery("from ProfileBean pr where pr.memberid='"+memid+"'").list();
     		System.out.println("FamilyBean====retrive query========"+query);

		for (Iterator it = query.iterator(); it.hasNext();) {
			
			System.out.println("Login====Iterator========");			
			profileBean = (ProfileBean) it.next();			
			System.out.println("FamilyBean====house id========"+profileBean.getHouseid());
			id = profileBean.getHouseid();			
		}
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return id;
	}

public FamilyBean familyid(Session session,int uid){
	  
	  int fid = 0;
	  RelationsBean relationbean = new RelationsBean();
	  FamilyBean familyBean = new FamilyBean();
	  try
	  {
	   System.out.println("Login====uid========"+uid);
	      
	   List query = session.createQuery("select new RelationsBean(fa.familyid) from RelationsBean re " +
	                              "join re.profile pr " +
	                              "join re.family fa " +
	                              "where pr.memberid='"+uid+"'").list();
	       System.out.println("Loginpage====query========"+query);

	  for (Iterator it = query.iterator(); it.hasNext();) {
	   System.out.println("Login====Iterator========");
	   relationbean = (RelationsBean) it.next();
	   System.out.println("Relationbean====familyid========"+relationbean.getFamilyid());
	   fid=relationbean.getFamilyid();
	   
	   List query1 = session.createQuery("from FamilyBean fa where fa.familyid='"+fid+"'").list();
	   
	   for (Iterator it1 = query1.iterator(); it1.hasNext();) {
			System.out.println("Login====Iterator========");
			
			familyBean = (FamilyBean) it1.next();
			System.out.println("Tree====familybean========"+familyBean.getFamilyname());
	   }
	  }
	  
	  }catch(HibernateException he){
	   System.out.println("errorrrrrrrr"+he);
	  }
	  return familyBean;
	 }

public int countwife(Session session,int memid){
	
	RelationsBean relationbean = new RelationsBean();
	int count=0;
	Collection spo = new ArrayList();
		try
		{
			Query query = session.createQuery("select count(*) from RelationsBean re " +
					                         "where re.spouseid='"+memid+"'");
     		System.out.println("ProfileBean====retrive query========"+query);
     		count=(Integer)query.uniqueResult();
			System.out.println("RelationBean====count========"+count);
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return count;
	}

public Relation2Bean retrievemember(Session session,int spoid){
	
	Relation2Bean relation2Bean = new Relation2Bean();
	System.out.println("Relation2Bean====inside retrievememberrrrrrrrrrrrrrr========");
			
	try
		{
			List query = session.createQuery("from Relation2Bean re where re.memberid='"+spoid+"'").list();
     		System.out.println("Relation2Bean====retrive query========"+query);

		for (Iterator it = query.iterator(); it.hasNext();) {
			
			System.out.println("Login====Iterator========");			
			relation2Bean = (Relation2Bean) it.next();			
			System.out.println("Relation2Bean====family id========"+relation2Bean.getFamilyid());
			System.out.println("Relation2Bean====family id========"+relation2Bean.getFamilyid());
			System.out.println("Relation2Bean====spouse id========"+relation2Bean.getSpouseid());
		}
		List query1 = session.createQuery("from Relation2Bean re where re.memberid='"+relation2Bean.getSpouseid()+"'").list();
 		System.out.println("Relation2Bean====retrive query111111111========"+query1);
       for (Iterator it1 = query1.iterator(); it1.hasNext();) {
			
			System.out.println("Login====Iterator========");			
			relation2Bean = (Relation2Bean) it1.next();			
			System.out.println("Relation2Bean====family id========"+relation2Bean.getFamilyid());
			System.out.println("Relation2Bean====family id========"+relation2Bean.getFamilyid());
			System.out.println("Relation2Bean====spouse id========"+relation2Bean.getSpouseid());
		}
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return relation2Bean;
	}

//johnson
public Collection displaymember(Session session, LoginBean loginbean,int q)
{
	
	Collection member=new ArrayList();
	List query = session.createSQLQuery("select * from member_login ds where memberid="+q+"").addEntity("ds",LoginBean.class).list();
	
  for (Iterator it = query.iterator(); it.hasNext();) 
  {
		System.out.println("displaystandard====Iterator========");
		loginbean = (LoginBean) it.next();
		member.add(loginbean);
	}
  return member;
}

//johnson
public Collection displaymember1(Session session, FamilyBean addfamilyBean,int q)
{
	
	Collection member1=new ArrayList();
	List query = session.createSQLQuery("select * from family_detail ps where familyadmin="+q+" and familyid='"+addfamilyBean.getFamilyid()+"'").addEntity("ps",FamilyBean.class).list();
	
  for (Iterator it = query.iterator(); it.hasNext();) 
  {
		System.out.println("displaystandard====2wwwwwwwww========");
		addfamilyBean = (FamilyBean) it.next();
		member1.add(addfamilyBean);
	}
  return member1;
}



//upesh**************************************************************
public Collection displayfamily(Session session,int q,int familyid)
{
	FamilyBean addfamilyBean = new FamilyBean();
	Collection admin=new ArrayList();
	List query = session.createSQLQuery("select * from family_detail ps where familyadmin="+q+" and familyid!='"+familyid+"'").addEntity("ps",FamilyBean.class).list();
	  for (Iterator it = query.iterator(); it.hasNext();) 
	  {
			System.out.println("displaystandard====2wwwwwwwww========");
			addfamilyBean = (FamilyBean) it.next();
			admin.add(addfamilyBean);
		}
	  return admin;
	
}


public FamilyBean displayfamily1(Session session,FamilyBean addfamilyBean,int memid)
{
	Relation2Bean parentrelationBean = new Relation2Bean();
	Collection familyname=new ArrayList();
	List query = session.createSQLQuery("select * from member_relations ps where memberid='"+memid+"' ").addEntity("ps",Relation2Bean.class).list();
	for (Iterator it = query.iterator(); it.hasNext();) 
	{
		parentrelationBean = (Relation2Bean) it.next();
		int familyid = parentrelationBean.getFamilyid();
		List query1 = session.createSQLQuery("select * from family_detail ps where familyid="+familyid+" ").addEntity("ps",FamilyBean.class).list();
		  for (Iterator it1 = query1.iterator(); it1.hasNext();) 
		  {
				System.out.println("displaystandard====2wwwwwwwww========");
				addfamilyBean = (FamilyBean) it1.next();
				
			}
		 
	}
	
	
	 return addfamilyBean;
	
}


public FamilyBean displayfamilynameadmin(Session session,FamilyBean addfamilyBean,int familyid)
{
	
	Collection familyname=new ArrayList();
	List query1 = session.createSQLQuery("select * from family_detail ps where familyid="+familyid+" ").addEntity("ps",FamilyBean.class).list();
	  for (Iterator it1 = query1.iterator(); it1.hasNext();) 
	  {
			System.out.println("displaystandard====2wwwwwwwww========");
			addfamilyBean = (FamilyBean) it1.next();
			
		}
	
	  return addfamilyBean;
}


public Collection retrieveadminsiblings(Session session,int famlyid)
{
	Collection siblings=new ArrayList();
	RelationsBean relationbean = new RelationsBean();
	Collection spo = new ArrayList();
	Relation2Bean parentrelationBean = new Relation2Bean();
	MembersearchBean membersearchBean = new MembersearchBean();
	try
	{
		List query1 = session.createSQLQuery("select * from member_relations ps where familyid="+famlyid+" ").addEntity("ps",Relation2Bean.class).list();
		  for (Iterator it1 = query1.iterator(); it1.hasNext();) 
		  {
				System.out.println("displaystandard====2wwwwwwwww========");
				parentrelationBean = (Relation2Bean) it1.next();
				
				List query2 = session.createSQLQuery("select * from member_profile ps where memberid="+parentrelationBean.getMemberid()+" ").addEntity("ps",MembersearchBean.class).list();
				  for (Iterator it2 = query2.iterator(); it2.hasNext();) 
				  {
						System.out.println("displaystandard====2wwwwwwwww========");
						membersearchBean = (MembersearchBean) it2.next();
						spo.add(membersearchBean);
						
				  }
				  
		  }
		
		
		

		  /*List query1 = session.createQuery("select new RelationsBean(pr.name,pr.memberid) from RelationsBean re " +
				                          "join re.profile pr " +
				                          "where pr.familyid='"+famlyid+"'").list();
 		System.out.println("ProfileBean====retrive query========"+query1);

	for (Iterator it1 = query1.iterator(); it1.hasNext();) {
		
		System.out.println("Login====Iterator========");			
		relationbean = (RelationsBean) it1.next();			
		System.out.println("RelationBean====spouse name========"+relationbean.getMembername());
			spo.add(relationbean);
	}*/
		
		
	
		
	}
	catch (Exception e)
	{
	
		System.out.println("EXCEPTION IN SIBLINGS DAO OF ADMIN+++++++++++++======"+e);
		
	}
	return spo;
	
}


 public Collection retrieveadminspouse(Session session,int famlyid)
{
	 FamilyBean addfamilyBean1 = new FamilyBean();
	Collection siblings=new ArrayList();
	Relation2Bean relation2Bean = new Relation2Bean();
	MembersearchBean membersearchBean1 = new MembersearchBean();
	try
	{
	List query1 = session.createSQLQuery("select * from family_detail ps where familyid="+famlyid+" ").addEntity("ps",FamilyBean.class).list();
	  for (Iterator it1 = query1.iterator(); it1.hasNext();) 
	  {
		
				
				addfamilyBean1 = (FamilyBean) it1.next();
				System.out.println("displaystandard====adddddddminnnnnnnnnnn in Querrryyy11111========"+addfamilyBean1.getFamilyadmin());
				List query2 = session.createSQLQuery("select * from member_relations ps where spouseid="+addfamilyBean1.getFamilyadmin()+" ").addEntity("ps",Relation2Bean.class).list();
				  for (Iterator it2 = query2.iterator(); it2.hasNext();) 
				  {
					
							
							relation2Bean = (Relation2Bean) it2.next();
							System.out.println("displaystandard====id inn querrrryyyyyyyyyy2222222========"+relation2Bean.getMemberid());
							List query3 = session.createSQLQuery("select * from member_profile ps where memberid="+relation2Bean.getMemberid()+" ").addEntity("ps",MembersearchBean.class).list();
							  for (Iterator it3 = query3.iterator(); it3.hasNext();) 
							  {
									
									membersearchBean1 = (MembersearchBean) it3.next();
									System.out.println("displaystandard====nammmamamamam in querrryyyyy33333333========"+membersearchBean1.getMembername());
									siblings.add(membersearchBean1);
							  }
				  }
	  }
	  
	  }
	  catch (Exception e)
	  {
		System.out.print("EXcepTion iN child of admin ");
	  }
	  return siblings;
}
 
 
 public Collection displaymember11(Session session, FamilyBean addfamilyBean,int q)
 {
 	
 	Collection member1=new ArrayList();
 	List query = session.createSQLQuery("select * from family_detail ps where familyadmin="+q+" ").addEntity("ps",FamilyBean.class).list();
 	
   for (Iterator it = query.iterator(); it.hasNext();) 
   {
 		System.out.println("displaystandard====2wwwwwwwww========");
 		addfamilyBean = (FamilyBean) it.next();
 		member1.add(addfamilyBean);
 	}
   return member1;
 }

 
	public Serializable inserthouse(Session session, HouseBean addhouseBean) {
		Serializable iid;
		session.beginTransaction();
		System.out.println("sososososos");
		iid=session.save(addhouseBean);
		session.getTransaction().commit();
		return iid;

	}
	
	
	public ChecksexBean checksex(Session session,ChecksexBean checksexBean,int memberid1)
	{
		List query = session.createSQLQuery("select * from member_profile ps where memberid="+memberid1+" ").addEntity("ps",ChecksexBean.class).list();
	 	
		   for (Iterator it = query.iterator(); it.hasNext();) 
		   {
		 		System.out.println("displaystandard====2wwwwwwwww========");
		 		checksexBean = (ChecksexBean) it.next();
		 		
		 	}
		
		return checksexBean;
		
	}
	
	
	public Collection login(Session session,LoginBean usernameBean,String uname)
	{
		Collection login = new ArrayList();
		try
		{
			List query1 = session.createSQLQuery("select * from member_login dt where username='"+uname+"'").addEntity("dt",LoginBean.class).list();
			System.out.println("displaystandard====query========"+query1);
					
			      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
			      {
			    	  usernameBean = (LoginBean) it1.next();
			    	  login.add(usernameBean);  
			      }
			
			
		}
		catch(Exception e)
		{
			System.out.println("EXCEPTION IN LOGIN CHECK"+e);
		}
		return login;
	}
	
	public boolean updatememnumber(Session session, ProfileBean profileBean)
	{
		session.beginTransaction();
		System.out.println("sososososos");
		session.update(profileBean);
		session.getTransaction().commit();
		
		return true;
	}
	
//upesh**************************************************************



}