package com.dory.tree;

import org.apache.struts.action.ActionForm;

public class TreeForm extends ActionForm{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String familyname;
	private String familynumber;
	private String childname;
	private String dob;
	private String sex;
	private String uname;
	private String pass;
	private int birthorder;
	private int motherid;
	private int childid;
	private String partnername;
	private String description;

	
	
	//PARTNER HOUSE DETAILS
	 private int housedetails;
	 private String housename;
	 private String city ;
	 private String address ;
	 private String remark;
	 private String status;

	
	
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDob() {
		return dob;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getSex() {
		return sex;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUname() {
		return uname;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getPass() {
		return pass;
	}
	public void setBirthorder(int birthorder) {
		this.birthorder = birthorder;
	}
	public int getBirthorder() {
		return birthorder;
	}
	public void setChildname(String childname) {
		this.childname = childname;
	}
	public String getChildname() {
		return childname;
	}
	public void setMotherid(int motherid) {
		this.motherid = motherid;
	}
	public int getMotherid() {
		return motherid;
	}
	public void setChildid(int childid) {
		this.childid = childid;
	}
	public int getChildid() {
		return childid;
	}
	public void setPartnername(String partnername) {
		this.partnername = partnername;
	}
	public String getPartnername() {
		return partnername;
	}
	public void setFamilyname(String familyname) {
		this.familyname = familyname;
	}
	public String getFamilyname() {
		return familyname;
	}
	public void setFamilynumber(String familynumber) {
		this.familynumber = familynumber;
	}
	public String getFamilynumber() {
		return familynumber;
	}
	public void setHousedetails(int housedetails) {
		this.housedetails = housedetails;
	}
	public int getHousedetails() {
		return housedetails;
	}
	public void setHousename(String housename) {
		this.housename = housename;
	}
	public String getHousename() {
		return housename;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCity() {
		return city;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDescription() {
		return description;
	}

	

}
