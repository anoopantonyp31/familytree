package com.dory.tree;

import java.io.Serializable;
import java.util.Collection;

import org.hibernate.Session;

import com.dory.house.HouseBean;
import com.dory.login.LoginBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalBean;

public interface TreeDAO {

	public Collection viewmembers(Session session,int fid,int memid);
	public Collection retrievespouse(Session session,int memid);
	public RelationdetailBean relationship(Session session,String sex,int checkid);
	public boolean relationinsert(Session session, RelationsBean relationBean);
	public Collection retrievesiblings(Session session,int memid,int famid);
	public int houseid(Session session,int fid);
	public Serializable insertfamily(Session session, FamilyBean familyBean);
	public boolean update(Session session,Relation2Bean relationBean);
	public Relation2Bean retrievemember(Session session,int spid);
	public FamilyBean retrievefamid(Session session,int famid);
	public int findhead(Session session,int famid);
	public Collection displaymember(Session session, LoginBean loginbean,int q);
	public Collection displaymember1(Session session,FamilyBean addfamilyBean,int q);
	public int countwife(Session session,int memid);
	public FamilyBean familyid(Session session,int uid);
	public ProfileBean profile(Session session, int memid);
	
	public Collection displayfamily(Session session,int q,int familyid);
	public FamilyBean displayfamily1(Session session,FamilyBean addfamilyBean,int memid);
	public FamilyBean displayfamilynameadmin(Session session,FamilyBean addfamilyBean,int familyid);
	public Collection retrieveadminsiblings(Session session,int famlyid);
	public Collection retrieveadminspouse(Session session,int famlyid);
	
	public LoginBean logcheck(Session session, int memid);
	public PersonalBean personaldet(Session session, int spoid);
	public String getfather(Session session, int fathid);
	public Collection displaymember11(Session session,FamilyBean addfamilyBean,int q);
	public String getmother(Session session, int momid);
	public Serializable inserthouse(Session session, HouseBean addhouseBean);
	public ChecksexBean checksex(Session session,ChecksexBean checksexBean,int memberid1);
	public Collection login(Session session,LoginBean usernameBean,String uname);
	public boolean updatememnumber(Session session, ProfileBean profileBean);
}
