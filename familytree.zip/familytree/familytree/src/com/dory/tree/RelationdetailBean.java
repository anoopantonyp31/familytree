package com.dory.tree;

public class RelationdetailBean {

	private int relationshipid;
	private String relationship;
	
	
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationshipid(int relationshipid) {
		this.relationshipid = relationshipid;
	}
	public int getRelationshipid() {
		return relationshipid;
	}
}
