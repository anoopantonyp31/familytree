package com.dory.tree;

public class Relation2Bean {

	private int relationid;
    private int fatherid;
    private int memberid;
    private int motherid;
    private int spouseid;
    private int familyid;
    private int relatshipid;   
    private String name;
    
	public void setRelationid(int relationid) {
		this.relationid = relationid;
	}
	public int getRelationid() {
		return relationid;
	}
	public void setFatherid(int fatherid) {
		this.fatherid = fatherid;
	}
	public int getFatherid() {
		return fatherid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setMotherid(int motherid) {
		this.motherid = motherid;
	}
	public int getMotherid() {
		return motherid;
	}
	public void setSpouseid(int spouseid) {
		this.spouseid = spouseid;
	}
	public int getSpouseid() {
		return spouseid;
	}
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}
	public void setRelatshipid(int relatshipid) {
		this.relatshipid = relatshipid;
	}
	public int getRelatshipid() {
		return relatshipid;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
    
}
