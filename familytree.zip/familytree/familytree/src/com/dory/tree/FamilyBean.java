package com.dory.tree;

public class FamilyBean {

	private int familyid;
	private String familyname;
	private String familyno;
	private int basefamilyid;
	private int houseid;
	private int familyadmin;
	private int createdby;
	private String description;
	
	public FamilyBean(){
		
	}
	
	public FamilyBean(int famid){
		this.familyid=famid;
	}
	
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}
	public void setFamilyname(String familyname) {
		this.familyname = familyname;
	}
	public String getFamilyname() {
		return familyname;
	}

	
	public void setBasefamilyid(int basefamilyid) {
		this.basefamilyid = basefamilyid;
	}
	public int getBasefamilyid() {
		return basefamilyid;
	}
	public void setHouseid(int houseid) {
		this.houseid = houseid;
	}
	public int getHouseid() {
		return houseid;
	}
	public void setFamilyadmin(int familyadmin) {
		this.familyadmin = familyadmin;
	}
	public int getFamilyadmin() {
		return familyadmin;
	}
	public void setCreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getCreatedby() {
		return createdby;
	}

	public void setFamilyno(String familyno) {
		this.familyno = familyno;
	}

	public String getFamilyno() {
		return familyno;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}
	
}
