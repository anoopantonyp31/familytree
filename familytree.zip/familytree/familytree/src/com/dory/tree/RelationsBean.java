package com.dory.tree;

import com.dory.memberprofile.ProfileBean;

public class RelationsBean {

    private int relationid;
    private int fatherid;
    private int memberid;
    private int motherid;
    private int spouseid;
    private int familyid;
    private int relationshipid;
    
    private String membername;
    private String relation;
    private String sex;
    private String mothername;
        
    private ProfileBean profile;
    private FamilyBean family;
    private RelationdetailBean relations;
    
    public RelationsBean(){
    	
    }
    public RelationsBean(int relid,int memid,int faid,int moid,int spoid,int relshid,int famid){
    	this.familyid=famid;
    	this.relationid=relid;
    	this.memberid=memid;
    	this.fatherid=faid;
    	this.motherid=moid;
    	this.spouseid=spoid;
    	this.setRelationshipid(relshid);
    }
    public RelationsBean(int famid){
    	this.familyid=famid;
    }
    //pr.name,pr.sex,pr.memberid,pr.mothername,re.spouseid,re.relationshipid
    public RelationsBean(String name,String sex,int memid,String momname,int spid,int relid){
    	this.membername=name;
    	this.sex=sex;
    	this.memberid=memid;
    	this.spouseid=spid;
    	this.relationshipid=relid;
    	this.mothername=momname;
    }
    public RelationsBean(String name,String sex,int memid,int spid,int relid){
    	this.membername=name;
    	this.sex=sex;
    	this.memberid=memid;
    	this.spouseid=spid;
    	this.relationshipid=relid;
    }
    public RelationsBean(String name,int memid){
    	this.membername=name;
    	this.memberid=memid;
    }
    public RelationsBean(String name,String sex,int memid,int spid,String momname){
    	this.membername=name;
    	this.sex=sex;
    	this.memberid=memid;
    	this.spouseid=spid;
    	this.mothername=momname;
    }
       
    
    
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}
	
	public void setSpouseid(int spouseid) {
		this.spouseid = spouseid;
	}
	public int getSpouseid() {
		return spouseid;
	}
	public void setMotherid(int motherid) {
		this.motherid = motherid;
	}
	public int getMotherid() {
		return motherid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setFatherid(int fatherid) {
		this.fatherid = fatherid;
	}
	public int getFatherid() {
		return fatherid;
	}
	public void setRelationid(int relationid) {
		this.relationid = relationid;
	}
	public int getRelationid() {
		return relationid;
	}
	public void setFamily(FamilyBean family) {
		this.family = family;
	}
	public FamilyBean getFamily() {
		return family;
	}
	public void setRelations(RelationdetailBean relations) {
		this.relations = relations;
	}
	public RelationdetailBean getRelations() {
		return relations;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getRelation() {
		return relation;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getSex() {
		return sex;
	}
	public void setProfile(ProfileBean profile) {
		this.profile = profile;
	}
	public ProfileBean getProfile() {
		return profile;
	}
	public void setRelationshipid(int relationshipid) {
		this.relationshipid = relationshipid;
	}
	public int getRelationshipid() {
		return relationshipid;
	}
	public void setMothername(String mothername) {
		this.mothername = mothername;
	}
	public String getMothername() {
		return mothername;
	}
	
	
	
    
    
}
