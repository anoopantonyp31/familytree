package com.dory.hibernate;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	
	private static final SessionFactory sessionFactory;

    static {
        try {
            // Create t he SessionFactory from standard (hibernate.cfg.xml)
            // config file.
              System.out.println("aaaaaaaaaaaaaaaaaaaaaa+++++++HibernateUtil");
        //    sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
              /* Load the hibernate configuration file */
              Configuration cfg = new Configuration();
              cfg.configure("hibernate.cfg.xml");
              System.out.println("bbbbbbbbbbbbbbbbbbbbbbb+++++++HibernateUtil");
               sessionFactory = cfg.buildSessionFactory();
               System.out.println("cccccccccccccccccccccc+++++++HibernateUtil");
              /* Retrieve the session */
            //  Session session = sessionFactory.openSession();
        } catch (Throwable ex) {
            // Log the exception. 
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

}
