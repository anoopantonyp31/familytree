package com.dory.deletemember;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;


import com.dory.aboutme.AboutBean;
import com.dory.confidential.ConfidentialBean;
import com.dory.contact.ContactsBean;
import com.dory.favourites.FavouritesBean;
import com.dory.hibernate.HibernateUtil;
import com.dory.login.LoginBean;
import com.dory.memberbiodata.BiodataBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalBean;
import com.dory.tree.Relation2Bean;

public class DeletememberAction extends Action
{

	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
	String target = null;
	try {
		  if (form != null)
		  {
			  DeletememberForm deletememberForm = (DeletememberForm) form;
			  Relation2Bean addrelationBean = new Relation2Bean();
			  AboutBean parentaboutBean = new AboutBean();
			  PersonalBean parentpersonalBean = new PersonalBean();
			  ConfidentialBean parentconfidentialBean = new ConfidentialBean();
			  ContactsBean parentcontactsBean = new ContactsBean();
			  FavouritesBean parentfavouritesBean = new FavouritesBean();
			  LoginBean loginBean = new LoginBean();
			  BiodataBean biodataBean = new BiodataBean();
			  Relation2Bean addrelationBean1 = new Relation2Bean();
			  ProfileBean getmemberBean = new ProfileBean();
			  String action = request.getParameter("action");
			  DeletememberDAOImpl deletememberDAOImpl = new DeletememberDAOImpl();
			  Session session = HibernateUtil.getSessionFactory()
				.openSession();
			  int flag=0;
			  int flag1=0;//To know if the member is deleted or not 
			  if ("display".equals(action)) 
			  {
				  int memberid = deletememberForm.getMemberid1();//To get the memberid from the Form
				  //To display the member of memberid given in the form
				Collection  getmember = deletememberDAOImpl.displaymember(session,getmemberBean,memberid);
				 if(getmember.isEmpty())
				 {
					 request.setAttribute("nomember", "nomember");
				 }
				 else
				 {
				   request.setAttribute("member", getmember);
				 }
			
				  target="member";
			  }
			  else if ("delete".equals(action)) 
			  {
				  int memberid = deletememberForm.getMemberid();//To get the memberid from the Form
				  //Check whether the Member is on the top of the tree
				  Collection parent = deletememberDAOImpl.checkmember(session,addrelationBean,memberid);
				  if(parent.size()>0)
				  {
					  System.out.println("displllllllllllllllllllaaaaaaaaaaaaaaaaaaaiffffffffffffffff=====");
					  //To check whether the member has more than one child
					  Collection child = deletememberDAOImpl.checkchild(session,addrelationBean,memberid);
					  System.out.println("no>>>>>>>>of father   CCCHHHHHHIiiiiiiiiiild====="+child.size());
					  if(child.size()<=1)
					  {
						  System.out.println("displllllllllllllllllllaaaaaif(parent.size()==1)");
						//To check the spouses of the member
						  Collection spouse = deletememberDAOImpl.checkspouse(session,addrelationBean,memberid);
						  System.out.println("displllllllldeletememberDAOImpl.checkspouse(session,addrelationBean,memberid)lllllllllllaaaaaif");
						  System.out.println("no>>>>>>>>of spouseiiiiild====="+spouse.size());
						  int memberid1;
						  for (Iterator it1 = spouse.iterator(); it1.hasNext();)
						  {
							  addrelationBean = (Relation2Bean) it1.next();
							  memberid1 = addrelationBean.getMemberid(); //memberid of the spouse
							  System.out.println("no>>>>>>>memberid1====="+memberid1);
							//To check whether the spouse has more than one child
							  Collection spousechild = deletememberDAOImpl.checkspousechild(session,addrelationBean,memberid1);
							  System.out.println("no>>>>>>>>of Collection spousechild = deletememberDAOImpl====="+spousechild.size());
							  if(spousechild.size()>1)//To check whether the spouse has more than one child
							  {
								  flag=1;
								  System.out.println("no>>>>>>>>of if(spousechild.size()>1)");
							  }
						  }
						  System.out.println("no>>>>>>>>of chilllddddddiiiiild====="+flag);
						  if(flag==0)//If all the conditions are satisfied
						  {
							  //TO DELETE THE MEMBER
							  
							//To delete from Aboutme table
							  deletememberDAOImpl.deleteabout(session,parentaboutBean,memberid);
							//To delete from  confidential_perminant_fields
							  deletememberDAOImpl.deleteconfident(session,parentconfidentialBean,memberid);
							//To delete from  Contact details
							  deletememberDAOImpl.deletecontact(session,parentcontactsBean,memberid);
							//To delete from  Personal details
							  deletememberDAOImpl.deletepersonal(session,parentpersonalBean,memberid);
							//To delete from  Memeber_favourites details
							  deletememberDAOImpl.deletefavourite(session,parentfavouritesBean,memberid);  
							//To delete from  Memeber_login details
							  deletememberDAOImpl.deletelogin(session,loginBean,memberid);
							//To delete from  Memeber_profile details
							  deletememberDAOImpl.deleteprofile(session,biodataBean,memberid);
							//To delete from  Memeber_relations details
							  deletememberDAOImpl.deleterelation(session,addrelationBean1,memberid);
							  
							  Collection spouse1 = deletememberDAOImpl.checkspouse(session,addrelationBean,memberid);
							  System.out.println("displllllllldeletememberDAOImpl.checkspouse(session,addrelationBean,memberid)lllllllllllaaaaaif");
							  System.out.println("no>>>>>>>>of spouseiiiiild====="+spouse.size());
							  for (Iterator it1 = spouse1.iterator(); it1.hasNext();)
							  {
								  addrelationBean = (Relation2Bean) it1.next();
								  memberid1 = addrelationBean.getMemberid();
								  //TO DELETE THE SPOUSE
								  
								//To delete from Aboutme table
								  deletememberDAOImpl.deleteabout(session,parentaboutBean,memberid1);
								//To delete from  confidential_perminant_fields
								  deletememberDAOImpl.deleteconfident(session,parentconfidentialBean,memberid1);
								//To delete from  Contact details
								  deletememberDAOImpl.deletecontact(session,parentcontactsBean,memberid1);
								//To delete from  Personal details
								  deletememberDAOImpl.deletepersonal(session,parentpersonalBean,memberid1);
								//To delete from  Memeber_favourites details
								  deletememberDAOImpl.deletefavourite(session,parentfavouritesBean,memberid1);  
								//To delete from  Memeber_login details
								  deletememberDAOImpl.deletelogin(session,loginBean,memberid1);
								//To delete from  Memeber_profile details
								  deletememberDAOImpl.deleteprofile(session,biodataBean,memberid1);
								//To delete from  Memeber_relations details
								  deletememberDAOImpl.deleterelation(session,addrelationBean1,memberid1);
								  
							 
								  Collection spouse2 = deletememberDAOImpl.checkspouse(session,addrelationBean,memberid1);
								  System.out.println("displllllllldeletememberDAOImpl.checkspouse(session,addrelationBean,memberid)lllllllllllaaaaaif");
								  System.out.println("no>>>>>>>>of spouseiiiiild====="+spouse.size());
                                  int memberid2;
								  for (Iterator it2 = spouse2.iterator(); it2.hasNext();)
								  {
									  addrelationBean = (Relation2Bean) it2.next();
									  memberid2 = addrelationBean.getMemberid();
									//TO DELETE THE SPOUSE 
									//To delete from Aboutme table
									  deletememberDAOImpl.deleteabout(session,parentaboutBean,memberid2);
									//To delete from  confidential_perminant_fields
									  deletememberDAOImpl.deleteconfident(session,parentconfidentialBean,memberid2);
									//To delete from  Contact details
									  deletememberDAOImpl.deletecontact(session,parentcontactsBean,memberid2);
									//To delete from  Personal details
									  deletememberDAOImpl.deletepersonal(session,parentpersonalBean,memberid2);
									//To delete from  Memeber_favourites details
									  deletememberDAOImpl.deletefavourite(session,parentfavouritesBean,memberid2);  
									//To delete from  Memeber_login details
									  deletememberDAOImpl.deletelogin(session,loginBean,memberid2);
									//To delete from  Memeber_profile details
									  deletememberDAOImpl.deleteprofile(session,biodataBean,memberid2);
									//To delete from  Memeber_relations details
									  deletememberDAOImpl.deleterelation(session,addrelationBean1,memberid2); 
								  }
								  
							  }
							//To update the  Memeber_relations details of the son
							  addrelationBean = deletememberDAOImpl.updaterelation(session,addrelationBean1,memberid);
							  int memid = addrelationBean.getMemberid();//memberid of the son
							  int familyid = addrelationBean.getFamilyid();//familyid of the son
							//To update the  Basefamilyid of the son
							deletememberDAOImpl.updatebasefamilyid (session,biodataBean,memid,familyid);
							flag1=1;
							target="control";
						  }
					  }
					  System.out.println("no>>>>>>>>of    if(parent.size()>0)     else if(flag==1)====="+flag);
					  System.out.println("no>>>>>>>>of    if(parent.size()>0)     else if(flag==11111111111111111111111111111111111111111111111)====="+flag1);
				  }
				  else if(parent.size()==0)
				  {
					  System.out.println("displllllllllllllllllllaaaaaaaaaaaaaaaaaaaielsssiiiiiiiiffffff=====");
					  System.out.println("displlllmenmmmmmmbbbeeerrridddddddddddddddd==========="+memberid);
					  //To check whether the member has child or not
					  Collection child = deletememberDAOImpl.checkchildother(session,addrelationBean,memberid);
					  System.out.println("dCollection child = deletememberDAOImpl.checkchildother(session,addrelationBean,memberid);"+child.size());
					  if(child.size()==0)
					  {

						  System.out.println("dCollection child = deletememberDAOImpl.checkchildother0000000(session,addrelationBean,memberid);"+child.size());
						//To check the spouses of the member
						  Collection spouse = deletememberDAOImpl.checkspouse(session,addrelationBean,memberid);
						  System.out.println("displllllllldeletememberDAOImpl.checkspouse(session,addrelationBean,memberid)lllllllllllaaaaaif");
						  System.out.println("no>>>>>>>>of spouseiiiiild====="+spouse.size());
						  int memberid1;
						  for (Iterator it1 = spouse.iterator(); it1.hasNext();)
						  {
							  addrelationBean = (Relation2Bean) it1.next();
							  memberid1 = addrelationBean.getMemberid(); //memberid of the spouse
							  System.out.println("no>>>>>>>memberid1====="+memberid1);
							//To check whether the spouse has more than one child
							  Collection spousechild = deletememberDAOImpl.checkspousechild(session,addrelationBean,memberid1);
							  System.out.println("no>>>>>>>>of Collection spousechild = deletememberDAOImpl====="+spousechild.size());
							  if(spousechild.size()>0)//To check whether the spouse child
							  {
								  flag=1;
								  System.out.println("no>>>>>>>>of if(spousechild.size()>1)");
							  }
						  }
						  System.out.println("no>>>>>>>>of chilllddddddiiiiild====="+flag);
						  if(flag==0)//If all the conditions are satisfied
						  {
							  //TO DELETE THE MEMBER
							  
							//To delete from Aboutme table
							  deletememberDAOImpl.deleteabout(session,parentaboutBean,memberid);
							//To delete from  confidential_perminant_fields
							  deletememberDAOImpl.deleteconfident(session,parentconfidentialBean,memberid);
							//To delete from  Contact details
							  deletememberDAOImpl.deletecontact(session,parentcontactsBean,memberid);
							//To delete from  Personal details
							  deletememberDAOImpl.deletepersonal(session,parentpersonalBean,memberid);
							//To delete from  Memeber_favourites details
							  deletememberDAOImpl.deletefavourite(session,parentfavouritesBean,memberid);  
							//To delete from  Memeber_login details
							  deletememberDAOImpl.deletelogin(session,loginBean,memberid);
							//To delete from  Memeber_profile details
							  deletememberDAOImpl.deleteprofile(session,biodataBean,memberid);
							//To delete from  Memeber_relations details
							  deletememberDAOImpl.deleterelation(session,addrelationBean1,memberid);
							  
							  Collection spouse1 = deletememberDAOImpl.checkspouse(session,addrelationBean,memberid);
							  System.out.println("displllllllldeletememberDAOImpl.checkspouse(session,addrelationBean,memberid)lllllllllllaaaaaif");
							  System.out.println("no>>>>>>>>of spouseiiiiild====="+spouse.size());
							  for (Iterator it1 = spouse1.iterator(); it1.hasNext();)
							  {
								  addrelationBean = (Relation2Bean) it1.next();
								  memberid1 = addrelationBean.getMemberid();
								  //TO DELETE THE SPOUSE
								  
								//To delete from Aboutme table
								  deletememberDAOImpl.deleteabout(session,parentaboutBean,memberid1);
								//To delete from  confidential_perminant_fields
								  deletememberDAOImpl.deleteconfident(session,parentconfidentialBean,memberid1);
								//To delete from  Contact details
								  deletememberDAOImpl.deletecontact(session,parentcontactsBean,memberid1);
								//To delete from  Personal details
								  deletememberDAOImpl.deletepersonal(session,parentpersonalBean,memberid1);
								//To delete from  Memeber_favourites details
								  deletememberDAOImpl.deletefavourite(session,parentfavouritesBean,memberid1);  
								//To delete from  Memeber_login details
								  deletememberDAOImpl.deletelogin(session,loginBean,memberid1);
								//To delete from  Memeber_profile details
								  deletememberDAOImpl.deleteprofile(session,biodataBean,memberid1);
								//To delete from  Memeber_relations details
								  deletememberDAOImpl.deleterelation(session,addrelationBean1,memberid1);
								  
							 
								  Collection spouse2 = deletememberDAOImpl.checkspouse(session,addrelationBean,memberid1);
								  System.out.println("displllllllldeletememberDAOImpl.checkspouse(session,addrelationBean,memberid)lllllllllllaaaaaif");
								  System.out.println("no>>>>>>>>of spouseiiiiild====="+spouse.size());
                                  int memberid2;
								  for (Iterator it2 = spouse2.iterator(); it2.hasNext();)
								  {
									  addrelationBean = (Relation2Bean) it2.next();
									  memberid2 = addrelationBean.getMemberid();
									//TO DELETE THE SPOUSE 
									//To delete from Aboutme table
									  deletememberDAOImpl.deleteabout(session,parentaboutBean,memberid2);
									//To delete from  confidential_perminant_fields
									  deletememberDAOImpl.deleteconfident(session,parentconfidentialBean,memberid2);
									//To delete from  Contact details
									  deletememberDAOImpl.deletecontact(session,parentcontactsBean,memberid2);
									//To delete from  Personal details
									  deletememberDAOImpl.deletepersonal(session,parentpersonalBean,memberid2);
									//To delete from  Memeber_favourites details
									  deletememberDAOImpl.deletefavourite(session,parentfavouritesBean,memberid2);  
									//To delete from  Memeber_login details
									  deletememberDAOImpl.deletelogin(session,loginBean,memberid2);
									//To delete from  Memeber_profile details
									  deletememberDAOImpl.deleteprofile(session,biodataBean,memberid2);
									//To delete from  Memeber_relations details
									  deletememberDAOImpl.deleterelation(session,addrelationBean1,memberid2);
									  
								  }
								  
							  }
                            flag1=1;
                            target="control";
						  }
					  
					  }
					  System.out.println("no>>>>>>>>of  else if(parent.size()==0)   else if(flag1==1)====="+flag);
					  System.out.println("no>>>>>>>>of  else if(parent.size()==0)   else if(flag1111111111111111111111111111111111111==1)====="+flag1);
				  }
				 
				  if(flag1==0)
				  {
					  System.out.println("       request.setAttribute(delete, delete)     no>>>>>>>>of  else if(flag1==0)=====");
					 Collection getmember = deletememberDAOImpl.displaymember(session,getmemberBean,memberid);
						 
					   request.setAttribute("member", getmember);
					   request.setAttribute("delete", "delete");
					   target="member";
				  }
				  
			  }
			
		  }
	  }
	
	catch (Exception e)
	{
		System.out.println("Exception in display Action======="+e);
	}
	return (mapping.findForward(target));
}
}