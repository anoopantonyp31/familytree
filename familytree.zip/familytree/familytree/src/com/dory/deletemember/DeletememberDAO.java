package com.dory.deletemember;

import java.util.Collection;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.confidential.ConfidentialBean;
import com.dory.contact.ContactsBean;
import com.dory.favourites.FavouritesBean;
import com.dory.login.LoginBean;
import com.dory.memberbiodata.BiodataBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalBean;
import com.dory.tree.Relation2Bean;


public interface DeletememberDAO
{
	//To display the member
	public Collection displaymember(Session session,ProfileBean getmemberBean,int memberid);
	//Check whether the Member is on the top of the tree
	public Collection checkmember(Session session,Relation2Bean addrelationBean,int memberid);
	//To check whether the member has more than one child
	public Collection checkchild(Session session,Relation2Bean addrelationBean,int memberid);
	//To check the spouses of the member
	public Collection checkspouse(Session session,Relation2Bean addrelationBean,int memberid);
	//To check whether the spouse has more than one child
	public Collection checkspousechild(Session session,Relation2Bean addrelationBean,int memberid);
	//To delete from Aboutme table
	public boolean deleteabout(Session session,AboutBean parentaboutBean,int memberid);
	//To delete from  confidential_perminant_fields
	public boolean deleteconfident(Session session,ConfidentialBean parentconfidentialBean,int memberid);
	//To delete from Contact details
	public boolean deletecontact(Session session,ContactsBean parentcontactsBean,int memberid);
	//To delete from favourite details
	public boolean deletefavourite(Session session,FavouritesBean parentfavouritesBean,int memberid);
	//To delete from  Memeber_login details
	public boolean deletelogin(Session session,LoginBean loginBean,int memberid);
	//To delete from  Memeber_profile details
	public boolean deleteprofile(Session session,BiodataBean biodataBean,int memberid);
	//To delete from  Memeber_relations details
	public boolean deleterelation(Session session,Relation2Bean addrelationBean1,int memberid);
	//To delete from  Personal details
	public boolean deletepersonal(Session session,PersonalBean parentpersonalBean,int memberid);
	//To update the  Memeber_relations details of the son
	public Relation2Bean updaterelation(Session session,Relation2Bean addrelationBean,int memberid);
	//To update the  Basefamilyid of the son
	public boolean updatebasefamilyid(Session session,BiodataBean biodataBean,int memid,int familyid);
	//To check whether the member has child
	public Collection checkchildother(Session session,Relation2Bean addrelationBean,int memberid);
	




	
	

	
}
