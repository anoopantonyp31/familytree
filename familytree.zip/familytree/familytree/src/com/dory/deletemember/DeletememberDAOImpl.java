package com.dory.deletemember;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.confidential.ConfidentialBean;
import com.dory.contact.ContactsBean;
import com.dory.favourites.FavouritesBean;
import com.dory.login.LoginBean;
import com.dory.memberbiodata.BiodataBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.personal.PersonalBean;
import com.dory.tree.Relation2Bean;


public class DeletememberDAOImpl implements DeletememberDAO
{

	public Collection displaymember(Session session,ProfileBean getmemberBean,int memberid)
	{
		Collection displaymember = new ArrayList();
		try
		{
		  List query1 = session.createSQLQuery("select * from member_profile dt where memberid='"+memberid+"'").addEntity("ds",ProfileBean.class).list();
		  System.out.println("displaystandard====query========"+query1);
				
		      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
		      {
					System.out.println("displaystandard====Iterator========");
					getmemberBean = (ProfileBean) it1.next();
					displaymember.add(getmemberBean);
					System.out.println("displllllllllllllllllllaaaaaaaaaaaaaaaaaaa====="+getmemberBean.getName());
					System.out.println("displllllllllllllllllllaaaaaaaaaaaahouseeeeeeid==="+getmemberBean.getHouseid());

		      }
         }
		catch (Exception e) 
		{
			System.out.println("Exception in memberdisplayyyyyDao=="+e);
		}
		return displaymember;
	}
	
	public Collection checkmember(Session session,Relation2Bean addrelationBean,int memberid)
	{
		Collection displaymember = new ArrayList();
		try
		{		
			List query = session.createSQLQuery("select * from member_relations ds where memberid='"+memberid+"' and fatherid='0' and motherid='0' and spouseid='0' and relationshipid=0").addEntity("ds",Relation2Bean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						addrelationBean = (Relation2Bean) it.next();
						displaymember.add(addrelationBean);
			      }
		}
		catch(Exception e)
		{
			
			System.out.println("Exception in memberDao=="+e);
			
		}
		return displaymember;
	}
	
	
	public Collection checkchild(Session session,Relation2Bean addrelationBean,int memberid)
	{
		
			Collection child = new ArrayList();
			try
			{		
				List query = session.createSQLQuery("select * from member_relations ds where fatherid='"+memberid+"'").addEntity("ds",Relation2Bean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it = query.iterator(); it.hasNext();) 
				      {
							System.out.println("displaystandard====Iterator========");
							addrelationBean = (Relation2Bean) it.next();
							child.add(addrelationBean);
				      }
			}
			catch(Exception e)
			{
				
				System.out.println("Exception in checkchild=="+e);
				
			}
			return child;	
	}
	
	public Collection checkspouse(Session session,Relation2Bean addrelationBean,int memberid)
	{
		
		Collection spouse = new ArrayList();
		try
		{		
			List query = session.createSQLQuery("select * from member_relations ds where spouseid='"+memberid+"'").addEntity("ds",Relation2Bean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						addrelationBean = (Relation2Bean) it.next();
						spouse.add(addrelationBean);
			      }
		}
		catch(Exception e)
		{
			
			System.out.println("Exception in checkspouse=="+e);
			
		}
		return spouse;	
	}
	
	public Collection checkspousechild(Session session,Relation2Bean addrelationBean,int memberid)
	{
		
		Collection child = new ArrayList();
		try
		{		
			List query = session.createSQLQuery("select * from member_relations ds where motherid='"+memberid+"'").addEntity("ds",Relation2Bean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						addrelationBean = (Relation2Bean) it.next();
						child.add(addrelationBean);
			      }
		}
		catch(Exception e)
		{
			
			System.out.println("Exception in checkchild=="+e);
			
		}
		return child;	
		
	}
	
	public boolean deleteabout(Session session,AboutBean parentaboutBean,int memberid)
	{
		try
		{		
			List query = session.createSQLQuery("select * from about_member ds where memberid='"+memberid+"'").addEntity("ds",AboutBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						parentaboutBean = (AboutBean) it.next();
						session.beginTransaction();
						session.delete(parentaboutBean);
						session.getTransaction().commit();
			      }
		}
		catch (Exception e) 
		{
			
			System.out.println("Exception in deleteabout=="+e);
		}
		return true;
	}
	
	
	public boolean deleteconfident(Session session,ConfidentialBean parentconfidentialBean,int memberid)
	{
		
		try
		{		
			List query = session.createSQLQuery("select * from confidential_perminant_fields ds where memberid='"+memberid+"'").addEntity("ds",ConfidentialBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						parentconfidentialBean = (ConfidentialBean) it.next();
						session.beginTransaction();
						session.delete(parentconfidentialBean);
						session.getTransaction().commit();
			      }
		}
		catch (Exception e) 
		{
			
			System.out.println("Exception in deleteconfident=="+e);
		}
		return true;
		
	}
	public boolean deletecontact(Session session,ContactsBean parentcontactsBean,int memberid)
	{
		
		try
		{		
			List query = session.createSQLQuery("select * from member_contact_detail ds where memberid='"+memberid+"'").addEntity("ds",ContactsBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						parentcontactsBean = (ContactsBean) it.next();
						session.beginTransaction();
						session.delete(parentcontactsBean);
						session.getTransaction().commit();
			      }
		}
		catch (Exception e) 
		{
			
			System.out.println("Exception in deletecontact=="+e);
		}
		return true;
		
	}
	
	public boolean deletefavourite(Session session,FavouritesBean parentfavouritesBean,int memberid)
	{
		try
		{		
			List query = session.createSQLQuery("select * from member_favourites ds where memberid='"+memberid+"'").addEntity("ds",FavouritesBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						parentfavouritesBean = (FavouritesBean) it.next();
						session.beginTransaction();
						session.delete(parentfavouritesBean);
						session.getTransaction().commit();
			      }
		}
		catch (Exception e) 
		{
			
			System.out.println("Exception in deletefavourite=="+e);
		}
		return true;
		
	}
	
	public boolean deletelogin(Session session,LoginBean loginBean,int memberid)
	{
		
		try
		{		
			List query = session.createSQLQuery("select * from member_login ds where memberid='"+memberid+"'").addEntity("ds",LoginBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						loginBean = (LoginBean) it.next();
						session.beginTransaction();
						session.delete(loginBean);
						session.getTransaction().commit();
			      }
		}
		catch (Exception e) 
		{
			
			System.out.println("Exception in deletefavourite=="+e);
		}
		return true;
	}
	public boolean deleteprofile(Session session,BiodataBean biodataBean,int memberid)
	{
		
	  System.out.println("displaystandard====Iterator========");
	  biodataBean.setMemberid(memberid);
	  session.beginTransaction();
	  session.delete(biodataBean);
	  return true;
		
	}
	
	public boolean deleterelation(Session session,Relation2Bean addrelationBean1,int memberid)
	{
		try
		{		
			List query = session.createSQLQuery("select * from member_relations ds where memberid='"+memberid+"'").addEntity("ds",Relation2Bean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						addrelationBean1 = (Relation2Bean) it.next();
						session.beginTransaction();
						session.delete(addrelationBean1);
						session.getTransaction().commit();
			      }
		}
		catch (Exception e) 
		{
			
			System.out.println("Exception in deletefavourite=="+e);
		}
		return true;
		
	}
	
	
	public boolean deletepersonal(Session session,PersonalBean parentpersonalBean,int memberid)
	{
		try
		{		
			List query = session.createSQLQuery("select * from member_personal_detail ds where memberid='"+memberid+"'").addEntity("ds",PersonalBean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						parentpersonalBean = (PersonalBean) it.next();
						session.beginTransaction();
						session.delete(parentpersonalBean);
						session.getTransaction().commit();
			      }
		}
		catch (Exception e) 
		{
			
			System.out.println("Exception in deletefavourite=="+e);
		}
		return true;
		
	}
	
	public Relation2Bean updaterelation(Session session,Relation2Bean addrelationBean,int memberid)
	{
		
		try
		{	
			
			List query = session.createSQLQuery("select * from member_relations ds where fatherid='"+memberid+"'").addEntity("ds",Relation2Bean.class).list();
			System.out.println("displaystandard====query========"+query);
					
			      for (Iterator it = query.iterator(); it.hasNext();) 
			      {
						System.out.println("displaystandard====Iterator========");
						addrelationBean = (Relation2Bean) it.next();
						addrelationBean.setFatherid(0);
						addrelationBean.setMotherid(0);
						session.beginTransaction();
						session.update(addrelationBean);
						session.getTransaction().commit();
			      }
			      
		}
		catch (Exception e) 
		{
			
			System.out.println("Exception in deletefavourite=="+e);
		}
		return addrelationBean;
		
		
	}
	
	
	public boolean updatebasefamilyid(Session session,BiodataBean biodataBean,int memid,int familyid)
	{
		try
		{
		  List query1 = session.createSQLQuery("select * from member_profile dt where memberid='"+memid+"'").addEntity("ds",BiodataBean.class).list();
		  System.out.println("displaystandard====query========"+query1);
				
		      for (Iterator it1 = query1.iterator(); it1.hasNext();) 
		      {
					System.out.println("displaystandard====Iterator========");
					biodataBean = (BiodataBean) it1.next();
					System.out.println("displllllllllllllllllllaaaaaaaiodataBean.getMembername(aaaaaaaaaaaa====="+biodataBean.getMembername());
					System.out.println("displllllllllllllllllllaaaaaaaaaaaiodataBean.getBasefamilyid()ahouseeeeeeid==="+biodataBean.getBasefamilyid());
					biodataBean.setBasefamilyid(familyid);
					session.beginTransaction();
					session.update(biodataBean);
					System.out.println("displllllllllllllllllllaaaaaaaaaaaiodataBean.getBasefamilyid()ahouseeeeeeid==="+biodataBean.getBasefamilyid());
					session.getTransaction().commit();

		      }
         }
		catch (Exception e) 
		{
			System.out.println("Exception in memberdisplayyyyyDao=="+e);
		}
		return true;
		
	}
	
	public Collection checkchildother(Session session,Relation2Bean addrelationBean,int memberid)
	{
		
			Collection child = new ArrayList();
			try
			{		
				List query = session.createSQLQuery("select * from member_relations ds where fatherid='"+memberid+"' or motherid='"+memberid+"'").addEntity("ds",Relation2Bean.class).list();
				System.out.println("displaystandard====query========"+query);
						
				      for (Iterator it = query.iterator(); it.hasNext();) 
				      {
							System.out.println("displaystandard====Iterator========");
							addrelationBean = (Relation2Bean) it.next();
							child.add(addrelationBean);
				      }
			}
			catch(Exception e)
			{
				
				System.out.println("Exception in checkchild=="+e);
				
			}
			return child;	
	}
}
