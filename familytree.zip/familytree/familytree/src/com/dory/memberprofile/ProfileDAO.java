package com.dory.memberprofile;

import java.io.Serializable;

import org.hibernate.Session;

public interface ProfileDAO {

	public Serializable insert(Session session, ProfileBean profileBean);
}
