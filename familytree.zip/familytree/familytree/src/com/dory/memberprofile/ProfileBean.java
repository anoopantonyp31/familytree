package com.dory.memberprofile;

import java.util.Date;

public class ProfileBean {

	private int memberid;
	private String name;
	private String birthcountry;
	private String nickname;
	private String birthplace;
	private String birthstate;
	private String address;
	private int birthorder;
	private String sex;
	private String status;
	private Date dob;
	private int basefamilyid;
	private int houseid;
	private String membernumber;
	private String visibletocommunity;
	private String fathername;
	private String mothername;
	private int visibility;
	
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getNickname() {
		return nickname;
	}
	public void setBirthplace(String birthplace) {
		this.birthplace = birthplace;
	}
	public String getBirthplace() {
		return birthplace;
	}
	public void setBirthstate(String birthstate) {
		this.birthstate = birthstate;
	}
	public String getBirthstate() {
		return birthstate;
	}
	public void setBirthorder(int birthorder) {
		this.birthorder = birthorder;
	}
	public int getBirthorder() {
		return birthorder;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getSex() {
		return sex;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Date getDob() {
		return dob;
	}
	public void setVisibletocommunity(String visibletocommunity) {
		this.visibletocommunity = visibletocommunity;
	}
	public String getVisibletocommunity() {
		return visibletocommunity;
	}
	public void setBirthcountry(String birthcountry) {
		this.birthcountry = birthcountry;
	}
	public String getBirthcountry() {
		return birthcountry;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	public void setBasefamilyid(int basefamilyid) {
		this.basefamilyid = basefamilyid;
	}
	public int getBasefamilyid() {
		return basefamilyid;
	}
	public void setHouseid(int houseid) {
		this.houseid = houseid;
	}
	public int getHouseid() {
		return houseid;
	}

	public void setFathername(String fathername) {
		this.fathername = fathername;
	}
	public String getFathername() {
		return fathername;
	}
	public void setMothername(String mothername) {
		this.mothername = mothername;
	}
	public String getMothername() {
		return mothername;
	}
	public void setVisibility(int visibility) {
		this.visibility = visibility;
	}
	public int getVisibility() {
		return visibility;
	}
	public void setMembernumber(String membernumber) {
		this.membernumber = membernumber;
	}
	public String getMembernumber() {
		return membernumber;
	}
	
}
