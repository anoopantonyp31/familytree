package com.dory.memberprofile;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.house.CountrylistBean;
public class ProfileDAOImpl implements ProfileDAO{

			
	public Serializable insert(Session session, ProfileBean profileBean) 
		
		{
		Serializable id;
			session.beginTransaction();
			id=session.save(profileBean);
			System.out.println("terminator111111>>>>>>"+id);
			session.getTransaction().commit();
			return id;

		}

	
	public Collection countrydisplay(Session session, CountrylistBean countrylistBean) {

		Collection countrycol = new ArrayList();
		try {
			List query = session.createQuery("from CountrylistBean ex order by ex.countryid")
					.list();
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				countrylistBean = (CountrylistBean) it.next();
				countrycol.add(countrylistBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return countrycol;
	}
	
	
	
}

