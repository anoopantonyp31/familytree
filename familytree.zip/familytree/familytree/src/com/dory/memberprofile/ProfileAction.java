package com.dory.memberprofile;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.house.CountrylistBean;
import com.dory.house.HouseDAOImpl;
public class ProfileAction extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
					//String a1= request.getParameter("fromWhere");
					String k = request.getParameter("action");
					//String k1 = request.getParameter("action1");
				// Use the NameForm to get the request parameters
				ProfileForm profileForm = (ProfileForm) form;
				ProfileBean profileBean = new ProfileBean();

				//BeanUtils.copyProperties(aboutBean, aboutForm);
				
				profileBean.setMemberid(profileForm
						.getMemberid());
				
				profileBean.setName(profileForm
						.getName());
				
				profileBean.setNickname(profileForm
						.getNickname());
				
				profileBean.setSex(profileForm
						.getSex());
				
				
				
				profileBean.setBirthorder(profileForm
						.getBirthorder());
				
	
				profileBean.setBirthplace(profileForm
						.getBirthplace());
	
				profileBean.setBirthstate(profileForm
						.getBirthstate());
				
				profileBean.setBirthcountry(profileForm
						.getBirthcountry());
				
				
				profileBean.setAddress(profileForm
						.getAddress());
				
				profileBean.setStatus(profileForm
						.getStatus());
				
				String dobnew = profileForm.getDob();
				System.out.println("dobnew===========>" + profileForm.getDob());
				System.out.println("dobnew===========>" + dobnew);
				
				if(dobnew!=null)
				{
				Date dt=new SimpleDateFormat("dd-MM-yyyy").parse(dobnew);
				profileBean.setDob(dt);
				}
				System.out.println("session======in ProfileAction=====>" + session);
				ProfileDAOImpl profileDAO = new ProfileDAOImpl();
				
				if ("insert".equals(k)) 
				{
							
				
										System.out.println("inside insert");
										Serializable id= profileDAO.insert(session, profileBean);
										int idd=(Integer)id;
						System.out.println("=====idddd========>>>>>>"+idd);
						String fol = String.valueOf(idd);
                        String fol1="23966349746773904";
                        String folderid=fol+fol1+fol;
                        System.out.println("folderid============"+folderid);
                        
						FileInputStream fin = new FileInputStream(getServlet().getServletContext().getRealPath("/")+"defaultimages/photo.jpg");
						System.out.print("==========fin========"+fin.available());
						File f= new File(getServlet().getServletContext().getRealPath("/")+"username/"+idd+"/images");
						System.out.print("==========after f========"+f);
						
						if(!f.exists())
						{
							System.out.print("==========in iffff========");
							f.mkdirs();
						}
						FileOutputStream fout=new FileOutputStream(getServlet().getServletContext().getRealPath("/")+"username/"+idd+"/images/photo.jpg"); 
						System.out.print("==========in fout========");
						byte b[]=new byte[fin.available()];
						fin.read(b);
						fout.write(b);
						System.out.print("===========after file operationssssssssss===============");
						target="correct";
						System.out.print("========target=============="+target);
						
				}		
				
				else if("display".equals(k))
				{
					CountrylistBean countrylistBean = new CountrylistBean();
					HouseDAOImpl houseDAO = new HouseDAOImpl();
					Collection exeobj = profileDAO.countrydisplay(session,countrylistBean);
					System.out.println("session======222222222222=====>"
							+ exeobj.size());
					if (exeobj.size() > 0) 
					{
						System.out.println("session======333333333=====>"
								+ exeobj.size());
						request.setAttribute("exeobj", exeobj);
						
						target = "profile";
					} 
						
									
				}
				
				
				
				
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}
}
