package com.dory.aboutme;
import org.apache.struts.action.ActionForm;
public class AboutForm extends ActionForm {

	//variable to get the values from the text boxes of aboutme.jsp
	 private String myself;
	 private String achivements;
	 private String remark;
	 private int aboutid;
	 
	 private int publicorprivate;
	 private int community;
	 private int groups;
	 private int family;
	 
	 
	public void setMyself(String myself) {
		this.myself = myself;
	}
	public String getMyself() {
		return myself;
	}
	public void setAchivements(String achivements) {
		this.achivements = achivements;
	}
	public String getAchivements() {
		return achivements;
	}
	public void setAboutid(int aboutid) {
		this.aboutid = aboutid;
	}
	public int getAboutid() {
		return aboutid;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	
	public void setCommunity(int community) {
		this.community = community;
	}
	public int getCommunity() {
		return community;
	}
	public void setGroups(int groups) {
		this.groups = groups;
	}
	public int getGroups() {
		return groups;
	}
	
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	public void setFamily(int family) {
		this.family = family;
	}
	public int getFamily() {
		return family;
	}
}
