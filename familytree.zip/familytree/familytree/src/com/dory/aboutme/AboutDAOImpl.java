package com.dory.aboutme;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.contact.ContactsBean;

public class AboutDAOImpl implements AboutDAO {
	
	//insertion is being carried out in this bellow function
	public boolean insert(Session session, AboutBean aboutBean) {
		session.beginTransaction();
		session.save(aboutBean);
		session.getTransaction().commit();
		return true;

	}
	
	
	
	public AboutBean displayaboutdetails(Session session,
			AboutBean aboutBean,int q) {

		Collection aboutcol = new ArrayList();
		try {
			List query = session.createQuery("from AboutBean ex where ex.memberid='"+q+"'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				aboutBean = (AboutBean) it.next();
				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return aboutBean;
	}
	
	public boolean update(Session session, AboutBean aboutBean) {
		session.beginTransaction();
		session.update(aboutBean);
		session.getTransaction().commit();
		return true;

	}
	
	
	

}
