//author:Anoop Antony.p
//created on:14-10-2010
//updated by:none
package com.dory.aboutme;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

public class AboutAction extends Action {
	

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//used to get the action value
					String k = request.getParameter("action");
					
				AboutForm aboutForm = (AboutForm) form;
				AboutBean aboutBean = new AboutBean();
                HttpSession httpsession = request.getSession();
                Session session = HibernateUtil.getSessionFactory()
				.openSession();
		       System.out.println("session======111111=====>" + session);
				//BeanUtils.copyProperties(aboutBean, aboutForm);
				
				/*aboutBean.setAchivements(aboutForm
						.getAchivements());
				aboutBean.setMyself(aboutForm.getMyself());
				aboutBean.setRemark(aboutForm.getRemark());*/
				
				
				
				
				//to get the session from the login action
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             aboutBean.setMemberid(q);
	            
				
				AboutDAO aboutDAO = new AboutDAOImpl();
				
				//if value of action=insert then enters below statement
				//function to insert the data from aboutme.jsp into about_member tables 
				if ("update".equals(k)) 
				{
							
					aboutBean = aboutDAO.displayaboutdetails(session,aboutBean,q);
					
					aboutBean.setAchivements(aboutForm.getAchivements());
					aboutBean.setMyself(aboutForm.getMyself());
					aboutBean.setRemark(aboutForm.getRemark());
					//*********************visibility part***********************//
					//--------------------------------------
					int privateorprivate1=aboutForm.getPublicorprivate();
					
					int family=aboutForm.getFamily();
					int groups=aboutForm.getGroups();
					int community=aboutForm.getCommunity();
					
					String privateorprivate2 = String.valueOf(privateorprivate1);
					System.out.println("===========gggggggg======="+privateorprivate2);
					if("1".equals(privateorprivate2))
					{
						//String visibility=privateorprivate1+"0"+"0"+"0";
						String visibility="8";
						System.out.println("===========in public======="+visibility);
						aboutBean.setVisibility(visibility);
					}
					if("0".equals(privateorprivate2))
					{
						//String visibility=privateorprivate1+"0"+"0"+"0";
						String visibility="0";
						System.out.println("===========in private======="+visibility);
						aboutBean.setVisibility(visibility);
					}
					
					if("500".equals(privateorprivate2))
					{
					String family2 = String.valueOf(family);
					String groups2 = String.valueOf(groups);
					String community2 = String.valueOf(community);
					
					 
						if("0".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
						{
							//String visibility="0"+"0"+"0"+"0";
							String visibility="0";
							System.out.println("===========1111111======="+visibility);
							aboutBean.setVisibility(visibility);
						}
						
						else if("0".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
						{
							String visibility="1";
							System.out.println("===========222222======="+visibility);
							aboutBean.setVisibility(visibility);
						}
						
						else if("1".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
						{
							String visibility="2";
							System.out.println("===========3333333======="+visibility);
							aboutBean.setVisibility(visibility);
						}
						
						else if("1".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
						{
							String visibility="3";
							System.out.println("===========44444444======="+visibility);
							aboutBean.setVisibility(visibility);
						}
						
						
						else if("0".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
						{
							String visibility="4";
							System.out.println("===========666666666======="+visibility);
							aboutBean.setVisibility(visibility);
						}
						
						
						else if("0".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
						{
							String visibility="5";
							System.out.println("===========7777777======="+visibility);
							aboutBean.setVisibility(visibility);
						}
						
						
						else if("1".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
						{
							String visibility="6";
							System.out.println("===========8888888======="+visibility);
							aboutBean.setVisibility(visibility);
						}
						
						
						else if("1".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
						{
							String visibility="7";
							System.out.println("===========99999999======="+visibility);
							aboutBean.setVisibility(visibility);
						}
						
						
					}
					
					//*********************visibility part***********************//
					
					
										System.out.println("inside insert");
										aboutDAO.update(session,aboutBean);
						
						target="correct";
						
				}	
				
				
				else if ("display".equals(k)) 
				{
							
					aboutBean = aboutDAO.displayaboutdetails(session,aboutBean,q);
					
					
					{
						
						request.setAttribute("about", aboutBean);
						target = "aboutme";
					} 
						
				}
				
				
				
				
				
				
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}

}
