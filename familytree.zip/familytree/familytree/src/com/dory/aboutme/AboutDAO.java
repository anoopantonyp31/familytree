package com.dory.aboutme;

import org.hibernate.Session;

public interface AboutDAO {

	public boolean insert(Session session, AboutBean aboutBean);
	public AboutBean displayaboutdetails(Session session,AboutBean aboutBean,int q);
	public boolean update(Session session, AboutBean aboutBean);
	
}
