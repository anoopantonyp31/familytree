package com.dory.advancesearch;

import java.util.Collection;

import org.hibernate.Session;

import com.dory.contact.ContactsBean;
import com.dory.memberprofile.ProfileBean;

public interface AdvancesearchDAO {

	public Collection display(Session session,ProfileBean profilebean,ContactsBean contactbean,int mid,int yr1,int yr2);
}
