package com.dory.advancesearch;

public class SelectionBean {

	private int memberid;
	private String membername;
	
	public SelectionBean(){
		
	}
	
	public SelectionBean(String name,int mid){
		this.memberid=mid;
		this.membername=name;
	}
	

	public void setMembername(String membername) {
		this.membername = membername;
	}

	public String getMembername() {
		return membername;
	}

	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}

	public int getMemberid() {
		return memberid;
	}
}
