package com.dory.advancesearch;

import org.apache.struts.action.ActionForm;

public class AdvancesearchForm extends ActionForm{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String member1;
	private String member11;
	private int member111;
	private String member2;
	private String member22;
	private int member222;
	private String member3;
	private String member33;
	private int member333;
	private String member4;
	private String member44;
	private int member444;
	
	private String house1;
	private String house11;
	private String house2;
	private String house22;
	private String house3;
	private String house33;
	
	private String family1;
	private String family11;
	private String family2;
	private String family22;
	private String family3;
	private String family33;
	
	private String job1;
	private String job11;
	private String job2;
	private String job22;
	
	

	public void setMember1(String member1) {
		this.member1 = member1;
	}

	public String getMember1() {
		return member1;
	}

	public void setMember11(String member11) {
		this.member11 = member11;
	}

	public String getMember11() {
		return member11;
	}

	public void setMember2(String member2) {
		this.member2 = member2;
	}

	public String getMember2() {
		return member2;
	}

	public void setMember22(String member22) {
		this.member22 = member22;
	}

	public String getMember22() {
		return member22;
	}

	public void setMember3(String member3) {
		this.member3 = member3;
	}

	public String getMember3() {
		return member3;
	}

	public void setMember33(String member33) {
		this.member33 = member33;
	}

	public String getMember33() {
		return member33;
	}

	public void setMember4(String member4) {
		this.member4 = member4;
	}

	public String getMember4() {
		return member4;
	}

	public void setMember44(String member44) {
		this.member44 = member44;
	}

	public String getMember44() {
		return member44;
	}

	public void setMember444(int member444) {
		this.member444 = member444;
	}

	public int getMember444() {
		return member444;
	}

	public void setMember333(int member333) {
		this.member333 = member333;
	}

	public int getMember333() {
		return member333;
	}

	public void setMember222(int member222) {
		this.member222 = member222;
	}

	public int getMember222() {
		return member222;
	}

	public void setMember111(int member111) {
		this.member111 = member111;
	}

	public int getMember111() {
		return member111;
	}

	public void setHouse1(String house1) {
		this.house1 = house1;
	}

	public String getHouse1() {
		return house1;
	}

	public void setHouse11(String house11) {
		this.house11 = house11;
	}

	public String getHouse11() {
		return house11;
	}

	public void setHouse2(String house2) {
		this.house2 = house2;
	}

	public String getHouse2() {
		return house2;
	}

	public void setHouse22(String house22) {
		this.house22 = house22;
	}

	public String getHouse22() {
		return house22;
	}

	public void setHouse3(String house3) {
		this.house3 = house3;
	}

	public String getHouse3() {
		return house3;
	}

	public void setHouse33(String house33) {
		this.house33 = house33;
	}

	public String getHouse33() {
		return house33;
	}

	public void setFamily1(String family1) {
		this.family1 = family1;
	}

	public String getFamily1() {
		return family1;
	}

	public void setFamily11(String family11) {
		this.family11 = family11;
	}

	public String getFamily11() {
		return family11;
	}

	public void setFamily2(String family2) {
		this.family2 = family2;
	}

	public String getFamily2() {
		return family2;
	}

	public void setFamily22(String family22) {
		this.family22 = family22;
	}

	public String getFamily22() {
		return family22;
	}

	public void setFamily3(String family3) {
		this.family3 = family3;
	}

	public String getFamily3() {
		return family3;
	}

	public void setFamily33(String family33) {
		this.family33 = family33;
	}

	public String getFamily33() {
		return family33;
	}

	public void setJob1(String job1) {
		this.job1 = job1;
	}

	public String getJob1() {
		return job1;
	}

	public void setJob11(String job11) {
		this.job11 = job11;
	}

	public String getJob11() {
		return job11;
	}

	public void setJob2(String job2) {
		this.job2 = job2;
	}

	public String getJob2() {
		return job2;
	}

	public void setJob22(String job22) {
		this.job22 = job22;
	}

	public String getJob22() {
		return job22;
	}
	
}
