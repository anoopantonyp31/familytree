package com.dory.advancesearch;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.contact.ContactsBean;
import com.dory.memberprofile.ProfileBean;

public class AdvancesearchDAOImpl implements AdvancesearchDAO{

	public Collection display(Session session,ProfileBean profilebean,ContactsBean contactbean,int mid,int year1,int year2){
		SelectionBean selectionbean = new SelectionBean();
		//String midd = Integer.toString(mid);
		//String year1 = Integer.toString(yr1);
		//String year2 = Integer.toString(yr2);
		String name=profilebean.getName();
		String mob=contactbean.getMobileno();
		String land=contactbean.getLandlineno();
		Collection ser = new ArrayList();
		System.out.println("Value of name: "+name);	
		System.out.println("Value of memberid: "+mid);
		System.out.println("Value of land: "+land);
		System.out.println("Value of mob: "+mob);
		System.out.println("Value of year1: "+year1);
		System.out.println("Value of year2: "+year2);
		try{
			/*if("0".equals(midd)){
				System.out.println("Inside mid if......");
				midd="%";
				System.out.println("value of mid...... "+midd);
			}
			
			if("0".equals(year1)){
				System.out.println("Inside year1 if......");
				year1="%";
				System.out.println("value of year1...... "+year1);
			}
			
			if("0".equals(year2)){
				System.out.println("Inside year2 if......");
				year2="%";
				System.out.println("value of year2...... "+year2);
			}
			
			if(name==null){
			System.out.println("Inside name if......");
			name="%";
		    }
			else{
				name="%"+name+"%";
			}
			
			if(mob==null){
				System.out.println("Inside mob if......");
				mob="%";
			    }
				else{
					mob="%"+mob+"%";
				}
			
			if(land==null){
				System.out.println("Inside land if......");
				land="%";
			    }
				else{
					land="%"+land+"%";
				}*/
			
			
			String main = "select new ContactsBean(pr.name,pr.memberid) from ContactsBean co " +
			              "join co.profile pr where ";
			String and = "and ";
			if(mid!=0){
				String q = "pr.memberid like '"+mid+"' ";
				main = main+q;
			}
			if(name!=null){
				if(mid!=0){
					main = main+and;
					String q1 = "pr.name like '%"+name+"%' ";
					main = main+q1;
				}
				else{
					String q1 = "pr.name like '%"+name+"%' ";
					main = main+q1;
				}
			}
			if(mob!=null){
				if(mid!=0||name!=null){
					main = main+and;
					String q2 = "co.mobileno like '%"+mob+"%' ";
					main = main+q2;
				}
				else{
					String q2 = "co.mobileno like '%"+mob+"%' ";
					main = main+q2;
				}
				
			}
			if(land!=null){
				if(mid!=0||name!=null||mob!=null){
					main = main+and;
					String q3 = "co.landlineno like '%"+land+"%' ";
					main = main+q3;
				}
				else{
					String q3 = "co.landlineno like '%"+land+"%' ";
					main = main+q3;
				}
				
			}
			if(year1!=0){
				if(mid!=0||name!=null||mob!=null||land!=null){
					main = main+and;
					String q3 = "YEAR(pr.dob)>= '"+year2+"' and YEAR(pr.dob)<= '"+year1+"' ";
					main = main+q3;
				}
				else{
					String q3 = "YEAR(pr.dob)>= '"+year2+"' and YEAR(pr.dob)<= '"+year1+"' ";
					main = main+q3;
				}
				
			}
			
		List query = session.createQuery(main).list();	
		/*List query = session.createQuery("select new ContactsBean(pr.name,pr.memberid) from ContactsBean co " +
				                         "join co.profile pr " +
				                         "where pr.memberid like '"+midd+"' " +
				                         "and pr.name like '"+name+"' " +
				                         "and co.mobileno like '"+mob+"' " +
				                         "and co.landlineno like '"+land+"' " +
				                         "and YEAR(pr.dob)>= '"+year2+"' " +
				                         "and YEAR(pr.dob)<= '"+year1+"'").list();*/
		System.out.println("List======query=====> "+query);
		for (Iterator it = query.iterator(); it.hasNext();) {
			
			contactbean = (ContactsBean) it.next();
			System.out.println("selectionbean======member name=====> "+contactbean.getMembername());
			ser.add(contactbean);
		}
		}
		catch(Exception e){
			System.out.println("ERORRRRRRRR=======>"+e);
		}
		return ser;
	}
}
