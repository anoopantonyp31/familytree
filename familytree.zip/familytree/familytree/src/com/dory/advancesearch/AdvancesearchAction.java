package com.dory.advancesearch;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.contact.ContactsBean;
import com.dory.hibernate.HibernateUtil;
import com.dory.memberprofile.ProfileBean;

public class AdvancesearchAction extends Action{

	public ActionForward execute(ActionMapping mapping,ActionForm form,
			     HttpServletRequest request,HttpServletResponse response)
	   throws IOException,ServletException{
		
		String target="failure";
		Session session=HibernateUtil.getSessionFactory().openSession();
		AdvancesearchForm advancesearch = (AdvancesearchForm)form;
		ProfileBean profilebean = new ProfileBean();
		ContactsBean contactbean = new ContactsBean();
		Collection ser = new ArrayList();
		int mid=0;
		String ag=null;
		int age1=0,age2=0,year=0,yr1=0,yr2=0;
		
		AdvancesearchDAO advancesearchDAO = new AdvancesearchDAOImpl();
		
		try{
			
		System.out.println("Inside try-------------");
		//............................WHEN THE VALUE IS MOB NO..................................
		if("Mobile no".equals(advancesearch.getMember1()))
		{
			System.out.println("Inside if loop--------mob no-----------");
			contactbean.setMobileno(advancesearch.getMember11());
			
			if("Member name".equals(advancesearch.getMember2())){
				System.out.println("Inside member name======2222222222==");
			    profilebean.setName(advancesearch.getMember22());
			    }
			    else if("Land no".equals(advancesearch.getMember2())){
			    	System.out.println("Inside land name======2222222222==");
				contactbean.setLandlineno(advancesearch.getMember22());
			    }
			    else if("Age".equals(advancesearch.getMember2())){
			    	System.out.println("Inside age limit======2222222222==");
				ag=advancesearch.getMember22();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember222();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
			
			
			if("Member name".equals(advancesearch.getMember3())){
				System.out.println("Inside member name======333333333333==");
				profilebean.setName(advancesearch.getMember33());
				}
				else if("Land no".equals(advancesearch.getMember3())){
					System.out.println("Inside land no======333333333333==");
					contactbean.setLandlineno(advancesearch.getMember33());
				}
				else if("Age".equals(advancesearch.getMember3())){
			    	System.out.println("Inside age limit======33333333333==");
				ag=advancesearch.getMember33();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember333();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
			
			
			if("Member name".equals(advancesearch.getMember4())){
				System.out.println("Inside member name======444444444444==");
				profilebean.setName(advancesearch.getMember44());
				}
				else if("Land no".equals(advancesearch.getMember4())){
					System.out.println("Inside land no======4444444444444==");
					contactbean.setLandlineno(advancesearch.getMember44());
				}
				else if("Age".equals(advancesearch.getMember4())){
			    	System.out.println("Inside age limit======444444444444==");
				ag=advancesearch.getMember44();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember444();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
			
			ser = advancesearchDAO.display(session,profilebean,contactbean,mid,yr1,yr2);
			if(ser.size()>0){
				System.out.println("Inside collection if===================");
				request.setAttribute("ser",ser);
			}
			else{
				System.out.println("Inside collection else if===================");
				request.setAttribute("fail", ser);
			}
			String valueset = request.getParameter("value");
			if("120".equals(valueset))
			{
				System.out.println("in if loooppppppppp==="+valueset);
				target="ddd";
			}
			else if("111".equals(valueset))
			{
			target="success";
			}
		}
		
		
		//.........................WHEN THE VALUE IS LAND NO..................................
		if("Land no".equals(advancesearch.getMember1()))
		{
			System.out.println("Inside if loop--------land no-----------");
			contactbean.setLandlineno(advancesearch.getMember11());
			
			
			if("Member name".equals(advancesearch.getMember2())){
				System.out.println("Inside member name=====2222222222222===");
				profilebean.setName(advancesearch.getMember22());
			    }
			    else if("Mobile no".equals(advancesearch.getMember2())){
			    	System.out.println("Inside mob no=====2222222222222===");
				contactbean.setMobileno(advancesearch.getMember22());
			    }
			    else if("Age".equals(advancesearch.getMember2())){
			    	System.out.println("Inside age limit======2222222222==");
				ag=advancesearch.getMember22();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember222();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
			
			if("Member name".equals(advancesearch.getMember3())){
				System.out.println("Inside member name======33333333333==");
				profilebean.setName(advancesearch.getMember33());
			    }
				else if("Mobile no".equals(advancesearch.getMember3())){
					System.out.println("Inside mob no=====33333333333333===");
					contactbean.setMobileno(advancesearch.getMember33());
				}
				else if("Age".equals(advancesearch.getMember3())){
			    	System.out.println("Inside age limit======33333333333==");
				ag=advancesearch.getMember33();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember333();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
				
			  
			if("Member name".equals(advancesearch.getMember4())){
				System.out.println("Inside member name=======444444444=");
				profilebean.setName(advancesearch.getMember44());
			    }
				else if("Mobile no".equals(advancesearch.getMember4())){
					System.out.println("Inside mob no=====444444444===");
					contactbean.setMobileno(advancesearch.getMember44());
				}
				else if("Age".equals(advancesearch.getMember4())){
			    	System.out.println("Inside age limit======444444444444==");
				ag=advancesearch.getMember44();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember444();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
				
			ser = advancesearchDAO.display(session,profilebean,contactbean,mid,yr1,yr2);
			if(ser.size()>0){
				System.out.println("Inside collection if===================");
				request.setAttribute("ser",ser);
			}
			else{
				System.out.println("Inside collection else if===================");
				request.setAttribute("fail", ser);
			}
			String valueset = request.getParameter("value");
			if("120".equals(valueset))
			{
				System.out.println("in if loooppppppppp==="+valueset);
				target="ddd";
			}
			else if("111".equals(valueset))
			{
			target="success";
			}
		}
		
		
		//.........................WHEN THE VALUE IS MEMBER NAME..............................
		if("Member name".equals(advancesearch.getMember1()))
		{
			System.out.println("Inside if loop--------member name-----------");
			profilebean.setName(advancesearch.getMember11());
			
			if("Land no".equals(advancesearch.getMember2())){
				System.out.println("Inside land no=====2222222===");
				contactbean.setLandlineno(advancesearch.getMember22());
			    }
			    else if("Mobile no".equals(advancesearch.getMember2())){
			    	System.out.println("Inside mob no=====2222222===");
				contactbean.setMobileno(advancesearch.getMember22());
			    }
			    else if("Age".equals(advancesearch.getMember2())){
			    	System.out.println("Inside age limit======2222222222==");
				ag=advancesearch.getMember22();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember222();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
			
			if("Land no".equals(advancesearch.getMember3())){
				System.out.println("Inside land no======3333333==");
					contactbean.setLandlineno(advancesearch.getMember33());
				}
				else if("Mobile no".equals(advancesearch.getMember3())){
					System.out.println("Inside mob no======3333333==");
					contactbean.setMobileno(advancesearch.getMember33());
				}
				else if("Age".equals(advancesearch.getMember3())){
			    	System.out.println("Inside age limit======33333333333==");
				ag=advancesearch.getMember33();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember333();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
				
			  
			if("Land no".equals(advancesearch.getMember4())){
				System.out.println("Inside land no======44444444==");
				contactbean.setLandlineno(advancesearch.getMember44());
			    }
				else if("Mobile no".equals(advancesearch.getMember4())){
					System.out.println("Inside mob no======44444444==");
					contactbean.setMobileno(advancesearch.getMember44());
				}
				else if("Age".equals(advancesearch.getMember4())){
			    	System.out.println("Inside age limit======444444444444==");
				ag=advancesearch.getMember44();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember444();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
			
			ser = advancesearchDAO.display(session,profilebean,contactbean,mid,yr1,yr2);
			if(ser.size()>0){
				System.out.println("Inside collection if===================");
				request.setAttribute("ser",ser);
			}
			else{
				System.out.println("Inside collection else if===================");
				request.setAttribute("fail", ser);
			}
			String valueset = request.getParameter("value");
			if("120".equals(valueset))
			{
				System.out.println("in if loooppppppppp==="+valueset);
				target="ddd";
			}
			else if("111".equals(valueset))
			{
			target="success";
			}
		}
		
		
		//.........................WHEN THE VALUE IS MEMBER ID..................................
		if("Member id".equals(advancesearch.getMember1()))
		{
			System.out.println("Inside if loop--------member id-----------");
			mid = Integer.parseInt(advancesearch.getMember11());
			
			
			if("Member name".equals(advancesearch.getMember2())){
				System.out.println("Inside member name======222222222==");
			    profilebean.setName(advancesearch.getMember22());
			    }
			    else if("Mobile no".equals(advancesearch.getMember2())){
			    	System.out.println("Inside mob no=====2222222222222===");
				contactbean.setMobileno(advancesearch.getMember22());
			    }
			    else if("Land no".equals(advancesearch.getMember2())){
			    	System.out.println("Inside land no=====2222222222222===");
				contactbean.setLandlineno(advancesearch.getMember22());
			    }
			    else if("Age".equals(advancesearch.getMember2())){
			    	System.out.println("Inside age limit======2222222222==");
				ag=advancesearch.getMember22();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember222();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
			
			
			if("Member name".equals(advancesearch.getMember3())){
				System.out.println("Inside member name=====3333333333===");
				profilebean.setName(advancesearch.getMember33());
				}
				else if("Mobile no".equals(advancesearch.getMember3())){
					System.out.println("Inside mob no=====333333333===");
					contactbean.setMobileno(advancesearch.getMember33());
				}
				else if("Land no".equals(advancesearch.getMember3())){
					System.out.println("Inside land no=====333333333===");
					contactbean.setLandlineno(advancesearch.getMember33());
				}
				else if("Age".equals(advancesearch.getMember3())){
			    	System.out.println("Inside age limit======33333333333==");
				ag=advancesearch.getMember33();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember333();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
			
			
			if("Member name".equals(advancesearch.getMember4())){
				System.out.println("Inside member name=====444444444444===");
				profilebean.setName(advancesearch.getMember44());
				}
				else if("Mobile no".equals(advancesearch.getMember4())){
					System.out.println("Inside mob no=====444444444444===");
					contactbean.setMobileno(advancesearch.getMember44());
				}
				else if("Land no".equals(advancesearch.getMember4())){
					System.out.println("Inside land no=====444444444444===");
					contactbean.setLandlineno(advancesearch.getMember44());
				}
				else if("Age".equals(advancesearch.getMember4())){
			    	System.out.println("Inside age limit======444444444444==");
				ag=advancesearch.getMember44();
				age1 = Integer.parseInt(ag);
				age2 = advancesearch.getMember444();
				Calendar cal = Calendar.getInstance();
				year = cal.get(Calendar.YEAR);
				yr1 = year-age1;
				yr2 = year-age2;
				
			    }
			
			ser = advancesearchDAO.display(session,profilebean,contactbean,mid,yr1,yr2);
			if(ser.size()>0){
				System.out.println("Inside collection if===================");
				request.setAttribute("ser",ser);
			}
			else{
				System.out.println("Inside collection else if===================");
				request.setAttribute("fail", ser);
			}
			String valueset = request.getParameter("value");
			if("120".equals(valueset))
			{
				System.out.println("in if loooppppppppp==="+valueset);
				target="ddd";
			}
			else if("111".equals(valueset))
			{
			target="success";
			}
		}
		
		//....................WHEN THE VALUE IS AGE LIMIT.........................
		if("Age".equals(advancesearch.getMember1()))
		{
			System.out.println("Inside if loop--------age limit-----------");
			ag=advancesearch.getMember11();
			age1 = Integer.parseInt(ag);
			age2 = advancesearch.getMember111();
			Calendar cal = Calendar.getInstance();
			year = cal.get(Calendar.YEAR);
			yr1 = year-age1;
			yr2 = year-age2;
			System.out.println("The value of--------year1-----------"+yr1);
			System.out.println("The value of--------year2-----------"+yr2);
			
			if("Member name".equals(advancesearch.getMember2())){
				System.out.println("Inside member name=====2222222222222===");
				profilebean.setName(advancesearch.getMember22());
			    }
			    else if("Mobile no".equals(advancesearch.getMember2())){
			    	System.out.println("Inside mob no=====2222222222222===");
				contactbean.setMobileno(advancesearch.getMember22());
			    }
			    else if("Land no".equals(advancesearch.getMember2())){
			    	System.out.println("Inside land no=====2222222222222===");
				contactbean.setLandlineno(advancesearch.getMember22());
			    }
			
			if("Member name".equals(advancesearch.getMember3())){
				System.out.println("Inside member name======33333333333==");
				profilebean.setName(advancesearch.getMember33());
			    }
				else if("Mobile no".equals(advancesearch.getMember3())){
					System.out.println("Inside mob no=====33333333333333===");
					contactbean.setMobileno(advancesearch.getMember33());
				}
				else if("Land no".equals(advancesearch.getMember3())){
					System.out.println("Inside land no=====333333333===");
					contactbean.setLandlineno(advancesearch.getMember33());
				}
				
			  
			if("Member name".equals(advancesearch.getMember4())){
				System.out.println("Inside member name=======444444444=");
				profilebean.setName(advancesearch.getMember44());
			    }
				else if("Mobile no".equals(advancesearch.getMember4())){
					System.out.println("Inside mob no=====444444444===");
					contactbean.setMobileno(advancesearch.getMember44());
				}
				else if("Land no".equals(advancesearch.getMember4())){
					System.out.println("Inside land no=====444444444444===");
					contactbean.setLandlineno(advancesearch.getMember44());
				}
				
			ser = advancesearchDAO.display(session,profilebean,contactbean,mid,yr1,yr2);
			if(ser.size()>0){
				System.out.println("Inside collection if===================");
				request.setAttribute("ser",ser);
			}
			else{
				System.out.println("Inside collection else if===================");
				request.setAttribute("fail", ser);
			}
			String valueset = request.getParameter("value");
			if("120".equals(valueset))
			{
				System.out.println("in if loooppppppppp==="+valueset);
				target="ddd";
			}
			else if("111".equals(valueset))
			{
			target="success";
			}
		}
		
		
		
		}
		catch(Exception e){
			System.out.println("Exceptionnnnnnnnn=========>"+e);
		}
		
		
		
		return mapping.findForward(target);
	}
}
