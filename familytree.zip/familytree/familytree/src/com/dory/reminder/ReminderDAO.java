package com.dory.reminder;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Session;

public interface ReminderDAO {
	public boolean insert(Session session, ReminderBean reminderBean);
	public Collection displayreminds(Session session,ReminderBean reminderBean,int uid,String dt);
	public boolean update(Session session, ReminderBean reminderBean);
	public boolean delete(Session session, ReminderBean reminderBean);
	public Collection detailedremind(Session session,ReminderBean reminderBean,int uid);
}
