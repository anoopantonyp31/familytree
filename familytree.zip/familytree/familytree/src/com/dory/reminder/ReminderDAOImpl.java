package com.dory.reminder;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Date;
import org.hibernate.Session;

import com.dory.community.CommunitymemberBean;
import com.dory.mygroup.MygroupBean;

public class ReminderDAOImpl implements ReminderDAO {

	public boolean insert(Session session, ReminderBean reminderBean) {
		session.beginTransaction();
		session.save(reminderBean);
		session.getTransaction().commit();
		return true;
	}
	public boolean update(Session session, ReminderBean reminderBean) {
		session.beginTransaction();
		session.update(reminderBean);
		session.getTransaction().commit();
		return true;
	}
	public boolean delete(Session session, ReminderBean reminderBean) {
		session.beginTransaction();
		session.delete(reminderBean);
		session.getTransaction().commit();
		return true;
	}
	public Collection displayreminds(Session session,ReminderBean reminderBean,int uid,String dateNow) {

		Collection executivecol = new ArrayList();
		try {
			System.out.println("session======displayreminds=====>"+session);	
			List query = session.createSQLQuery("select * from member_reminders rs where memberid='"+uid+"' and status='unread' and reminderstartingdate>='"+dateNow+"' and eventdate<='"+reminderBean.getEventdate()+"'").addEntity("rs",ReminderBean.class).list();
			   System.out.println("=====query for displayreminds======="+query);
			for (Iterator it = query.iterator(); it.hasNext();) 
			{
				System.out.println("=====in displayreminds iterator=====> ");	
				reminderBean = (ReminderBean) it.next();
				executivecol.add(reminderBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return executivecol;
	}
	
	public Collection detailedremind(Session session,ReminderBean reminderBean,int remid) {

		Collection detailrem = new ArrayList();
		try {
			System.out.println("session======detailedremind=====>"+session);	
			List query = session.createSQLQuery("select * from member_reminders ds where reminderid='"+remid+"'").addEntity("ds",ReminderBean.class).list();
			   System.out.println("=====query for detailedremind======="+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in detailedremind iterator=====> ");	
				reminderBean = (ReminderBean) it.next();
				detailrem.add(reminderBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return detailrem;
	}
	
	public Collection allreminds(Session session,ReminderBean reminderBean,int uid) 
	{

		Collection allremindscol = new ArrayList();
		try {
			System.out.println("session======allreminds=====>"+session);	
			List query = session.createSQLQuery("select * from member_reminders rs where memberid='"+uid+"'").addEntity("rs",ReminderBean.class).list();
			   System.out.println("=====query for allreminds======="+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in allreminds iterator=====> ");	
				reminderBean = (ReminderBean) it.next();
				allremindscol.add(reminderBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return allremindscol;
	}
	public Collection edit(Session session,ReminderBean reminderBean,int b) 
	{

		Collection allreminds = new ArrayList();
		try {
			System.out.println("session======allreminds=====>"+session);	
			List query = session.createSQLQuery("select * from member_reminders rs where reminderid='"+b+"'").addEntity("rs",ReminderBean.class).list();
			   System.out.println("=====query for allreminds======="+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in allreminds iterator=====> ");	
				reminderBean = (ReminderBean) it.next();
				allreminds.add(reminderBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return allreminds;
	}
	//johnson
	public Collection allreminds1(Session session,ReminderBean reminderBean,int id) 
	{

		Collection detailremj = new ArrayList();
		try {
			System.out.println("session======allreminds=====>"+session);	
			List query = session.createSQLQuery("select * from member_reminders rs where reminderid='"+id+"'").addEntity("rs",ReminderBean.class).list();
			   System.out.println("=====query for allreminds======="+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in allreminds iterator=====> ");	
				reminderBean = (ReminderBean) it.next();
				detailremj.add(reminderBean);
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return detailremj;
	}
	//resume
	public ReminderBean allremindsresume(Session session,ReminderBean reminderBean,int remid) 
	{

		Collection detailremresume = new ArrayList();
		try {
			System.out.println("session======allreminds=====>"+session);	
			List query = session.createSQLQuery("select * from member_reminders rs where reminderid='"+remid+"'").addEntity("rs",ReminderBean.class).list();
			   System.out.println("=====query for allreminds======="+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in allreminds iterator=====> ");	
				reminderBean = (ReminderBean) it.next();				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		//session.close();
		return reminderBean;
	}	
}
