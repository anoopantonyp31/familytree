package com.dory.reminder;
import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

public class ReminderAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
				String s=request.getParameter("action");
				System.out.print("===in=====reminderAction====="+s);
				ReminderActionForm remainderActionForm = (ReminderActionForm) form;
				ReminderBean reminderBean = new ReminderBean();
				ReminderDAOImpl daoImpl=new ReminderDAOImpl();
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
	        	System.out.println("session======111111=====>" + session);
	        	HttpSession session1=request.getSession();
	        	int uid=Integer.parseInt(""+session1.getAttribute("mid"));
	        	Calendar cal=Calendar.getInstance();
	        	Date dt=cal.getTime();
	        	System.out.println("date============"+dt);
	        	SimpleDateFormat formatter=  new SimpleDateFormat("yyyy-MM-dd");
	        	String dateNow = formatter.format(cal.getTime());
	        	System.out.println("========String date============"+dateNow);
	        	
				
				
				if(s.equals("insert"))
				{
				System.out.println("=======in insert========");
				Date fromdate=new SimpleDateFormat("dd-MM-yyyy").parse(remainderActionForm.getFromdate());
				reminderBean.setReminderstartingdate(fromdate);
				System.out.println("from date========"+fromdate);
				reminderBean.setMemberid(uid);
				reminderBean.setRemindertext(remainderActionForm.getData());
				
				System.out.println("========tooo date============"+remainderActionForm.getTodate());
				Date todate=new SimpleDateFormat("dd-MM-yyyy").parse(remainderActionForm.getTodate());
				reminderBean.setEventdate(todate);
				reminderBean.setStatus("unread");
				System.out.println("to date========"+todate);
				daoImpl.insert(session, reminderBean);
				target ="success";
			   }
				if(s.equals("view"))
				{
					System.out.println("<<<<<<<====in view========>>>>>>>");
					System.out.println("date====in viewwwwwwww========"+dateNow);
					Collection rem=daoImpl.displayreminds(session, reminderBean,uid,dateNow);
					request.setAttribute("rem", rem);
					target ="success";
				}
				if(s.equals("viewall"))
				{
					System.out.println("<<<<<<<====in viewalllllll========>>>>>>>");
					System.out.println("date====in viewwwwwwww========"+dateNow);
					Collection allrem=daoImpl.allreminds(session, reminderBean, uid);
					request.setAttribute("allrem", allrem);
					target ="detailedrem";
				}
				if(s.equals("detailview"))
						{
					System.out.println("<<<<<<<====in detailview========>>>>>>>");
					String rem=request.getParameter("remid");
					int remid=Integer.parseInt(rem);
					System.out.print("===in=====reminderID====="+remid);
					Collection detailedrem=daoImpl.detailedremind(session, reminderBean, remid);
					request.setAttribute("detailedrem", detailedrem);
					target ="detailedrem";
					
						}
				//johnson
				if(s.equals("pause"))
				{
					System.out.println("=====in pause======");					
					String p=request.getParameter("s");
					int remid=Integer.parseInt(p);					
					reminderBean.setReminderid(remid);
					System.out.println("======reminderid in pause======"+remid);					
					reminderBean=daoImpl.allremindsresume(session,reminderBean,remid);
					System.out.println("======reminderid in resume======"+reminderBean.getReminderid());
					reminderBean.setStatus("read");
					daoImpl.update(session, reminderBean);
					//Collection detailedrem=daoImpl.displayreminds(session,reminderBean,uid,dateNow);
					Collection allrem=daoImpl.allreminds(session, reminderBean, uid);
					//request.setAttribute("detailedrem", detailedrem);
					request.setAttribute("allrem", allrem);
					target ="detailedrem";
				}
				//johnson
				if(s.equals("resume"))
				{
					System.out.println("=====in resume======");
					String p=request.getParameter("t");
					int remid=Integer.parseInt(p);					
					reminderBean.setReminderid(remid);
					reminderBean=daoImpl.allremindsresume(session,reminderBean,remid);
					System.out.println("======reminderid in resume======"+reminderBean.getReminderid());
					reminderBean.setStatus("unread");
					daoImpl.update(session, reminderBean);
					//Collection detailedrem=daoImpl.displayreminds(session,reminderBean,uid,dateNow);
					Collection allrem=daoImpl.allreminds(session, reminderBean, uid);
					//request.setAttribute("detailedrem", detailedrem);
					request.setAttribute("allrem", allrem);
					target ="detailedrem";
				}
				if(s.equals("delete"))
				{
					System.out.println("=====in delete======");
					String del[]=request.getParameterValues("remdel");
					System.out.println("======DELETE LENGTH======"+del.length);
					for(int i=0;i<del.length;i++)
					{						
						int remid=Integer.parseInt(del[i]);
						System.out.println("======in delete for====="+remid);
						reminderBean.setReminderid(remid);
						daoImpl.delete(session, reminderBean);
					}
			     	Collection allrem=daoImpl.allreminds(session, reminderBean, uid);
					request.setAttribute("allrem", allrem);
					target ="detailedrem";
				}
				//johnson
				if(s.equals("edit"))
				{
					int a[]= remainderActionForm.getRemdel();					
					for(int i=0;i<a.length;i++)
					{
						System.out.println("IN THE LOOP+++++++++++++++++++"+a[i]);
					  
						/* delete district name */	
					    System.out.println("CHECKBOXID======================================================="+a[i]);
					    int b = a[i];
					    System.out.println("CHECKBOXID==============bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"+b);					    
					    Collection allreminds = daoImpl.edit(session,reminderBean,b);
						if(allreminds.size()>0)
						{
							System.out.println("in district.size>0=====>"+allreminds.size());
						    for (Iterator iterator = allreminds.iterator(); iterator.hasNext();) 
					    	    { 
						    	reminderBean = (ReminderBean) iterator.next();
					    		}
						    remainderActionForm.setReminderid(reminderBean.getReminderid());
						    System.out.println("dataid======"+remainderActionForm.getReminderid());
						   remainderActionForm.setData(reminderBean.getRemindertext());
						   
						    System.out.println("data======"+remainderActionForm.getRemindertext());
						    remainderActionForm.setMemberid(reminderBean.getMemberid());
						   System.out.println("memberid====="+remainderActionForm.getMemberid());
						    request.setAttribute("allremindscol", allreminds);
						    request.setAttribute("add", "add");
						}
					      }			
					target="edit";
						
					}
				//johnson
				if(s.equals("update"))
				{
					//reminder id
					String w=request.getParameter("t");
					System.out.println("reminder id========="+w);
					int id=Integer.parseInt(w);
					reminderBean.setReminderid(id);
					System.out.println("Bean reminder id========="+reminderBean.getReminderid());
					//reminder Text					
					String r=request.getParameter("databox");
					System.out.println("reminder text========="+r);			
					reminderBean.setRemindertext(r);
					//member id
					String p=request.getParameter("chkd");
					int mid=Integer.parseInt(p);
					reminderBean.setMemberid(mid);
					String gg="unread";
					reminderBean.setStatus(gg);
					//from date
					String frmdt=request.getParameter("frmdat");
					System.out.println("date11111111111111========="+frmdt);
					Date fromdate=new SimpleDateFormat("dd-MM-yyyy").parse(frmdt);
					reminderBean.setReminderstartingdate(fromdate);
					System.out.println("reminder s date========="+reminderBean.getReminderstartingdate());	
					//to Date
					String tdat=request.getParameter("todt");
					System.out.println(" to date11111111111111111111========="+tdat);
					
					Date todate=new SimpleDateFormat("dd-MM-yyyy").parse(tdat);
					System.out.println(" converted========="+todate);
					reminderBean.setEventdate(todate);
					System.out.println("reminder e datet========="+reminderBean.getEventdate());
					//System.out.println("member id========="+reminderBean.getMemberid());					
					
					//System.out.println("Exception id========="+remainderActionForm.getRemindertext());					 
					 
					daoImpl.update(session,reminderBean);
					Collection allrem=daoImpl.allreminds(session, reminderBean, uid);
					request.setAttribute("allrem", allrem);
					target ="detailedrem";
					
				}
				if(s.equals("display"))
				{
			   System.out.println("<<<<<<<====in detailview========>>>>>>>");
			   request.setAttribute("update","update");
			   target ="display";
				}
			
				}
			
		}
			catch (Exception e) 
			{
			System.out.println("Exception====in remainderAction======>  "+e);
			}

		return (mapping.findForward(target));
		}
			
}
