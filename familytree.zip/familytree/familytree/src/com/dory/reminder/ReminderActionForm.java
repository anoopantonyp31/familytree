package com.dory.reminder;

import java.util.Date;

import org.apache.struts.action.ActionForm;

public class ReminderActionForm extends ActionForm {

	 private String data;
	 private String todate;
	 private String fromdate;
	 private int hiddenid;
	 private int hiddenmemid;
	 private String hiddentext;
	 private String hiddeneventdate;
	 private String hiddenstartingdate;
	 //edit
	 private int remdel[];
	 private int reminderid;
	 private int memberid;	
	 private Date eventdate;
	 private Date reminderstartingdate;
	 private String status;
	 private String remindertext;
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}
	public void setTodate(String todate) {
		this.todate = todate;
	}
	public String getTodate() {
		return todate;
	}
	public void setHiddenid(int hiddenid) {
		this.hiddenid = hiddenid;
	}
	public int getHiddenid() {
		return hiddenid;
	}
	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}
	public String getFromdate() {
		return fromdate;
	}
	public void setHiddenmemid(int hiddenmemid) {
		this.hiddenmemid = hiddenmemid;
	}
	public int getHiddenmemid() {
		return hiddenmemid;
	}
	public void setHiddentext(String hiddentext) {
		this.hiddentext = hiddentext;
	}
	public String getHiddentext() {
		return hiddentext;
	}
	public void setHiddeneventdate(String hiddeneventdate) {
		this.hiddeneventdate = hiddeneventdate;
	}
	public String getHiddeneventdate() {
		return hiddeneventdate;
	}
	public void setHiddenstartingdate(String hiddenstartingdate) {
		this.hiddenstartingdate = hiddenstartingdate;
	}
	public String getHiddenstartingdate() {
		return hiddenstartingdate;
	}
	public void setReminderid(int reminderid) {
		this.reminderid = reminderid;
	}
	public int getReminderid() {
		return reminderid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}	
	public void setEventdate(Date eventdate) {
		this.eventdate = eventdate;
	}
	public Date getEventdate() {
		return eventdate;
	}
	public void setReminderstartingdate(Date reminderstartingdate) {
		this.reminderstartingdate = reminderstartingdate;
	}
	public Date getReminderstartingdate() {
		return reminderstartingdate;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setRemdel(int remdel[]) {
		this.remdel = remdel;
	}
	public int[] getRemdel() {
		return remdel;
	}
	public void setRemindertext(String remindertext) {
		this.remindertext = remindertext;
	}
	public String getRemindertext() {
		return remindertext;
	}
		
	
}
