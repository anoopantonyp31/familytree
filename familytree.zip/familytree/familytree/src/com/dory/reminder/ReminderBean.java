package com.dory.reminder;
import java.util.Date;

public class ReminderBean {

	 private int reminderid;
	 private int memberid;
	 private String remindertext;
	 private Date eventdate;
	 private Date reminderstartingdate;
	 private String status;
	 
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setReminderid(int reminderid) {
		this.reminderid = reminderid;
	}
	public int getReminderid() {
		return reminderid;
	}
	public void setRemindertext(String remindertext) {
		this.remindertext = remindertext;
	}
	public String getRemindertext() {
		return remindertext;
	}
	public void setReminderstartingdate(Date reminderstartingdate) {
		this.reminderstartingdate = reminderstartingdate;
	}
	public Date getReminderstartingdate() {
		return reminderstartingdate;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setEventdate(Date eventdate) {
		this.eventdate = eventdate;
	}
	public Date getEventdate() {
		return eventdate;
	}
	
	
}
