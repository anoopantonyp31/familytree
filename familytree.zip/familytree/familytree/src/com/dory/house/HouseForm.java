package com.dory.house;

import org.apache.struts.action.ActionForm;

public class HouseForm extends ActionForm{

	
	 private String housename;
	 private String city ;
	 private String address ;
	 private String remark;
	 private String status;
	 private int houseid;
	 private int memberid;
	 
	 

	 private int publicorprivate;
	 private int community;
	 private int groups;
	 private int family;
	
	 public void setHousename(String housename) {
		this.housename = housename;
	}
	public String getHousename() {
		return housename;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setHouseid(int houseid) {
		this.houseid = houseid;
	}
	public int getHouseid() {
		return houseid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCity() {
		return city;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	public void setCommunity(int community) {
		this.community = community;
	}
	public int getCommunity() {
		return community;
	}
	public void setGroups(int groups) {
		this.groups = groups;
	}
	public int getGroups() {
		return groups;
	}
	public void setFamily(int family) {
		this.family = family;
	}
	public int getFamily() {
		return family;
	}
}
