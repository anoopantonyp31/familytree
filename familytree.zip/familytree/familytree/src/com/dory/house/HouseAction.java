package com.dory.house;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.aboutme.AboutDAOImpl;
import com.dory.aboutme.AboutForm;
import com.dory.hibernate.HibernateUtil;

public class HouseAction extends Action {

	

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//used to get the action value
					String k = request.getParameter("action");
					
				HouseForm houseForm = (HouseForm) form;
				HouseBean houseBean = new HouseBean();
				
               HttpSession httpsession = request.getSession();
                
				//BeanUtils.copyProperties(houseBean, houseForm);
			
				houseBean.setAddress(houseForm
						.getAddress());
			
				houseBean.setCity(houseForm.getCity());
				
				houseBean.setHouseid(houseForm.getHouseid());
				houseBean.setHousename(houseForm.getHousename());
				houseBean.setRemark(houseForm.getRemark());
				houseBean.setStatus(houseForm.getStatus());
				
				
				
				Session session = HibernateUtil.getSessionFactory()
						.openSession();
				System.out.println("session======111111=====>" + session);
				
				//to get the session from the login action
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	            // aboutBean.setMemberid(q);
	            
				
				
				
				
				HouseDAOImpl houseDAO = new HouseDAOImpl();
				
				//if value of action=insert then enters below statement
				//function to insert the data from aboutme.jsp into about_member tables 
				if ("update".equals(k)) 
				{
					houseBean.setAddress(houseForm
							.getAddress());
				
					houseBean.setCity(houseForm.getCity());
					
					//houseBean.setHouseid(houseForm.getHouseid());
					System.out.println("houseiiiiiiiiiiiidddddddddddd==="+houseForm.getHouseid());
					houseBean.setHousename(houseForm.getHousename());
					houseBean.setRemark(houseForm.getRemark());
					houseBean.setStatus(houseForm.getStatus());
					//houseBean.setHouseid(houseForm.getHouseid());
					int houseid=Integer.parseInt(request.getParameter("houseid"));
					houseBean.setHouseid(houseid);
					System.out.println("houseiiiiiiiiiiiidddddddddddd========="+houseBean.getHouseid());
					System.out.println("housenamnmmmmmmmmmeee=========="+houseBean.getHousename());
					System.out.println("housenaaaaaaddrrrresss==========="+houseBean.getAddress());
					//*********************visibility part***********************//
					//--------------------------------------
					int privateorprivate1=houseForm.getPublicorprivate();
					
					int family=houseForm.getFamily();
					int groups=houseForm.getGroups();
					int community=houseForm.getCommunity();
					
					
					
					String privateorprivate2 = String.valueOf(privateorprivate1);
							
					
					if("1".equals(privateorprivate2))
					{
						//String visibility=privateorprivate1+"0"+"0"+"0";
						String visibility="8";
						System.out.println("===========in public======="+visibility);
						houseBean.setVisibility(visibility);
					}
					if("0".equals(privateorprivate2))
					{
						//String visibility=privateorprivate1+"0"+"0"+"0";
						String visibility="0";
						System.out.println("===========in public======="+visibility);
						houseBean.setVisibility(visibility);
					}
					
					if("500".equals(privateorprivate2))
					{
					String family2 = String.valueOf(family);
					String groups2 = String.valueOf(groups);
					String community2 = String.valueOf(community);
					
					 
						if("0".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
						{
							//String visibility="0"+"0"+"0"+"0";
							String visibility="0";
							System.out.println("===========1111111======="+visibility);
							houseBean.setVisibility(visibility);
						}
						
						else if("0".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
						{
							String visibility="1";
							System.out.println("===========222222======="+visibility);
							houseBean.setVisibility(visibility);
						}
						
						else if("1".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
						{
							String visibility="2";
							System.out.println("===========3333333======="+visibility);
							houseBean.setVisibility(visibility);
						}
						
						else if("1".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
						{
							String visibility="3";
							System.out.println("===========44444444======="+visibility);
							houseBean.setVisibility(visibility);
						}
						
						
						else if("0".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
						{
							String visibility="4";
							System.out.println("===========666666666======="+visibility);
							houseBean.setVisibility(visibility);
						}
						
						
						else if("0".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
						{
							String visibility="5";
							System.out.println("===========7777777======="+visibility);
							houseBean.setVisibility(visibility);
						}
						
						
						else if("1".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
						{
							String visibility="6";
							System.out.println("===========8888888======="+visibility);
							houseBean.setVisibility(visibility);
						}
						
						
						else if("1".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
						{
							String visibility="7";
							System.out.println("===========99999999======="+visibility);
							houseBean.setVisibility(visibility);
						}
						
						
					}
					
					//*********************visibility part***********************//
					
				
										System.out.println("inside insert");
						//houseDAO.insert(session, houseBean);
						houseDAO.update(session,houseBean);
						target="correct";
						
				}
				
				
				else if ("display".equals(k)) 
				{
							
					System.out.println("Inside uusddddddddddddisplayuuuu house");
					houseBean = houseDAO.displayhousedetails(session,houseBean,q);
					System.out.println("In bean nammmmmmmmmmmmmmmmmmmm========"+houseBean.getHousename());
					
					{
						
						request.setAttribute("house", houseBean);
						target = "house";
					} 
						
				}
				
				
				
				
				
				
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}
}
