package com.dory.house;

public class HouseBean {

	 private String housename;
	 private String city ;
	 private String address ;
	 private String remark;
	 private String status;
	 private int houseid;
	 private int memberid;
	 private String visibility;
	 public void setHousename(String housename) {
		this.housename = housename;
	}
	public String getHousename() {
		return housename;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setHouseid(int houseid) {
		this.houseid = houseid;
	}
	public int getHouseid() {
		return houseid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCity() {
		return city;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAddress() {
		return address;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public String getVisibility() {
		return visibility;
	}
}
