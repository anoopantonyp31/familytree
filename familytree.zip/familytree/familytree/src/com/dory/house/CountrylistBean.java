package com.dory.house;

public class CountrylistBean {

	 private String name;
	 private int countryid;
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setCountryid(int countryid) {
		this.countryid = countryid;
	}
	public int getCountryid() {
		return countryid;
	}
	
}
