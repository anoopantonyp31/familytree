package com.dory.house;

public interface HouseDAO {

}
