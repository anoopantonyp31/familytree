package com.dory.house;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.house.HouseBean;
import com.dory.memberprofile.ProfileBean;
import com.dory.proffessional.ProffessionalBean;

public class HouseDAOImpl {

	
	//insertion is being carried out in this bellow function
	public boolean insert(Session session, HouseBean houseBean) {
		session.beginTransaction();
		session.save(houseBean);
		session.getTransaction().commit();
		return true;

	}

	public boolean update(Session session, HouseBean houseBean) {
		session.beginTransaction();
		session.update(houseBean);
		session.getTransaction().commit();
		return true;

	}
	
	
	
	public HouseBean displayhousedetails(Session session,
			HouseBean houseBean,int q) {

		System.out.println("Inside     iiiiii mmmmmmmmppppppppppppppppppppppppppppppppplllll");
		Collection housecol = new ArrayList();
		try {
			HouseBean gethouseBean = new HouseBean();
			ProfileBean profileBean = new ProfileBean();
			
			List query1 = session.createSQLQuery("select * from member_profile where memberid='"+q+"' ").addEntity("ds",ProfileBean.class).list();
		  	for (Iterator it1 = query1.iterator(); it1.hasNext();)
		  	{
		  		
		  		profileBean = (ProfileBean) it1.next();
				int housid = profileBean.getHouseid();
				
				List query2 = session.createSQLQuery("select * from member_house_detail where houseid='"+housid+"' ").addEntity("ds",HouseBean.class).list();
			  	for (Iterator it2 = query2.iterator(); it2.hasNext();)
			  	{
			  		houseBean = (HouseBean) it2.next();
			  		housecol.add(houseBean);
			  	}
		  	}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return houseBean;
	}
	
	
	
}
