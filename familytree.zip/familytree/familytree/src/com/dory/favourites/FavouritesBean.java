package com.dory.favourites;

public class FavouritesBean {
	private String activities;
	private String interests;
	private String movies;
	private String tvshows;
	private String music;
	private String books;
	private String sports;
	private String remark;
	private String hobbies;
	private String visibility;
	private int favouriteid;
	private int memberid;
	public void setActivities(String activities) {
		this.activities = activities;
	}
	public String getActivities() {
		return activities;
	}
	public void setInterests(String interests) {
		this.interests = interests;
	}
	public String getInterests() {
		return interests;
	}
	public void setMovies(String movies) {
		this.movies = movies;
	}
	public String getMovies() {
		return movies;
	}
	public void setTvshows(String tvshows) {
		this.tvshows = tvshows;
	}
	public String getTvshows() {
		return tvshows;
	}
	public void setMusic(String music) {
		this.music = music;
	}
	public String getMusic() {
		return music;
	}
	public void setBooks(String books) {
		this.books = books;
	}
	public String getBooks() {
		return books;
	}
	public void setSports(String sports) {
		this.sports = sports;
	}
	public String getSports() {
		return sports;
	}
	public void setFavouriteid(int favouriteid) {
		this.favouriteid = favouriteid;
	}
	public int getFavouriteid() {
		return favouriteid;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	public String getHobbies() {
		return hobbies;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public String getVisibility() {
		return visibility;
	}

}
