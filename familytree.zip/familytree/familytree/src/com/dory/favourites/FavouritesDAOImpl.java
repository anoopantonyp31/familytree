package com.dory.favourites;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.favourites.FavouritesBean;
import com.dory.favourites.FavouritesDAO;

public class FavouritesDAOImpl implements FavouritesDAO {

	
	public boolean insert(Session session, FavouritesBean favouritesBean) {
		session.beginTransaction();
		session.save(favouritesBean);
		session.getTransaction().commit();
		return true;

	}
	
	
	public boolean update(Session session, FavouritesBean favouritesBean) {
		session.beginTransaction();
		session.update(favouritesBean);
		session.getTransaction().commit();
		return true;

	}
	
	
	public FavouritesBean displayfavdetails(Session session,
			FavouritesBean favouritesBean,int q) {

		Collection aboutcol = new ArrayList();
		try {
			List query = session.createQuery("from FavouritesBean ex where ex.memberid='"+q+"'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				favouritesBean = (FavouritesBean) it.next();
				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return favouritesBean;
	}
	
}
