package com.dory.favourites;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.aboutme.AboutDAOImpl;
import com.dory.aboutme.AboutForm;
import com.dory.hibernate.HibernateUtil;

public class FavouritesAction extends Action {


	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//String a1= request.getParameter("fromWhere");
					String k = request.getParameter("action");
					//String k1 = request.getParameter("action1");
				// Use the NameForm to get the request parameters
					FavouritesForm favouritesForm = (FavouritesForm) form;
					FavouritesBean favouritesBean = new FavouritesBean();
					Session session = HibernateUtil.getSessionFactory()
					.openSession();
					 HttpSession httpsession = request.getSession();
				//BeanUtils.copyProperties(favouritesBean, favouritesForm);
				
				

							
				
				// executiveBean.setExecutiveposid(executiveForm.getExecutiveposid());
				//String executive = aboutForm.getExecutivepos();
				//System.out.println("exe===========>" + executive);

				
				System.out.println("session======111111=====>" + session);
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             favouritesBean.setMemberid(q);
				
				
				FavouritesDAO favouritesDAO = new FavouritesDAOImpl();
				
				if ("update".equals(k)) 
				{
					favouritesBean = favouritesDAO.displayfavdetails(session,favouritesBean,q);
					favouritesBean.setActivities(favouritesForm
							.getActivities());
					
					favouritesBean.setInterests(favouritesForm.getInterests());
					
					favouritesBean.setBooks(favouritesForm.getBooks());
					favouritesBean.setHobbies(favouritesForm.getHobbies());
					favouritesBean.setMovies(favouritesForm.getMovies());
					favouritesBean.setMusic(favouritesForm.getMusic());
					
					favouritesBean.setRemark(favouritesForm.getRemark());
					favouritesBean.setSports(favouritesForm.getSports());
					favouritesBean.setTvshows(favouritesForm.getTvshows());
					
					//*********************visibility part***********************//
					//--------------------------------------
					int privateorprivate1=favouritesForm.getPublicorprivate();
					
					int family=favouritesForm.getFamily();
					int groups=favouritesForm.getGroups();
					int community=favouritesForm.getCommunity();
					
					
					
					String privateorprivate2 = String.valueOf(privateorprivate1);
							
					
					if("1".equals(privateorprivate2))
					{
						//String visibility=privateorprivate1+"0"+"0"+"0";
						String visibility="8";
						System.out.println("===========in public======="+visibility);
						favouritesBean.setVisibility(visibility);
					}
					if("0".equals(privateorprivate2))
					{
						//String visibility=privateorprivate1+"0"+"0"+"0";
						String visibility="0";
						System.out.println("===========in public======="+visibility);
						favouritesBean.setVisibility(visibility);
					}
					
					if("500".equals(privateorprivate2))
					{
					String family2 = String.valueOf(family);
					String groups2 = String.valueOf(groups);
					String community2 = String.valueOf(community);
					
					 
						if("0".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
						{
							//String visibility="0"+"0"+"0"+"0";
							String visibility="0";
							System.out.println("===========1111111======="+visibility);
							favouritesBean.setVisibility(visibility);
						}
						
						else if("0".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
						{
							String visibility="1";
							System.out.println("===========222222======="+visibility);
							favouritesBean.setVisibility(visibility);
						}
						
						else if("1".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
						{
							String visibility="2";
							System.out.println("===========3333333======="+visibility);
							favouritesBean.setVisibility(visibility);
						}
						
						else if("1".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
						{
							String visibility="3";
							System.out.println("===========44444444======="+visibility);
							favouritesBean.setVisibility(visibility);
						}
						
						
						else if("0".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
						{
							String visibility="4";
							System.out.println("===========666666666======="+visibility);
							favouritesBean.setVisibility(visibility);
						}
						
						
						else if("0".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
						{
							String visibility="5";
							System.out.println("===========7777777======="+visibility);
							favouritesBean.setVisibility(visibility);
						}
						
						
						else if("1".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
						{
							String visibility="6";
							System.out.println("===========8888888======="+visibility);
							favouritesBean.setVisibility(visibility);
						}
						
						
						else if("1".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
						{
							String visibility="7";
							System.out.println("===========99999999======="+visibility);
							favouritesBean.setVisibility(visibility);
						}
						
						
					}
					
					//*********************visibility part***********************//
		
					
					
				
										System.out.println("inside update");
										//favouritesDAO.insert(session, favouritesBean);
										favouritesDAO.update(session,favouritesBean);
						target="correct";
						
				}						
					
				else if ("display".equals(k)) 
				{
							
					favouritesBean = favouritesDAO.displayfavdetails(session,favouritesBean,q);
					
					
					{
						
						request.setAttribute("fav", favouritesBean);
						target = "favourite";
					} 
						
				}
			
			
			
			
			
			} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}

}
