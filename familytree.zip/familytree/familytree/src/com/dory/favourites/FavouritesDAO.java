package com.dory.favourites;

import org.hibernate.Session;

public interface FavouritesDAO {

	public boolean insert(Session session, FavouritesBean favouritesBean);
	public boolean update(Session session, FavouritesBean favouritesBean);
	public FavouritesBean displayfavdetails(Session session,FavouritesBean favouritesBean,int q);
	
}
