package com.dory.favourites;

import org.apache.struts.action.ActionForm;

public class FavouritesForm extends ActionForm {

	private String activities;
	private String interests;
	private String movies;
	private String tvshows;
	private String music;
	private String books;
	private String sports;
	private String remark;
	private String hobbies;
	private int favouriteid;
	
	
	 private int publicorprivate;
	 private int community;
	 private int groups;
	 private int family;
	
	public void setActivities(String activities) {
		this.activities = activities;
	}
	public String getActivities() {
		return activities;
	}
	public void setInterests(String interests) {
		this.interests = interests;
	}
	public String getInterests() {
		return interests;
	}
	public void setMovies(String movies) {
		this.movies = movies;
	}
	public String getMovies() {
		return movies;
	}
	public void setTvshows(String tvshows) {
		this.tvshows = tvshows;
	}
	public String getTvshows() {
		return tvshows;
	}
	public void setMusic(String music) {
		this.music = music;
	}
	public String getMusic() {
		return music;
	}
	public void setBooks(String books) {
		this.books = books;
	}
	public String getBooks() {
		return books;
	}
	public void setSports(String sports) {
		this.sports = sports;
	}
	public String getSports() {
		return sports;
	}
	public void setFavouriteid(int favouriteid) {
		this.favouriteid = favouriteid;
	}
	public int getFavouriteid() {
		return favouriteid;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	public void setCommunity(int community) {
		this.community = community;
	}
	public int getCommunity() {
		return community;
	}
	public void setGroups(int groups) {
		this.groups = groups;
	}
	public int getGroups() {
		return groups;
	}
	public void setFamily(int family) {
		this.family = family;
	}
	public int getFamily() {
		return family;
	}
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	public String getHobbies() {
		return hobbies;
	}
}
