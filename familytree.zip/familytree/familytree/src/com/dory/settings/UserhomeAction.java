package com.dory.settings;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

public class UserhomeAction extends Action {

	public ActionForward execute (ActionMapping mapping,ActionForm form,
			HttpServletRequest request,HttpServletResponse response)
	throws IOException,ServletException{
		String target="scrapbook";
		String scrapbook = request.getParameter("forscrap");
		System.out.println("Scrapbook=====>"+scrapbook);
		Collection scrap = new ArrayList();
		try{
			if(form!=null){
				
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
				HttpSession httpsession = request.getSession();
				UserhomeForm userhomeForm = (UserhomeForm) form;
				UserhomeBean userhomeBean = new UserhomeBean();
				UserhomeDAO userhomeDAO = new UserhomeDAOImpl();
				int memid=0;
				String memberid = (String)httpsession.getAttribute("mid").toString();
				memid=Integer.parseInt(memberid);
						
				
				
				if("scrap".equals(scrapbook)){
					scrap = userhomeDAO.viewscrap(session,memid);
					System.out.println("After view function=====>"+scrap);
					request.setAttribute("scrap", scrap);
					target = "scrapbook";
					System.out.println("Target after function call=====>"+target);
				}
				
				
				
			}
		}
		catch (Exception e) {
            System.out.println("Exception=====>"+e);
		}
		
		return mapping.findForward(target);
		
	}
	
}
