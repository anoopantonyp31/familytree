package com.dory.settings;

import org.apache.struts.action.ActionForm;

public class UserhomeForm extends ActionForm{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
