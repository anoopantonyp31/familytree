package com.dory.settings;

import java.util.Collection;

import org.hibernate.Session;

public interface UserhomeDAO {

	public Collection viewscrap(Session session,int memid);
}
