package com.dory.settings;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.dory.scrapbook.ScrapBean;

public class UserhomeDAOImpl implements UserhomeDAO{

public Collection viewscrap(Session session,int memid){
		
		Collection log =new ArrayList();
		
		try
		{
			System.out.println("InsideScrap====memberid========"+memid);
			
			List query = session.createQuery("select new ScrapBean(s.scrapid,s.scrap,p.name,s.posteddate) from ScrapBean s " +
					                         "join s.profiles as p " +
					                         "where s.sentto='"+memid+"' order by s.scrapid desc").list();
     
			System.out.println("Loginpage====query========"+query);

		for (Iterator it = query.iterator(); it.hasNext();) {
			System.out.println("Login====Iterator========");
			ScrapBean scrapBean=new ScrapBean();
			scrapBean = (ScrapBean) it.next();
			log.add(scrapBean);
			System.out.println("ScrapBean====visibility========"+scrapBean.getVisibility());
			System.out.println("ScrapBean====scrap========"+scrapBean.getScrap());
			System.out.println("ScrapBean====scrapid========"+scrapBean.getScrapid());
			System.out.println("ScrapBean====ProfileBean========Name========="+scrapBean.getProfiles());
			
			
		}
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return log;
	}
}
