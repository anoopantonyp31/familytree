//Created By:Upesh.A
//Created on:15/11/2010

package com.dory.displayinvitation;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;

public class DisplayinvitationAction extends DispatchAction 
{
	//Action for displaying all Invitations
	public ActionForward display(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = null;
		try {
			
			if (form != null) 
			{
				HttpSession httpsession = request.getSession();
				//Retrieving memberid
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
				DisplayinvitationForm displayinvitationForm =(DisplayinvitationForm)form;
				DisplayinvitationBean displayinvitationBean= new DisplayinvitationBean();
				BeanUtils.copyProperties(displayinvitationBean,displayinvitationForm);
				
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
		       
				DisplayinvitationDAOImpl displayinvitationDAOImpl=new DisplayinvitationDAOImpl();

			   //Method for displaying Invitation
				Collection invitation=displayinvitationDAOImpl.displayinvitation(session,displayinvitationBean,q);
				
			
				
					System.out.println("in district.size>0=====>"+invitation.size());
					if(invitation.size()>0)
					{
				    request.setAttribute("invitation", invitation);
				    request.setAttribute("abc", "abc");
					}
					else
					{
						request.setAttribute("noinvitation", "noinvitation");
					}
				    target="success";
				
			}
		}
			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
				target="failure";
			}
			return (mapping.findForward(target));
            }
			
	public ActionForward view(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		//Action for displaying Unread Invitations
		String target = null;
		try {
			
			if (form != null) 
			{

				HttpSession httpsession = request.getSession();
				//Retrieving memberid
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
				DisplayinvitationForm displayinvitationForm =(DisplayinvitationForm)form;
				DisplayinvitationBean displayinvitationBean= new DisplayinvitationBean();
				BeanUtils.copyProperties(displayinvitationBean,displayinvitationForm);
				
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
		       
				DisplayinvitationDAOImpl displayinvitationDAOImpl=new DisplayinvitationDAOImpl();

				//Method for displaying Unread Invitation
				Collection invitation=displayinvitationDAOImpl.displayinvitationread(session,displayinvitationBean,q);
				
			
				
					System.out.println("in district.size>0=====>"+invitation.size());
				   request.setAttribute("invitation", invitation);
				    target="user";
				
			}
		}
			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
				target="failure";
			}
			return (mapping.findForward(target));
            }
			
		
	public ActionForward hideread(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		String target = null;
		try {
			
			if (form != null) 
			{

				HttpSession httpsession = request.getSession();
				//Retrieving memberid
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
				DisplayinvitationForm displayinvitationForm =(DisplayinvitationForm)form;
				DisplayinvitationBean displayinvitationBean= new DisplayinvitationBean();
				BeanUtils.copyProperties(displayinvitationBean,displayinvitationForm);
				BeanUtils.copyProperties(displayinvitationBean,displayinvitationForm);
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
				System.out.println("in hide ==============================================================");
				DisplayinvitationDAOImpl displayinvitationDAOImpl=new DisplayinvitationDAOImpl();
				//Getting the id of the check box from the form
				int a[]=displayinvitationForm.getInvitid();
				System.out.println("a====>"+a);
				for(int i=0;i<a.length;i++)
				{
					System.out.println("IN THE LOOP+++++++++++++++++++");
					Session session1 = HibernateUtil.getSessionFactory()
					.openSession();
					int s =a[i];	
				    System.out.println("CHECKBOXID======================================================="+a[i]);
				    //Calling update Method
				    displayinvitationDAOImpl.update(session1,displayinvitationBean,s);
					
				}
				//Method for displaying Unread Invitation
				Collection invitation = displayinvitationDAOImpl.displayinvitationread(session,displayinvitationBean,q);
				
					System.out.println("in district.size>0=====>"+invitation.size());
				    request.setAttribute("invitation", invitation);
				
				target="user";
			      }				


		}

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
				target="failure";
			}

			return (mapping.findForward(target));
			}	
	
	
	public ActionForward viewdetil(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception 
			{
		//Action for displaying  Invitations
		String target = null;
		try {
			
			if (form != null) 
			{

				HttpSession httpsession = request.getSession();
				//Retrieving memberid
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
				 DisplayinvitationForm displayinvitationForm =(DisplayinvitationForm)form;
				InvitationBean1 invitationBean2= new InvitationBean1();
				
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
		       
				DisplayinvitationDAOImpl displayinvitationDAOImpl=new DisplayinvitationDAOImpl();
				
				int invitationid = Integer.parseInt(request.getParameter("invid"));
				

				//Method for displaying  Invitation
				 invitationBean2=displayinvitationDAOImpl.invitation(session,invitationBean2,invitationid);
				
			
				
					
				   request.setAttribute("invitation11", invitationBean2);
				    target="invitation";
				
			}
		}
			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
				target="failure";
			}
			return (mapping.findForward(target));
            }
	
		
}