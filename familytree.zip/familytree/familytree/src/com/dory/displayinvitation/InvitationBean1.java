//Created By:Upesh.A
//Created on:14/11/2010

package com.dory.displayinvitation;

public class InvitationBean1 
 {
	private String subject;
	  private String invitation;
	  private int invitationid;
	  private String membername;
	  private String invitationdate;
	  private int memberid;
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubject() {
		return subject;
	}
	public void setInvitation(String invitation) {
		this.invitation = invitation;
	}
	public String getInvitation() {
		return invitation;
	}
	public void setInvitationid(int invitationid) {
		this.invitationid = invitationid;
	}
	public int getInvitationid() {
		return invitationid;
	}
	public void setInvitationdate(String invitationdate) {
		this.invitationdate = invitationdate;
	}
	public String getInvitationdate() {
		return invitationdate;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
	

 }
