//Created By:Upesh.A
//Created on:14/11/2010

package com.dory.displayinvitation;

import java.util.Collection;

import org.hibernate.Session;

public interface DisplayinvitationDAO
{
	public Collection displayinvitation(Session session,DisplayinvitationBean displayinvitationBean,int q);
	public Collection displayinvitationread(Session session,DisplayinvitationBean displayinvitationBean,int q);
	public boolean update(Session session1, DisplayinvitationBean displayinvitationBean,int s);
	public InvitationBean1 invitation(Session session,InvitationBean1 invitationBean,int invitationid);
}

