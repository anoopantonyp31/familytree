//Created By:Upesh.A
//Created on:15/11/2010

package com.dory.displayinvitation;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Session;

public class DisplayinvitationDAOImpl implements DisplayinvitationDAO
{
	//Method for displaying all Invitation
	public Collection displayinvitation(Session session,DisplayinvitationBean displayinvitationBean,int q)
	{

		Collection standardcol=new ArrayList();
		InvitationBean1 invitationBean = new InvitationBean1();
		MemberBean memberBean= new MemberBean();
		try
		{
			
			
			//Selecting data from receipients_of_invitation table where memberid="q"
		List query = session.createSQLQuery("select * from receipients_of_invitation ds  where sentto='"+q+"' ").addEntity("ds",DisplayinvitationBean.class).list();
System.out.println("displaystandard====query========"+query);
		
      for (Iterator it = query.iterator(); it.hasNext();) {
			System.out.println("displaystandard====Iterator========");
			displayinvitationBean = (DisplayinvitationBean) it.next();
			System.out.println("displayStandard====invita========"+standardcol.size());
			System.out.println("displayStandard====invitationiddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd========"+displayinvitationBean.getInvitationid());
			
			
			//Selecting data from invitations table
			List query1 = session.createSQLQuery("select * from invitations ts where invitationid='"+displayinvitationBean.getInvitationid()+"' order by sentdate").addEntity("ts",InvitationBean1.class).list();
			
				for (Iterator it1 = query1.iterator(); it1.hasNext();)
				{
				invitationBean = (InvitationBean1) it1.next();
				
				//Setting values from InvitationBean to DisplayinvitationBean
				displayinvitationBean.setInvitation(invitationBean.getInvitation());
				displayinvitationBean.setMemberid(invitationBean.getMemberid());
				displayinvitationBean.setSubject(invitationBean.getSubject());
				displayinvitationBean.setInvitationdate(invitationBean.getInvitationdate());
			}
				//Selecting member name from member_profile table
			List query2 = session.createSQLQuery("select memberid,membername from member_profile ms where memberid='"+displayinvitationBean.getMemberid()+"' ").addEntity("ms",MemberBean.class).list();
			for (Iterator it2 = query2.iterator(); it2.hasNext();)
			{
				memberBean = (MemberBean) it2.next();
				System.out.println("displayStandard====invitationmembernammmmmmmmeeee"+memberBean.getMembername());
				displayinvitationBean.setMembername(memberBean.getMembername());
			}
			standardcol.add(displayinvitationBean);
		}
	
		}catch(Exception he){
			System.out.println("errorrrrrrrr"+he);
		}
		
		return standardcol;
	}
	
	
	//Method for displaying unread Invitation
	public Collection displayinvitationread(Session session,DisplayinvitationBean displayinvitationBean,int q)
	{

		Collection standardcol=new ArrayList();
		InvitationBean1 invitationBean = new InvitationBean1();
		MemberBean memberBean= new MemberBean();
		String s="ok";
		try
		{
			//Selecting data from receipients_of_invitation table where memberid="q"
		List query = session.createSQLQuery("select * from receipients_of_invitation ds where sentto='"+q+"' and status='"+s+"' ").addEntity("ds",DisplayinvitationBean.class).list();
System.out.println("displaystandard====query========"+query);
		
      for (Iterator it = query.iterator(); it.hasNext();) {
			System.out.println("displaystandard====Iterator========");
			displayinvitationBean = (DisplayinvitationBean) it.next();
			System.out.println("displayStandard====invita========"+standardcol.size());
			System.out.println("displayStandard====invitationiddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd========"+displayinvitationBean.getInvitationid());
			
			
			//Selecting data from invitations table
			List query1 = session.createSQLQuery("select * from invitations ts where invitationid='"+displayinvitationBean.getInvitationid()+"' ").addEntity("ts",InvitationBean1.class).list();
			
				for (Iterator it1 = query1.iterator(); it1.hasNext();)
				{
				invitationBean = (InvitationBean1) it1.next();
				displayinvitationBean.setInvitation(invitationBean.getInvitation());
				displayinvitationBean.setMemberid(invitationBean.getMemberid());
				displayinvitationBean.setSubject(invitationBean.getSubject());
				displayinvitationBean.setInvitationdate(invitationBean.getInvitationdate());
			}
				
			//Selecting member name from member_profile table
			List query2 = session.createSQLQuery("select memberid,membername from member_profile ms where memberid='"+displayinvitationBean.getMemberid()+"' ").addEntity("ms",MemberBean.class).list();
			for (Iterator it2 = query2.iterator(); it2.hasNext();)
			{
				memberBean = (MemberBean) it2.next();
				System.out.println("displayStandard====invitationmembernammmmmmmmeeee"+memberBean.getMembername());
				displayinvitationBean.setMembername(memberBean.getMembername());
			}
			standardcol.add(displayinvitationBean);
		}
	
		}catch(Exception he){
			System.out.println("errorrrrrrrr"+he);
		}
		
		return standardcol;
	}
	
	
	//Method for update
	public boolean update(Session session1, DisplayinvitationBean displayinvitationBean,int s)
    {
		//Selecting data from receipients_of_invitation table 
		List query = session1.createSQLQuery("select * from receipients_of_invitation ds where receivinvitationid='"+s+"'  ").addEntity("ds",DisplayinvitationBean.class).list();
System.out.println("displaystandard====query========"+query);
		
      for (Iterator it = query.iterator(); it.hasNext();) {
			System.out.println("displaystandard====Iterator========");
			displayinvitationBean = (DisplayinvitationBean) it.next();
			//Setting the status to read
			displayinvitationBean.setStatus("read");
      }
	session1.beginTransaction(); 
	session1.update(displayinvitationBean);
	session1.getTransaction().commit();
	return true;
    }
	
	
	public InvitationBean1 invitation(Session session,InvitationBean1 invitationBean,int invitationid)
	{
		
		MemberBean memberBean = new MemberBean();
		try
		{
			List query1 = session.createSQLQuery("select * from invitations ts where invitationid='"+invitationid+"' ").addEntity("ts",InvitationBean1.class).list();
			
			for (Iterator it1 = query1.iterator(); it1.hasNext();)
			{
				invitationBean = (InvitationBean1) it1.next();
				List query2 = session.createSQLQuery("select memberid,membername from member_profile ms where memberid='"+invitationBean.getMemberid()+"' ").addEntity("ms",MemberBean.class).list();
				for (Iterator it2 = query2.iterator(); it2.hasNext();)
				{
					memberBean = (MemberBean) it2.next();
					System.out.println("displayStandard====invitationmembernammmmmmmmeeee"+memberBean.getMembername());
					invitationBean.setMembername(memberBean.getMembername());
				}
				
				System.out.println("EX                         ============================================"+invitationBean.getInvitation());
				System.out.println("EX        suuub                 ============================================"+invitationBean.getSubject());
			}
			
			
		}
 catch (Exception e)
 {
	System.out.println("EXcEpTiOnnnnnnnnnnnn============"+e);
}	
 return invitationBean;
		
	}

	
}
