//Created By:Upesh.A
//Created on:14/11/2010

package com.dory.displayinvitation;

public class DisplayinvitationBean 
{
	  private int receivinvitationid;
	  private String status;
	  private String subject;
	  private String invitation;
	  private int invitationid;
	  private int sentto;
	  private String invitationdate;
	  private String membername;
	  private int memberid;
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubject() {
		return subject;
	}
	public void setInvitation(String invitation) {
		this.invitation = invitation;
	}
	public String getInvitation() {
		return invitation;
	}
	public void setInvitationdate(String invitationdate) {
		this.invitationdate = invitationdate;
	}
	public String getInvitationdate() {
		return invitationdate;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMembername() {
		return membername;
	}
	public void setReceivinvitationid(int receivinvitationid) {
		this.receivinvitationid = receivinvitationid;
	}
	public int getReceivinvitationid() {
		return receivinvitationid;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setInvitationid(int invitationid) {
		this.invitationid = invitationid;
	}
	public int getInvitationid() {
		return invitationid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setSentto(int sentto) {
		this.sentto = sentto;
	}
	public int getSentto() {
		return sentto;
	}
	
}
