//Created By:Upesh.A
//Created on:15/11/2010

package com.dory.displayinvitation;

public class MemberBean 
{
 private int memberid;
 private String membername;
public void setMemberid(int memberid) {
	this.memberid = memberid;
}
public int getMemberid() {
	return memberid;
}
public void setMembername(String membername) {
	this.membername = membername;
}
public String getMembername() {
	return membername;
}
}
