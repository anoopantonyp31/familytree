//Created By:Upesh.A
//Created on:14/11/2010

package com.dory.displayinvitation;

import org.apache.struts.action.ActionForm;

public class DisplayinvitationForm extends ActionForm 
{
  private String subject;
  private String invitation;
  private int[]invitid;
  private String invitationdate;
  private String membername;
public void setSubject(String subject) {
	this.subject = subject;
}
public String getSubject() {
	return subject;
}
public void setInvitation(String invitation) {
	this.invitation = invitation;
}
public String getInvitation() {
	return invitation;
}
public void setInvitationdate(String invitationdate) {
	this.invitationdate = invitationdate;
}
public String getInvitationdate() {
	return invitationdate;
}
public void setMembername(String membername) {
	this.membername = membername;
}
public String getMembername() {
	return membername;
}
public void setInvitid(int[] invitid) {
	this.invitid = invitid;
}
public int[] getInvitid() {
	return invitid;
}

}
