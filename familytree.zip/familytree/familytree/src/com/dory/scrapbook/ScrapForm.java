package com.dory.scrapbook;

import org.apache.struts.action.ActionForm;

public class ScrapForm extends ActionForm{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String scrap;
	private String visibility;
	private int sentby;
	private int sentto;
	private String repscrap;
	private int repto;

	public void setScrap(String scrap) {
		this.scrap = scrap;
	}

	public String getScrap() {
		return scrap;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setSentby(int sentby) {
		this.sentby = sentby;
	}

	public int getSentby() {
		return sentby;
	}

	public void setSentto(int sentto) {
		this.sentto = sentto;
	}

	public int getSentto() {
		return sentto;
	}

	

	

	public void setRepscrap(String repscrap) {
		this.repscrap = repscrap;
	}

	public String getRepscrap() {
		return repscrap;
	}

	public void setRepto(int repto) {
		this.repto = repto;
	}

	public int getRepto() {
		return repto;
	}

	

	

	
}
