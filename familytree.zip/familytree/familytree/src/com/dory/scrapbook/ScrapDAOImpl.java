package com.dory.scrapbook;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.dory.memberprofile.ProfileBean;
import com.dory.reminder.ReminderBean;



public class ScrapDAOImpl implements ScrapDAO{

	public boolean delete(Session session, ScrapBean scrapBean) {
		session.beginTransaction();
		session.delete(scrapBean);
		session.getTransaction().commit();
		return true;
	}
	
public ProfileBean retrieve(Session session,ProfileBean profileBean){
		
		try
		{
			
			
			List query = session.createQuery("from ProfileBean where memberid='"+profileBean.getMemberid()+"'").list();
     		System.out.println("ProfileBean====retrive query========"+query);

		for (Iterator it = query.iterator(); it.hasNext();) {
			
			System.out.println("Login====Iterator========");			
			profileBean = (ProfileBean) it.next();			
			System.out.println("ProfileBean====name========"+profileBean.getName());
			
			
		}
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return profileBean;
	}
	
	
	public boolean insert(Session session,ScrapBean scrapBean)
			{
				System.out.println("inside Insert scrap()=====>");
				System.out.println("Scrapbean====scrap========"+scrapBean.getScrap());
				System.out.println("Scrapbean====status========"+scrapBean.getVisibility());
				session.beginTransaction();     
				session.save(scrapBean);
				session.getTransaction().commit();
				System.out.println("after insert()=====>");
				return true;
				
			}
		
		
   /*public Collection view(Session session,int memid){
		
		Collection log =new ArrayList();
		
		try
		{
			System.out.println("Login====memberid========"+memid);
			
			List query = session.createQuery("select new ScrapBean(s.scrapid,s.scrap,p.name,s.posteddate) from ScrapBean s " +
                    "join s.profiles as p " +
                    "where s.sentto='"+memid+"' order by s.scrapid desc").list();
     
			System.out.println("Loginpage====query========"+query);

		for (Iterator it = query.iterator(); it.hasNext();) {
			System.out.println("Login====Iterator========");
			ScrapBean scrapBean=new ScrapBean();
			scrapBean = (ScrapBean) it.next();
			log.add(scrapBean);
			System.out.println("Loginbean====category========"+scrapBean.getVisibility());
			
			
		}
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return log;
	}*/
   
   
   
   public Collection viewscrap(Session session,int memid){
		
		Collection log =new ArrayList();
		
		try
		{
			System.out.println("InsideScrap====memberid========"+memid);
			
			List query = session.createQuery("select new ScrapBean(s.scrapid,p.memberid,s.sentto,s.scrap,p.name,s.posteddate) from ScrapBean s " +
					                         "join s.profiles as p " +
					                         "where s.sentto='"+memid+"' order by s.scrapid desc").list();
    
			System.out.println("Loginpage====query========"+query);

		for (Iterator it = query.iterator(); it.hasNext();) {
			System.out.println("Login====Iterator========");
			ScrapBean scrapBean=new ScrapBean();
			scrapBean = (ScrapBean) it.next();
			log.add(scrapBean);
			
			System.out.println("ScrapBean====scrap========"+scrapBean.getScrap());
			System.out.println("ScrapBean====scrapid========"+scrapBean.getScrapid());
			System.out.println("ScrapBean====getPosteddate================="+scrapBean.getPosteddate());
			
			
		}
		
		}catch(HibernateException he){
			System.out.println("errorrrrrrrr"+he);
		}
		return log;
	}
   
   
}



