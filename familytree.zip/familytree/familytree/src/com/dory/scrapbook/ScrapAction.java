package com.dory.scrapbook;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.memberprofile.ProfileBean;

public class ScrapAction extends Action {

	public ActionForward execute (ActionMapping mapping,ActionForm form,
			HttpServletRequest request,HttpServletResponse response)
	throws IOException,ServletException{
		String target="failure";
		System.out.println("Inside actionnnnnnnnnnnnnnn=====>");
		String scrapbook = request.getParameter("userhome");
		String inserting = request.getParameter("scrapbook");
		String reply = request.getParameter("scrapreply");
		System.out.println("Scrap bookkkkkkkkkkkkkkkk=====>"+reply);
		Collection scrap = new ArrayList();
		try{
			if(form!=null){
				
				Session session = HibernateUtil.getSessionFactory()
				.openSession();
				System.out.println("hoooooooooooooooooooooooooooo=====>");
				HttpSession httpsession = request.getSession();
				ScrapForm scrapForm = (ScrapForm) form;
				ScrapBean scrapBean = new ScrapBean();
				ProfileBean profileBean = new ProfileBean();
				ScrapDAO scrapdao = new ScrapDAOImpl();
				int memid=0;
				String memberid = (String)httpsession.getAttribute("mid").toString();
				memid=Integer.parseInt(memberid);
				
				
				if("scrap".equals(scrapbook)){
					System.out.println("Inside scrap view==========>");
					scrap = scrapdao.viewscrap(session,memid);
					System.out.println("After view function=====>"+scrap);
					request.setAttribute("scrap", scrap);
					target = "scrapbook";
					System.out.println("Target after function call=====>"+target);
				}
				
				
				
				if("insert".equals(inserting)){
					
					System.out.println("Inside scrap insert==========>");
					
					/*DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:MM:SS");
					Calendar cal = Calendar.getInstance();
					
					System.out.println("System date: "+dateFormat.format(cal.getTime()));
					String dat=dateFormat.format(cal.getTime());
					Date date = dateFormat.parse(dat);*/
					
					java.util.Date date=new java.util.Date();
					System.out.println("System date===========>: "+date);
					scrapBean.setPosteddate(date);
					scrapBean.setScrap(scrapForm.getScrap());
					scrapBean.setVisibility(scrapForm.getVisibility());
					
					profileBean.setMemberid(memid);
					profileBean = scrapdao.retrieve(session,profileBean);
					scrapBean.setProfiles(profileBean);
					
					scrapBean.setSentto(memid);
					System.out.println("scrapbean=====Visibility11111======>"+scrapBean.getVisibility());
					System.out.println("scrapbean=====Sentby======>"+scrapBean.getSentby());
					System.out.println("scrapbean=====Posted date======>"+scrapBean.getPosteddate());
					scrapdao.insert(session,scrapBean);
					scrap = scrapdao.viewscrap(session,memid);
					request.setAttribute("scrap", scrap);
					target = "success";
				}
				
				
                if("reply".equals(reply)){
					
                	System.out.println("Inside scrap reply==========>");
                	java.util.Date date=new java.util.Date();
					System.out.println("System date===========>: "+date);
					//Date dt= new SimpleDateFormat("dd-MM-yyyy").parse(date);
					
					scrapBean.setPosteddate(date);
					scrapBean.setScrap(scrapForm.getRepscrap());
					scrapBean.setVisibility(scrapForm.getVisibility());
					
					profileBean.setMemberid(memid);
					profileBean = scrapdao.retrieve(session,profileBean);
					System.out.println("After retrieveeeeeee==========>");
					scrapBean.setProfiles(profileBean);
					
					scrapBean.setSentto(scrapForm.getRepto());
					System.out.println("Reply section====scrappppp==========>"+scrapBean.getScrap());
					System.out.println("Reply section=====Visibility11111======>"+scrapBean.getVisibility());
					System.out.println("Reply section=====Sentto======>"+scrapBean.getSentto());
					System.out.println("Reply section=====Posted date======>"+scrapBean.getPosteddate());
					scrapdao.insert(session,scrapBean);
					scrap = scrapdao.viewscrap(session,memid);
					target = "scrap";
				}
                if("deletea".equals(reply))
				{
					System.out.println("=====in delete======");
					String w=request.getParameter("t");
					int scrapid=Integer.parseInt(w);
						System.out.println("======in delete for====="+scrapid);
						scrapBean.setScrapid(scrapid);
						scrapdao.delete(session, scrapBean);
						scrap = scrapdao.viewscrap(session,memid);
						System.out.println("After view function=====>"+scrap);
				}
                request.setAttribute("scrap", scrap);
                target = "scrapbook";
			}
			System.out.println("Target after function call=====>"+target);
		}
		catch (Exception e) {
            System.out.println("Exception=====>"+e);
		}
		return (mapping.findForward(target));
		
	}
	
}
