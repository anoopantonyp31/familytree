package com.dory.scrapbook;

import java.util.Collection;

import org.hibernate.Session;
import com.dory.memberprofile.ProfileBean;


public interface ScrapDAO {

	public ProfileBean retrieve(Session session,ProfileBean profileBean);
	public boolean insert(Session session,ScrapBean scrapBean);
	public boolean delete(Session session,ScrapBean scrapBean);
	public Collection viewscrap(Session session,int memid);
}
