package com.dory.scrapbook;

import java.util.Date;

import com.dory.memberprofile.ProfileBean;

public class ScrapBean {

	private int scrapid;
	private String scrap;
	private int sentby;
	private int sentto;
	private String visibility;
	private String status;
	private Date posteddate;
	
	private ProfileBean profiles;
	
	private String name;
	
	
	public ScrapBean(){
		
		
	}
	public ScrapBean(int scrapid,int memberid,int sentto,String scrap,String name,Date posteddate){
		this.scrapid=scrapid;
		this.scrap=scrap;
		this.name=name;
		this.posteddate=posteddate;
		this.sentby=memberid;
		this.sentto=sentto;
		
	}
	public void setScrapid(int scrapid) {
		this.scrapid = scrapid;
	}
	public int getScrapid() {
		return scrapid;
	}
	public void setScrap(String scrap) {
		this.scrap = scrap;
	}
	public String getScrap() {
		return scrap;
	}
	public void setSentby(int sentby) {
		this.sentby = sentby;
	}
	public int getSentby() {
		return sentby;
	}
	public void setSentto(int sentto) {
		this.sentto = sentto;
	}
	public int getSentto() {
		return sentto;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public String getVisibility() {
		return visibility;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setPosteddate(Date posteddate) {
		this.posteddate = posteddate;
	}
	public Date getPosteddate() {
		return posteddate;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setProfiles(ProfileBean profiles) {
		this.profiles = profiles;
	}
	public ProfileBean getProfiles() {
		return profiles;
	}
	
}
