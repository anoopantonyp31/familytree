package com.dory.photoalbum;

import org.apache.struts.action.ActionForm;

public class PhotoalbumForm extends ActionForm {

	private String variable;

	public void setVariable(String variable) {
		this.variable = variable;
	}

	public String getVariable() {
		return variable;
	}
}
