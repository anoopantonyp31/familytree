package com.dory.photoalbum;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.login.LoginAction;
import com.dory.login.LoginBean;
import com.dory.login.LoginDAO;
import com.dory.login.LoginDAOImpl;
import com.dory.login.LoginForm;

public class PhotoalbumAction extends Action  {

	
		
		public ActionForward execute(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws IOException, ServletException 
				{
			    String target = null;
			try {
				if (form != null) 
				{
					// Use the NameForm to get the request parameters
					System.out.print("===in=====login");
					PhotoalbumForm photoalbumForm = (PhotoalbumForm) form;
					
					
					Session session = HibernateUtil.getSessionFactory()
							.openSession();
					System.out.println("session======888888=====>"+session);
				
					
					String code1=request.getParameter("code");
					String file1=request.getParameter("file");
					
					System.out.println("code========="+code1);
					System.out.println("file========="+file1);
					
					
				
					{
						// here decryption of the member id is done
						System.out.println("inside check");
						String d= code1;
						int frt=Integer.parseInt(d);
						int j=frt/10;
						int decrypted=j-10;
						
						
						//here we will be geting the memberid in the variable decrypted;
						// decryption methord is by { encryptedvalue/10 then 10 is subtracted from the answer to get memberid 
						
						System.out.println("decrypted value======="+decrypted);
						String file=request.getParameter("file");
					String alter="username/"+decrypted+"/photoalbum/"+file1;
					System.out.println("file path===="+alter);
					
					 HttpSession filesession = request.getSession();
					 filesession.setAttribute("name",alter);
				
					
					target="photoalbum";
					}
				}
			}
				catch (Exception e) 
				{
	            System.out.println("Exception in LoginAction=====>"+e);
			}
				
			return (mapping.findForward(target));
		}
		
	}

