package com.dory.familydetails;

import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.hibernate.Session;
import com.dory.hibernate.HibernateUtil;

public class FamilydetailsAction extends DispatchAction

{

		
		public ActionForward displayfamily(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception 
				{
			String target =null;
			try {
				
				if (form != null) 
				{

					System.out.println("after target==fRelationnnnnnnn daction");
					FamilydetailsForm familydetailsForm =(FamilydetailsForm)form;	
					FamilydetailsBean familydetailsBean= new FamilydetailsBean();
					BeanUtils.copyProperties(familydetailsBean,familydetailsForm);
					Session session = HibernateUtil.getSessionFactory()
					.openSession();
					/*HttpSession httpsession = request.getSession();
					String r=(String)httpsession.getAttribute("mid").toString();
					int d=Integer.parseInt(r);*/
					int fid=familydetailsForm.getFamid();
					FamilydetailsdaoImpl familydetailsdaoImpl=new FamilydetailsdaoImpl();
		             Collection familydetails = familydetailsdaoImpl.displayfamilydetails(session,familydetailsBean,fid); 
		             for (Iterator iterator = familydetails.iterator(); iterator.hasNext();) 
	    	          { 
		            	 familydetailsBean = (FamilydetailsBean) iterator.next();
						 System.out.println("after target==fRelationnnnnnnn daction==========="+familydetailsBean.getFamilyid());
						 System.out.println("after target==fRelationnnnnnnn daction==========="+familydetailsBean.getFamilyname());
						 System.out.println("after target==fRelationnnnnnnn daction==========="+familydetailsBean.getFamilynumber());
					  }
		             familydetailsForm.setFamilyid(familydetailsBean.getFamilyid());
		             familydetailsForm.setFamilyname(familydetailsBean.getFamilyname());
		             familydetailsForm.setFamilynumber(familydetailsBean.getFamilynumber());
		             familydetailsForm.setDescription(familydetailsBean.getDescription());
					}
			
				 target="family";
				 System.out.println("after target=====>"+target);
	}
			

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}
			 System.out.println("after findForward=====>"+target);
			return (mapping.findForward(target));
			
			}
		public ActionForward save(ActionMapping mapping, ActionForm form,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception 
				{
			String target =null;
			try {
				
				if (form != null) 
				{

					System.out.println("after target==fRelationnnnnnnn daction");
					FamilydetailsForm familydetailsForm =(FamilydetailsForm)form;	
					FamilydetailsBean familydetailsBean= new FamilydetailsBean();
					BeanUtils.copyProperties(familydetailsBean,familydetailsForm);
					Session session = HibernateUtil.getSessionFactory()
					.openSession();
					int fid=familydetailsForm.getFamid();
					System.out.println("after target==fRelationnnnnnnn fid"+fid);
					FamilydetailsdaoImpl familydetailsdaoImpl=new FamilydetailsdaoImpl();
		             
					familydetailsBean.setFamilyid(fid);
					familydetailsBean.setFamilyname(familydetailsForm.getFamilyname());
					System.out.println("after target==fRelationnnnnnnn getFamilyname"+familydetailsBean.getFamilyname());
					familydetailsBean.setFamilynumber(familydetailsForm.getFamilynumber());
					familydetailsBean.setDescription(familydetailsForm.getDescription());
					familydetailsdaoImpl.update(session,familydetailsBean);
					}
			
				 target="home";
				 System.out.println("after target=====>"+target);
	}
			

			catch (Exception e) 
			{
				System.out.println("Exception=====>"+e);
			}
			 System.out.println("after findForward=====>"+target);
			return (mapping.findForward(target));
			
			}
		
	
	
}
