package com.dory.familydetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

public class FamilydetailsdaoImpl 
{
	
	public boolean update(Session session,FamilydetailsBean familydetailsBean)
	{
	session.beginTransaction(); 
	session.update(familydetailsBean);	
	session.getTransaction().commit();
	return true;
	}
	public Collection displayfamilydetails(Session session,FamilydetailsBean familydetailsBean,int fid)
	{
		
		
		Collection familydetails=new ArrayList();
		List query = session.createSQLQuery("select * from family_detail ds where familyid='"+fid+"'").addEntity("ds",FamilydetailsBean.class).list();
		
      for (Iterator it = query.iterator(); it.hasNext();) 
        {
    	  familydetailsBean = (FamilydetailsBean) it.next();  
    	  familydetails.add(familydetailsBean);
		}
      
      return familydetails;
	}
}
