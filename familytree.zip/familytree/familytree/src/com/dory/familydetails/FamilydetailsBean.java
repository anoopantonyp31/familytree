package com.dory.familydetails;

public class FamilydetailsBean 
{
	private int familyid;
	private String familyname;
	private String familynumber;
	private String description;
	private int familyadmin;
	private int createdby;
	public void setFamilyid(int familyid) {
		this.familyid = familyid;
	}
	public int getFamilyid() {
		return familyid;
	}
	public void setFamilyname(String familyname) {
		this.familyname = familyname;
	}
	public String getFamilyname() {
		return familyname;
	}
	public void setFamilynumber(String familynumber) {
		this.familynumber = familynumber;
	}
	public String getFamilynumber() {
		return familynumber;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDescription() {
		return description;
	}
	public void setFamilyadmin(int familyadmin) {
		this.familyadmin = familyadmin;
	}
	public int getFamilyadmin() {
		return familyadmin;
	}
	public void setCreatedby(int createdby) {
		this.createdby = createdby;
	}
	public int getCreatedby() {
		return createdby;
	}
}
