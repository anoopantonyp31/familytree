package com.dory.familydetails;
import org.apache.struts.action.ActionForm;
public class FamilydetailsForm extends ActionForm
{
private int familyid;
private int famid;
private String familyname;
private String familynumber;
private String description;
public void setFamilyid(int familyid) {
	this.familyid = familyid;
}
public int getFamilyid() {
	return familyid;
}
public void setFamilyname(String familyname) {
	this.familyname = familyname;
}
public String getFamilyname() {
	return familyname;
}
public void setFamilynumber(String familynumber) {
	this.familynumber = familynumber;
}
public String getFamilynumber() {
	return familynumber;
}
public void setDescription(String description) {
	this.description = description;
}
public String getDescription() {
	return description;
}
public void setFamid(int famid) {
	this.famid = famid;
}
public int getFamid() {
	return famid;
}
}
