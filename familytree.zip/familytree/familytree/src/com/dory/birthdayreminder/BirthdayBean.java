package com.dory.birthdayreminder;

public class BirthdayBean 
{

	private int month;
	private int date;
	public void setMonth(int month) {
		this.month = month;
	}
	public int getMonth() {
		return month;
	}
	public void setDate(int date) {
		this.date = date;
	}
	public int getDate() {
		return date;
	}
}
