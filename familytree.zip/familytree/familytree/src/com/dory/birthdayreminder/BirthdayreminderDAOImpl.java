package com.dory.birthdayreminder;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;


import com.dory.aboutme.AboutBean;
import com.dory.changepassword.ChangepasswordBean;
import com.dory.memberprofile.ProfileBean;

public class BirthdayreminderDAOImpl implements BirthdayreminderDAO{

	
	public Collection displaydate(Session session,BirthdayBean birthdayBean,int memberid)
	{
 
		ProfileBean profileBean = new ProfileBean();
		Collection birthdayreminder = new ArrayList();
		//ProfileBean profileBean = new ProfileBean();
		try {
			System.out.println("Inside======display date=====> ");
			List query1 = session.createSQLQuery("select * from member_profile cs where Month(dob) = '"+birthdayBean.getMonth()+"' and Day(dob)='"+birthdayBean.getDate()+"' and memberid!='"+memberid+"' ").addEntity("cs",ProfileBean.class).list();
			//List query = session.createQuery("from ProfileBean pr where pr.dob='"+dt+"' and pr.memberid!='"+profileBean.getMemberid()+"'")
				//	.list();
			for (Iterator it = query1.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				profileBean = (ProfileBean) it.next();
				System.out.println("After======query=====> ");
				System.out.println("profilebean======Name=====> "+profileBean.getName());
				birthdayreminder.add(profileBean);
			}
		} 
		
		catch (Exception e) {
			System.out.println("MONSTERRRRRRRRR=========>"+e);
		}
		
		return birthdayreminder;
	}
	
	public DisplayaboutmeBean displayaboutdetails(Session session,DisplayaboutmeBean displayaboutmeBean,int q) 
	{

		Collection aboutcol = new ArrayList();
		try 
		{
			List query = session.createQuery("from DisplayaboutmeBean ex where ex.memberid='"+q+"'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) 
			{
				System.out.println("session======displayexecutivepos=====> ");	
				displayaboutmeBean = (DisplayaboutmeBean) it.next();
				
			}
			
		}
		catch (Exception e) 
		{
			
		}
		return displayaboutmeBean;
	}
	
}