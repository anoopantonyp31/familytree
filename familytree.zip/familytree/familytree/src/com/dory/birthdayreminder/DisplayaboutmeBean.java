package com.dory.birthdayreminder;

public class DisplayaboutmeBean {

//bean to write into the tables
	 private String myself;
	 private String achivements;
	 private String remark;
	 private int aboutid;
	 private int memberid;
	 private String visibility;
	public void setMyself(String myself) {
		this.myself = myself;
	}
	public String getMyself() {
		return myself;
	}
	public void setAchivements(String achivements) {
		this.achivements = achivements;
	}
	public String getAchivements() {
		return achivements;
	}
	public void setAboutid(int aboutid) {
		this.aboutid = aboutid;
	}
	public int getAboutid() {
		return aboutid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public String getVisibility() {
		return visibility;
	}
}
