package com.dory.birthdayreminder;

import java.util.Collection;
import java.util.Date;

import org.hibernate.Session;

import com.dory.memberprofile.ProfileBean;

public interface BirthdayreminderDAO {

	public Collection displaydate(Session session,BirthdayBean birthdayBean,int memberid);
	public DisplayaboutmeBean displayaboutdetails(Session session,DisplayaboutmeBean displayaboutmeBean,int q);
}
