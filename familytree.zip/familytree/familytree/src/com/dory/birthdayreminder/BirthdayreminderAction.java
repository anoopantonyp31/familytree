package com.dory.birthdayreminder;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.memberprofile.ProfileBean;

public class BirthdayreminderAction extends Action {

	

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//used to get the action value
					String reminder = request.getParameter("action");
					System.out.print("value of reminder------->"+reminder);
		             HttpSession httpsession = request.getSession();
					String r=(String)httpsession.getAttribute("mid").toString();
					 int q=Integer.parseInt(r);
		             System.out.println("rambooo"+q);
					
				BirthdayreminderForm birthdayreminderForm = (BirthdayreminderForm) form;
				BirthdayBean birthdayBean = new BirthdayBean();
				DisplayaboutmeBean displayaboutmeBean = new DisplayaboutmeBean();
               
                
			
				Session session = HibernateUtil.getSessionFactory()
						.openSession();
				System.out.println("session======111111=====>" + session);
				
			     BirthdayreminderDAO birthdayreminderDAO = new BirthdayreminderDAOImpl();
	             ProfileBean profileBean = new ProfileBean();
	             
				
				if ("display".equals(reminder)) 
				{
					Calendar cal=Calendar.getInstance();
					   System.out.println("Current Year is :================== " + cal.get(Calendar.YEAR));
					    // month start from 0 to 11
					    System.out.println("Current Month is :================== " + (cal.get(Calendar.MONTH)+1 ));
					    System.out.println("Current Date is : =====================" + cal.get(Calendar.DATE));
					    int date = cal.get(Calendar.DATE);
					    int month = (cal.get(Calendar.MONTH)+1 );
					    birthdayBean.setDate(date);
					    birthdayBean.setMonth(month);
					Date dt=cal.getTime();
					
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
					//String date = df.format(dt);
					//SimpleDateFormat sdf;
					//sdf = new SimpleDateFormat("MM");
					//System.out.print("value of date sddddddddddddddddddffffffffffffffffffffffffffffff============="+sdf.format(df));
					//System.out.print("value of date------->"+dt);
					profileBean.setMemberid(q);
					Collection birth = birthdayreminderDAO.displaydate(session,birthdayBean,q);
					System.out.print("afterbirth day reminder members------->"+birth.size());
					if(birth.size()>0){
					request.setAttribute("breminder",birth);
					target="birthdayreminder";
					}
					
					else
					{
						target="birthdayreminder";
					}
					displayaboutmeBean = birthdayreminderDAO.displayaboutdetails(session,displayaboutmeBean,q);
					request.setAttribute("about",displayaboutmeBean);
						
				}						
					} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}

}