package com.dory.birthdayreminder;

import org.apache.struts.action.ActionForm;

public class BirthdayreminderForm extends ActionForm{
	
	

	
}
