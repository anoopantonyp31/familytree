package com.dory.discussionforum;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.hibernate.HibernateUtil;
import com.dory.mygroup.GroupmemberBean;
import com.dory.mygroup.MygroupBean;

public class DiscussionforumAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String target = null;
		try {
			if (form != null) {
				
				String k = request.getParameter("action");
				DiscussionforumForm discussionforumForm = (DiscussionforumForm) form;
				DiscussionforumBean discussionforumBean = new DiscussionforumBean();
				DiscussionreplyBean discussionReplayBean = new DiscussionreplyBean();
				DiscussionforumDAOImpl discussionforumDAO = new DiscussionforumDAOImpl();
				MygroupBean mygroupBean= new MygroupBean();
				GroupmemberBean groupmemberBean= new GroupmemberBean();
				System.out.println("session======0000000000000=====>");
				Session session = HibernateUtil.getSessionFactory()
						.openSession();
				HttpSession httpsession = request.getSession();
				// -----------------------------------------------------------//
				
				java.util.Date date=new java.util.Date();
				Calendar cal = Calendar.getInstance();
				Date dt = cal.getTime();
				discussionforumBean.setPosteddate(date);
				discussionReplayBean.setReplyposteddate(date);
				discussionforumBean.setStartby(discussionforumForm.getStartby());

				discussionforumBean.setDiscreption(discussionforumForm.getDiscreption());
				discussionforumBean.setTopic(discussionforumForm.getTopic());				
				
				System.out.println("session======111111=====>" + session);
				discussionReplayBean.setReplytext(discussionforumForm
						.getReplytext());
				discussionReplayBean.setForumid(discussionforumForm.getIdd());
				
				//to get the session from the login action
				String r=(String)httpsession.getAttribute("mid").toString();
				 int memid=Integer.parseInt(r);
	             System.out.println("rambooo"+memid);
	             
               discussionforumBean.setStartby(memid);
discussionReplayBean.setReplypostedby(memid);
				System.out.println("session22======111111=====>" + session);
				
				if ("rat".equals(k)) {
					String k1 = request.getParameter("id");
					int k2 = Integer.parseInt(k1);
					System.out.println("sssssssssssssss");

					Collection exeobj5 = discussionforumDAO.displayAllForum1(session, discussionforumBean, k2);	
					
					for (Iterator iterator = exeobj5.iterator(); iterator.hasNext();) 
					 {
						discussionforumBean = (DiscussionforumBean) iterator.next();						
					 }
					System.out.println("johnsonnnnnnnnnnnnnnn Dateeeeeeee"+discussionforumBean.getEnddate());
					System.out.println("johnsonnnnnnnnnnnnnnn Boolionnnn"+discussionforumBean.getPublicorprivate());
					Date endate=discussionforumBean.getEnddate();
					if(date.after(endate))
					{
						request.setAttribute("replay","replay");
					}					
					request.setAttribute("exeobj5", exeobj5);

					Collection exeobj6 = discussionforumDAO.viewreply(session,
							discussionReplayBean, k2);
					System.out.println("session======222222222222=====>"
							+ exeobj5.size());
					request.setAttribute("exeobj6", exeobj6);
					target = "discussiondiscription";
				}

				if ("display".equals(k)) 
				{
					
					Collection vis = discussionforumDAO.displaydiscussion1(session,discussionforumBean,memid);
					 vis = discussionforumDAO.displaydiscussion(session,discussionforumBean,memid);					
					for (Iterator iterator = vis.iterator(); iterator.hasNext();) 
					 {
						System.out.println("session======inside iterator=====>");
						discussionforumBean = (DiscussionforumBean) iterator.next();
						 int fid=discussionforumBean.getForumid();
						 System.out.println("fidddddddd======inside iterator=====>"+fid);
						 Collection counting = discussionforumDAO.displaycounting(session,discussionReplayBean,fid);
						 int count= counting.size();
						 System.out.println("Action======count=====>"+count);
						 discussionforumBean.setCount(count);
					 }	
					request.setAttribute("vis", vis);					
					System.out.println("session======222222222222=====>"+ vis.size());
					target = "correct";
					
				}

				
				if ("insert".equals(k)) {

					System.out.println("inside insert");
					Date fromdate=new SimpleDateFormat("dd-MM-yyyy").parse(discussionforumForm.getEnddate());	
					discussionforumBean.setEnddate(fromdate);
					discussionforumBean.setPublicorprivate(discussionforumForm.getPublicorprivate());
					discussionforumDAO.insert(session, discussionforumBean);
					Collection vis = discussionforumDAO.displaydiscussion1(session,discussionforumBean,memid);
					 vis = discussionforumDAO.displaydiscussion(session,discussionforumBean,memid);
					 for (Iterator iterator = vis.iterator(); iterator.hasNext();) 
					 {
						System.out.println("session======inside iterator=====>");
						discussionforumBean = (DiscussionforumBean) iterator.next();
						 int fid=discussionforumBean.getForumid();
						 System.out.println("fidddddddd======inside iterator=====>"+fid);
						 Collection counting = discussionforumDAO.displaycounting(session,discussionReplayBean,fid);
						 int count= counting.size();
						 System.out.println("Action======count=====>"+count);
						 discussionforumBean.setCount(count);
					 } 
					
					 request.setAttribute("vis", vis);
					target = "correct";
					System.out.println("target22222222=====>" + target);
				}

				System.out.println("session23======111111=====>" + session);
				
				
				if ("view".equals(k)) {
					System.out.println("inside insert1");
					String i = request.getParameter("idd");
					int i2 = Integer.parseInt(i);
					System.out.println("id-----------" + i2);

					discussionforumDAO.insert1(session, discussionReplayBean);
					Collection exeobj5 = discussionforumDAO.displayAllForum1(
							session, discussionforumBean, i2);
					System.out.println("ssize======displayAllForum1=====>"
							+ exeobj5.size());
					request.setAttribute("exeobj5", exeobj5);
					
					Collection exeobj6 = discussionforumDAO.viewreply(session,
							discussionReplayBean,i2);
					System.out.println("size======viewreplay=====>"
							+ exeobj6.size());
					request.setAttribute("exeobj6", exeobj6);
					
					target = "correct";

				}
				if ("search".equals(k))
				{
					String data=discussionforumForm.getData();	
					System.out.println("size======data=====>"
							+data );
					Collection vis = discussionforumDAO.searchtopic(session,discussionforumBean,data,memid);
					for (Iterator iterator = vis.iterator(); iterator.hasNext();) 
					 {
						System.out.println("session======inside iterator=====>");
						discussionforumBean = (DiscussionforumBean) iterator.next();
						 int fid=discussionforumBean.getForumid();
						 System.out.println("fidddddddd======inside iterator=====>"+fid);
						 Collection counting = discussionforumDAO.displaycounting(session,discussionReplayBean,fid);
						 int count= counting.size();
						 System.out.println("Action======count=====>"+count);
						 discussionforumBean.setCount(count);
					 }
					request.setAttribute("vis",vis);
					target="dis";
		             }
				//delete Discussionreplay Fourm
				if ("deleted".equals(k))
				{
					System.out.println("session======deleted=====>");
					String id =request.getParameter("t");
					int disid=Integer.parseInt(id);
					System.out.println("session======222222222222=====>"+disid);
							
					 String d=(String)httpsession.getAttribute("mid").toString();
					 int s=Integer.parseInt(d);
					 System.out.println("session======222222222222=====>"+s);
					 Collection disdelete = discussionforumDAO.disdelete(session,discussionReplayBean,disid);
					 for (Iterator iterator = disdelete.iterator(); iterator.hasNext();) 
					 {
						 discussionReplayBean = (DiscussionreplyBean) iterator.next();
						 System.out.println("Action======getReplypostedby iterator =====>"+discussionReplayBean.getReplypostedby());
					 }
					 
					 int ee=discussionReplayBean.getReplypostedby();
					 System.out.println("Action======getReplypostedby=====>"+ee);
					 if(ee==s)
					 {
						 discussionReplayBean.setForumreplyid(disid);
						 System.out.println("Action======getReplyid=====>"+discussionReplayBean.getForumreplyid());
						 discussionforumDAO.delete(session,discussionReplayBean);
						 Collection vis = discussionforumDAO.displaydiscussion1(session,discussionforumBean,memid);
						 vis = discussionforumDAO.displaydiscussion(session,discussionforumBean,memid);
						 for (Iterator iterator = vis.iterator(); iterator.hasNext();) 
						 {
							System.out.println("session======inside iterator=====>");
							discussionforumBean = (DiscussionforumBean) iterator.next();
							 int fid=discussionforumBean.getForumid();
							 System.out.println("fidddddddd======inside iterator=====>"+fid);
							 Collection counting = discussionforumDAO.displaycounting(session,discussionReplayBean,fid);
							 int count= counting.size();
							 System.out.println("Action======count=====>"+count);
							 discussionforumBean.setCount(count);
						 }
						 request.setAttribute("vis", vis);
						 target = "deletedis";
					 }
					 else
					 {
						 Collection vis = discussionforumDAO.displaydiscussion1(session,discussionforumBean,memid);
						 vis = discussionforumDAO.displaydiscussion(session,discussionforumBean,memid);
						 for (Iterator iterator = vis.iterator(); iterator.hasNext();) 
						 {
							System.out.println("session======inside iterator=====>");
							discussionforumBean = (DiscussionforumBean) iterator.next();
							 int fid=discussionforumBean.getForumid();
							 System.out.println("fidddddddd======inside iterator=====>"+fid);
							 Collection counting = discussionforumDAO.displaycounting(session,discussionReplayBean,fid);
							 int count= counting.size();
							 System.out.println("Action======count=====>"+count);
							 discussionforumBean.setCount(count);
						 }
						 request.setAttribute("vis", vis);
						 target = "deletedis"; 
					 }
					
		        }
				//delete Discussion Fourm
				if ("deleting".equals(k))
				{
					System.out.println("session======deleted=====>");
					String id =request.getParameter("t");
					int disid=Integer.parseInt(id);
					System.out.println("session======222222222222=====>"+disid);
							
					 String d=(String)httpsession.getAttribute("mid").toString();
					 int s=Integer.parseInt(d);
					 System.out.println("session======222222222222=====>"+s);
					 Collection disfourmdelete = discussionforumDAO.disfourmdelete(session,discussionforumBean,disid);
					 for (Iterator iterator = disfourmdelete.iterator(); iterator.hasNext();) 
					 {
						 discussionforumBean = (DiscussionforumBean) iterator.next();
						 System.out.println("Action======getReplypostedby iterator =====>"+discussionforumBean.getForumid());
						 System.out.println("Action======getReplypostedby iterator =====>"+discussionforumBean.getStartby());
					 }
					 
					 int ee=discussionforumBean.getStartby();
					 System.out.println("Action======getStartby=====>"+ee);
					 if(ee==s)
					 {
						 discussionforumBean.setForumid(disid);
						
						 System.out.println("Action======getReplyid=====>"+discussionforumBean.getForumid());
						 discussionforumDAO.delete1(session,discussionforumBean);
						 Collection vis = discussionforumDAO.displaydiscussion1(session,discussionforumBean,memid);
						 vis = discussionforumDAO.displaydiscussion(session,discussionforumBean,memid);						 
						 for (Iterator iterator = vis.iterator(); iterator.hasNext();) 
						 {
							System.out.println("session======inside iterator=====>");
							discussionforumBean = (DiscussionforumBean) iterator.next();
							 int fid=discussionforumBean.getForumid();
							 System.out.println("fidddddddd======inside iterator=====>"+fid);
							 Collection counting = discussionforumDAO.displaycounting(session,discussionReplayBean,fid);
							 int count= counting.size();
							 System.out.println("Action======count=====>"+count);
							 discussionforumBean.setCount(count);
						 }
						 request.setAttribute("vis", vis);
						
						 target = "deletedis";
					 }
					 else
					 {
						 Collection vis = discussionforumDAO.displaydiscussion1(session,discussionforumBean,memid);
						 vis = discussionforumDAO.displaydiscussion(session,discussionforumBean,memid);
						 for (Iterator iterator = vis.iterator(); iterator.hasNext();) 
						 {
							System.out.println("session======inside iterator=====>");
							discussionforumBean = (DiscussionforumBean) iterator.next();
							 int fid=discussionforumBean.getForumid();
							 System.out.println("fidddddddd======inside iterator=====>"+fid);
							 Collection counting = discussionforumDAO.displaycounting(session,discussionReplayBean,fid);
							 int count= counting.size();
							 System.out.println("Action======count=====>"+count);
							 discussionforumBean.setCount(count);
						 }
						 request.setAttribute("vis", vis);
						 target = "deletedis"; 
					 }
					
		        }
				
				}
		}

		catch (Exception e) {
			System.out.println("Exception===in discussion action==>" + e);
		}
	    System.out.println("target========DiscussionforumAction=========="+target);
		return (mapping.findForward(target));
	}
}
