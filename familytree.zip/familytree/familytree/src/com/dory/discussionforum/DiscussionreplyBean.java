package com.dory.discussionforum;

import java.util.Date;

public class DiscussionreplyBean {

	private int forumreplyid;
	private int forumid;
	private int replypostedby ;
	private String name ;
	private String replytext ;	
	private Date replyposteddate ;
	
	
	
	public void setForumreplyid(int forumreplyid) {
		this.forumreplyid = forumreplyid;
	}
	public int getForumreplyid() {
		return forumreplyid;
	}
	
	public void setForumid(int forumid) {
		this.forumid = forumid;
	}
	public int getForumid() {
		return forumid;
	}
	
	public void setReplypostedby(int replypostedby) {
		this.replypostedby = replypostedby;
	}
	public int getReplypostedby() {
		return replypostedby;
	}
	
	public void setReplytext(String replytext) {
		this.replytext = replytext;
	}
	public String getReplytext() {
		return replytext;
	}
	
	public void setReplyposteddate(Date replyposteddate) {
		this.replyposteddate = replyposteddate;
	}
	public Date getReplyposteddate() {
		return replyposteddate;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	
	
	
	
	}
	 
