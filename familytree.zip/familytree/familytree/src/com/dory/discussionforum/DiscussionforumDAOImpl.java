 package com.dory.discussionforum;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.mygroup.GroupmemberBean;
import com.dory.mygroup.MygroupBean;



public class DiscussionforumDAOImpl implements DiscussionforumDAO {

	
	public boolean insert(Session session, DiscussionforumBean discussionforumBean) 
	{
		session.beginTransaction();
		session.save(discussionforumBean);
		session.getTransaction().commit();
		return true;

	}
public boolean insert1(Session session,DiscussionreplyBean discussionReplayBean )
	{
		session.beginTransaction();
		session.save(discussionReplayBean);
		session.getTransaction().commit();
		return true;
	}
public boolean delete(Session session,DiscussionreplyBean discussionReplayBean)

{	
	List query = session.createSQLQuery("select * from discussion_forum_reply ds where forumreplyid="+discussionReplayBean.getForumreplyid()+"").addEntity("ds",DiscussionreplyBean.class).list();
	
	
	for (Iterator it = query.iterator(); it.hasNext();) 
	{
		discussionReplayBean = (DiscussionreplyBean) it.next();
	}
session.beginTransaction();     
session.delete(discussionReplayBean);
session.getTransaction().commit();
return true;
}

public boolean delete1(Session session,DiscussionforumBean discussionforumBean)


{	
	DiscussionreplyBean  discussionreplyBean = new DiscussionreplyBean();
	List query = session.createSQLQuery("select * from discussion_forum ps where forumid="+discussionforumBean.getForumid()+"").addEntity("ps",DiscussionforumBean.class).list();
	
	
	for (Iterator it = query.iterator(); it.hasNext();) 
	{
		discussionforumBean = (DiscussionforumBean) it.next();
		List query1 = session.createSQLQuery("select * from discussion_forum_reply ds where forumid="+discussionforumBean.getForumid()+"").addEntity("ds",DiscussionreplyBean.class).list();
		
		for (Iterator it2 = query1.iterator(); it2.hasNext();) 
		{
			discussionreplyBean = (DiscussionreplyBean) it2.next();
			session.beginTransaction(); 
			session.delete(discussionreplyBean);
			session.getTransaction().commit();
		}
		session.beginTransaction();     
		session.delete(discussionforumBean);
		session.getTransaction().commit();
	}
	
	return true;

}
	public Collection displayAllForum1(Session session, DiscussionforumBean discussionforumBean, int k2)
	{
		Collection exeobj5 = new ArrayList();
		
		try {
			System.out.println("List======123456=====> ");
			List query = session.createQuery("from DiscussionforumBean ex  where ex.forumid='"+k2+"'").list();
			System.out.println("List======query=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				discussionforumBean = (DiscussionforumBean) it.next();
				System.out.println("createcommunityBean======community name=====> "+discussionforumBean.getTopic());
				System.out.println("johnsonnnnnnnnnnnnnnn Dateeeeeeee IMPL"+discussionforumBean.getEnddate());
				System.out.println("johnsonnnnnnnnnnnnnnn Boolionnnn IMPL"+discussionforumBean.getPublicorprivate());
				exeobj5.add(discussionforumBean);
			}
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
	    }
		return exeobj5;
	}
	
	
	public Collection viewreply(Session session, DiscussionreplyBean discussionReplayBean, int k2){
		Collection replay = new ArrayList();
		MemberprofileBean memberprofileBean= new MemberprofileBean();
		try {
			System.out.println("List======123456==viewreplay===> "+k2);			
			List query = session.createSQLQuery("select * from discussion_forum_reply dr where forumid='"+k2+"'").addEntity("dr",DiscussionreplyBean.class).list();			
			System.out.println("List===viewreplay===query=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				discussionReplayBean = (DiscussionreplyBean) it.next();
				List query1 = session.createSQLQuery("select * from member_profile te where memberid='"+discussionReplayBean.getReplypostedby()+"'").addEntity("te",MemberprofileBean.class).list();			
				 for (Iterator it1 = query1.iterator(); it1.hasNext();) 
				 {
					 memberprofileBean = (MemberprofileBean) it1.next();
					 System.out.println("List======123456==viewreplayno===> "+memberprofileBean.getName());	
					 discussionReplayBean.setName(memberprofileBean.getName());
			     }
				 replay.add(discussionReplayBean);
			 }
			
		} 
		catch (Exception e) {
			e.printStackTrace();
	}
		return replay;
		
	}
	public Collection viewreplayno(Session session, DiscussionreplyBean discussionReplayBean, int k2){
		Collection replay1 = new ArrayList();
		
		try {
			System.out.println("List======123456==viewreplayno===> "+k2);			
			List query = session.createSQLQuery("select * from discussion_forum_reply dr where forumid='"+k2+"' order by replyposteddate desc").addEntity("dr",DiscussionreplyBean.class).list();			
			System.out.println("List===viewreplay===query=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				discussionReplayBean = (DiscussionreplyBean) it.next();
				System.out.println("repiddddddddddddddddd"+discussionReplayBean.getForumreplyid());
				replay1.add(discussionReplayBean);
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
	}
		return replay1;
	}
	
	/*public Collection searchtopic(Session session, DiscussionforumBean discussionforumBean, String data){
		Collection exeobj = new ArrayList();
		MemberprofileBean memberprofileBean= new MemberprofileBean();
		try {
			System.out.println("List======123456==viewreplayno===> "+data);			
			List query = session.createSQLQuery("select * from discussion_forum ex where topic like'%"+data+"%'").addEntity("dr",DiscussionforumBean.class).list();			
			for (Iterator it = query.iterator(); it.hasNext();) 
			{
				 discussionforumBean = (DiscussionforumBean) it.next();
				 List query1 = session.createSQLQuery("select * from member_profile dx where memberid='"+discussionforumBean.getStartby()+"'").addEntity("dr",MemberprofileBean.class).list();			
				 for (Iterator it1 = query1.iterator(); it1.hasNext();) 
				 {
					 memberprofileBean = (MemberprofileBean) it1.next();
					 System.out.println("List======123456==viewreplayno===> "+memberprofileBean.getName());	
					 discussionforumBean.setName(memberprofileBean.getName());
			     }
			exeobj.add(discussionforumBean);
		  }
		}
		catch (Exception e) 
		{
			e.printStackTrace();
	    }
	
		return exeobj;
	
	}*/
//delete Discussion fourmreplay
	public Collection disdelete(Session session, DiscussionreplyBean discussionReplayBean, int disid){
		Collection disdelete = new ArrayList();
		
		try {
			System.out.println("List======123456==viewreplayno===> "+disid);			
			List query = session.createSQLQuery("select * from discussion_forum_reply jr where forumreplyid='"+disid+"'").addEntity("jr",DiscussionreplyBean.class).list();			
			System.out.println("List===viewreplay===query=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) 
			{
				discussionReplayBean = (DiscussionreplyBean) it.next();
				System.out.println("Forumreplyid"+discussionReplayBean.getForumreplyid());
				System.out.println("Replypostedby"+discussionReplayBean.getReplypostedby());
			}
			disdelete.add(discussionReplayBean);
		} 
		catch (Exception e) {
			e.printStackTrace();
	}
		return disdelete;
	}
//delete Discussion fourm	
	public Collection disfourmdelete(Session session, DiscussionforumBean discussionforumBean, int disid)
	{
		Collection disfourmdelete = new ArrayList();
		
		try {
			System.out.println("List======123456==viewreplayno===> "+disid);			
			List query = session.createSQLQuery("select * from discussion_forum hr where forumid='"+disid+"'").addEntity("hr",DiscussionforumBean.class).list();			
			System.out.println("List===viewreplay===query=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) 
			{
				discussionforumBean = (DiscussionforumBean) it.next();
				System.out.println("Forumreplyid"+discussionforumBean.getForumid());
				System.out.println("Replypostedby"+discussionforumBean.getStartby());
			}
			disfourmdelete.add(discussionforumBean);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
	}
		return disfourmdelete;
	}
	//display discussion fourm is group	member
	public Collection displaydiscussion(Session session, DiscussionforumBean discussionforumBean,int memid)
	{
		Collection vis = new ArrayList();
		MygroupBean mygroupBean= new MygroupBean();
		GroupmemberBean groupmemberBean = new GroupmemberBean();
		try {
				
			List query = session.createSQLQuery("select * from discussion_forum vr").addEntity("vr",DiscussionforumBean.class).list();			
			System.out.println("List===viewreplay===query=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) 
			{
				discussionforumBean = (DiscussionforumBean) it.next();
				int visibility =discussionforumBean.getPublicorprivate();
				int strby=discussionforumBean.getStartby();				
				if(visibility==0 && strby!=memid)
				{
					List query1 = session.createSQLQuery("select * from groups ur where groupowner='"+strby+"'").addEntity("ur",MygroupBean.class).list();			
					System.out.println("List===viewreplay===query=====> "+query1);
					for (Iterator it1 = query1.iterator(); it1.hasNext();) 
					{
						mygroupBean = (MygroupBean) it1.next();
						int grid=mygroupBean.getGroupid();
						List query2 = session.createSQLQuery("select * from group_members kr where groupid='"+grid+"'").addEntity("kr",GroupmemberBean.class).list();			
						System.out.println("List===viewreplay===query=====> "+query2);
						for (Iterator it2 = query2.iterator(); it2.hasNext();) 
						{
							groupmemberBean = (GroupmemberBean) it2.next();	
							int mid=groupmemberBean.getMemberid();
						}
				   }
					if(groupmemberBean.getMemberid()==memid)
					{
						vis.add(discussionforumBean);
					}
				}			
				
				else
				{
					vis.add(discussionforumBean);	
				}
			}
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
	}
		return vis;
	}

public Collection displaydiscussion1(Session session, DiscussionforumBean discussionforumBean, int memid)
{
	Collection vis = new ArrayList();
	
	try {
		System.out.println("List======123456==viewreplayno===> "+memid);			
		List query = session.createSQLQuery("select * from discussion_forum hr where startby='"+memid+"'").addEntity("hr",DiscussionforumBean.class).list();			
		System.out.println("List===viewreplay===query=====> "+query);
		for (Iterator it = query.iterator(); it.hasNext();) 
		{
			discussionforumBean = (DiscussionforumBean) it.next();
			vis.add(discussionforumBean);
		}
		
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
}
	return vis;
}
//count
public Collection displaycounting(Session session,DiscussionreplyBean discussionReplayBean,int fid)
{
	Collection counting = new ArrayList();
	
	try {
					
		List query = session.createSQLQuery("select * from discussion_forum_reply hr where forumid='"+fid+"'").addEntity("hr",DiscussionreplyBean.class).list();			
		System.out.println("List===viewreplay===query=====> "+query);
		for (Iterator it = query.iterator(); it.hasNext();) 
		{
			discussionReplayBean = (DiscussionreplyBean) it.next();
			counting.add(discussionReplayBean);
		}
		
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
}
	return counting;
}

//discussion forum search

public Collection searchtopic(Session session, DiscussionforumBean discussionforumBean,String data,int memid)
{
	Collection vis = new ArrayList();
	MygroupBean mygroupBean= new MygroupBean();
	GroupmemberBean groupmemberBean = new GroupmemberBean();
	try {
			
		List query = session.createSQLQuery("select * from discussion_forum ex where topic like'%"+data+"%'").addEntity("vr",DiscussionforumBean.class).list();			
		
		for (Iterator it = query.iterator(); it.hasNext();) 
		{
			discussionforumBean = (DiscussionforumBean) it.next();			
			int visibility =discussionforumBean.getPublicorprivate();
			System.out.println("List===visibilityfffffffffv"+visibility);
			int strby=discussionforumBean.getStartby();				
			if(visibility==0 && strby!=memid)
			  {
				System.out.println("List===ifffffffffffff=========iooppppppppp"+visibility);
				List query1 = session.createSQLQuery("select * from groups ur where groupowner='"+strby+"'").addEntity("ur",MygroupBean.class).list();			
				System.out.println("List===viewreplay===query=====> "+query1);
				for (Iterator it1 = query1.iterator(); it1.hasNext();) 
				{
					mygroupBean = (MygroupBean) it1.next();
					int grid=mygroupBean.getGroupid();
					List query2 = session.createSQLQuery("select * from group_members kr where groupid='"+grid+"'").addEntity("kr",GroupmemberBean.class).list();			
					System.out.println("List===viewreplay===query=====> "+query2);
					for (Iterator it2 = query2.iterator(); it2.hasNext();) 
					{
						groupmemberBean = (GroupmemberBean) it2.next();	
					}
			   }
				if(groupmemberBean.getMemberid()==memid)
				{
					vis.add(discussionforumBean);
				}
			}
			else if(visibility==1 && strby!=memid)
			{
				System.out.println("List===elseeeeeeee=========iooppppppppp"+visibility);
				vis.add(discussionforumBean);	
				System.out.println("List==implllllll size=============="+vis.size());
			}
			
			else if( strby==memid)
			{
				System.out.println("List===elseeeeeeee=========iooppppppppp========= strby==memid ");
				vis.add(discussionforumBean);	
				System.out.println("List==implllllll size=============="+vis.size());
			}
		}
		
	}
	catch (Exception e) 
	{
		e.printStackTrace();
}
	System.out.println("List==implllllll size=returnNNNNNNNNN============"+vis.size());
	return vis;
}
}