package com.dory.discussionforum;
import org.apache.struts.action.ActionForm;

public class DiscussionforumForm extends ActionForm {


	private int forumid;
	private int startby;
	private String topic ;	
	private String discreption ;
	private int forumreplyid;
	private int replypostedby ;	
	private String replytext ;	
	private int idd;
	private String data;
	private int memberid;
	private String name;
	private String enddate;
	private int publicorprivate;
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getTopic() {
		return topic;
	}
	
	public void setForumid(int forumid) {
		this.forumid = forumid;
	}
	public int getForumid() {
		return forumid;
	}
		
	public void setStartby(int startby) {
		this.startby = startby;
	}
	public int getStartby() {
		return startby;
	}
	
	public void setDiscreption(String discreption) {
		this.discreption = discreption;
	}
	public String getDiscreption() {
		return discreption;
	}
	
	public void setForumreplyid(int forumreplyid) {
		this.forumreplyid = forumreplyid;
	}
	public int getForumreplyid() {
		return forumreplyid;
	}
	
	public void setReplypostedby(int replypostedby) {
		this.replypostedby = replypostedby;
	}
	public int getReplypostedby() {
		return replypostedby;
	}
	
	public void setReplytext(String replytext) {
		this.replytext = replytext;
	}
	public String getReplytext() {
		return replytext;
	}
	
	public void setIdd(int idd) {
		this.idd = idd;
	}
	public int getIdd() {
		return idd;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	
}
