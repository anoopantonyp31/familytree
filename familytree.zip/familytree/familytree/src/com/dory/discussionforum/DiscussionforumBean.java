package com.dory.discussionforum;

import java.util.Date;

public class DiscussionforumBean {

	private int forumid;
	private int startby;
	private String topic ;	
	private String discreption ;	
	private Date posteddate ;
	private Date enddate;
	private int publicorprivate;
	private String name;
	private int count;
	
	
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getTopic() {
		return topic;
	}
	
	
	public void setPosteddate(Date posteddate) {
		this.posteddate = posteddate;
	}
	public Date getPosteddate() {
		return posteddate;
	}
	public void setForumid(int forumid) {
		this.forumid = forumid;
	}
	public int getForumid() {
		return forumid;
	}
	public void setStartby(int startby) {
		this.startby = startby;
	}
	public int getStartby() {
		return startby;
	}
	public void setDiscreption(String discreption) {
		this.discreption = discreption;
	}
	public String getDiscreption() {
		return discreption;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getCount() {
		return count;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}
	public Date getEnddate() {
		return enddate;
	}
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	
	
	}
	 
