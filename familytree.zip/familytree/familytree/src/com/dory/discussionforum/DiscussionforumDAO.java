package com.dory.discussionforum;

import org.hibernate.Session;



public interface DiscussionforumDAO 
{
	public boolean insert(Session session,DiscussionforumBean discussionforumBean);

}

