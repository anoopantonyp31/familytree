package com.dory.newsletter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;




public class NewsletterDAOImpl {

	
	public boolean insert(Session session, NewsletterBean newsletterBean) {
		session.beginTransaction();
		session.save(newsletterBean);
		session.getTransaction().commit();
		return true;

	}
	public Collection displaynews(Session session,NewsletterBean newsletterBean) {

		Collection newscol = new ArrayList();
		try {
			System.out.println("session======displaynews=====>"+session);	
			List query = session.createSQLQuery("select * from newsletter ns order by sentdate DESC  limit 5").addEntity("ns",NewsletterBean.class).list();
			System.out.println("Query for display news========>>>>>"+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in displaynews iterator=====> ");	
				newsletterBean = (NewsletterBean) it.next();
				newscol.add(newsletterBean);
			}
		} 
		
		catch (Exception e) {
			System.out.println("Exception in displayNews====>>>>>"+e);
		}
		//session.close();
		return newscol;
	}
	
	public Collection displayfullnews(Session session,NewsletterBean newsletterBean) {

		Collection fullnewscol = new ArrayList();
		try {
			System.out.println("session======displayfullnews=====>"+session);	
			List query = session.createSQLQuery("select memberid,newsid,sentdate,subject,left(data,30) data from newsletter nl order by sentdate limit 10").addEntity("nl",NewsletterBean.class).list();
			System.out.println("Query for displayfullnews========>>>>>"+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in displayfullnews iterator=====> ");	
				newsletterBean = (NewsletterBean) it.next();
				newsletterBean.setNewstype("sortbydate");
				fullnewscol.add(newsletterBean);
			}
		} 
		
		catch (Exception e) {
			System.out.println("Exception in displayFullNews====>>>>>"+e);
		}
		//session.close();
		return fullnewscol;
	}
	
	/*public Collection displaysortnews(Session session,NewsletterBean newsletterBean) {

		Collection sortnewscol = new ArrayList();
		try {
			System.out.println("session======displaysortnews=====>"+session);	
			List query = session.createSQLQuery("select memberid,newsid,sentdate,subject,left(data,30) data from newsletter na order by subject asc").addEntity("na",NewsletterBean.class).list();
			System.out.println("Query for displaysortnews========>>>>>"+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in displaysortnews iterator=====> ");	
				newsletterBean = (NewsletterBean) it.next();
				newsletterBean.setNewstype("sortbyname");
				sortnewscol.add(newsletterBean);
			}
		} 
		
		catch (Exception e) {
			System.out.println("Exception in displaySortNews====>>>>>"+e);
		}
		//session.close();
		return sortnewscol;
	}*/
	public Collection displayDetailednews(Session session,NewsletterBean newsletterBean,int newsid) {

		Collection detailednewscol = new ArrayList();
		try {
			System.out.println("session======displayDetailednews=====>"+session);	
			List query = session.createSQLQuery("select * from newsletter nd where newsid='"+newsid+"'").addEntity("nd",NewsletterBean.class).list();
			System.out.println("Query for displayDetailednews========>>>>>"+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in displaydetailednews iterator=====> ");	
				newsletterBean = (NewsletterBean) it.next();
				detailednewscol.add(newsletterBean);
			}
		} 
		
		catch (Exception e) {
			System.out.println("Exception in displayDetailednews====>>>>>"+e);
		}
		//session.close();
		return detailednewscol;
	}
	
	public Collection searchnews(Session session,NewsletterBean newsletterBean,int x,int y) {

		Collection searchnewscol = new ArrayList();
		try {
			System.out.println("session======searchnews=====>"+session);	
			String q1="select memberid,newsid,sentdate,subject,left(data,30) data from newsletter sn ";
			String datafield=newsletterBean.getSearchbydata();
			String q2="where "+datafield+" like '%"+newsletterBean.getSerdata()+"%'";
			String searchtype=newsletterBean.getSerfrom();
			String q3="";
			if(searchtype.equals("on"))
			{
				 q3=" and sentdate='"+newsletterBean.getSearchfromdate()+"'";
			}
			if(searchtype.equals("after"))
			{
				 q3=" and sentdate>'"+newsletterBean.getSearchfromdate()+"'";
			}
			if(searchtype.equals("before"))
			{
				 q3=" and sentdate<'"+newsletterBean.getSearchfromdate()+"'";
			}
			if(searchtype.equals("between"))
			{
				 q3=" and sentdate between '"+newsletterBean.getSearchfromdate()+"' and '"+newsletterBean.getSearchtodate()+"'";
			}
			String q4="";
			String q5="";
			String sortby=newsletterBean.getSortby();
			if(sortby.equals("name"))
			{
				q4=" order by subject asc";
				q5=",subject limit "+x+","+y+"";
			}
			if(sortby.equals("date"))
			{
				q4=" order by subject limit "+x+","+y+"";
			}
			String q=q1+q2+q3+q4+q5;
			System.out.println("===========appended queryyy=========="+q);
			List query = session.createSQLQuery(q).addEntity("sn",NewsletterBean.class).list();
			System.out.println("Query for searchnews========>>>>>"+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in searchnews iterator=====> ");	
				newsletterBean = (NewsletterBean) it.next();
				searchnewscol.add(newsletterBean);
			}
		} 
		
		catch (Exception e) {
			System.out.println("Exception in searchnews====>>>>>"+e);
		}
		//session.close();
		return searchnewscol;
	}
	
	
	public int newscount(Session session,NewsletterBean newsletterBean) {

	   int count=0;
	try {
		System.out.println("session======newscount=====>"+session);	
		List q= session.createSQLQuery("select * from newsletter na").addEntity("na",NewsletterBean.class).list();
		System.out.println("Query for newscount========>>>>>"+q);
		for (Iterator it = q.iterator(); it.hasNext();) {
			it.next();
			System.out.println("resultt====Iterator========");
            count=count+1;
		}
	} 
	
	catch (Exception e) {
		System.out.println("Exception in newscount====>>>>>"+e);
	}
	
	return count;
}
	
	
	//-------------------
	
	public Collection displaynewslimit(Session session,NewsletterBean newsletterBean,int y,int z) {

		Collection newscol = new ArrayList();
		try {
			System.out.println("session======displaynewslimit=====>"+session);	
			List query = session.createSQLQuery("select * from newsletter nq order by sentdate limit "+y+","+z+"").addEntity("nq",NewsletterBean.class).list();
			System.out.println("Query for displaynewslimit news========>>>>>"+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("=====in displaynewslimit iterator=====> ");	
				newsletterBean = (NewsletterBean) it.next();
				newscol.add(newsletterBean);
			}
		} 
		
		catch (Exception e) {
			System.out.println("Exception in displaynewslimit====>>>>>"+e);
		}
		//session.close();
		return newscol;
	}
	
}
