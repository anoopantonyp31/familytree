package com.dory.newsletter;

public interface NewsletterDAO {

}
