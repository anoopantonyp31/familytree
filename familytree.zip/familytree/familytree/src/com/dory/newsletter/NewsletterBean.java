package com.dory.newsletter;

import java.util.Date;

public class NewsletterBean {

	
	 private String subject;
	 private String data;
	 private int newsid;
	 private int memberid;
	 private Date sentdate;
	 private String newstype;
	 private String searchbydata;
	 private String serdata;
	 private String serfrom;
	 private String searchfromdate;
	 private String searchtodate;
	 private String sortby;
	 private int nextfield ;
	 private int prevfield;
	 private int totalcount;
	 private int nextresult ;
	 private int prevresult;
	 
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubject() {
		return subject;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getData() {
		return data;
	}
	public void setNewsid(int newsid) {
		this.newsid = newsid;
	}
	public int getNewsid() {
		return newsid;
	}
	public void setSentdate(Date sentdate) {
		this.sentdate = sentdate;
	}
	public Date getSentdate() {
		return sentdate;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setNewstype(String newstype) {
		this.newstype = newstype;
	}
	public String getNewstype() {
		return newstype;
	}
	public void setSearchbydata(String searchbydata) {
		this.searchbydata = searchbydata;
	}
	public String getSearchbydata() {
		return searchbydata;
	}
	public void setSerdata(String serdata) {
		this.serdata = serdata;
	}
	public String getSerdata() {
		return serdata;
	}
	public void setSerfrom(String serfrom) {
		this.serfrom = serfrom;
	}
	public String getSerfrom() {
		return serfrom;
	}
	public void setSearchfromdate(String searchfromdate) {
		this.searchfromdate = searchfromdate;
	}
	public String getSearchfromdate() {
		return searchfromdate;
	}
	public void setSearchtodate(String searchtodate) {
		this.searchtodate = searchtodate;
	}
	public String getSearchtodate() {
		return searchtodate;
	}
	public void setSortby(String sortby) {
		this.sortby = sortby;
	}
	public String getSortby() {
		return sortby;
	}
	public void setNextfield(int nextfield) {
		this.nextfield = nextfield;
	}
	public int getNextfield() {
		return nextfield;
	}
	public void setPrevfield(int prevfield) {
		this.prevfield = prevfield;
	}
	public int getPrevfield() {
		return prevfield;
	}
	public void setTotalcount(int totalcount) {
		this.totalcount = totalcount;
	}
	public int getTotalcount() {
		return totalcount;
	}
	public void setNextresult(int nextresult) {
		this.nextresult = nextresult;
	}
	public int getNextresult() {
		return nextresult;
	}
	public void setPrevresult(int prevresult) {
		this.prevresult = prevresult;
	}
	public int getPrevresult() {
		return prevresult;
	}

}
