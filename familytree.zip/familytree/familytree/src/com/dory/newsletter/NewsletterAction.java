package com.dory.newsletter;

import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Stack;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.aboutme.AboutDAOImpl;
import com.dory.hibernate.HibernateUtil;

public class NewsletterAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String target = null;
		try {
			if (form != null) {
				String k = request.getParameter("action");
				System.out.println("====action======" + k);
				NewsletterForm newsletterForm = (NewsletterForm) form;
				NewsletterBean newsletterBean = new NewsletterBean();
				HttpSession httpsession = request.getSession();
				newsletterBean.setSubject(newsletterForm.getSubject());
				newsletterBean.setData(newsletterForm.getData());
				newsletterBean.setNewsid(newsletterForm.getNewsid());
				Session session = HibernateUtil.getSessionFactory()
						.openSession();

				System.out.println("session======111111=====>" + session);
				String r = (String) httpsession.getAttribute("mid").toString();
				int q = Integer.parseInt(r);

				Calendar cal = Calendar.getInstance();
				Date dt = cal.getTime();
				newsletterBean.setSentdate(dt);
				newsletterBean.setMemberid(q);
				NewsletterDAOImpl newsletterDAO = new NewsletterDAOImpl();

				int count = newsletterDAO.newscount(session, newsletterBean);
				System.out.println("count==========" + count);
				int totalcount = count / 10;
				System.out.println("totalcount==========" + totalcount);
				int remcount = count % 10;
				System.out.println("remcount==========" + remcount);
				if (remcount > 0) {
					totalcount = totalcount + 1;
				}
				request.setAttribute("totalcount", totalcount);

				if ("displayforward".equals(k)) {
					System.out.println("inside displayforward");
					String actiontype="fullview";
					request.setAttribute("actiontype", actiontype);
					int nxtcount = newsletterForm.getNextfield();
					System.out
							.println("value of nxtcount==========" + nxtcount);
					if (nxtcount == 0) {
						nxtcount = nxtcount + 1;
					}
					nxtcount = nxtcount + 1;
					System.out.println("value of new nxtcountttttttttt======="
							+ nxtcount);
					request.setAttribute("count", nxtcount);

					int fromlimit = ((nxtcount * 10) - 10);
					int tolimit = (fromlimit + 10);
					System.out.println("value of y=======" + fromlimit);
					System.out.println("value of z=======" + tolimit);
					Collection fullnews = newsletterDAO.displaynewslimit(
							session, newsletterBean, fromlimit, tolimit);

					System.out.println("======in collection size======="
							+ fullnews.size());

					request.setAttribute("fullnews", fullnews);
					target = "fullnews";

				}
				if ("displaybackward".equals(k)) {
					System.out.println("inside displaybackward");
					String actiontype="fullview";
					request.setAttribute("actiontype", actiontype);
					int prevcount = newsletterForm.getPrevfield();
					System.out.println("value of prevcount=========="
							+ prevcount);
					prevcount = prevcount - 1;
					System.out.println("value of new prevcountttt======="
							+ prevcount);
					request.setAttribute("count", prevcount);
					int fromlimit = ((prevcount * 10) - 10);
					int tolimit = (fromlimit + 10);
					System.out.println("value of y=======" + fromlimit);
					System.out.println("value of z=======" + tolimit);
					Collection fullnews = newsletterDAO.displaynewslimit(
							session, newsletterBean, fromlimit, tolimit);
					request.setAttribute("fullnews", fullnews);
					target = "fullnews";

				}

				if ("insert".equals(k)) {
					System.out.println("=======inside insert=========");
					newsletterDAO.insert(session, newsletterBean);
					target = "news";
				}
				if ("view".equals(k)) {
					System.out.println("=======inside view=========");
					Collection news = newsletterDAO.displaynews(session,
							newsletterBean);
					request.setAttribute("news", news);
					target = "news";
				}
				int pageno = 1;
				if ("fullview".equals(k)) {
					System.out.println("=======inside fullview=========");
					String actiontype="fullview";
					request.setAttribute("actiontype", actiontype);
					Collection fullnews = newsletterDAO.displayfullnews(
							session, newsletterBean);
					System.out.println("=======fullnews size==========="
							+ fullnews.size());
					request.setAttribute("fullnews", fullnews);
					target = "fullnews";
				}
			
				if ("detailednews".equals(k)) {
					System.out.println("=======inside detailednews=========");
					String nid = request.getParameter("newsid");
					System.out.println("=======newsiddd======" + nid);
					int newsid = Integer.parseInt(nid);
					System.out
							.println("=======integer newsiddd======" + newsid);
					Collection detailednews = newsletterDAO
							.displayDetailednews(session, newsletterBean,
									newsid);
					request.setAttribute("detailednews", detailednews);
					target = "detailednews";
				}
				if ("searchbackward".equals(k)) {
					System.out.println("=======uid in searchbackward==========="
							+ q);
					String actiontype="search";
					request.setAttribute("actiontype", actiontype);
					int prevcount = newsletterForm.getPrevresult();
					System.out.println("value of prevcount=========="
							+ prevcount);
					prevcount = prevcount - 1;
					System.out.println("value of new prevcountttt======="
							+ prevcount);
					request.setAttribute("count", prevcount);
					int fromlimit = ((prevcount * 10) - 10);
					int tolimit = (fromlimit + 10);
					System.out.println("value of fromlimit=======" + fromlimit);
					System.out.println("value of tolimit=======" + tolimit);					
					
					BeanUtils.copyProperties(newsletterBean, newsletterForm);
					String searchcriteria123 = newsletterBean.getSerfrom();
					System.out.println("=======searchcriteria======"
							+ searchcriteria123);
					Collection search = newsletterDAO.searchnews(session,
							newsletterBean,fromlimit,tolimit);
					System.out.println("=======searchcollection======"
							+ search.size());
					int searchcount=search.size();
					request.setAttribute("searchcount",searchcount);
					request.setAttribute("searchnews", search);
					target = "fullnews";
				}
				if ("searchforward".equals(k)) {
					System.out.println("=======uid in searchforward==========="
							+ q);
					String actiontype="search";
					request.setAttribute("actiontype", actiontype);
					int nxtcount = newsletterForm.getNextresult();
					System.out
							.println("value of nxtcount==========" + nxtcount);
					if (nxtcount == 0) {
						nxtcount = nxtcount + 1;
					}
					nxtcount = nxtcount + 1;
					System.out.println("value of new nxtcountttttttttt======="
							+ nxtcount);
					request.setAttribute("count", nxtcount);

					int fromlimit = ((nxtcount * 10) - 10);
					int tolimit = (fromlimit + 10);
					BeanUtils.copyProperties(newsletterBean, newsletterForm);
					String searchcriteria123 = newsletterBean.getSerfrom();
					System.out.println("=======searchcriteria======"
							+ searchcriteria123);
					Collection search = newsletterDAO.searchnews(session,
							newsletterBean,fromlimit,tolimit);
					System.out.println("=======searchcollection======"
							+ search.size());
					int searchcount=search.size();
					request.setAttribute("searchcount",searchcount);
					request.setAttribute("searchnews", search);
					target = "fullnews";
				}
				if ("search".equals(k)) {
					System.out.println("=======uid in search==========="
							+ q);
					String actiontype="search";
					request.setAttribute("actiontype", actiontype);
					int fromlimit =0;
					int tolimit =10;
					BeanUtils.copyProperties(newsletterBean, newsletterForm);
					String searchcriteria123 = newsletterBean.getSerfrom();
					System.out.println("=======searchcriteria======"
							+ searchcriteria123);
					Collection search = newsletterDAO.searchnews(session,
							newsletterBean,fromlimit,tolimit);
					System.out.println("=======searchcollection======"
							+ search.size());
					int searchcount=search.size();
					request.setAttribute("searchcount",searchcount);
					request.setAttribute("searchnews", search);
					target = "fullnews";
				}
			}
		} catch (Exception e) {
			System.out.println("Exception====in====NewsAction===>" + e);
		}

		return (mapping.findForward(target));

	}

}
