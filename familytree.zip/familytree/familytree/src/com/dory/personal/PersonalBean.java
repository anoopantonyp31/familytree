package com.dory.personal;

public class PersonalBean {
	 private int memberid;
	 private String height;
	 private String weight;
	 private int maritalstatus;
	 private String maritalstatus1;
	 private int personalid;
	 private String religion;
	 private String language;
	 private String bloodgroup;
	 private String visibility;
	 private String remark;
	
	public void setReligion(String religion) {
		this.religion = religion;
	}
	public String getReligion() {
		return religion;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getLanguage() {
		return language;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setPersonalid(int personalid) {
		this.personalid = personalid;
	}
	public int getPersonalid() {
		return personalid;
	}
	public void setMemberid(int memberid) {
		this.memberid = memberid;
	}
	public int getMemberid() {
		return memberid;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	public String getVisibility() {
		return visibility;
	}
	public void setMaritalstatus(int maritalstatus) {
		this.maritalstatus = maritalstatus;
	}
	public int getMaritalstatus() {
		return maritalstatus;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getHeight() {
		return height;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getWeight() {
		return weight;
	}
	public void setMaritalstatus1(String maritalstatus1) {
		this.maritalstatus1 = maritalstatus1;
	}
	public String getMaritalstatus1() {
		return maritalstatus1;
	}
	
}
