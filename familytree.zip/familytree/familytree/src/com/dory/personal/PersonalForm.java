package com.dory.personal;
import org.apache.struts.action.ActionForm;
public class PersonalForm extends ActionForm {

	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String height;
	 private String weight;
	 private int personalid;
	 private int maritalstatus;
	 private String religion;
	 private String language;
	 private String bloodgroup;
	 private String remark;
	 
	 private int publicorprivate;
	 private int community;
	 private int groups;
	 private int family;
	 
	
	
	public void setReligion(String religion) {
		this.religion = religion;
	}
	public String getReligion() {
		return religion;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getLanguage() {
		return language;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setPersonalid(int personalid) {
		this.personalid = personalid;
	}
	public int getPersonalid() {
		return personalid;
	}
	public void setPublicorprivate(int publicorprivate) {
		this.publicorprivate = publicorprivate;
	}
	public int getPublicorprivate() {
		return publicorprivate;
	}
	public void setCommunity(int community) {
		this.community = community;
	}
	public int getCommunity() {
		return community;
	}
	public void setGroups(int groups) {
		this.groups = groups;
	}
	public int getGroups() {
		return groups;
	}
	public void setFamily(int family) {
		this.family = family;
	}
	public int getFamily() {
		return family;
	}
	public void setMaritalstatus(int maritalstatus) {
		this.maritalstatus = maritalstatus;
	}
	public int getMaritalstatus() {
		return maritalstatus;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getHeight() {
		return height;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getWeight() {
		return weight;
	}
	
}
