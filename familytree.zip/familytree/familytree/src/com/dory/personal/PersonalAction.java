package com.dory.personal;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.aboutme.AboutDAOImpl;
import com.dory.aboutme.AboutForm;
import com.dory.hibernate.HibernateUtil;

public class PersonalAction extends Action {

	
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException 
			{
		String target = null;
		try {
			if (form != null)
			{
					//String a1= request.getParameter("fromWhere");
					String k = request.getParameter("action");
					//String k1 = request.getParameter("action1");
				// Use the NameForm to get the request parameters
				PersonalForm personalForm = (PersonalForm) form;
				PersonalBean personalBean = new PersonalBean();
				HttpSession httpsession = request.getSession();
				
				

				
				
				

				Session session = HibernateUtil.getSessionFactory()
						.openSession();
				System.out.println("session======111111=====>" + session);
				String r=(String)httpsession.getAttribute("mid").toString();
				 int q=Integer.parseInt(r);
	             System.out.println("rambooo"+q);
	             personalBean.setMemberid(q);
	            
				
				PersonalDAO personalDAO = new PersonalDAOImpl();
				
				if ("update".equals(k)) 
				{
					System.out.println("================in update=======================");
					personalBean = personalDAO.displaypersonaldetails(session,personalBean,q);	
					
					personalBean.setReligion(personalForm.getReligion());
					personalBean.setBloodgroup(personalForm.getBloodgroup());
					personalBean.setHeight(personalForm.getHeight());
					personalBean.setLanguage(personalForm.getLanguage());
					personalBean.setMaritalstatus(personalForm.getMaritalstatus());
					System.out.println("===============from form=hight======================="+personalForm.getHeight());
					System.out.println("===============from form=hight======================="+personalBean.getHeight());
					personalBean.setRemark(personalForm.getRemark());
					personalBean.setBloodgroup(personalForm.getBloodgroup());
					System.out.println("===============from form=weight======================="+personalForm.getWeight());
					personalBean.setWeight(personalForm.getWeight());
					System.out.println("==============after set==weight======================="+personalBean.getWeight());
					
					//*********************visibility part***********************//
					//--------------------------------------
					int privateorprivate1=personalForm.getPublicorprivate();
					
					int family=personalForm.getFamily();
					int groups=personalForm.getGroups();
					int community=personalForm.getCommunity();
					
					
					
					String privateorprivate2 = String.valueOf(privateorprivate1);
							
					
					if("1".equals(privateorprivate2))
					{
						//String visibility=privateorprivate1+"0"+"0"+"0";
						String visibility="8";
						System.out.println("===========in public======="+visibility);
						personalBean.setVisibility(visibility);
					}
					
					if("0".equals(privateorprivate2))
					{
						//String visibility=privateorprivate1+"0"+"0"+"0";
						String visibility="0";
						System.out.println("===========in public======="+visibility);
						personalBean.setVisibility(visibility);
					}
					
					if("500".equals(privateorprivate2))
					{
					String family2 = String.valueOf(family);
					String groups2 = String.valueOf(groups);
					String community2 = String.valueOf(community);
					
					 
						if("0".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
						{
							//String visibility="0"+"0"+"0"+"0";
							String visibility="0";
							System.out.println("===========1111111======="+visibility);
							personalBean.setVisibility(visibility);
						}
						
						else if("0".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
						{
							String visibility="1";
							System.out.println("===========222222======="+visibility);
							personalBean.setVisibility(visibility);
						}
						
						else if("1".equals(community2)&&"0".equals(family2)&&"0".equals(groups2))
						{
							String visibility="2";
							System.out.println("===========3333333======="+visibility);
							personalBean.setVisibility(visibility);
						}
						
						else if("1".equals(community2)&&"1".equals(family2)&&"0".equals(groups2))
						{
							String visibility="3";
							System.out.println("===========44444444======="+visibility);
							personalBean.setVisibility(visibility);
						}
						
						
						else if("0".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
						{
							String visibility="4";
							System.out.println("===========666666666======="+visibility);
							personalBean.setVisibility(visibility);
						}
						
						
						else if("0".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
						{
							String visibility="5";
							System.out.println("===========7777777======="+visibility);
							personalBean.setVisibility(visibility);
						}
						
						
						else if("1".equals(community2)&&"0".equals(family2)&&"1".equals(groups2))
						{
							String visibility="6";
							System.out.println("===========8888888======="+visibility);
							personalBean.setVisibility(visibility);
						}
						
						
						else if("1".equals(community2)&&"1".equals(family2)&&"1".equals(groups2))
						{
							String visibility="7";
							System.out.println("===========99999999======="+visibility);
							personalBean.setVisibility(visibility);
						}
						
						
					}
					
					//*********************visibility part***********************//
					
								
					
					
					
					
				
										System.out.println("inside insert");
						
										personalDAO.update(session,personalBean);
						target="correct";
						
				}						
					
			
				
				else if ("display".equals(k)) 
				{
					System.out.println("================in dispaly=======================");	
					personalBean = personalDAO.displaypersonaldetails(session,personalBean,q);
					
					
					{
						
						request.setAttribute("personal1", personalBean);
						target = "personal";
					} 
						
				}
			
			
			
			
			
			} 
					
								
			
		} 
			catch (Exception e) 
			{
			System.out.println("Exception=====>" + e);
			}

		return (mapping.findForward(target));
	
	
}

}
