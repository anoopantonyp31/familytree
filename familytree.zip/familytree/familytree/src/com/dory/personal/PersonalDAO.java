package com.dory.personal;

import org.hibernate.Session;

public interface PersonalDAO {

	public boolean insert(Session session, PersonalBean personalBean);
	public boolean update(Session session, PersonalBean personalBean);
	public PersonalBean displaypersonaldetails(Session session,
			PersonalBean personalBean,int q);
}
