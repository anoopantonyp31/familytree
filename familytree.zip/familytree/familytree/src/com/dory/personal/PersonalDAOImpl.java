package com.dory.personal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import com.dory.aboutme.AboutBean;
import com.dory.personal.PersonalBean;
import com.dory.personal.PersonalDAO;

public class PersonalDAOImpl implements PersonalDAO {
	
	public boolean insert(Session session, PersonalBean personalBean) {
		session.beginTransaction();
		session.save(personalBean);
		session.getTransaction().commit();
		return true;

	}

	
	
	public boolean update(Session session, PersonalBean personalBean) {
		session.beginTransaction();
		session.update(personalBean);
		session.getTransaction().commit();
		return true;

	}
	
	
	public PersonalBean displaypersonaldetails(Session session,
			PersonalBean personalBean,int q) {

		Collection aboutcol = new ArrayList();
		try {
			List query = session.createQuery("from PersonalBean ex where ex.memberid='"+q+"'")
					.list();
			System.out.println("====queryyyy=====> "+query);
			for (Iterator it = query.iterator(); it.hasNext();) {
				System.out.println("session======displayexecutivepos=====> ");	
				personalBean = (PersonalBean) it.next();
				
			}
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return personalBean;
	}
	
	
	
	
	
}
